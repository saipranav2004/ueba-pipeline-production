import { useEffect, useRef, useState } from 'react'
import { NavLink } from 'react-router-dom'
import clsx from 'clsx'
import {
  LogOut,
  Settings as SettingsIcon,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
} from 'lucide-react'
import { ROLE_BADGE } from '../../config/constants'
import { mfaSummary } from '../../lib/mfaStatus'

// ---------------------------------------------------------------------------
// Identity avatar
// ---------------------------------------------------------------------------
// Initials on a two-stop brand gradient with an inset light edge. The
// gradient is the same navy->cyan pairing the login screen uses, which is
// what ties the signed-in chrome back to the front door.
export function initialsOf(name) {
  if (!name) return '-'
  const parts = String(name)
    .replace(/[._@-]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
  if (parts.length === 0) return '-'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

// Round, not rounded-rect. A circle is what every console uses for a person
// and a squircle for an application or a tenant, so the shape alone says which
// kind of thing this is before the initials are read.
const AVATAR_SIZES = {
  sm: 'h-7 w-7 rounded-full text-2xs',
  md: 'h-9 w-9 rounded-full text-xs',
  lg: 'h-11 w-11 rounded-full text-sm',
  xl: 'h-14 w-14 rounded-full text-base',
}

export function Avatar({ name, size = 'md', className = '' }) {
  return (
    <span
      aria-hidden="true"
      className={clsx(
        'flex flex-none items-center justify-center bg-gradient-to-br from-blue-600 to-sky-500',
        'font-semibold uppercase tracking-wide text-white shadow-sm ring-1 ring-inset ring-white/20',
        AVATAR_SIZES[size] || AVATAR_SIZES.md,
        className
      )}
    >
      {initialsOf(name)}
    </span>
  )
}

// Highest-privilege role wins the trigger badge, root outranks admin
// outranks everything else. Showing three badges in the topbar is noise;
// the full set lives in the dropdown header.
// The role badge is NOT shown on the trigger. A saturated "ROOT" chip in the
// navbar is the loudest thing on a screen whose job is to be calm, and it
// tells the signed-in user something they already know. Okta, CyberArk, the
// AWS console and Google Cloud all do the same: avatar and name in the bar,
// full role detail one click away in the menu. Kept as a helper because the
// dropdown header still orders roles by privilege.
// The word shown on the role line. "Administrator" rather than "admin",
// because the header is addressed to a person, not to the API.
const ROLE_TITLE = {
  root: 'Root',
  admin: 'Administrator',
  user: 'Standard user',
}

function primaryRole(roles) {
  if (!Array.isArray(roles) || roles.length === 0) return null
  if (roles.includes('root')) return 'root'
  if (roles.includes('admin')) return 'admin'
  return roles[0]
}

function MenuItem({ to, onClick, icon: Icon, children, danger = false }) {
  const className = clsx(
    'flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[0.8125rem] font-medium transition-colors duration-150',
    'outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40',
    danger
      ? 'text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30'
      : 'text-ink-200 hover:bg-surface-800 hover:text-ink-50'
  )
  const glyph = <Icon className={clsx('h-4 w-4 flex-none', danger ? '' : 'text-ink-500')} strokeWidth={1.6} />
  if (to) {
    return (
      <NavLink to={to} role="menuitem" onClick={onClick} className={className}>
        {glyph}
        {children}
      </NavLink>
    )
  }
  return (
    <button type="button" role="menuitem" onClick={onClick} className={className}>
      {glyph}
      {children}
    </button>
  )
}

// ---------------------------------------------------------------------------
// Topbar profile control
// ---------------------------------------------------------------------------
// Trigger: avatar + username + role badge. No chevron, the avatar itself is
// the affordance every enterprise console uses, and a caret next to a photo
// reads as a form control rather than an identity.
export function UserMenu({ user, roles = [], onLogout, loading = false, mfa }) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef(null)
  const triggerRef = useRef(null)

  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setOpen(false)
        triggerRef.current?.focus()
      }
    }
    const onPointerDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    document.addEventListener('pointerdown', onPointerDown)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.removeEventListener('pointerdown', onPointerDown)
    }
  }, [open])

  const name = user?.username || (loading ? '…' : 'Signed in')
  // Security posture, stated the way mfaStatus computed it, enrolment and
  // session verification are different facts and this line never conflates
  // them (a session can be marked verified on an account with no MFA).
  const posture = mfaSummary(mfa)

  return (
    <div ref={wrapRef} className="relative flex-none">
      {/* JUST THE AVATAR.
          The bar used to carry the avatar AND the username AND a bordered
          well around both, which is three ways of saying one thing in the
          most crowded strip of the page. Who you are signed in as is not
          something you need restated at all times; it is something you need
          to be able to CHECK, which is one click away and now has room to
          answer properly. The accessible name still carries the username, so
          nothing is lost to a screen reader. */}
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Account menu for ${name}`}
        title={name}
        className={clsx(
          'flex h-10 w-10 items-center justify-center rounded-full transition-colors duration-150',
          'outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40',
          open ? 'ring-2 ring-blue-500/40' : 'hover:opacity-90'
        )}
      >
        <Avatar name={user?.username} />
      </button>

      {open && (
        <div
          role="menu"
          aria-label="Account"
          className="animate-menu-in absolute right-0 z-50 mt-2 w-[17.5rem] overflow-hidden rounded-2xl border border-surface-700 bg-surface-900 shadow-overlay"
        >
          <div className="border-b border-surface-800 px-4 pb-3 pt-4">
            <div className="flex items-center gap-3">
              <Avatar name={user?.username} size="lg" />
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink-50">
                  {user?.full_name || user?.username || '-'}
                </p>
                <p className="mt-0.5 truncate text-xs text-ink-500">{user?.email || '-'}</p>
              </div>
            </div>

            {/* ONE line for privilege, not a row of chips.
                Listing every role held turned the header into a chip cloud on
                any account with more than two, and the reader's question is
                not "which roles" but "what am I signed in AS". The highest
                privilege answers that; the full list is on the account record
                for anyone who needs it. */}
            {primaryRole(roles) && (
              <div
                className={clsx(
                  'mt-3 flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold ring-1 ring-inset',
                  ROLE_BADGE[primaryRole(roles)] || ROLE_BADGE.user
                )}
              >
                <ShieldCheck className="h-3.5 w-3.5 flex-none" strokeWidth={2} />
                <span className="capitalize">{ROLE_TITLE[primaryRole(roles)] || primaryRole(roles)}</span>
                {roles.length > 1 && (
                  <span className="font-normal opacity-70">+{roles.length - 1} more</span>
                )}
              </div>
            )}
          </div>

          {/* Session posture, not decoration: whether this session cleared
              MFA decides whether vault reveals will succeed, so it belongs
 where the user checks who they're signed in as. */}
          <div className="flex items-center gap-2 border-b border-surface-800 px-4 py-2.5">
            {posture.tone === 'emerald' ? (
              <ShieldCheck
                className="h-3.5 w-3.5 flex-none text-emerald-600 dark:text-emerald-400"
                strokeWidth={1.75}
              />
            ) : posture.tone === 'amber' ? (
              <ShieldAlert
                className="h-3.5 w-3.5 flex-none text-amber-600 dark:text-amber-400"
                strokeWidth={1.75}
              />
            ) : (
              <HelpCircle className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
            )}
            <span className="text-xs text-ink-400">{posture.label}</span>
            {mfa?.loaded && !mfa.enabled && (
              <NavLink
                to="/settings?tab=security"
                onClick={() => setOpen(false)}
                className="ml-auto text-xs font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400"
              >
                Set up
              </NavLink>
            )}
          </div>

          <div className="p-1.5">
            {/* <MenuItem to="/settings?tab=account" icon={UserRound} onClick={() => setOpen(false)}>
              Profile
            </MenuItem> */}
            <MenuItem to="/settings" icon={SettingsIcon} onClick={() => setOpen(false)}>
              Settings
            </MenuItem>
          </div>
          <div className="border-t border-surface-800 p-1.5">
            <button
              type="button"
              role="menuitem"
              onClick={() => {
                setOpen(false)
                onLogout?.()
              }}
              className={clsx(
                'flex w-full items-center justify-center gap-2 rounded-lg px-3 py-2.5',
                'text-sm font-semibold text-red-600 transition-colors dark:text-red-400',
                'hover:bg-red-50 dark:hover:bg-red-500/10',
                'outline-none focus-visible:ring-2 focus-visible:ring-red-500/40'
              )}
            >
              <LogOut className="h-4 w-4 flex-none" strokeWidth={2} />
              Sign out
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
