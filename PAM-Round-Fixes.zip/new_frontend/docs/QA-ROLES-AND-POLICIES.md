# QA test roles and policies

Build these in the console, assign them to test accounts, and each one should
produce a **visibly different** result. Every action name, pattern form and
precedence rule below is taken from the running authorisation engine
(`opa/engine.go`, `opa/policies/default_bundle.json`), not invented for this
document.

---

## 0. The five rules everything here depends on

Read these once. Every expected result later follows from them.

1. **Default deny.** No matching allow means no access. A brand new role with
   nothing attached can do nothing.
2. **Explicit deny always wins.** One matching deny beats any number of
   matching allows, and evaluation stops there. Order of attachment is
   irrelevant.
3. **Root bypasses evaluation entirely.** The engine short circuits for the
   `root` role before it reads a single policy. Do not use a root account to
   test a policy: it will pass everything and prove nothing.
4. **Patterns.** `*` matches anything. A trailing `*` is a prefix match
   (`pam:vault:*`, `pam:resource/prod-*`). Anything else is an exact match.
5. **An empty resource list matches nothing.** This is deliberate, and it is
   how the seeded `resource-access-default-deny` policy keeps standard users
   away from resources until an admin grants one explicitly.

### Action vocabulary

Format is `pam:<module>:<Action>`.

| Module | Actions |
|---|---|
| `vault` | `List` `Read` `Create` `Store` `Reveal` `Rotate` |
| `resource` | `List` `Read` `Connect` |
| `session` | `List` `Start` `Connect` `End` `Kill` |
| `jit` | `Request` `Cancel` |
| `audit` | `Read` `Verify` |
| `report` | `Generate` |
| `breakglass` | `Use` |

### Resource pattern vocabulary

| Form | Meaning |
|---|---|
| `*` | every resource and every secret |
| `pam:resource/<resource-id>` | one PAM resource |
| `pam:resource/*` | every PAM resource |
| `pam:vault/<credential-id>` | one vault credential |
| `pam:vault/*` | every vault credential |
| `pam:audit` | the audit trail |

---

## 1. What ships already

Know the baseline before adding anything, or you will attribute a seeded
behaviour to your new policy.

| Role | Policy | Effect |
|---|---|---|
| `admin` | `full-access` | `*` on `*` |
| `user` | `standard-user-access` | vault + JIT + audit read, on `*` |
| `user` | `resource-access-default-deny` | resource actions on **no** resources |

So a standard user starts able to use the vault and request JIT, and unable to
reach any resource until you grant one.

---

## 2. Test accounts

Create four standard accounts. Give none of them `admin` or `root`.

| Account | Purpose |
|---|---|
| `qa.readonly` | can look, cannot touch |
| `qa.operator` | can connect to non-production |
| `qa.vault` | can reveal one specific secret and no other |
| `qa.denied` | holds a broad allow and a narrow deny, to prove deny wins |

---

## 3. The roles to build

Create each role, create its policies, attach the policies to the role, then
assign the role to the account. **Sign the test account out and back in for the
first check**, then use the later checks to confirm changes land without a
re-login.

---

### Role A — `qa-readonly`

Assign to: `qa.readonly`

| Policy | Effect | Actions | Resources |
|---|---|---|---|
| `qa-read-resources` | allow | `pam:resource:List`, `pam:resource:Read` | `pam:resource/*` |
| `qa-read-audit` | allow | `pam:audit:Read` | `pam:audit` |

**Expected**

- Resources page lists every resource.
- Opening a resource shows its detail.
- **Connect fails.** `pam:resource:Connect` was never granted, so this is
  `default_deny_no_matching_policy`, not an explicit deny.
- Vault still works, from the seeded `standard-user-access`. That is expected;
  it is not your policy leaking.

---

### Role B — `qa-operator-nonprod`

Assign to: `qa.operator`

Pick two real resources first and note their ids. One should be named with a
`prod` prefix, one without.

| Policy | Effect | Actions | Resources |
|---|---|---|---|
| `qa-connect-nonprod` | allow | `pam:resource:Connect`, `pam:session:Start`, `pam:session:End` | `pam:resource/<nonprod-id>` |

**Expected**

- Connect succeeds on the non-production resource, and a session appears in
  Sessions and in the audit trail.
- Connect on the production resource fails with default deny.
- This is the clearest demonstration that a **resource-scoped** allow is
  narrower than an action-scoped one.

---

### Role C — `qa-vault-single-secret`

Assign to: `qa.vault`

Note one credential id from the vault first.

| Policy | Effect | Actions | Resources |
|---|---|---|---|
| `qa-reveal-one` | allow | `pam:vault:Reveal` | `pam:vault/<credential-id>` |
| `qa-deny-other-reveals` | **deny** | `pam:vault:Reveal` | `pam:vault/*` |

**Expected, and this is the important one**

- **Every reveal fails, including the one you allowed.** The deny matches
  `pam:vault/*`, which covers the single credential too, and deny wins
  outright.
- The reason reported is `explicit_deny`, not default deny. If the console
  shows the same message for both, that is a UI finding worth raising.

To make the intended behaviour work, narrow the deny so it does not cover the
allowed credential, or drop the deny and rely on the seeded policy. Test both
ways: the failure case above is what proves precedence, the success case proves
the allow.

---

### Role D — `qa-deny-beats-allow`

Assign to: `qa.denied`

| Policy | Effect | Actions | Resources |
|---|---|---|---|
| `qa-allow-everything-resources` | allow | `pam:resource:*` | `pam:resource/*` |
| `qa-deny-prod-connect` | **deny** | `pam:resource:Connect` | `pam:resource/<prod-id>` |

**Expected**

- Can list, read and connect to every resource **except** the one named in the
  deny.
- On that one, connect fails with `explicit_deny` while list and read still
  work, because the deny names only the `Connect` action.
- This is the cleanest allow/deny pair in the set. Use it as the smoke test.

---

## 4. Live-change checks (no sign-out)

These verify that a change reaches a session that is already open. Keep the
test account signed in and watching the screen throughout.

| # | Do this | Expect, without signing out |
|---|---|---|
| 1 | As root, delegate admin to `qa.readonly` | Admin Center appears in their sidebar within about a minute, or immediately if they switch away and back to the tab. A toast says administrative access was granted. |
| 2 | As root, revoke that delegation | Admin Center disappears the same way, with a toast. Any Admin Center page they are sitting on starts refusing. |
| 3 | Attach an MFA policy to a role `qa.operator` holds | Their next request is redirected to MFA enrolment. They must not be able to keep working until enrolled. |
| 4 | Detach `qa-deny-prod-connect` from Role D | Connect to the production resource starts succeeding. |
| 5 | Assign Role B to an account that is signed in | The newly allowed resource becomes connectable. |

If any of 1 to 5 only takes effect after a sign-out, that is a bug: report it
with the account, the time, and what you changed.

---

## 5. Criticality checks

The Roles page scores each role. Use these to sanity check it.

| Role | Expected band | Why |
|---|---|---|
| `root` | **Critical, 100** | Scored structurally from the engine bypass, not from its policies. It stays Critical even with zero policies attached, and its band cannot be overridden. |
| `admin` | Critical | Holds `full-access` (`*` on `*`). |
| `qa-readonly` | Low | Read and list only, no standing path to a secret. |
| `qa-vault-single-secret` | High or Critical | `pam:vault:Reveal` is the highest-weighted action in the model. |
| `qa-deny-beats-allow` | Moderate or higher, reduced by its deny | Deny policies are counted as a compensating control. |

---

## 6. Reporting a failure

Include all of these or the result cannot be reproduced:

- account username and the roles it held at the time
- the policy name, its effect, its exact action list and its exact resource
  patterns
- what you did, what you expected, what happened
- whether the account had signed in **before or after** the change
- the decision reason shown, if any: `explicit_deny` and
  `default_deny_no_matching_policy` are different findings
