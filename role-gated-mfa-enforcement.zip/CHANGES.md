# Role-Gated MFA Enforcement

## The answer to the question: no, this cannot be done from the frontend

The decision has to be made **where the token is minted**. `AuthService.Login`
is the only point that knows the password was correct and has not yet issued a
session. By the time any console code runs, a valid JWT already exists — and a
session the console refuses to use is still a session `curl` will happily use.

Two findings from reading your backend made that concrete, and both had to be
fixed before "group-gated MFA" could mean anything at all:

**1. MFA is opt-in, per user, with no policy anywhere.** `Login` challenges only
if the account happens to own an `ACTIVE` row in `pam_mfa_devices`
(`auth_service.go:127`). Nothing consults roles. There was no table, no rule, no
evaluation — so there was nothing for a UI to manage.

**2. `RequireMFA()` was a no-op for every user in the system.** This is the
serious one. `auth_service.go` called
`issueTokensForUser(user, true, clientIP)` on the **no-MFA** path — passing a
literal `true` for `mfaVerified`. Every account without a second factor received
a token asserting it had presented one. `middleware.RequireMFA()` reads exactly
that claim, and it guards **vault reveal, JIT approval and agent pairing**
(`main.go:435, 493, 541, 563, 579, 692`). The gate passed for precisely the
users it exists to stop. It is also why bug-sheet #22 reported "root has no MFA
but Settings says MFA: verified this session" — the claim really did say that.

Fixing #2 is a **behaviour change worth planning for**: an account with no
second factor can no longer reveal a credential, approve a JIT request or pair
an agent until it enrols. That is what `RequireMFA` was always meant to do.

---

## What was built

**No new "group" concept.** The rule targets an existing **role**, and holding
that role is the gate — the same shape as an Entra Conditional Access policy
scoped to a group, or an Okta enrollment policy bound to one.

### Backend (8 files — 3 new, 5 edited)

```
internal/services/mfa_policy.go            NEW   rules, decision, compliance
internal/services/mfa_policy_test.go       NEW   13 tests over the decision table
internal/api/handlers/mfa_policy_handler.go NEW  admin CRUD + compliance
internal/services/auth_service.go          EDIT  evaluate at login; the mfa_verified fix
internal/api/handlers/auth_handler.go      EDIT  restricted-session response; /auth/me truth
internal/middleware/auth.go                EDIT  RequireMFAEnrollment(); claim in context
pkg/jwt/issuer.go                          EDIT  mfa_enrollment_required claim
cmd/pam-api/main.go                        EDIT  wiring, routes, gate on 3 route groups
```

**Three modes**, because a rollout with only "off" and "locked out" never gets
switched on:

| Mode | Sign-in | Who uses it |
|---|---|---|
| `off` | unaffected | rule kept for the record |
| `monitor` | allowed, breach logged, user sees a banner | **start here** — shows who enforcement would eject |
| `enforce` | restricted session: enrol or nothing | once monitor is clean |

**The restricted session** is the part that is easy to get wrong. Refusing the
login outright is unimplementable: enrolling *requires* an authenticated call
(`POST /auth/mfa/setup/initiate`), so a hard refusal leaves a user who must
enrol with no way to enrol. Entra solves this with a registration interrupt,
Okta with an enrollment redirect. Here the server issues a token carrying
`mfa_enrollment_required=true`, and `RequireMFAEnrollment()` refuses every route
except `/auth/me`, `/auth/logout` and the two setup endpoints. **The allowlist
lives inside the middleware**, so applying it to a group cannot accidentally
lock users out of the enrolment flow, and a route added tomorrow is closed by
default.

**Grace period** (hours, per rule) counted from the later of account creation
and the rule's last change — so switching a rule to `enforce` gives people the
configured window instead of ejecting them mid-shift.

**Decisions worth knowing:**
- A user in two gated roles is held to the **stricter** mode, and the **most
  generous** grace. (Mode decides whether the gate exists; grace decides when it
  closes.)
- Rules load fails **open**, loudly logged — the alternative is nobody can sign
  in, including whoever would fix it.
- An unresolvable grace window fails **closed** — a misconfiguration must not
  silently become an exemption.
- Writes are **root only** (service-layer check, same as admin delegation): an
  admin who can switch off the rule gating admins was never gated.

**Endpoints** (all under the existing `RequireAdmin` group):
```
GET    /api/v1/pam/admin/mfa-policy                  rules + summary
GET    /api/v1/pam/admin/mfa-policy/compliance       per-account breakdown
PUT    /api/v1/pam/admin/mfa-policy/rules/:role_name upsert   (root)
DELETE /api/v1/pam/admin/mfa-policy/rules/:role_name remove   (root)
```

**`/auth/me` now tells the truth.** It gained `mfa_enabled` (the account fact,
read from the same ACTIVE-device definition login uses), plus `mfa_required`,
`mfa_policy_mode`, `mfa_required_by_roles`, `mfa_enrollment_required` and
`mfa_enrollment_deadline`. `SetupMFAVerify` also writes the long-dormant
`users.mfa_enabled` column, and `SetupMFAInitiate` clears it — that call deletes
the ACTIVE device, so the column would otherwise claim protection the user no
longer has.

This retires the frontend's `lib/mfaEvidence.js` localStorage workaround, which
existed only because `/auth/me` could not answer "does this account have MFA".
I left that file in place — it is still the fallback for a console pointed at an
older backend — but `readMfaStatus` already prefers `mfa_enabled`, so it now
wins automatically.

### Frontend (8 files — 4 new, 4 edited)

```
src/lib/mfaPolicy.js                      NEW   posture reader + labels (pure)
src/api/mfaPolicy.js                      NEW   admin API client
src/pages/admin/MfaPolicyPage.jsx         NEW   Admin Center → MFA Policy
src/components/auth/MfaEnforcementGate.jsx NEW  banner + enrolment interrupt
src/config/nav.js                         EDIT  nav entry
src/App.jsx                               EDIT  route
src/components/common/AppLayout.jsx       EDIT  mount the gate
src/pages/auth/LoginPage.jsx              EDIT  store the restricted session
```

**MFA Policy screen**: one row per role with its mode, grace and reason, and a
live compliance table beside it. Before you switch a rule to `enforce` the row
tells you *"3 accounts in this role have no second factor — they will be
restricted at their next sign-in"*. Non-root admins get the whole screen
read-only with the reason shown.

**The gate** renders the server's decision, never its own: a dismissible banner
during monitor/grace, and a full-screen enrolment interrupt when the session is
restricted. After enrolling it says to sign in again — correctly, because the
token in hand was issued before the factor existed and only a fresh sign-in
challenges for a code.

---

## Verification

- `go build ./...` clean, `go vet ./...` clean
- `go test ./...` — all packages pass, including **13 new tests** over the
  decision table (enforce blocks / monitor never blocks / off inert / strictest
  mode wins / case-insensitive role match / grace fails closed / root-only)
- `npm run lint` clean (the 4 pre-existing issues in `nav.js`,
  `useMfaStatus.js`, `validators.js` are untouched), `npm run build` passes
- 30 runtime assertions over the frontend posture reader, including every
  "server said nothing" path — a console pointed at the old backend shows no
  banner and no wall

## Rollout order (please do it in this order)

1. Deploy the backend. Nothing changes yet: no rules exist, so no account is
   gated — **except** that `mfa_verified` now tells the truth, so vault reveal /
   JIT approve / agent pair start requiring a real second factor. Enrol the
   admins first.
2. Open **Admin Center → MFA Policy**, set `admin` and `root` to **monitor**.
3. Read the compliance table. Chase the non-compliant accounts.
4. Switch to **enforce** with a grace period (24–72h is typical) once the
   "would be restricted" count is zero or acceptable.
