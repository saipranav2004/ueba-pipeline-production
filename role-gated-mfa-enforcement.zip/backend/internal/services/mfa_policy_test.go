package services

import (
	"testing"
	"time"

	"go.uber.org/zap"
)

// The decision table is the whole feature, so it is tested directly rather
// than through the login path: Evaluate is pure once the rules are in hand.
//
// These cases use a service with no DB, which is fine for everything except
// the grace-window branch (it reads the user row) — that branch is exercised
// separately below with a nil-DB failure to confirm it fails CLOSED for an
// enforce rule rather than silently letting a non-compliant user through.

// decide() is the pure half of Evaluate — rules in, decision out — so the
// table below needs no database at all.
type policyFixture struct {
	svc   *MFAPolicyService
	rules map[string]MFAPolicyRule
}

func newTestPolicy(rules map[string]MFAPolicyRule) policyFixture {
	return policyFixture{svc: &MFAPolicyService{logger: zap.NewNop()}, rules: rules}
}

func (f policyFixture) Evaluate(userID string, roles []string, enrolled bool, at time.Time) (MFADecision, error) {
	return f.svc.decide(userID, roles, enrolled, at, f.rules), nil
}

func rule(mode string, grace int) MFAPolicyRule {
	return MFAPolicyRule{Mode: mode, GraceHours: grace, UpdatedAt: time.Now().Add(-48 * time.Hour)}
}

func TestEvaluate_NoRules(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{})
	d, err := s.Evaluate("u1", []string{"admin", "user"}, false, time.Now())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if d.Required || d.Block || d.Mode != MFAModeOff {
		t.Fatalf("ungated install must not require or block: %+v", d)
	}
	if !d.Compliant() {
		t.Fatal("an ungated user is compliant by definition")
	}
}

func TestEvaluate_RoleNotHeld(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 0)})
	d, _ := s.Evaluate("u1", []string{"user"}, false, time.Now())
	if d.Required || d.Block {
		t.Fatalf("a rule on a role the user does not hold must not fire: %+v", d)
	}
}

func TestEvaluate_EnforceBlocksNonEnrolled(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 0)})
	d, _ := s.Evaluate("u1", []string{"admin"}, false, time.Now())
	if !d.Required || !d.Block {
		t.Fatalf("enforce + not enrolled must block: %+v", d)
	}
	if d.Compliant() {
		t.Fatal("blocked user is not compliant")
	}
	if len(d.MatchedRoles) != 1 || d.MatchedRoles[0] != "admin" {
		t.Fatalf("the user must be told which role gated them: %+v", d.MatchedRoles)
	}
}

func TestEvaluate_EnforceAllowsEnrolled(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 0)})
	d, _ := s.Evaluate("u1", []string{"admin"}, true, time.Now())
	if !d.Required {
		t.Fatal("still required — the user simply satisfies it")
	}
	if d.Block || !d.Compliant() {
		t.Fatalf("an enrolled user must never be blocked: %+v", d)
	}
}

func TestEvaluate_MonitorNeverBlocks(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeMonitor, 0)})
	d, _ := s.Evaluate("u1", []string{"admin"}, false, time.Now())
	if !d.Required {
		t.Fatal("monitor still means required — that is what makes it reportable")
	}
	if d.Block {
		t.Fatal("monitor must never block; that is the entire point of the mode")
	}
	if d.Mode != MFAModeMonitor {
		t.Fatalf("mode should be monitor, got %q", d.Mode)
	}
}

func TestEvaluate_OffModeIsInert(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeOff, 0)})
	d, _ := s.Evaluate("u1", []string{"admin"}, false, time.Now())
	if d.Required || d.Block {
		t.Fatalf("an off rule must do nothing: %+v", d)
	}
}

// A user in two gated roles is held to the STRICTER of the two. Getting this
// backwards would let a second, laxer role silently downgrade enforcement.
func TestEvaluate_StrictestModeWins(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{
		"admin":   rule(MFAModeEnforce, 0),
		"auditor": rule(MFAModeMonitor, 0),
	})
	d, _ := s.Evaluate("u1", []string{"auditor", "admin"}, false, time.Now())
	if d.Mode != MFAModeEnforce || !d.Block {
		t.Fatalf("enforce must win over monitor: %+v", d)
	}
	if len(d.MatchedRoles) != 2 {
		t.Fatalf("both gating roles should be reported: %+v", d.MatchedRoles)
	}
}

func TestEvaluate_RoleMatchIsCaseInsensitive(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 0)})
	d, _ := s.Evaluate("u1", []string{"Admin"}, false, time.Now())
	if !d.Block {
		t.Fatal("role matching must not depend on casing")
	}
}

func TestEvaluate_NoRolesAtAll(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 0)})
	d, _ := s.Evaluate("u1", nil, false, time.Now())
	if d.Required || d.Block {
		t.Fatalf("a user with no roles cannot be gated by a role rule: %+v", d)
	}
}

// Grace with no reachable user row: the deadline cannot be computed, and the
// rule explicitly says enforce. Failing OPEN here would mean a
// misconfiguration silently disables the control, so it fails closed.
func TestEvaluate_GraceFailsClosedWithoutUserRow(t *testing.T) {
	s := newTestPolicy(map[string]MFAPolicyRule{"admin": rule(MFAModeEnforce, 24)})
	d, _ := s.Evaluate("missing-user", []string{"admin"}, false, time.Now())
	if !d.Block {
		t.Fatal("an unresolvable grace window must not become an exemption")
	}
	if d.GraceUntil != nil {
		t.Fatal("no deadline should be reported when it could not be computed")
	}
}

func TestModeRanking(t *testing.T) {
	if rankMFAMode(MFAModeEnforce) <= rankMFAMode(MFAModeMonitor) {
		t.Fatal("enforce must outrank monitor")
	}
	if rankMFAMode(MFAModeMonitor) <= rankMFAMode(MFAModeOff) {
		t.Fatal("monitor must outrank off")
	}
	if rankMFAMode("nonsense") != 0 {
		t.Fatal("an unknown mode must rank as off, never above it")
	}
}

func TestValidMFAMode(t *testing.T) {
	for _, m := range MFAModes() {
		if !validMFAMode(m) {
			t.Fatalf("advertised mode %q must validate", m)
		}
	}
	for _, m := range []string{"", "ENFORCE", "on", "required"} {
		if validMFAMode(m) {
			t.Fatalf("mode %q must be rejected", m)
		}
	}
}

func TestHasRoleNamed(t *testing.T) {
	if !hasRoleNamed([]string{"user", "ROOT"}, RoleRoot) {
		t.Fatal("root check must be case-insensitive")
	}
	if hasRoleNamed([]string{"admin"}, RoleRoot) {
		t.Fatal("admin is not root — this is the whole write gate")
	}
	if hasRoleNamed(nil, RoleRoot) {
		t.Fatal("no roles is not root")
	}
}
