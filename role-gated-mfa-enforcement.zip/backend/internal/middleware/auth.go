// pam/internal/middleware/auth.go
package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	"go.uber.org/zap"
)

// PAMAuth verifies a PAM-issued HS256 JWT (not IAM's RS256 token).
// PAM owns its own authentication entirely.
func PAMAuth(issuer *pamjwt.Issuer, log *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if !strings.HasPrefix(authHeader, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Missing or malformed Authorization header. Expected: Bearer <token>",
			})
			return
		}
		tokenString := strings.TrimPrefix(authHeader, "Bearer ")

		claims, sessionID, err := issuer.Verify(tokenString)
		if err != nil {
			log.Debug("pam.jwt.verify.fail", zap.Error(err))
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Invalid or expired PAM token",
			})
			return
		}

		c.Set("user_id", claims.Subject)
		c.Set("username", claims.Username)
		c.Set("email", claims.Email)
		c.Set("account_id", claims.AccountID)
		c.Set("mfa_verified", claims.MFAVerified)
		c.Set("mfa_enrollment_required", claims.MFAEnrollmentRequired)
		c.Set("roles", claims.Roles)
		c.Set("session_id", sessionID)
		c.Set("jti", claims.ID)
		c.Next()
	}
}

// RequireMFA blocks requests if the PAM JWT doesn't have mfa_verified=true.
//
// Worth knowing what this now actually does: until recently every session was
// issued with mfa_verified=true, including sessions for accounts with no
// second factor at all (auth_service.go passed a literal `true` on the no-MFA
// path). This gate therefore passed for everyone and stopped nobody. The claim
// now reports the truth, which means these routes — vault reveal, JIT
// approval, agent pairing — really are second-factor-only from here on.
func RequireMFA() gin.HandlerFunc {
	return func(c *gin.Context) {
		mfa, exists := c.Get("mfa_verified")
		if !exists || !mfa.(bool) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "MFA verification required for this action",
				"code":    "mfa_required",
			})
			return
		}
		c.Next()
	}
}

// ---------------------------------------------------------------------------
// Role-gated MFA enforcement — the restricted session
// ---------------------------------------------------------------------------
//
// A user whose role requires a second factor, who has not enrolled one, is
// issued a token carrying mfa_enrollment_required=true (see
// services/mfa_policy.go for why they get a token at all rather than a
// refusal). This middleware is what makes that token restricted: it refuses
// every route except the handful needed to complete enrolment.
//
// The allowlist lives INSIDE the middleware rather than at the call sites, so
// applying it to a route group can never accidentally lock the user out of the
// enrolment flow itself, and a route added tomorrow is closed by default.
var mfaEnrollmentAllowedPaths = map[string]bool{
	"/api/v1/auth/me":                 true,
	"/api/v1/auth/logout":             true,
	"/api/v1/auth/mfa/setup/initiate": true,
	"/api/v1/auth/mfa/setup/verify":   true,
	"/api/v1/auth/api/health":         true,
}

// RequireMFAEnrollment aborts with 403 + code "mfa_enrollment_required" when
// the caller holds a restricted enrolment session. The console reads that code
// and shows the enrolment interrupt instead of a generic permission error.
func RequireMFAEnrollment() gin.HandlerFunc {
	return func(c *gin.Context) {
		pending, exists := c.Get("mfa_enrollment_required")
		if !exists {
			c.Next()
			return
		}
		required, _ := pending.(bool)
		if !required || mfaEnrollmentAllowedPaths[c.FullPath()] || mfaEnrollmentAllowedPaths[c.Request.URL.Path] {
			c.Next()
			return
		}
		c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
			"success": false,
			"error":   "Set up multi-factor authentication to continue. Your role requires a second factor.",
			"code":    "mfa_enrollment_required",
		})
	}
}
