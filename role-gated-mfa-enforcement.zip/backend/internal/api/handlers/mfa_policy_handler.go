// pam/internal/api/handlers/mfa_policy_handler.go
//
// Role-gated MFA enforcement — Admin Center API.
//
// Reads are admin-or-root: an administrator has to be able to see which roles
// are gated and who is out of compliance, or the policy is invisible to the
// people operating it.
//
// Writes are ROOT ONLY, enforced in the service (MFAPolicyService.UpsertRule /
// DeleteRule return ErrMFAPolicyForbidden). The reasoning is the same one
// behind admin delegation: an admin who could edit the rule that forces admins
// to hold a second factor could simply switch it off, which is indistinguish-
// able from not having the control at all.
//
// Wire in main.go inside the existing admin group (RequireAdmin already
// applied):
//
//	mfaPolicy := admin.Group("/mfa-policy")
//	mfaPolicy.GET   ("",                  mfaPolicyHandler.GetPolicy)
//	mfaPolicy.PUT   ("/rules/:role_name", mfaPolicyHandler.UpsertRule)
//	mfaPolicy.DELETE("/rules/:role_name", mfaPolicyHandler.DeleteRule)
//	mfaPolicy.GET   ("/compliance",       mfaPolicyHandler.Compliance)
package handlers

import (
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type MFAPolicyHandler struct {
	policy *services.MFAPolicyService
	logger *zap.Logger
}

func NewMFAPolicyHandler(policy *services.MFAPolicyService, logger *zap.Logger) *MFAPolicyHandler {
	return &MFAPolicyHandler{policy: policy, logger: logger}
}

// rolesOf reads the caller's roles off the verified JWT (set by PAMAuth).
func rolesOf(c *gin.Context) []string {
	raw, ok := c.Get("roles")
	if !ok {
		return nil
	}
	roles, _ := raw.([]string)
	return roles
}

func actorOf(c *gin.Context) string {
	userID, _ := middleware.AdminIdentityFromContext(c)
	return userID
}

// ---------------------------------------------------------------------------
// GET /api/v1/pam/admin/mfa-policy
// ---------------------------------------------------------------------------

// GetPolicy returns every rule plus the headline compliance counters, so the
// console can render the screen from one round trip.
func (h *MFAPolicyHandler) GetPolicy(c *gin.Context) {
	rules, err := h.policy.ListRules()
	if err != nil {
		h.logger.Error("mfa_policy.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load MFA policy")
		return
	}

	summary, err := h.policy.Compliance()
	if err != nil {
		// The rules are the important half. A compliance query that fails
		// should not blank the policy screen — return what we have.
		h.logger.Error("mfa_policy.compliance.fail", zap.Error(err))
		response.Success(c, gin.H{"rules": rules, "modes": services.MFAModes()}, "MFA policy fetched")
		return
	}

	response.Success(c, gin.H{
		"rules": rules,
		"modes": services.MFAModes(),
		"summary": gin.H{
			"total_users":   summary.TotalUsers,
			"gated":         summary.Gated,
			"enrolled":      summary.Enrolled,
			"non_compliant": summary.NonCompliant,
			"would_block":   summary.WouldBlock,
		},
	}, "MFA policy fetched")
}

// ---------------------------------------------------------------------------
// PUT /api/v1/pam/admin/mfa-policy/rules/:role_name
// ---------------------------------------------------------------------------

type upsertMFARuleRequest struct {
	// Mode: off | monitor | enforce.
	Mode string `json:"mode" binding:"required"`
	// GraceHours delays enforcement for accounts that fall under the rule,
	// counted from the later of account creation and the rule's last change.
	GraceHours int `json:"grace_hours"`
	// Reason is free text recorded with the rule — why this role is gated.
	Reason string `json:"reason"`
}

func (h *MFAPolicyHandler) UpsertRule(c *gin.Context) {
	var req upsertMFARuleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}

	rule, err := h.policy.UpsertRule(services.UpsertRuleInput{
		RoleName:   c.Param("role_name"),
		Mode:       req.Mode,
		GraceHours: req.GraceHours,
		Reason:     req.Reason,
		ActorID:    actorOf(c),
		ActorRoles: rolesOf(c),
	})
	if err != nil {
		switch {
		case errors.Is(err, services.ErrMFAPolicyForbidden):
			response.Error(c, http.StatusForbidden, "Only root users can change MFA policy")
		case errors.Is(err, services.ErrMFAPolicyRole):
			response.Error(c, http.StatusNotFound, "No such role in this install")
		case errors.Is(err, services.ErrMFAPolicyMode):
			response.Error(c, http.StatusBadRequest, "mode must be one of: off, monitor, enforce")
		default:
			h.logger.Error("mfa_policy.upsert.fail", zap.Error(err))
			response.Error(c, http.StatusInternalServerError, "Failed to save the rule")
		}
		return
	}

	response.Success(c, gin.H{"rule": rule}, "MFA policy rule saved")
}

// ---------------------------------------------------------------------------
// DELETE /api/v1/pam/admin/mfa-policy/rules/:role_name
// ---------------------------------------------------------------------------

func (h *MFAPolicyHandler) DeleteRule(c *gin.Context) {
	err := h.policy.DeleteRule(c.Param("role_name"), rolesOf(c), actorOf(c))
	if err != nil {
		if errors.Is(err, services.ErrMFAPolicyForbidden) {
			response.Error(c, http.StatusForbidden, "Only root users can change MFA policy")
			return
		}
		h.logger.Error("mfa_policy.delete.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to remove the rule")
		return
	}
	response.Success(c, nil, "MFA policy rule removed")
}

// ---------------------------------------------------------------------------
// GET /api/v1/pam/admin/mfa-policy/compliance
// ---------------------------------------------------------------------------

// Compliance answers the question that has to be answered BEFORE a rule is
// switched to enforce: who is currently out of compliance, and who would be
// locked out at the next sign-in.
func (h *MFAPolicyHandler) Compliance(c *gin.Context) {
	summary, err := h.policy.Compliance()
	if err != nil {
		h.logger.Error("mfa_policy.compliance.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to evaluate compliance")
		return
	}
	response.Success(c, summary, "MFA compliance evaluated")
}
