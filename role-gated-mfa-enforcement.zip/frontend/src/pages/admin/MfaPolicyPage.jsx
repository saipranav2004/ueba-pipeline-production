import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  ShieldCheck, ShieldAlert, ShieldOff, Users, Lock, AlertTriangle, Info,
  CheckCircle2, Clock, RefreshCw, Trash2, Save,
} from 'lucide-react'
import { toast } from 'sonner'
import clsx from 'clsx'
import { getMfaPolicy, getMfaCompliance, upsertMfaRule, deleteMfaRule } from '../../api/mfaPolicy'
import { listRoles } from '../../api/rbac'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, EmptyState, Section } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge, StatusIndicator, MetaTag } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { SearchField } from '../../components/common/TableControls'
import { selectClass, inputClass } from '../../components/common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { roleBadgeClass, normalizeRoleList, isSystemRoleName } from '../../config/constants'
import { MFA_MODE_BLURBS, mfaModeLabel, mfaModeBadgeClass } from '../../lib/mfaPolicy'

// ---------------------------------------------------------------------------
// Admin Center — MFA Policy
// ---------------------------------------------------------------------------
// "Accounts holding this role must have a second factor."
//
// The same control Entra ID expresses as a Conditional Access policy scoped to
// a group and Okta as an enrollment policy bound to a group — expressed here
// against ROLES, because PAM already has roles and a second grouping concept
// would just be two things to keep in sync.
//
// The screen is built around the question an operator actually has to answer
// before switching anything on: WHO WOULD THIS LOCK OUT? That is why the
// compliance table sits next to the rules rather than on another page, and why
// monitor mode is presented as the normal first step rather than a lesser one.
//
// Everything here is a view over the server's decision. The console does not
// evaluate policy — see lib/mfaPolicy.js for why that would be theatre.

const MODE_ICON = { off: ShieldOff, monitor: ShieldAlert, enforce: ShieldCheck }

function StatTile({ icon: Icon, label, value, hint, tone = 'default' }) {
  return (
    <div
      className={clsx(
        'rounded-xl border px-4 py-3.5',
        tone === 'danger'
          ? 'border-red-300/70 bg-red-50/70 dark:border-red-900/50 dark:bg-red-950/20'
          : tone === 'warn'
            ? 'border-amber-300/70 bg-amber-50/70 dark:border-amber-900/50 dark:bg-amber-950/20'
            : 'border-surface-700/70 bg-surface-900'
      )}
    >
      <div className="flex items-center gap-2">
        <Icon
          className={clsx(
            'h-3.5 w-3.5 flex-none',
            tone === 'danger'
              ? 'text-red-600 dark:text-red-400'
              : tone === 'warn'
                ? 'text-amber-600 dark:text-amber-400'
                : 'text-ink-500'
          )}
          strokeWidth={1.9}
        />
        <span className="text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">{label}</span>
      </div>
      <p className="mt-2 text-xl font-semibold leading-none tabular-nums text-ink-50">{value}</p>
      {hint && <p className="mt-1.5 text-xs leading-relaxed text-ink-500">{hint}</p>}
    </div>
  )
}

// One row per role in the install: its current rule (or none), the controls to
// change it, and how many of its members are already compliant.
function RoleRuleRow({ role, rule, stats, canEdit, onSave, onRemove, saving, removing }) {
  const current = rule?.mode || 'off'
  const [mode, setMode] = useState(current)
  const [grace, setGrace] = useState(String(rule?.grace_hours ?? 0))
  const [reason, setReason] = useState(rule?.reason || '')
  const [open, setOpen] = useState(false)

  // The row is the source of truth while it is closed; opening it starts from
  // whatever the server currently holds, so a failed save never leaves the
  // form showing something that was never stored.
  const reset = () => {
    setMode(current)
    setGrace(String(rule?.grace_hours ?? 0))
    setReason(rule?.reason || '')
  }

  const dirty = mode !== current || Number(grace) !== (rule?.grace_hours ?? 0) || reason !== (rule?.reason || '')
  const ModeIcon = MODE_ICON[current] || ShieldOff
  const gated = current !== 'off'

  return (
    <li className="px-4 py-3.5 transition-colors hover:bg-surface-850/40">
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3">
        <div className="flex min-w-0 items-center gap-3">
          <span
            className={clsx(
              'flex h-8 w-8 flex-none items-center justify-center rounded-lg border',
              gated
                ? 'border-blue-500/30 bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-300'
                : 'border-surface-700 bg-surface-850 text-ink-500'
            )}
          >
            <ModeIcon className="h-4 w-4" strokeWidth={1.8} />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className={roleBadgeClass(role.name)}>{role.name}</Badge>
              <MetaTag>{isSystemRoleName(role.name) ? 'System' : 'Custom'}</MetaTag>
              <Badge className={mfaModeBadgeClass(current)}>{mfaModeLabel(current)}</Badge>
              {gated && rule?.grace_hours > 0 && (
                <span className="inline-flex items-center gap-1 text-2xs text-ink-500">
                  <Clock className="h-3 w-3" strokeWidth={1.9} />
                  {rule.grace_hours}h grace
                </span>
              )}
            </div>
            <p className="mt-1 text-xs leading-relaxed text-ink-500">
              {stats
                ? `${stats.members} member${stats.members === 1 ? '' : 's'} · ${stats.enrolled} with a second factor${
                    gated && stats.nonCompliant > 0 ? ` · ${stats.nonCompliant} not compliant` : ''
                  }`
                : 'No members'}
            </p>
          </div>
        </div>

        <div className="flex flex-none items-center gap-2">
          {gated && stats?.nonCompliant > 0 && current === 'enforce' && (
            <span className="flex items-center gap-1.5 text-2xs font-medium text-red-600 dark:text-red-400">
              <AlertTriangle className="h-3.5 w-3.5" strokeWidth={2} />
              {stats.nonCompliant} locked out at next sign-in
            </span>
          )}
          {canEdit ? (
            <Button
              size="xs"
              variant={open ? 'subtle' : 'secondary'}
              onClick={() => {
                if (!open) reset()
                setOpen((v) => !v)
              }}
            >
              {open ? 'Close' : gated ? 'Edit rule' : 'Add rule'}
            </Button>
          ) : (
            <span
              title="Only root users can change MFA policy"
              className="inline-flex items-center gap-1.5 rounded-md border border-surface-700 bg-surface-850 px-2 py-1 text-2xs font-medium text-ink-500"
            >
              <Lock className="h-3 w-3" strokeWidth={1.9} /> Root only
            </span>
          )}
        </div>
      </div>

      {open && canEdit && (
        <div className="mt-3.5 rounded-xl border border-surface-700 bg-surface-850/60 p-3.5">
          <div className="flex flex-wrap items-end gap-3">
            <label className="min-w-[10rem] flex-1">
              <span className="mb-1.5 block text-xs font-medium text-ink-300">Mode</span>
              <select className={selectClass(false)} value={mode} onChange={(e) => setMode(e.target.value)}>
                <option value="off">Off — rule does nothing</option>
                <option value="monitor">Monitor — allow and record</option>
                <option value="enforce">Enforce — require before access</option>
              </select>
            </label>
            <label className="w-32">
              <span className="mb-1.5 block text-xs font-medium text-ink-300">Grace (hours)</span>
              <input
                type="number"
                min={0}
                max={8760}
                value={grace}
                onChange={(e) => setGrace(e.target.value)}
                className={inputClass(false)}
              />
            </label>
            <label className="min-w-[14rem] flex-[2]">
              <span className="mb-1.5 block text-xs font-medium text-ink-300">Reason (optional)</span>
              <input
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Why this role is gated"
                className={inputClass(false)}
              />
            </label>
          </div>

          <p className="mt-2.5 flex items-start gap-2 text-2xs leading-relaxed text-ink-500">
            <Info className="mt-px h-3 w-3 flex-none" strokeWidth={1.9} />
            <span>{MFA_MODE_BLURBS[mode]}</span>
          </p>

          {mode === 'enforce' && stats?.nonCompliant > 0 && (
            <div className="mt-2.5 flex items-start gap-2.5 rounded-lg border border-amber-300/70 bg-amber-50 px-3 py-2.5 dark:border-amber-900/40 dark:bg-amber-950/25">
              <AlertTriangle className="mt-px h-3.5 w-3.5 flex-none text-amber-600 dark:text-amber-400" strokeWidth={1.9} />
              <p className="text-xs leading-relaxed text-amber-800 dark:text-amber-200">
                <span className="font-semibold">
                  {stats.nonCompliant} account{stats.nonCompliant === 1 ? '' : 's'} in this role
                </span>{' '}
                {stats.nonCompliant === 1 ? 'has' : 'have'} no second factor.{' '}
                {Number(grace) > 0
                  ? `They will have ${grace} hours to enrol before they are restricted.`
                  : 'Their next sign-in will be restricted to enrolment only. Set a grace period if that is too abrupt.'}
              </p>
            </div>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              variant="primary"
              icon={Save}
              disabled={!dirty}
              loading={saving}
              onClick={() =>
                onSave({
                  roleName: role.name,
                  mode,
                  grace_hours: Math.max(0, Number(grace) || 0),
                  reason: reason.trim(),
                })
              }
            >
              Save rule
            </Button>
            {rule && (
              <Button
                size="sm"
                variant="dangerGhost"
                icon={Trash2}
                loading={removing}
                onClick={() => onRemove(role.name)}
              >
                Remove rule
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={() => { reset(); setOpen(false) }}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </li>
  )
}

export default function MfaPolicyPage() {
  const queryClient = useQueryClient()
  const isRoot = useAuthStore((s) => s.isRoot())
  const [q, setQ] = useState('')
  const [onlyBreaches, setOnlyBreaches] = useState(false)

  const policyQuery = useQuery({
    queryKey: ['admin', 'mfa-policy'],
    queryFn: ({ signal }) => getMfaPolicy(signal),
  })

  const complianceQuery = useQuery({
    queryKey: ['admin', 'mfa-policy', 'compliance'],
    queryFn: ({ signal }) => getMfaCompliance(signal),
  })

  const rolesQuery = useQuery({
    queryKey: ['admin', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'mfa-policy'] })

  const saveMutation = useMutation({
    mutationFn: ({ roleName, ...payload }) => upsertMfaRule(roleName, payload),
    onSuccess: (_d, vars) => {
      toast.success(`MFA policy updated for “${vars.roleName}”`)
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const removeMutation = useMutation({
    mutationFn: (roleName) => deleteMfaRule(roleName),
    onSuccess: (_d, roleName) => {
      toast.success(`MFA policy removed for “${roleName}”`)
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const rules = useMemo(() => policyQuery.data?.rules || [], [policyQuery.data])
  const rulesByRole = useMemo(() => {
    const map = new Map()
    for (const r of rules) map.set(String(r.role_name).toLowerCase(), r)
    return map
  }, [rules])

  const rows = useMemo(() => complianceQuery.data?.rows || [], [complianceQuery.data])

  // Per-role membership and compliance, derived from the compliance rows so
  // the numbers next to a rule and the numbers in the table are the same
  // numbers — computed twice is computed differently, eventually.
  const statsByRole = useMemo(() => {
    const map = new Map()
    for (const row of rows) {
      for (const role of row.roles || []) {
        const key = String(role).toLowerCase()
        const s = map.get(key) || { members: 0, enrolled: 0, nonCompliant: 0 }
        s.members += 1
        if (row.mfa_enabled) s.enrolled += 1
        else if (row.required) s.nonCompliant += 1
        map.set(key, s)
      }
    }
    return map
  }, [rows])

  const roleCatalogue = useMemo(() => normalizeRoleList(rolesQuery.data), [rolesQuery.data])

  const filteredRows = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return rows.filter((r) => {
      if (onlyBreaches && (r.compliant || !r.required)) return false
      if (!needle) return true
      return (
        String(r.username || '').toLowerCase().includes(needle) ||
        String(r.email || '').toLowerCase().includes(needle) ||
        (r.roles || []).some((role) => String(role).toLowerCase().includes(needle))
      )
    })
  }, [rows, q, onlyBreaches])

  const summary = complianceQuery.data

  return (
    <div>
      <PageHeader
        eyebrow="Admin Center"
        title="MFA Policy"
        description="Require a second factor from the accounts that hold a given role. Evaluated by the server on every sign-in, so a role granted today gates the next login with no extra step."
        meta={
          !isRoot ? (
            <span className="inline-flex items-center gap-1.5 rounded-md border border-surface-700 bg-surface-850 px-2 py-1 text-2xs font-medium text-ink-400">
              <Lock className="h-3 w-3" strokeWidth={1.9} /> Read-only — only root can change policy
            </span>
          ) : null
        }
        actions={
          <Button
            variant="secondary"
            icon={RefreshCw}
            loading={policyQuery.isFetching || complianceQuery.isFetching}
            onClick={() => invalidate()}
          >
            Refresh
          </Button>
        }
      />

      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile
          icon={Users}
          label="Accounts"
          value={summary?.totalUsers ?? '—'}
          hint="Every account in this install"
        />
        <StatTile
          icon={ShieldCheck}
          label="Gated by a rule"
          value={summary?.gated ?? '—'}
          hint="Hold a role that requires a second factor"
        />
        <StatTile
          icon={CheckCircle2}
          label="Second factor set up"
          value={summary?.enrolled ?? '—'}
          hint="Across all accounts, gated or not"
        />
        <StatTile
          icon={AlertTriangle}
          label="Not compliant"
          value={summary?.nonCompliant ?? '—'}
          tone={summary?.wouldBlock > 0 ? 'danger' : summary?.nonCompliant > 0 ? 'warn' : 'default'}
          hint={
            summary?.wouldBlock > 0
              ? `${summary.wouldBlock} restricted at next sign-in`
              : 'Gated accounts with no second factor'
          }
        />
      </div>

      <Section label="Rules">
        <Card className="overflow-hidden">
          <div className="flex items-center gap-3 border-b border-surface-800 bg-surface-850/50 px-4 py-3">
            <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-900 text-ink-400">
              <ShieldCheck className="h-4 w-4" strokeWidth={1.7} />
            </span>
            <h3 className="text-sm font-semibold text-ink-50">One rule per role</h3>
            <Link
              to="/admin/roles"
              className="ml-auto text-xs font-semibold text-blue-600 transition-colors hover:text-blue-500 dark:text-blue-400"
            >
              Manage roles
            </Link>
          </div>

          <QueryState query={policyQuery} skeletonRows={4}>
            {() =>
              roleCatalogue.length === 0 ? (
                <EmptyState
                  icon={ShieldOff}
                  title="No roles defined"
                  description="MFA policy gates roles, so there is nothing to gate until a role exists."
                />
              ) : (
                <ul className="divide-y divide-surface-800">
                  {roleCatalogue.map((role) => (
                    <RoleRuleRow
                      key={role.name}
                      role={role}
                      rule={rulesByRole.get(String(role.name).toLowerCase())}
                      stats={statsByRole.get(String(role.name).toLowerCase())}
                      canEdit={isRoot}
                      saving={saveMutation.isPending && saveMutation.variables?.roleName === role.name}
                      removing={removeMutation.isPending && removeMutation.variables === role.name}
                      onSave={(payload) => saveMutation.mutate(payload)}
                      onRemove={(roleName) => removeMutation.mutate(roleName)}
                    />
                  ))}
                </ul>
              )
            }
          </QueryState>

          <div className="border-t border-surface-800 bg-surface-850/40 px-4 py-3">
            <p className="flex items-start gap-2 text-2xs leading-relaxed text-ink-500">
              <Info className="mt-px h-3 w-3 flex-none" strokeWidth={1.9} />
              <span>
                Start a rule in <span className="font-semibold">monitor</span> and read the table below before
                switching it to <span className="font-semibold">enforce</span>. A user in two gated roles is held to
                the stricter of the two.
              </span>
            </p>
          </div>
        </Card>
      </Section>

      <Section label="Compliance">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 border-b border-surface-800 px-3 py-2.5">
            <SearchField value={q} onChange={setQ} placeholder="Search account or role…" className="min-w-[14rem] sm:max-w-xs" />
            <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-ink-400">
              <input
                type="checkbox"
                checked={onlyBreaches}
                onChange={(e) => setOnlyBreaches(e.target.checked)}
                className="h-3.5 w-3.5 cursor-pointer rounded border-surface-600 bg-surface-900 text-blue-600"
              />
              Only accounts out of compliance
            </label>
            <span className="ml-auto text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
              {filteredRows.length} shown
            </span>
          </div>

          <QueryState query={complianceQuery} skeletonRows={6}>
            {() =>
              filteredRows.length === 0 ? (
                <EmptyState
                  icon={CheckCircle2}
                  title={onlyBreaches ? 'Everyone is compliant' : 'No accounts match'}
                  description={
                    onlyBreaches
                      ? 'Every account gated by a rule has a second factor set up.'
                      : 'Try a different search term.'
                  }
                />
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-surface-800 bg-surface-850/50 text-left">
                        <th className="px-4 py-2 text-2xs font-semibold uppercase tracking-[0.08em] text-ink-500">Account</th>
                        <th className="px-4 py-2 text-2xs font-semibold uppercase tracking-[0.08em] text-ink-500">Roles</th>
                        <th className="px-4 py-2 text-2xs font-semibold uppercase tracking-[0.08em] text-ink-500">Second factor</th>
                        <th className="px-4 py-2 text-2xs font-semibold uppercase tracking-[0.08em] text-ink-500">Policy</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-800">
                      {filteredRows.map((row) => (
                        <tr key={row.user_id} className="transition-colors hover:bg-surface-850/40">
                          <td className="px-4 py-2.5">
                            <Link
                              to={`/admin/identity/${row.user_id}`}
                              className="font-medium text-ink-100 transition-colors hover:text-blue-500"
                            >
                              {row.username}
                            </Link>
                            <p className="truncate text-2xs text-ink-500">{row.email}</p>
                          </td>
                          <td className="px-4 py-2.5">
                            <span className="flex flex-wrap gap-1">
                              {(row.roles || []).length === 0 ? (
                                <span className="text-xs text-ink-500">None</span>
                              ) : (
                                (row.roles || []).map((r) => (
                                  <MetaTag key={r}>{r}</MetaTag>
                                ))
                              )}
                            </span>
                          </td>
                          <td className="px-4 py-2.5">
                            <StatusIndicator tone={row.mfa_enabled ? 'emerald' : 'neutral'}>
                              {row.mfa_enabled ? 'Enrolled' : 'Not set up'}
                            </StatusIndicator>
                          </td>
                          <td className="px-4 py-2.5">
                            {!row.required ? (
                              <span className="text-xs text-ink-500">Not gated</span>
                            ) : row.compliant ? (
                              <StatusIndicator tone="emerald">
                                Compliant · {mfaModeLabel(row.mode)}
                              </StatusIndicator>
                            ) : (
                              <span className="flex flex-wrap items-center gap-1.5">
                                <StatusIndicator tone={row.mode === 'enforce' ? 'red' : 'amber'}>
                                  {row.mode === 'enforce' ? 'Will be restricted' : 'In breach'}
                                </StatusIndicator>
                                {(row.gated_by || []).length > 0 && (
                                  <span className="text-2xs text-ink-500">via {row.gated_by.join(', ')}</span>
                                )}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )
            }
          </QueryState>
        </Card>
      </Section>
    </div>
  )
}
