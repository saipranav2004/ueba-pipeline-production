import { http } from '../lib/http'

// ---------------------------------------------------------------------------
// Service identities — the vault's MACHINE data plane, control side
// ---------------------------------------------------------------------------
// Two planes, and the split is the whole security model:
//
//   CONTROL (these calls) — a human administrator, JWT + MFA, under
//     /api/v1/pam/admin/services. Creates identities, mints tokens, grants
//     path scopes. Minting and granting additionally require a fresh MFA
//     assertion server-side (middleware.RequireMFA), so a 403 from those two
//     most likely means "step up", not "no permission".
//
//   DATA (never called from this console) — the application itself, holding a
//     service token, under /api/v1/pam/svc. Reads secrets by canonical path.
//     A service token cannot reach any of the routes below, which is what
//     stops a compromised application from minting itself a broader one.
//
// RESPONSE SHAPE: like vault.js and unlike resources.js, these handlers put
// the array or object straight in `data` with no wrapper key. Each function
// is a deliberate pass-through of exactly what its handler returns.

export async function listServiceIdentities(signal) {
  const { data } = await http.get('/api/v1/pam/admin/services', { signal })
  return data.data || [] // ServiceIdentity[]
}

export async function createServiceIdentity(payload) {
  const { data } = await http.post('/api/v1/pam/admin/services', payload)
  return data.data // ServiceIdentity
}

// Requires MFA server-side. The response carries the ONLY copy of the token
// that will ever exist — nothing re-reads it, so whatever shows it to the
// operator is the last chance to store it.
export async function issueServiceToken(service, payload) {
  const { data } = await http.post(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/tokens`,
    payload
  )
  return data.data // { token_id, token, service_id, service_name, expires_at }
}

// Every token the identity has ever held, live and revoked. Hashes are never
// exposed; there is no endpoint that can return a token's secret again.
export async function listServiceTokens(service, signal) {
  const { data } = await http.get(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/tokens`,
    { signal }
  )
  return data.data || [] // ServiceToken[]
}

export async function revokeServiceToken(tokenId) {
  const { data } = await http.delete(`/api/v1/pam/admin/service-tokens/${encodeURIComponent(tokenId)}`)
  return data.data
}

// Requires MFA server-side.
export async function grantServiceScope(service, payload) {
  const { data } = await http.post(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/grants`,
    payload
  )
  return data.data // ServiceGrant
}

// `includeInactive` is the difference between two genuinely different
// questions. Without it the server returns the grants the authorisation path
// would actually consult — "what can this service read right now". With it,
// revoked and expired grants come too, so a reviewer can see that a scope was
// granted and then withdrawn instead of inferring it from an absence.
export async function listServiceGrants(service, { includeInactive = false, signal } = {}) {
  const { data } = await http.get(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/grants`,
    { params: includeInactive ? { include_inactive: true } : undefined, signal }
  )
  return data.data || [] // ServiceGrant[]
}

export async function revokeServiceGrant(grantId) {
  const { data } = await http.delete(`/api/v1/pam/admin/service-grants/${encodeURIComponent(grantId)}`)
  return data.data
}

// The incident-response switch: revokes every token the identity holds, in
// one statement, no enumeration and no partial state. Grants are left intact.
export async function disableServiceIdentity(service) {
  const { data } = await http.post(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/disable`
  )
  return data.data
}

// The other half of disable, so a kill is not a one-way door. The identity and
// its grants come back; the tokens the disable revoked STAY revoked, because
// undoing an administrative action must not resurrect a credential that may
// have leaked. Recovery is therefore "enable, then mint one fresh token".
export async function enableServiceIdentity(service) {
  const { data } = await http.post(
    `/api/v1/pam/admin/services/${encodeURIComponent(service)}/enable`
  )
  return data.data
}
