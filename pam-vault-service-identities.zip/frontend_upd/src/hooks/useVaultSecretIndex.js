import { useMemo } from 'react'
import { useQueries, useQuery } from '@tanstack/react-query'
import { listCredentials, listFolders, listSafes } from '../api/vault'
import { canonicalSecretPath } from '../lib/secretScope'

// ---------------------------------------------------------------------------
// Every secret's canonical path, as the data plane addresses it
// ---------------------------------------------------------------------------
// A grant is a glob over paths like `prod-db/replicas/pg-reader`, and nothing
// in the console showed those paths anywhere — an administrator writing a
// scope was typing a pattern against an address space they could not see. So
// this assembles it from what the vault API already exposes:
//
//     <safe.name>/<folder.path>/<credential.name>
//
// which is CanonicalSecretPath(safe_name, folder_path, name) on the server,
// over the same two columns its own join reads (pam_safes.name and
// pam_folders.path). If that derivation ever drifts, the preview built on it
// becomes a confident lie, so the pairing is spelled out here rather than
// buried in a component.
//
// One request per safe for folders and one for credentials, fired only when
// `enabled` — nothing loads this until a form that needs it is actually open.
// A vault with hundreds of safes would want a server-side index instead; at
// that point the endpoint to add is a flat path list, not a faster loop.
export function useVaultSecretIndex(enabled) {
  const safesQuery = useQuery({
    queryKey: ['vault', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
    enabled,
  })

  const safes = useMemo(() => safesQuery.data || [], [safesQuery.data])

  const folderQueries = useQueries({
    queries: safes.map((safe) => ({
      queryKey: ['vault', 'folders', safe.id],
      queryFn: ({ signal }) => listFolders(safe.id, signal),
      enabled: enabled && !!safe.id,
    })),
  })

  const credentialQueries = useQueries({
    queries: safes.map((safe) => ({
      queryKey: ['vault', 'credentials', safe.id],
      queryFn: ({ signal }) => listCredentials(safe.id, signal),
      enabled: enabled && !!safe.id,
    })),
  })

  // Serialised into the dependency list because useQueries returns a fresh
  // array of fresh result objects on every render — depending on the arrays
  // themselves would rebuild the index on each one, and the modals below
  // recompute a preview from it on every keystroke.
  const folderData = folderQueries.map((q) => q.data)
  const credentialData = credentialQueries.map((q) => q.data)
  const folderKey = folderData.map((d) => (d ? d.length : -1)).join(',')
  const credentialKey = credentialData.map((d) => (d ? d.length : -1)).join(',')

  const secrets = useMemo(() => {
    const out = []
    safes.forEach((safe, i) => {
      const folders = folderData[i] || []
      const byId = new Map(folders.map((f) => [f.id, f]))
      for (const cred of credentialData[i] || []) {
        const folder = cred.folder_id ? byId.get(cred.folder_id) : null
        out.push({
          id: cred.id,
          path: canonicalSecretPath(safe.name, folder?.path || '', cred.name),
          safeId: safe.id,
          safeName: safe.name,
          folderPath: folder?.path || '',
          name: cred.name,
          accountName: cred.account_name,
          credentialType: cred.credential_type,
          isBreakglass: !!cred.is_breakglass,
        })
      }
    })
    return out.sort((a, b) => a.path.localeCompare(b.path))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [safes, folderKey, credentialKey])

  const isLoading =
    safesQuery.isLoading ||
    folderQueries.some((q) => q.isLoading) ||
    credentialQueries.some((q) => q.isLoading)

  // Partial is the honest word for it: if one safe's listing failed, the
  // preview is built on less than the whole vault and must say so rather than
  // quietly under-reporting what a scope reaches.
  const isPartial =
    safesQuery.isError || folderQueries.some((q) => q.isError) || credentialQueries.some((q) => q.isError)

  return { secrets, safes, isLoading, isPartial }
}
