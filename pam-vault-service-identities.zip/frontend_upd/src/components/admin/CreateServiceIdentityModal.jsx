import { useEffect, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Bot, Gauge, Plus } from 'lucide-react'
import clsx from 'clsx'
import { createServiceIdentity } from '../../api/serviceIdentity'
import { Modal } from '../common/Modal'
import { Field, FieldSet, inputClass } from '../common/FormFields'
import { Button } from '../common/Button'
import { SegmentedControl } from '../common/SegmentedControl'
import { apiErrorMessage } from '../../lib/apiError'
import { serviceNameRules } from '../../lib/validators'

// ---------------------------------------------------------------------------
// Register a service identity
// ---------------------------------------------------------------------------
// An identity on its own can do nothing: it holds no token and no scope, so
// registering one is safe and reversible. The form says so, because the
// instinct on a screen inside a PAM console is that creating a machine
// principal is the dangerous step — it isn't; minting and granting are, and
// they are separate, MFA-gated actions.
//
// Only the name is required. Environment and owner are optional but earn
// their place: an unowned machine identity is one nobody is accountable for,
// so the owner defaults server-side to the administrator creating it rather
// than to nothing.

const ENVIRONMENTS = [
  { key: 'production', label: 'Production' },
  { key: 'staging', label: 'Staging' },
  { key: 'development', label: 'Development' },
]

export function CreateServiceIdentityModal({ open, onClose, onCreated }) {
  const queryClient = useQueryClient()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [environment, setEnvironment] = useState('production')
  const [rateLimit, setRateLimit] = useState('')

  useEffect(() => {
    if (!open) return
    setName('')
    setDescription('')
    setEnvironment('production')
    setRateLimit('')
  }, [open])

  const nameError = name && !serviceNameRules.test(name) ? serviceNameRules.message : undefined

  const mutation = useMutation({
    mutationFn: () =>
      createServiceIdentity({
        name: name.trim(),
        description: description.trim() || undefined,
        environment,
        max_secrets_per_minute: Number(rateLimit) > 0 ? Number(rateLimit) : 0,
      }),
    onSuccess: (identity) => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-identities'] })
      toast.success(`Service identity “${identity?.name || name}” registered`, {
        description: 'It can read nothing yet. Grant it a scope, then mint a token.',
      })
      onCreated?.(identity)
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const submit = (e) => {
    e.preventDefault()
    if (!serviceNameRules.test(name.trim())) {
      toast.error(serviceNameRules.message)
      return
    }
    mutation.mutate()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon={Bot}
      title="Register a service identity"
      description="A machine principal: an application, job or agent that reads secrets without a person in the loop."
      size="md"
      busy={mutation.isPending}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            form="create-service-form"
            type="submit"
            variant="primary"
            icon={Plus}
            loading={mutation.isPending}
            disabled={!name.trim() || !!nameError}
          >
            Register identity
          </Button>
        </>
      }
    >
      <form id="create-service-form" onSubmit={submit} noValidate className="space-y-5">
        <FieldSet title="Identity">
          <Field
            label="Name"
            required
            hint={serviceNameRules.hint}
            error={nameError}
            htmlFor="cs-name"
          >
            <input
              id="cs-name"
              autoComplete="off"
              spellCheck={false}
              placeholder="billing-api-prod"
              className={clsx(inputClass(!!nameError), 'font-mono')}
              value={name}
              onChange={(e) => setName(e.target.value)}
              // Pasting a human label should produce a usable name rather than
              // an error the operator has to fix by hand.
              onBlur={() => setName((v) => (serviceNameRules.test(v) ? v : serviceNameRules.slugify(v)))}
            />
          </Field>

          <Field
            label="What it does"
            hint="One line. This is what a reviewer reads when they find this identity holding a broad scope."
            htmlFor="cs-desc"
          >
            <textarea
              id="cs-desc"
              rows={2}
              placeholder="Reads the invoices database writer credential on start-up and on rotation."
              className={inputClass(false)}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Field>

          <Field label="Environment" htmlFor="cs-env">
            <SegmentedControl
              ariaLabel="Environment"
              value={environment}
              onChange={setEnvironment}
              options={ENVIRONMENTS}
            />
          </Field>
        </FieldSet>

        <FieldSet
          title="Rate limit"
          description="A compromised token's blast radius is bounded by how fast it can read. A healthy service reads on start-up and on rotation, not continuously."
        >
          <Field
            label="Secret reads per minute"
            hint="Blank means unlimited. Set it to a few times what the service actually needs."
            htmlFor="cs-rate"
          >
            <div className="relative">
              <Gauge
                className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-500"
                strokeWidth={1.75}
              />
              <input
                id="cs-rate"
                type="number"
                min="0"
                inputMode="numeric"
                placeholder="unlimited"
                className={clsx(inputClass(false), 'pl-8 tabular-nums')}
                value={rateLimit}
                onChange={(e) => setRateLimit(e.target.value)}
              />
            </div>
          </Field>
        </FieldSet>

        <p className="rounded-lg border border-surface-700 bg-surface-850 px-3 py-2.5 text-2xs leading-relaxed text-ink-400">
          Registering an identity grants nothing. It holds no token and no scope until you add them, and
          both of those are separate actions that require MFA.
        </p>
      </form>
    </Modal>
  )
}
