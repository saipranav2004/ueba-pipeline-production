import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  Ban,
  Bot,
  Clock,
  Gauge,
  KeyRound,
  Plus,
  ShieldCheck,
  ShieldOff,
  Trash2,
  Undo2,
} from 'lucide-react'
import clsx from 'clsx'
import {
  listServiceGrants,
  listServiceTokens,
  revokeServiceGrant,
  revokeServiceToken,
} from '../../api/serviceIdentity'
import { Drawer } from '../common/Drawer'
import { Button } from '../common/Button'
import { ConfirmDialog } from '../common/ConfirmDialog'
import { TabBar } from '../common/TabBar'
import { Badge } from '../common/Badge'
import { SkeletonLines } from '../ui/states'
import { Meta, StatusDot } from '../ui/bits'
import { apiErrorMessage } from '../../lib/apiError'
import { useActorNames } from '../../hooks/useActorNames'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { SCOPE_BREADTH_LABEL, scopeBreadth } from '../../lib/secretScope'

// ---------------------------------------------------------------------------
// One service identity, in full
// ---------------------------------------------------------------------------
// Two questions, and they are not the same question:
//
//   GRANTS — what can this machine read? Live grants are what the
//     authorisation path would consult right now. The history view adds the
//     revoked and expired ones, because "this scope was granted in March and
//     pulled in April" is a fact a reviewer needs, and an absence does not
//     state it.
//   TOKENS — what can authenticate as it? Each row is a credential in someone's
//     deployment. Last-used is the column that matters: a token nobody has
//     presented in months is one to revoke, and one being used from an address
//     you do not recognise is an incident.
//
// The two are deliberately separate: revoking a token stops a deployment,
// revoking a grant narrows every deployment at once.

// A StatusDot tone. Every token row has a state, which by this console's own
// rule (Badge.jsx) makes it an indicator rather than a badge: a dot and a
// word, not a filled chip on every line.
function tokenState(token) {
  if (token.revoked_at) return { tone: 'muted', label: 'Revoked', live: false }
  if (token.expires_at && new Date(token.expires_at) <= new Date())
    return { tone: 'warn', label: 'Expired', live: false }
  return { tone: 'ok', label: 'Active', live: true }
}

function grantState(grant) {
  if (grant.revoked_at) return { label: 'Revoked', live: false }
  if (grant.expires_at && new Date(grant.expires_at) <= new Date())
    return { label: 'Expired', live: false }
  return { label: 'Live', live: true }
}

const BREADTH_CLASS = {
  all: 'border-red-500/40 bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300',
  subtree: 'border-amber-400/50 bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300',
  wildcard: 'border-amber-400/40 bg-amber-50/70 text-amber-700 dark:bg-amber-500/[0.07] dark:text-amber-300',
  exact: 'border-surface-700 bg-surface-850 text-ink-300',
}

function EmptyPane({ icon: Icon, title, body, action }) {
  return (
    <div className="px-4 py-10 text-center">
      <Icon className="mx-auto h-6 w-6 text-ink-600" strokeWidth={1.5} />
      <p className="mt-2.5 text-sm font-medium text-ink-200">{title}</p>
      <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-ink-500">{body}</p>
      {action && <div className="mt-3.5 flex justify-center">{action}</div>}
    </div>
  )
}

export function ServiceIdentityDrawer({ identity, onClose, onGrant, onMintToken, onDisable, onEnable }) {
  const queryClient = useQueryClient()
  const [tab, setTab] = useState('grants')
  const [showHistory, setShowHistory] = useState(false)
  const [revokeGrantTarget, setRevokeGrantTarget] = useState(null)
  const [revokeTokenTarget, setRevokeTokenTarget] = useState(null)

  // These records store the actor's user id, which is right for the record and
  // useless on screen. Resolved to a name for display; the id stays in the
  // tooltip so it is still copyable into a ticket.
  const { nameOf } = useActorNames(!!identity)

  const name = identity?.name
  const open = !!identity

  const grantsQuery = useQuery({
    queryKey: ['admin', 'service-grants', name, showHistory],
    queryFn: ({ signal }) => listServiceGrants(name, { includeInactive: showHistory, signal }),
    enabled: open,
  })

  const tokensQuery = useQuery({
    queryKey: ['admin', 'service-tokens', name],
    queryFn: ({ signal }) => listServiceTokens(name, signal),
    enabled: open,
  })

  // `|| []` inline would be a new array identity on every render, which
  // would make the two useMemos below recompute on each one. Memoised here
  // so the fallback is stable too.
  const grants = useMemo(() => grantsQuery.data || [], [grantsQuery.data])
  const tokens = useMemo(() => tokensQuery.data || [], [tokensQuery.data])
  const liveTokens = useMemo(() => tokens.filter((t) => tokenState(t).live), [tokens])
  const liveGrants = useMemo(() => grants.filter((g) => grantState(g).live), [grants])

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['admin', 'service-grants', name] })
    queryClient.invalidateQueries({ queryKey: ['admin', 'service-tokens', name] })
    queryClient.invalidateQueries({ queryKey: ['admin', 'service-identities'] })
  }

  const revokeGrantMutation = useMutation({
    mutationFn: (grantId) => revokeServiceGrant(grantId),
    onSuccess: () => {
      toast.success('Scope revoked', {
        description: 'Effective immediately on the server. A client already holding the plaintext keeps it until its cache lifetime runs out.',
      })
      invalidate()
      setRevokeGrantTarget(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setRevokeGrantTarget(null)
    },
  })

  const revokeTokenMutation = useMutation({
    mutationFn: (tokenId) => revokeServiceToken(tokenId),
    onSuccess: () => {
      toast.success('Token revoked', {
        description: 'Anything still presenting it now fails to authenticate.',
      })
      invalidate()
      setRevokeTokenTarget(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setRevokeTokenTarget(null)
    },
  })

  if (!identity) return null

  const disabled = identity.status !== 'active'

  return (
    <>
      <Drawer
        open={open}
        onClose={onClose}
        width="lg"
        icon={Bot}
        title={identity.name}
        subtitle={identity.description || identity.id}
        footer={
          <>
            {disabled ? (
              <Button size="sm" variant="secondary" icon={Undo2} onClick={() => onEnable(identity)}>
                Enable identity
              </Button>
            ) : (
              <Button size="sm" variant="dangerGhost" icon={ShieldOff} onClick={() => onDisable(identity)}>
                Disable identity
              </Button>
            )}
            <span className="ml-auto text-2xs text-ink-500">
              {liveGrants.length} live scope{liveGrants.length === 1 ? '' : 's'} ·{' '}
              {liveTokens.length} active token{liveTokens.length === 1 ? '' : 's'}
            </span>
          </>
        }
      >
        {/* The posture, as a sentence, before the tables. An identity with a
            scope and no token, or a token and no scope, is a half-finished
            setup, and that is exactly the state that produces a 403 nobody
            can explain. */}
        <div
          className={clsx(
            'border-b border-surface-800 px-4 py-3.5',
            disabled
              ? 'bg-surface-850'
              : liveTokens.length === 0 || liveGrants.length === 0
                ? 'bg-amber-50/60 dark:bg-amber-950/15'
                : 'bg-emerald-50/60 dark:bg-emerald-950/15'
          )}
        >
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <Badge
              className={
                disabled
                  ? 'border-surface-700 bg-surface-800 text-ink-400'
                  : 'border-emerald-500/40 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300'
              }
            >
              {disabled ? identity.status : 'active'}
            </Badge>
            {identity.environment && <Meta>{identity.environment}</Meta>}
            {identity.max_secrets_per_minute > 0 ? (
              <Meta>{identity.max_secrets_per_minute}/min</Meta>
            ) : (
              <Meta tone="warn">no rate limit</Meta>
            )}
          </div>
          <p className="text-sm font-medium leading-relaxed text-ink-100">
            {disabled
              ? 'This identity is disabled, so nothing can authenticate as it and it cannot mint a token. Its scopes are intact: enable it, mint one fresh token, and it is back.'
              : liveTokens.length === 0
                ? 'No active token, so nothing can authenticate as this identity right now. Its scopes are waiting.'
                : liveGrants.length === 0
                  ? 'It can authenticate, but it holds no scope — every secret read will be refused. Grant it what it needs to read.'
                  : `It can read ${liveGrants.length} scope${liveGrants.length === 1 ? '' : 's'}, using ${liveTokens.length} active token${liveTokens.length === 1 ? '' : 's'}.`}
          </p>
        </div>

        <div className="px-4 pt-2">
          <TabBar
            active={tab}
            onChange={setTab}
            tabs={[
              { key: 'grants', label: 'Scopes', icon: ShieldCheck, count: liveGrants.length },
              { key: 'tokens', label: 'Tokens', icon: KeyRound, count: liveTokens.length },
            ]}
          />
        </div>

        {tab === 'grants' ? (
          <section>
            <header className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-surface-800 bg-surface-850/60 px-4 py-2">
              <span className="flex-1 text-xs font-semibold text-ink-500">
                What this service can read
              </span>
              <button
                type="button"
                onClick={() => setShowHistory((v) => !v)}
                className="flex-none rounded px-1.5 py-0.5 text-2xs font-semibold text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-100"
              >
                {showHistory ? 'Live only' : 'Show revoked'}
              </button>
              {!disabled && (
                <Button size="xs" variant="subtle" icon={Plus} onClick={() => onGrant(identity)}>
                  Grant scope
                </Button>
              )}
            </header>

            {grantsQuery.isLoading ? (
              <div className="px-4 py-4">
                <SkeletonLines rows={4} />
              </div>
            ) : grantsQuery.isError ? (
              <p className="px-4 py-6 text-center text-xs text-danger">
                {apiErrorMessage(grantsQuery.error)}
              </p>
            ) : grants.length === 0 ? (
              <EmptyPane
                icon={ShieldCheck}
                title="No scopes granted"
                body="Until this identity holds a scope it can authenticate and read nothing. Every secret read will be refused."
                action={
                  !disabled && (
                    <Button size="sm" variant="primary" icon={Plus} onClick={() => onGrant(identity)}>
                      Grant its first scope
                    </Button>
                  )
                }
              />
            ) : (
              <ul className="divide-y divide-surface-800/70">
                {grants.map((g) => {
                  const state = grantState(g)
                  const breadth = scopeBreadth(g.scope)
                  return (
                    <li key={g.id} className={clsx('px-4 py-3', !state.live && 'opacity-60')}>
                      <div className="flex flex-wrap items-start gap-x-2 gap-y-1.5">
                        <span className="min-w-0 flex-1 break-all font-mono text-sm text-ink-100">
                          {g.scope}
                        </span>
                        <span
                          className={clsx(
                            'flex-none rounded border px-1.5 py-px text-2xs font-semibold',
                            BREADTH_CLASS[breadth]
                          )}
                        >
                          {SCOPE_BREADTH_LABEL[breadth]}
                        </span>
                        {!state.live && <Meta>{state.label}</Meta>}
                        {state.live && !disabled && (
                          <button
                            type="button"
                            onClick={() => setRevokeGrantTarget(g)}
                            title="Revoke this scope"
                            className="flex h-6 w-6 flex-none items-center justify-center rounded text-ink-600 transition-colors hover:bg-danger-soft hover:text-danger"
                          >
                            <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                          </button>
                        )}
                      </div>
                      <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-2xs text-ink-500">
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3 w-3" strokeWidth={1.75} />
                          {g.max_ttl_seconds > 0
                            ? `caches for at most ${g.max_ttl_seconds}s`
                            : 'server default cache lifetime'}
                        </span>
                        {g.expires_at && <span>expires {formatRelativeToNow(g.expires_at)}</span>}
                        {g.granted_by && <span title={g.granted_by}>by {nameOf(g.granted_by)}</span>}
                        {g.revoked_at && (
                          <span title={g.revoked_by || undefined}>
                            revoked {formatRelativeToNow(g.revoked_at)}
                            {g.revoked_by ? ` by ${nameOf(g.revoked_by)}` : ''}
                          </span>
                        )}
                      </p>
                      {g.reason && (
                        <p className="mt-1 text-xs leading-relaxed text-ink-400">{g.reason}</p>
                      )}
                    </li>
                  )
                })}
              </ul>
            )}
          </section>
        ) : (
          <section>
            <header className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-surface-800 bg-surface-850/60 px-4 py-2">
              <span className="flex-1 text-xs font-semibold text-ink-500">
                What can authenticate as it
              </span>
              {!disabled && (
                <Button size="xs" variant="subtle" icon={KeyRound} onClick={() => onMintToken(identity)}>
                  Mint token
                </Button>
              )}
            </header>

            {tokensQuery.isLoading ? (
              <div className="px-4 py-4">
                <SkeletonLines rows={4} />
              </div>
            ) : tokensQuery.isError ? (
              <p className="px-4 py-6 text-center text-xs text-danger">
                {apiErrorMessage(tokensQuery.error)}
              </p>
            ) : tokens.length === 0 ? (
              <EmptyPane
                icon={KeyRound}
                title="No tokens minted"
                body="Nothing can authenticate as this identity yet. A token is shown exactly once, when it is minted."
                action={
                  !disabled && (
                    <Button size="sm" variant="primary" icon={KeyRound} onClick={() => onMintToken(identity)}>
                      Mint the first token
                    </Button>
                  )
                }
              />
            ) : (
              <ul className="divide-y divide-surface-800/70">
                {tokens.map((t) => {
                  const state = tokenState(t)
                  return (
                    <li key={t.token_id} className={clsx('px-4 py-3', !state.live && 'opacity-60')}>
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5">
                        <span className="min-w-0 flex-1 break-all font-mono text-xs text-ink-200">
                          pamsvc.{t.token_id}.…
                        </span>
                        <StatusDot tone={state.tone} label={state.label} live={state.live} />
                        {state.live && (
                          <button
                            type="button"
                            onClick={() => setRevokeTokenTarget(t)}
                            title="Revoke this token"
                            className="flex h-6 w-6 flex-none items-center justify-center rounded text-ink-600 transition-colors hover:bg-danger-soft hover:text-danger"
                          >
                            <Ban className="h-3.5 w-3.5" strokeWidth={1.75} />
                          </button>
                        )}
                      </div>
                      {t.description && (
                        <p className="mt-1 text-xs text-ink-300">{t.description}</p>
                      )}
                      <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-2xs text-ink-500">
                        <span>minted {formatRelativeToNow(t.created_at)}</span>
                        {t.expires_at && <span title={formatDateTime(t.expires_at)}>expires {formatRelativeToNow(t.expires_at)}</span>}
                        {/* Never-used is as interesting as recently-used: a
                            token minted weeks ago and never presented is one
                            that went into a deployment that never shipped. */}
                        <span className={t.last_used_at ? undefined : 'text-warn'}>
                          {t.last_used_at
                            ? `last used ${formatRelativeToNow(t.last_used_at)}${t.last_used_ip ? ` from ${t.last_used_ip}` : ''}`
                            : 'never used'}
                        </span>
                        {t.revoked_at && (
                          <span title={t.revoked_by || undefined}>
                            revoked {formatRelativeToNow(t.revoked_at)}
                            {t.revoked_by ? ` by ${nameOf(t.revoked_by)}` : ''}
                          </span>
                        )}
                      </p>
                    </li>
                  )
                })}
              </ul>
            )}
          </section>
        )}

        <dl className="divide-y divide-surface-800 border-t border-surface-800">
          {[
            { label: 'Owner', value: nameOf(identity.owner_id) || '—', title: identity.owner_id },
            {
              label: 'Rate limit',
              value:
                identity.max_secrets_per_minute > 0
                  ? `${identity.max_secrets_per_minute} secret reads per minute`
                  : 'unlimited',
            },
            { label: 'Registered', value: formatDateTime(identity.created_at) },
            { label: 'Identity ID', value: identity.id, mono: true },
          ].map((row) => (
            <div key={row.label} className="grid grid-cols-[minmax(6.5rem,34%)_1fr] gap-3 px-4 py-2.5">
              <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-ink-500">
                {row.label}
              </dt>
              <dd
                title={row.title}
                className={clsx('break-all text-ink-100', row.mono ? 'font-mono text-xs' : 'text-sm')}
              >
                {row.value}
              </dd>
            </div>
          ))}
        </dl>

        <p className="flex items-start gap-2 border-t border-surface-800 px-4 py-3 text-2xs leading-relaxed text-ink-500">
          <Gauge className="mt-px h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
          <span>
            Every secret this identity reads is recorded with the purpose the caller stated. Admin Center →
            Audit &amp; Compliance, filtered to this name, is the full trail.
          </span>
        </p>
      </Drawer>

      <ConfirmDialog
        open={!!revokeGrantTarget}
        title={`Revoke “${revokeGrantTarget?.scope}”?`}
        description="This service stops being able to read anything that scope covered. It takes effect on the server immediately; a client that already holds a plaintext keeps it until its cache lifetime runs out."
        confirmLabel="Revoke scope"
        destructive
        isLoading={revokeGrantMutation.isPending}
        onConfirm={() => revokeGrantMutation.mutate(revokeGrantTarget.id)}
        onCancel={() => setRevokeGrantTarget(null)}
      />

      <ConfirmDialog
        open={!!revokeTokenTarget}
        title="Revoke this token?"
        description="Any deployment still presenting it will fail to authenticate on its next read. If that is the only live token, the service stops reading secrets entirely."
        confirmLabel="Revoke token"
        destructive
        isLoading={revokeTokenMutation.isPending}
        onConfirm={() => revokeTokenMutation.mutate(revokeTokenTarget.token_id)}
        onCancel={() => setRevokeTokenTarget(null)}
      />
    </>
  )
}
