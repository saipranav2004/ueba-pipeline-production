// pam/internal/api/handlers/service_identity_handler.go
//
// Control-plane surface for provisioning the machine data plane. Mounted in
// the admin group (JWT + MFA + OPA), never on the service group — a service
// token must not be able to mint itself a broader one.
package handlers

import (
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type ServiceIdentityHandler struct {
	svc    *services.ServiceIdentityService
	logger *zap.Logger
}

func NewServiceIdentityHandler(svc *services.ServiceIdentityService, logger *zap.Logger) *ServiceIdentityHandler {
	return &ServiceIdentityHandler{svc: svc, logger: logger}
}

func (h *ServiceIdentityHandler) actor(c *gin.Context) string {
	if u := c.GetString("user_id"); u != "" {
		return u
	}
	return c.GetString("username")
}

// POST /admin/services
func (h *ServiceIdentityHandler) CreateIdentity(c *gin.Context) {
	var req struct {
		Name                string `json:"name" binding:"required"`
		Description         string `json:"description"`
		Environment         string `json:"environment"`
		OwnerID             string `json:"owner_id"`
		MaxSecretsPerMinute int    `json:"max_secrets_per_minute"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}

	// Default the owner to the creating admin rather than leaving it blank:
	// an unowned machine identity is one nobody is accountable for.
	ownerID := req.OwnerID
	if ownerID == "" {
		ownerID = h.actor(c)
	}

	// Checked before the write so a malformed name is a 400 naming the rule,
	// not a 500 wrapping a database error. The same function is what
	// CreateIdentity enforces, so the two cannot disagree.
	if err := services.ValidateServiceName(strings.TrimSpace(req.Name)); err != nil {
		response.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	identity, err := h.svc.CreateIdentity(c.Request.Context(),
		req.Name, req.Description, req.Environment, ownerID, h.actor(c), req.MaxSecretsPerMinute)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	response.Created(c, identity, "Service identity created successfully")
}

// GET /admin/services
func (h *ServiceIdentityHandler) ListIdentities(c *gin.Context) {
	out, err := h.svc.ListIdentities(c.Request.Context())
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	response.Success(c, out, "Service identities retrieved successfully")
}

// POST /admin/services/:service/tokens
//
// The response carries the only copy of the token that will ever exist. The
// previous token stays valid until explicitly revoked — that overlap is what
// makes rotation a rolling deploy instead of an outage.
func (h *ServiceIdentityHandler) IssueToken(c *gin.Context) {
	noStore(c)

	var req struct {
		Description string `json:"description"`
		TTLDays     int    `json:"ttl_days"`
	}
	_ = c.ShouldBindJSON(&req)

	// Default to a finite lifetime. A non-expiring machine credential is a
	// permanent liability, and defaulting to "never expires" guarantees that
	// is what ends up in production.
	if req.TTLDays <= 0 {
		req.TTLDays = 90
	}

	issued, err := h.svc.IssueToken(c.Request.Context(),
		c.Param("service"), req.Description, h.actor(c),
		time.Duration(req.TTLDays)*24*time.Hour)
	if err != nil {
		h.writeErr(c, err)
		return
	}
	response.Created(c, issued, "Service token issued — store it now, it cannot be retrieved again")
}

// GET /admin/services/:service/tokens
func (h *ServiceIdentityHandler) ListTokens(c *gin.Context) {
	out, err := h.svc.ListTokens(c.Request.Context(), c.Param("service"))
	if err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, out, "Service tokens retrieved successfully")
}

// DELETE /admin/service-tokens/:token_id
func (h *ServiceIdentityHandler) RevokeToken(c *gin.Context) {
	if err := h.svc.RevokeToken(c.Request.Context(), c.Param("token_id"), h.actor(c)); err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, gin.H{"status": "revoked"}, "Service token revoked successfully")
}

// POST /admin/services/:service/disable
func (h *ServiceIdentityHandler) DisableIdentity(c *gin.Context) {
	if err := h.svc.DisableIdentity(c.Request.Context(), c.Param("service"), h.actor(c)); err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, gin.H{"status": "disabled"}, "Service identity disabled and all tokens revoked")
}

// POST /admin/services/:service/enable
//
// The other half of disable. Tokens stay revoked; the identity and its grants
// come back, so recovery is to mint one fresh token.
func (h *ServiceIdentityHandler) EnableIdentity(c *gin.Context) {
	if err := h.svc.EnableIdentity(c.Request.Context(), c.Param("service"), h.actor(c)); err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, gin.H{"status": "active"},
		"Service identity enabled — its previous tokens stay revoked, mint a new one")
}

// POST /admin/services/:service/grants
func (h *ServiceIdentityHandler) GrantScope(c *gin.Context) {
	var req struct {
		Scope         string `json:"scope" binding:"required"`
		Reason        string `json:"reason" binding:"required"`
		MaxTTLSeconds int    `json:"max_ttl_seconds"`
		ExpiresInDays int    `json:"expires_in_days"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}

	var expiresAt *time.Time
	if req.ExpiresInDays > 0 {
		t := time.Now().UTC().AddDate(0, 0, req.ExpiresInDays)
		expiresAt = &t
	}

	grant, err := h.svc.GrantScope(c.Request.Context(), c.Param("service"),
		req.Scope, req.Reason, h.actor(c), req.MaxTTLSeconds, expiresAt)
	if err != nil {
		h.writeErr(c, err)
		return
	}
	response.Created(c, grant, "Service grant created successfully")
}

// GET /admin/services/:service/grants[?include_inactive=true]
//
// Defaults to the usable grants — the same set the authorisation path would
// consult, which is what "what can this service read right now" means. With
// include_inactive the revoked and expired ones come too, so a reviewer can
// see that a scope was granted and then withdrawn rather than inferring its
// absence from an empty list.
func (h *ServiceIdentityHandler) ListGrants(c *gin.Context) {
	list := h.svc.ListGrants
	if includeInactive(c) {
		list = h.svc.ListAllGrants
	}
	out, err := list(c.Request.Context(), c.Param("service"))
	if err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, out, "Service grants retrieved successfully")
}

// includeInactive reads the query flag permissively: present-and-empty
// (`?include_inactive`) reads as true, the way a flag is usually typed by
// hand, and anything strconv understands as false stays false.
func includeInactive(c *gin.Context) bool {
	raw, ok := c.GetQuery("include_inactive")
	if !ok {
		return false
	}
	if strings.TrimSpace(raw) == "" {
		return true
	}
	v, err := strconv.ParseBool(strings.TrimSpace(raw))
	return err == nil && v
}

// DELETE /admin/service-grants/:grant_id
func (h *ServiceIdentityHandler) RevokeGrant(c *gin.Context) {
	if err := h.svc.RevokeGrant(c.Request.Context(), c.Param("grant_id"), h.actor(c)); err != nil {
		h.writeErr(c, err)
		return
	}
	response.Success(c, gin.H{"status": "revoked"}, "Service grant revoked successfully")
}

func (h *ServiceIdentityHandler) writeErr(c *gin.Context, err error) {
	switch {
	case errors.Is(err, services.ErrIdentityNotFound):
		response.Error(c, http.StatusNotFound, "Service identity not found")
	case errors.Is(err, services.ErrTokenInvalid):
		response.Error(c, http.StatusNotFound, "Service token not found or already revoked")
	case errors.Is(err, services.ErrServiceGrantNotFound):
		response.Error(c, http.StatusNotFound, "Service grant not found")
	case errors.Is(err, services.ErrServiceDisabled):
		response.Error(c, http.StatusConflict, "Service identity is disabled")
	default:
		h.logger.Error("service_identity.request.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, err.Error())
	}
}
