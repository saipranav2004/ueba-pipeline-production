# PAM — Vault machine data plane (service identities) + the AAD data-loss fix

This zip carries **everything changed across all rounds so far, cumulatively**,
so it applies cleanly straight onto the original `backend_upd.zip` /
`frontend_upd.zip`. Nothing else needs to be applied first.

`backend_upd/.env` is **deliberately excluded**. The copy in the repository
holds live production secrets (RDS host and password, MinIO access keys,
`PAM_JWT_SECRET_KEY`, `PAM_AUDIT_HMAC_SECRET`, `PAM_ROOT_PASSWORD`). I used my
own throwaway values for every test in this round and never sent yours
anywhere. Those secrets should be rotated and that file removed from version
control.

---

## 1. What this round added

The human side of the vault already had a console. The machine side had a JSON
API and nothing else. An **application** — a billing service, a nightly job, an
agent — now has a first-class way to read secrets with no person in the loop,
and an administrator has a screen to govern it.

Two planes, and the split is the security model:

| | Control plane | Data plane |
|---|---|---|
| Who | a human administrator | the application itself |
| Auth | JWT + MFA + OPA | `X-Service-Token` (or `Authorization: Bearer`) |
| Mounted at | `/api/v1/pam/admin/services…` | `/api/v1/pam/svc/…` |
| Can do | create identities, mint tokens, grant scopes | read secrets by path |

A service token cannot reach any control-plane route. That is what stops a
compromised application from minting itself a broader credential, and it is
enforced by the router (the `/pam/svc` group carries `ServiceAuth` and nothing
else), not by the console.

### Scopes: the one rule that surprises people

A credential's address is its **canonical path** — `<safe>/<folder…>/<name>`,
e.g. `prod-db/replicas/pg-reader`. A grant is a glob over those paths:

```
prod-db/*      one level  — prod-db/pg-app-writer, NOT prod-db/replicas/pg-reader
prod-db/**     the subtree — both, and prod-db itself
*   or   **    every secret in the vault, present and future
```

`*` stopping at `/` is the whole point, and it is verified end to end over real
HTTP (see §4).

---

## 2. The bugs found and fixed

These were all found by exercising the feature, not by reading it.

### 2.1 A credential stored without an explicit safe could never be decrypted again *(data loss)*

Credentials are sealed with envelope encryption bound to **AAD** (additional
authenticated data) naming the account, safe and resource. Four call sites
built that AAD by hand. `Credential.BeforeCreate` defaults a blank `SafeID` to
`"default"` — *after* the AAD was computed. So a credential stored without an
explicit `safe_id` was encrypted under `safe_id: ""` and decrypted under
`safe_id: "default"`:

```
additional authenticated data (AAD) mismatch during decryption:
cipher: message authentication failed
```

The plaintext was **unrecoverable**. Fixed by making the AAD one method,
`Credential.EncryptionAAD()`, that normalises the safe itself, replacing all
four hand-built sites, and normalising `req.SafeID` in `StoreCredential`
*before* the AAD is computed. `vault_aad_binding_test.go` reproduces the
failure first, then pins the fix; its sibling test (explicit `safe_id`) passed
throughout, which is what proved the drift rather than the harness.

### 2.2 Disable was a one-way door

`DisableIdentity` is the incident-response switch: one statement, every token
revoked. But `IssueToken` refuses a disabled identity and **nothing could
re-enable one**. A disable that turned out to be a false alarm killed the
identity permanently — the only recovery was a new identity with every scope
re-granted by hand. That is a bad trade to force on someone mid-incident, and
it is why a kill switch gets hesitated over when it should be instant.

Added `EnableIdentity` and `POST /admin/services/:service/enable`. The
semantics are deliberate and stated in the UI: **the identity and its grants
come back, the revoked tokens stay revoked.** Undoing an administrative action
must not resurrect a credential that may have leaked, so recovery is "enable,
then mint one fresh token".

My first draft of the console copy said minting would restore a disabled
identity. That was false — it would have returned 409 — and is corrected.

### 2.3 Revoking a missing grant returned 500 with a raw database string

```
DELETE /admin/service-grants/<unknown>   ->  500  {"message":"record not found"}
DELETE /admin/service-tokens/<unknown>   ->  404  clean message
POST   /admin/services/<unknown>/disable ->  404  clean message
```

Three siblings agreeing and one not is the shape of a bug. `RevokeGrant`
returned the raw `gorm.ErrRecordNotFound`, which the handler mapped to a 500.
An operator retrying a `DELETE`, or a script replaying a run, hits this
constantly, and it reads as "the server is broken" rather than "that is already
gone". Now `ErrServiceGrantNotFound` → **404**, pinned by a test that asserts
all five not-found routes agree and that none leaks a database string.

### 2.4 Any string was accepted as a service identity name

The name **is** the identity's address on the control plane
(`/admin/services/<name>/tokens`) and the subject of every audit record it
produces. `billing/api` is not addressable on that route at all; `Billing-API`
and `billing-api` are two rows for one service; whitespace breaks the audit
string. The server accepted all of them, and by the time you noticed, the row
existed and was unmanageable through the API that created it.

Now validated at creation (`services.ValidateServiceName`) and reported as a
**400 naming the rule**, not a 500. The console states the same rule before the
round trip and slugifies a pasted human label (`"Billing API / prod"` →
`billing-api-prod`) rather than making you fix it by hand.

### 2.5 The grant list could not show a withdrawal

`ListGrants` returns only usable grants — correct for the authorisation path,
wrong for a reviewer, who needs "this scope was granted in March and pulled in
April" on screen rather than inferred from an absence. Added `ListAllGrants`
and `GET …/grants?include_inactive=true`. Kept as a **separate method**, not a
flag on the cached one, because the two have opposite requirements: the
authorisation path must be cached and must contain only usable grants; the
reviewer's view must never read a cache the console's own write may not have
reached.

---

## 3. The console: Admin Center → Service Identities

`/admin/services`, admin/root only, sitting under Vault Operations — the same
vault seen from the other side.

Audit-bearing fields (`granted_by`, `revoked_by`, `owner_id`) store the
actor's **user id**, which is right for the record and useless on screen —
"granted by 73fb3c88-abd7-42f3-9375-1d0b9213b57c" answers nothing a reviewer
asked. They are resolved to usernames for display, with the id kept in the
tooltip so it is still copyable into a ticket.

**The list answers two questions no screen previously could:** what can this
machine read (live scopes), and what can authenticate as it (live tokens).
Counts are of *live* things, not totals: an identity with four revoked tokens
and none active can read nothing, and a row saying "4" would be lying.

**Posture** is the column that earns its place, because each state is a
different action:

| | meaning | what to do |
|---|---|---|
| **Ready** | token + scope | nothing |
| **No token** | scopes, nothing authenticating | mint one |
| **No scope** | authenticates, every read refused | grant one |
| **Not set up** | neither | it is registered, not in use |
| **Disabled** | tokens revoked, scopes intact | enable, then mint |

**No scope** is the state that generates support tickets: the application has a
token, authenticates fine, and every secret read comes back 403 with nothing in
its own logs to explain why. An identity holding a vault-wide scope carries a
red edge rail — the same mark a deny policy gets — so it is findable without
reading across to another column.

### The grant form has a live preview

This is the part that turns a guess into a decision. Build the path from the
real vault (safe → folder → secret, or a wildcard), or type the pattern
directly, and the **exact paths it matches right now** are listed underneath,
counted, with the cases that also cover *future* secrets called out. `**` is
refused until explicitly acknowledged. A malformed pattern says so instead of
previewing as "matches nothing".

`src/lib/secretScope.js` is a **line-for-line port of Go's `path.Match`**, not
a translation to `RegExp`. That distinction is load-bearing: Go's matcher is
leftmost-commit with no backtracking, so `*[^a]*/*` accepts `0/b1/p2` under a
regex and is rejected by Go. A differential sweep against the real Go function
over **316,000 (scope, path) pairs** — random patterns, escapes, malformed
character classes, leading and trailing slashes — found that class of
disagreement with the regex version and finds **zero** with the port.

### The token hand-off

The mint response carries the only copy of the token that will ever exist, so
the dialog does not close on success. It swaps into a hand-off view where the
secret is masked until asked for, the only way out is a checkbox saying it has
been stored, and it is offered as the three shapes you are actually about to
use (`.env`, `curl`, `kubectl`) — because the failure mode here is a token
pasted into the wrong shape and then re-minted, leaving a live credential
nobody is tracking. Minting does not invalidate the current token; that overlap
is what makes rotation a rolling deploy instead of an outage, and the dialog
says so.

---

## 4. How this was tested

Everything below was run, not reasoned about.

**Go, against real PostgreSQL 16** — `go build ./...`, `go vet ./...`, and
`go test ./...`: **13 packages pass**, including the new `pkg/vaultclient`. Ten
tests drive the feature through the real gin router:

- a service reads only what it was granted, and its cache TTL is clamped to the grant's cap
- a read without a stated purpose is refused
- unauthenticated, malformed, unknown and revoked tokens are all refused identically
- disabling an identity kills every token at once
- `prod-db/*` does not cross a separator
- secret responses are `no-store`
- a revoked grant leaves the live list and stays in the history
- an unaddressable name is refused (8 shapes), a well-formed one accepted
- revoking something absent is a 404 across all five routes, with no leaked database string
- disable → enable restores the identity and its grants but not its tokens

**A live server** — the real binary against real PostgreSQL, exercised over
HTTP with real credentials in a real safe with a real folder:

```
prod-db/pg-app-writer                200  'the-app-password'   ttl=120
prod-db/pg-reader                    200  'the-reader-password' ttl=120
prod-db/replicas/pg-replica-reader   403  not authorized     <- * stops at /
no purpose                           400
no token                             401
Cache-Control: no-store, no-cache, must-revalidate, private
```

**The console in a real Chromium**, against that same server and the shipped
production bundle — **58 checks, all passing** across three suites: the main
screen and grant preview (26), visual and responsive plus the create and mint
flows (17), and the full disable-and-recover cycle (15). Highlights:

- the preview correctly discriminated **8 of 9** secrets for `prod-db/*` and **9 of 9** for `prod-db/**` against the live vault
- a scope granted in the browser was verified on the server, then **read successfully by the service** with its token
- the token is never rendered in the tokens list — only `pamsvc.<id>.…`
- a new identity reads "Not set up"; after minting, "No scope"; after granting, "Ready"
- no horizontal overflow at **400px, 768px or 1024px**; no truncated column headers; no console errors

**The Postman collection** (`postman/`) — all **70** requests from your v1
collection were resolved against the live router: every endpoint still exists
and is mounted on the plane the collection assumes. Six new requests were added
for this round's behaviour (name validation, `include_inactive`, the 404
parity, and the disable → enable → re-mint → read recovery).

`eslint --max-warnings 0` and `vite build` are both clean. Line endings were
audited file-by-file against your original zips: **zero drift** in either tree,
and no new `gofmt` offenders.

---

## 5. Configuration

Two new settings, both under `PAM_VAULT_`:

```
PAM_VAULT_SERVICE_TOKEN_PEPPER   # HMAC pepper for token hashes, >= 32 bytes
PAM_VAULT_DEFAULT_SECRET_TTL_SEC # server-authoritative cache lifetime, default 300
```

In **development** the pepper is derived from the vault encryption key if unset,
so nothing extra is needed to run locally. In **production** an unset or
too-short pepper is a **fatal** start-up error — a machine credential store
whose token hashes are unpeppered is not something to warn about and continue
past.

Migrations run automatically: `pam_service_identities`, `pam_service_tokens`,
`pam_service_grants`.

---

## 6. What I did not do, and one thing to know

- **`pkg/vaultclient`** (the consumer SDK with singleflight, async refresh at
  75% of TTL, stale-serve and hard-evict on 401/403/404) is ported and unit
  tested, but no application in this repository consumes it yet.
- **The preview loads one request per safe** for folders and credentials. Fine
  for a handful of safes and it only fires when a grant form is open; a vault
  with hundreds of safes wants a flat server-side path index instead, and the
  endpoint to add then is a path list, not a faster loop.
- **Two pre-existing `react-hooks/exhaustive-deps` warnings** exist in
  `CreatePolicyModal.jsx` and `CreateRoleModal.jsx`. They are not mine and
  `npm run lint` passes, so I left them alone rather than widening this diff.
- **`npm run verify` cannot run** in the zip you sent: `package.json` references
  `tools/check-exports.cjs` and `tools/mock-api/`, and the `tools/` directory is
  not in the archive. `npm run lint` and `npm run build` both pass.
