# MFA Policy — admins can now apply it too

Group-gated MFA (the role IS the group) was **root-only for writes**. It is now
**admin or root**, on both sides of the wire.

Reads were already admin-or-root and are unchanged.

## Files

### Backend (`backend/`)

| File | Change |
|---|---|
| `internal/services/mfa_policy.go` | New `canManageMFAPolicy(roles)` — root **or** admin — and both writes (`UpsertRule`, `DeleteRule`) now call it instead of checking `RoleRoot` separately. One function so the two writes cannot drift apart. `ErrMFAPolicyForbidden` text updated. |
| `internal/services/mfa_policy_test.go` | New `TestCanManageMFAPolicy` covering root, admin, mixed roles, case variants, and the deny cases including the near-misses `administrator` and `rooted`. |
| `internal/api/handlers/mfa_policy_handler.go` | Both 403 messages now say "Only admin or root users can change MFA policy"; header comment rewritten. |
| `cmd/pam-api/main.go` | Route-group comment only — no route change. |

The check deliberately stays in the **service**, not on the route:
`RequireAdmin` admits every admin to every route in that group, so a
route-level check would be checking the group rather than the caller.

### Frontend (`UI/src/`)

| File | Change |
|---|---|
| `pages/admin/MfaPolicyPage.jsx` | `isRoot()` → `isAdmin()` (true for admin **and** root) for the four gates: the read-only badge, the "no role requires MFA yet" prompt, each row's Edit / Require-MFA button, and the rule editor itself. Copy updated ("Root only" chip → "Read-only"). |
| `api/mfaPolicy.js` | Header comment — writes are admin-or-root now. |

## One thing worth knowing

The original root-only rule existed because an admin who can edit the rule
gating admins can also switch it off — so the control becomes self-editable.
That is now the case by design; what makes it accountable is the audit record,
which already names the acting user on every write
(`mfa_policy.rule.created` / `.updated` / `.deleted`). This is the same posture
Okta and Entra take for authentication policy.

## Verification

- `gofmt -l` clean · `go build ./...` · `go vet ./...` · `go test ./internal/services/` — all pass.
- `npm run lint` clean apart from the 4 pre-existing baseline issues
  (`nav.js`, `useMfaStatus.js`, `validators.js`) · `npm run build` succeeds.
