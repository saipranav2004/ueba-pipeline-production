import { useCallback, useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { useQuery } from '@tanstack/react-query'
import { Link, useSearchParams } from 'react-router-dom'
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  Controls,
  useReactFlow,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import {
  ArrowUpRight,
  ChevronLeft,
  Clock,
  Database,
  FileKey2,
  KeyRound,
  Maximize2,
  Minimize2,
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightOpen,
  RotateCcw,
  Route as RouteIcon,
  Search,
  Share2,
  ShieldCheck,
  ShieldOff,
  Target,
  UserRound,
  X,
  Layers,
} from 'lucide-react'
import clsx from 'clsx'
import { listUsers } from '../../api/identity'
import { getMemberGraph } from '../../api/identityGraph'
import {
  LEVELS,
  REVEAL_BATCH,
  buildTree,
  isMoreNode,
  layout,
  subtreeCount,
  pathNodes,
  pathToRoot,
  summarise,
  visibleNodes,
} from '../../lib/identityGraph'
import GraphNodeCard from '../../components/graph/GraphNode'
import { PageTitle, Stack } from '../../components/ui/layout'
import { Button } from '../../components/common/Button'
import { DeniedState, EmptyState, ErrorState, OfflineState } from '../../components/ui/states'
import { apiErrorMessage, normalizeApiError } from '../../lib/apiError'
import { formatDateTime } from '../../lib/format'
import { SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Identity graph
// ---------------------------------------------------------------------------
// "How is this account actually assembled, and what can it reach?"
//
// THE ONE DESIGN DECISION THIS PAGE IS BUILT ON: it never draws the whole
// graph. A single ordinary account returns around a hundred nodes, and a
// hundred nodes drawn at once is a hairball that answers nothing. Every
// product that does attack-path and access visualisation well collapses the
// graph and lets the reader open one branch at a time, keeping a count on the
// closed ones so nothing is silently hidden. That is the model here:
//
//   01 ACCOUNT -> 02 GRANTS -> 03 POLICIES -> 04 REACH
//
// Opening a card reveals only its own children. The branch you are reading
// stays fully lit; everything else dims rather than disappearing, so you keep
// your bearings while following a path.
//
// The colours are this console's own semantic tokens, not a second palette. A
// canvas is still part of the product, and a graph that invents its own reds
// and ambers teaches the reader that colour means something different here
// than it does on every other screen.

const nodeTypes = { identity: GraphNodeCard }

// ── Small pieces ───────────────────────────────────────────────────────────

// Screen furniture, so it behaves like screen furniture. The first version
// positioned each label at its column's x, which cannot work: the canvas pans
// and zooms underneath, so the labels drifted off their columns the moment
// anyone moved the view and the last one slid under the detail panel. This
// reports how many nodes are open at each level and never pretends to be
// anchored to the scene.
//
// Numbered, because the levels are a sequence and not a set: an account leads
// to grants, grants carry policies, policies reach things. The number is what
// makes that readable at a glance without a sentence explaining it.
function LevelRail({ counts }) {
  return (
    <div className="pointer-events-none absolute left-3 top-3 z-10 flex items-center gap-3 rounded-lg border border-line-soft bg-surface/90 px-2.5 py-1.5 backdrop-blur">
      {LEVELS.map((l) => {
        const open = counts[l.index] > 0
        return (
          <span key={l.key} className="flex items-center gap-1.5">
            <span className={clsx('tabular text-2xs font-bold', open ? 'text-accent' : 'text-tertiary/60')}>
              {String(l.index + 1).padStart(2, '0')}
            </span>
            <span
              className={clsx(
                'text-2xs font-semibold uppercase tracking-[0.08em]',
                open ? 'text-primary' : 'text-tertiary/60'
              )}
            >
              {l.label}
            </span>
            {open && (
              <span className="tabular rounded bg-accent-soft px-1 text-2xs font-bold text-accent">
                {counts[l.index]}
              </span>
            )}
          </span>
        )
      })}
    </div>
  )
}

/**
 * What the canvas is drawing, and what it is not.
 *
 * Progressive disclosure only works if it is honest about itself. Without this
 * the reader has no way to tell a fully opened branch from one that stopped at
 * ten, so the canvas states both numbers in one line at the top of itself.
 */
function ShowingPill({ shown, total }) {
  const hidden = Math.max(0, total - shown)
  return (
    <span className="hidden items-center rounded-full border border-line-soft bg-subtle px-2.5 py-1 text-2xs text-secondary lg:inline-flex">
      <span className="tabular font-semibold text-primary">{shown}</span>
      <span className="px-1">of</span>
      <span className="tabular font-semibold text-primary">{total}</span>
      <span className="pl-1 text-tertiary">
        {hidden > 0 ? 'objects, open a branch for more' : 'objects, everything is open'}
      </span>
    </span>
  )
}

const LEGEND = [
  { tone: 'bg-danger', label: 'Secret or full access' },
  { tone: 'bg-warn', label: 'Standing access' },
  { tone: 'bg-ok', label: 'Time boxed or deny' },
  { tone: 'bg-accent', label: 'Structure' },
  { tone: 'bg-line-strong', label: 'Informational' },
]

// NO LEGEND ON THE CANVAS. It lived bottom-left, wrapped to two lines as soon
// as the canvas got a third column, and collided with the zoom controls. It is
// also reference material rather than something you consult mid-gesture, so it
// belongs where the rest of the reading is: the bottom of the detail panel.

// ── Panel pieces ───────────────────────────────────────────────────────────
//
// The rule this panel is built to, and the one the first version broke: SAY IT
// IN A NUMBER OR A LABEL, NOT IN A SENTENCE. A rail that explains each finding
// in two lines of prose reads as documentation, and nobody reads documentation
// while they are looking at a picture. The information is the same; it is
// carried by a headline figure, a grid of counts and a short label each,
// because that is what can be taken in at a glance beside a canvas.

function PanelLead({ icon: Icon, eyebrow, title, hint }) {
  return (
    <div className="flex items-start gap-2.5">
      <span className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-accent-soft text-accent">
        <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
      </span>
      <div className="min-w-0">
        {eyebrow && (
          <p className="text-2xs font-semibold uppercase tracking-[0.08em] text-tertiary">{eyebrow}</p>
        )}
        <p className="mt-0.5 text-sm font-bold text-primary">{title}</p>
        {hint && <p className="mt-0.5 text-xs leading-relaxed text-tertiary">{hint}</p>}
      </div>
    </div>
  )
}

/** The one figure the panel leads with. */
function HeroMetric({ label, value, hint }) {
  return (
    <div className="rounded-xl border border-accent/25 bg-accent-soft px-4 py-4 text-center">
      <p className="text-2xs font-semibold uppercase tracking-[0.08em] text-accent">{label}</p>
      <p className="tabular mt-1 text-4xl font-bold leading-none text-primary">{value}</p>
      <p className="mt-1.5 text-2xs text-tertiary">{hint}</p>
    </div>
  )
}

function StatTile({ icon: Icon, label, value, tone }) {
  return (
    <div className="rounded-lg border border-line-soft px-2.5 py-2">
      <div className="flex items-center gap-1.5">
        <Icon className="h-3 w-3 flex-none text-tertiary" strokeWidth={1.9} />
        <span
          className={clsx(
            'tabular text-lg font-bold leading-none',
            tone === 'warn' ? 'text-warn' : tone === 'danger' ? 'text-danger' : 'text-primary'
          )}
        >
          {value}
        </span>
      </div>
      <p className="mt-1 text-2xs leading-tight text-tertiary">{label}</p>
    </div>
  )
}

/**
 * The risk chips under the account name.
 *
 * These replace the paragraph-per-finding list that was here. A chip carries
 * the same fact in three words, sits next to the name it is about, and can be
 * read without being read: the colour alone says whether there is anything to
 * look at.
 */
function RiskChips({ stats, user }) {
  const chips = []
  if (!user?.mfa_enabled) chips.push({ tone: 'danger', label: 'No MFA' })
  if (stats.credentials > 0) chips.push({ tone: 'danger', label: `${stats.credentials} revealable` })
  if (stats.standing > 0) chips.push({ tone: 'warn', label: `${stats.standing} standing` })
  if (stats.directPolicies > 0) chips.push({ tone: 'warn', label: `${stats.directPolicies} direct` })
  if (user?.status && user.status !== 'ACTIVE') chips.push({ tone: 'muted', label: user.status })
  if (user?.is_protected) chips.push({ tone: 'accent', label: 'Protected' })
  if (chips.length === 0) chips.push({ tone: 'ok', label: 'Nothing standing' })

  const TONE = {
    danger: 'border-danger/35 bg-danger-soft text-danger',
    warn: 'border-warn/35 bg-warn-soft text-warn',
    ok: 'border-ok/35 bg-ok-soft text-ok',
    accent: 'border-accent/35 bg-accent-soft text-accent',
    muted: 'border-line bg-subtle text-secondary',
  }

  return (
    <div className="flex flex-wrap gap-1">
      {chips.map((c) => (
        <span
          key={c.label}
          className={clsx(
            'rounded border px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-wide',
            TONE[c.tone]
          )}
        >
          {c.label}
        </span>
      ))}
    </div>
  )
}

// ── Access path ────────────────────────────────────────────────────────────
//
// THE REASON THIS PAGE IS A GRAPH AND NOT A LIST.
//
// "Can this account reach the payments database" is a yes or no that a table
// can answer. "Through what" is the question a graph exists for, and it is the
// one that matters operationally: the hop is the thing that can be revoked.
//
// Each step names the RELATION in two words, the way an attack-path view
// labels its edges, rather than explaining itself in a clause.

const PATH_ICON = {
  user: UserRound,
  role: ShieldCheck,
  policy: FileKey2,
  direct_policy: FileKey2,
  resource: Database,
  credential: KeyRound,
}

/** The relation that gets you from the previous hop to this one. */
function relationInto(node) {
  switch (node.kind) {
    case 'role':
      return node.meta?.roleKind === 'user_type' ? 'user type' : 'member of'
    case 'direct_policy':
      return 'attached'
    case 'policy':
      return String(node.meta?.effect || '').toLowerCase() === 'deny' ? 'denies' : 'allows'
    case 'resource':
      return 'reaches'
    case 'credential':
      return 'reveals'
    default:
      return 'then'
  }
}

const KIND_LABEL = {
  user: 'Account',
  role: 'Role',
  direct_policy: 'Direct policy',
  policy: 'Policy',
  resource: 'Resource',
  credential: 'Credential',
  capability: 'Capability',
}

function AccessPath({ nodes, onSelect }) {
  if (!nodes || nodes.length < 2) return null
  return (
    <ol>
      {nodes.map((n, i) => {
        const Icon = PATH_ICON[n.kind] || Layers
        const last = i === nodes.length - 1
        return (
          <li key={n.id}>
            {i > 0 && (
              <div className="flex items-center gap-2 py-1 pl-[0.4375rem]">
                <span className="h-3 w-px flex-none bg-line" aria-hidden="true" />
                <span className="text-2xs font-semibold uppercase tracking-[0.08em] text-tertiary">
                  {relationInto(n)}
                </span>
              </div>
            )}
            <button
              type="button"
              onClick={() => onSelect(n.id)}
              className={clsx(
                'flex w-full items-center gap-2 rounded-lg border px-2 py-1.5 text-left transition-colors',
                last
                  ? 'border-accent/35 bg-accent-soft'
                  : 'border-line-soft bg-surface hover:border-line hover:bg-hover'
              )}
            >
              <span
                className={clsx(
                  'flex h-5 w-5 flex-none items-center justify-center rounded',
                  last ? 'text-accent' : 'text-tertiary'
                )}
              >
                <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
              </span>
              <span className="min-w-0 flex-1">
                <span
                  className={clsx(
                    'block truncate text-xs font-semibold',
                    last ? 'text-accent' : 'text-primary'
                  )}
                  title={n.label}
                >
                  {n.label}
                </span>
              </span>
              <span className="flex-none text-2xs uppercase tracking-wide text-tertiary">
                {KIND_LABEL[n.kind] || n.kind}
              </span>
            </button>
          </li>
        )
      })}
    </ol>
  )
}

// ── The right rail ─────────────────────────────────────────────────────────
//
// Two modes, and the switch between them is the whole design. With nothing
// selected it is an ACCOUNT OVERVIEW: how much this account reaches and what
// is worth looking at. With a card selected it becomes an OBJECT VIEW: what
// that object is, how the account arrived at it, and where to go to change it.
//
// Cloudscape's guidance is the reason it is not one scrolling column holding
// both: a panel that stacks a summary the reader has finished with on top of
// the thing they just clicked buries the answer under the context.

/**
 * A wrapped row of monospace chips.
 *
 * A policy's actions are the densest thing in the panel and were the tallest:
 * ten one-per-line entries pushed everything under them off the screen. They
 * are short tokens, not sentences, so they wrap like tokens.
 */
function ChipList({ label, items, empty, tone = 'muted' }) {
  const list = Array.isArray(items) ? items : []
  const TONE = {
    accent: 'border-accent/25 bg-accent-soft text-accent',
    ok: 'border-ok/30 bg-ok-soft text-ok',
    muted: 'border-line-soft bg-subtle text-secondary',
  }
  return (
    <div>
      <p className="text-2xs font-semibold uppercase tracking-[0.08em] text-tertiary">{label}</p>
      {list.length === 0 ? (
        <p className="mt-1.5 text-xs text-tertiary">{empty}</p>
      ) : (
        <div className="mt-1.5 flex flex-wrap gap-1">
          {list.map((v) => (
            <span
              key={v}
              className={clsx(
                'break-all rounded border px-1.5 py-0.5 font-mono text-2xs',
                TONE[tone] || TONE.muted
              )}
            >
              {v}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

function PanelSection({ children, className = '' }) {
  return (
    <section className={clsx('border-b border-line-soft px-4 py-4', className)}>{children}</section>
  )
}

function Definitions() {
  return (
    <PanelSection className="border-b-0">
      <p className="text-2xs font-semibold uppercase tracking-[0.08em] text-tertiary">
        What the colours mean
      </p>
      <ul className="mt-2 space-y-1.5">
        {LEGEND.map((l) => (
          <li key={l.label} className="flex items-center gap-2 text-xs text-secondary">
            <span className={clsx('h-2 w-2 flex-none rounded-sm', l.tone)} aria-hidden="true" />
            {l.label}
          </li>
        ))}
      </ul>
    </PanelSection>
  )
}

function AccountView({ tree, stats }) {
  const reach = useMemo(() => subtreeCount(tree), [tree])

  return (
    <>
      <PanelSection>
        <PanelLead
          icon={Target}
          eyebrow="Access reach"
          title="What can this account touch?"
          hint="Everything the canvas can be opened to show, counted from the same tree."
        />
        <div className="mt-3">
          <HeroMetric
            label="Reachable objects"
            value={reach}
            hint="roles, policies, resources and secrets below this account"
          />
        </div>
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <StatTile icon={Database} label="Resources" value={stats.resources} />
          <StatTile
            icon={KeyRound}
            label="Revealable secrets"
            value={stats.credentials}
            tone={stats.credentials > 0 ? 'danger' : undefined}
          />
          <StatTile
            icon={ShieldCheck}
            label="Standing, no request"
            value={stats.standing}
            tone={stats.standing > 0 ? 'warn' : undefined}
          />
          <StatTile icon={Clock} label="Behind a JIT gate" value={stats.jitGated} />
          <StatTile icon={FileKey2} label={`Policies, ${stats.denyPolicies} deny`} value={stats.policies} />
          <StatTile
            icon={Layers}
            label="Direct, outside a role"
            value={stats.directPolicies}
            tone={stats.directPolicies > 0 ? 'warn' : undefined}
          />
        </div>
      </PanelSection>

      <PanelSection>
        <p className="flex items-start gap-2 text-xs leading-relaxed text-secondary">
          <Share2 className="mt-0.5 h-3.5 w-3.5 flex-none text-tertiary" strokeWidth={1.9} />
          <span>Open one branch at a time. Each card says how much sits underneath it.</span>
        </p>
      </PanelSection>

      <Definitions />
    </>
  )
}

function SelectedView({ tree, selected, onSelect, onBack }) {
  const path = useMemo(() => pathNodes(tree, selected.id), [tree, selected.id])
  const Icon = PATH_ICON[selected.kind] || Layers

  // Only where a real page exists for the object. A dead link that 404s is
  // worse than no link, so policies and credentials, which have no detail
  // route, simply do not get one.
  const href =
    selected.kind === 'resource'
      ? `/resources/${selected.id.replace(/^resource:/, '')}`
      : selected.kind === 'role'
        ? `/admin/roles/${selected.id.replace(/^role:/, '')}`
        : selected.kind === 'user'
          ? `/admin/identity/${selected.meta?.id || ''}`
          : null

  const facts =
    selected.kind === 'resource'
      ? [
          ['Type', selected.sublabel],
          ['Access', selected.badge],
          ['JIT gated', selected.meta?.requiresJit ? 'Yes' : 'No'],
          ['Always recorded', selected.meta?.alwaysRecord ? 'Yes' : 'No'],
          ['Active', selected.meta?.active ? 'Yes' : 'No'],
        ]
      : selected.kind === 'role'
        ? [
            ['Kind', selected.meta?.roleKind === 'user_type' ? 'User type' : 'Additional role'],
            ['Origin', selected.meta?.isSystem ? 'System' : 'Custom'],
            ['Policies', selected.childCount],
          ]
        : selected.kind === 'credential'
          ? [
              ['Type', selected.meta?.type || 'Secret'],
              ['Account', selected.meta?.account || 'Not recorded'],
            ]
          : []

  return (
    <>
      <div className="flex items-center gap-2 border-b border-line-soft px-4 py-2">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1 rounded px-1 py-0.5 text-xs font-medium text-secondary transition-colors hover:text-accent"
        >
          <ChevronLeft className="h-3.5 w-3.5 flex-none" strokeWidth={2} />
          Account overview
        </button>
      </div>

      <PanelSection>
        <div className="flex items-start gap-2.5">
          <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-line-soft bg-subtle text-tertiary">
            <Icon className="h-4 w-4" strokeWidth={1.8} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="break-words text-sm font-bold text-primary">{selected.label}</p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-2xs uppercase tracking-wide text-tertiary">
              <span>{KIND_LABEL[selected.kind] || selected.kind}</span>
              {selected.badge && (
                <span
                  className={clsx(
                    'font-semibold',
                    selected.tone === 'danger'
                      ? 'text-danger'
                      : selected.tone === 'warn'
                        ? 'text-warn'
                        : selected.tone === 'ok'
                          ? 'text-ok'
                          : 'text-accent'
                  )}
                >
                  {selected.badge}
                </span>
              )}
            </p>
          </div>
        </div>
        {href && (
          <Link
            to={href}
            className="mt-2.5 inline-flex items-center gap-1.5 text-xs font-semibold text-accent transition-colors hover:text-accent-hover hover:underline"
          >
            Open the full record
            <ArrowUpRight className="h-3.5 w-3.5 flex-none" strokeWidth={2} />
          </Link>
        )}
      </PanelSection>

      {path.length > 1 && (
        <PanelSection>
          <PanelLead icon={RouteIcon} eyebrow="Access path" title="How the account gets here" />
          <div className="mt-3">
            <AccessPath nodes={path} onSelect={onSelect} />
          </div>
        </PanelSection>
      )}

      {facts.length > 0 && (
        <PanelSection>
          <dl className="space-y-1.5">
            {facts.map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between gap-3">
                <dt className="text-xs text-tertiary">{k}</dt>
                <dd className="text-xs font-medium text-primary">{v}</dd>
              </div>
            ))}
          </dl>
          {selected.meta?.standing && (
            <p className="mt-2.5 rounded-lg border border-warn/35 bg-warn-soft px-2.5 py-1.5 text-xs leading-relaxed text-primary">
              Standing access. Reachable right now, with nothing to request.
            </p>
          )}
          {selected.kind === 'credential' && (
            <p className="mt-2.5 rounded-lg border border-danger/35 bg-danger-soft px-2.5 py-1.5 text-xs leading-relaxed text-primary">
              A policy on this account can reveal this secret in plaintext.
            </p>
          )}
        </PanelSection>
      )}

      {(selected.kind === 'policy' || selected.kind === 'direct_policy') && (
        <PanelSection>
          <ChipList
            label="Actions"
            items={selected.meta?.actions}
            empty="None recorded"
            tone={String(selected.meta?.effect || '').toLowerCase() === 'deny' ? 'ok' : 'accent'}
          />
          <div className="mt-3">
            <ChipList
              label="Resource patterns"
              items={selected.meta?.patterns}
              empty="None. Matches nothing on its own."
            />
          </div>
        </PanelSection>
      )}

      {selected.meta?.description && (
        <PanelSection>
          <p className="text-xs leading-relaxed text-secondary">{selected.meta.description}</p>
        </PanelSection>
      )}

      <Definitions />
    </>
  )
}

function DetailPanel({ graph, tree, selected, onSelect, onClose }) {
  const stats = useMemo(() => summarise(tree), [tree])
  const user = graph?.user || {}

  return (
    <aside className="flex h-full w-full flex-col overflow-y-auto border-l border-line bg-surface">
      <div className="sticky top-0 z-10 border-b border-line-soft bg-surface px-4 py-3">
        <div className="flex items-start gap-2.5">
          <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-accent-soft text-sm font-bold text-accent">
            {(user.username || '?').slice(0, 2).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-base font-bold leading-tight text-primary">{user.username}</p>
            <p className="truncate text-xs text-tertiary">{user.full_name || user.email}</p>
          </div>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close panel"
              className="flex h-7 w-7 flex-none items-center justify-center rounded-lg text-tertiary transition-colors hover:bg-hover hover:text-primary"
            >
              <X className="h-4 w-4" strokeWidth={1.8} />
            </button>
          )}
        </div>
        <div className="mt-2">
          <RiskChips stats={stats} user={user} />
        </div>
      </div>

      {selected ? (
        <SelectedView
          tree={tree}
          selected={selected}
          onSelect={onSelect}
          onBack={() => onSelect(null)}
        />
      ) : (
        <AccountView tree={tree} stats={stats} />
      )}

      {graph?.built_at && (
        <p className="mt-auto border-t border-line-soft px-4 py-2.5 text-2xs text-tertiary">
          Built {formatDateTime(graph.built_at)}
        </p>
      )}
    </aside>
  )
}

// ── Canvas ─────────────────────────────────────────────────────────────────

function Canvas({ tree, expanded, revealed, onToggle, onReveal, selectedId, onSelect }) {
  const { fitView } = useReactFlow()

  const nodes = useMemo(() => visibleNodes(tree, expanded, revealed), [tree, expanded, revealed])
  const positions = useMemo(() => layout(nodes), [nodes])

  // The lit branch: root down to whatever is selected. Used to keep one path
  // at full strength while the rest recedes.
  const lit = useMemo(() => new Set(selectedId ? pathToRoot(tree, selectedId) : []), [tree, selectedId])

  const rfNodes = useMemo(
    () =>
      nodes.map((n) => ({
        id: n.id,
        type: 'identity',
        position: positions.get(n.id) || { x: 0, y: 0 },
        draggable: false,
        selectable: true,
        data: {
          ...n,
          selected: n.id === selectedId,
          // A "more" card inherits its parent's lit state: it stands in for
          // that parent's children, so dimming it while the branch is lit
          // would hide the one control that finishes reading the branch.
          onLit: lit.has(n.id) || (isMoreNode(n) && lit.has(n.parentOf)),
          dimmed: lit.size > 0 && !lit.has(n.id) && !(isMoreNode(n) && lit.has(n.parentOf)),
        },
      })),
    [nodes, positions, selectedId, lit]
  )

  const rfEdges = useMemo(
    () =>
      nodes
        .filter((n) => n.parentId)
        .map((n) => {
          const onPath = lit.has(n.id) && lit.has(n.parentId)
          return {
            id: `${n.parentId}->${n.id}`,
            source: n.parentId,
            target: n.id,
            type: 'smoothstep',
            // The relation, named, and only where it is being read. An
            // attack-path view earns its edges by saying what each one IS
            // ("member of", "allows", "reaches"); labelling all forty at once
            // would bury the picture in captions, so only the lit branch,
            // which is the one the reader is following, carries them.
            label: onPath && !isMoreNode(n) ? relationInto(n) : undefined,
            labelBgPadding: [6, 2],
            labelBgBorderRadius: 4,
            labelBgStyle: { fill: 'rgb(var(--bg-surface))', fillOpacity: 0.95 },
            labelStyle: {
              fill: 'rgb(var(--accent))',
              fontSize: 10,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
            },
            // Only the lit branch animates. Animating every edge is how a
            // canvas turns into a screensaver: motion stops meaning anything
            // once it is everywhere.
            animated: onPath,
            style: {
              stroke: onPath ? 'rgb(var(--accent))' : 'rgb(var(--border))',
              strokeWidth: onPath ? 2 : 1.25,
              strokeDasharray: onPath ? '6 5' : undefined,
              opacity: lit.size > 0 && !onPath ? 0.35 : 1,
              transition: 'stroke 200ms ease, opacity 200ms ease',
            },
          }
        }),
    [nodes, lit]
  )

  // Refit when the visible set changes, so opening a branch never leaves the
  // new cards off screen. Deferred a frame so React Flow measures first.
  //
  // minZoom MATTERS HERE. A policy can match forty resources, and fitting a
  // column that tall to the viewport shrinks every card until the labels are
  // grey smears, which defeats the point of opening the branch at all. The
  // floor keeps the cards readable and lets a long column overflow instead;
  // readable-and-pannable beats complete-and-illegible.
  const count = rfNodes.length
  useEffect(() => {
    const t = setTimeout(
      () => fitView({ duration: 450, padding: 0.18, minZoom: 0.62, maxZoom: 1 }),
      60
    )
    return () => clearTimeout(t)
  }, [count, fitView])

  const levelCounts = useMemo(() => {
    const c = [0, 0, 0, 0]
    // "more" cards are chrome, not objects, so they are not counted as one.
    for (const n of nodes) if (!isMoreNode(n)) c[n.level] = (c[n.level] || 0) + 1
    return c
  }, [nodes])


  const handleNodeClick = useCallback(
    (_e, node) => {
      const model = nodes.find((n) => n.id === node.id)
      // A "more" card is a control, not an object. Selecting it would light a
      // branch that ends in a button and replace the panel's contents with
      // nothing worth reading, so it only ever reveals.
      if (model && isMoreNode(model)) {
        onReveal(model.parentOf)
        return
      }
      onSelect(node.id)
      if (model && !model.isLeaf) onToggle(node.id)
    },
    [nodes, onSelect, onToggle, onReveal]
  )

  return (
    <>
      <LevelRail counts={levelCounts} />
      <ReactFlow
        nodes={rfNodes}
        edges={rfEdges}
        nodeTypes={nodeTypes}
        onNodeClick={handleNodeClick}
        onPaneClick={() => onSelect(null)}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable
        proOptions={{ hideAttribution: true }}
        minZoom={0.25}
        maxZoom={1.6}
        defaultEdgeOptions={{ type: 'smoothstep' }}
        fitView
        fitViewOptions={{ padding: 0.18, minZoom: 0.62, maxZoom: 1 }}
      >
        <Background variant={BackgroundVariant.Dots} gap={22} size={1} className="opacity-60" />
        {/* NO MINIMAP, deliberately. A minimap earns its place when the scene
            is bigger than the viewport, and progressive disclosure means this
            one never is: the canvas holds an account, its grants, and one
            opened branch, which is a dozen or two cards. An overview of a
            scene that already fits is decoration, and it was rendering as an
            empty grey rectangle in the corner. */}
        <Controls
          showInteractive={false}
          position="bottom-right"
          className="!rounded-lg !border !border-line-soft !bg-surface !shadow-card"
        />
      </ReactFlow>
    </>
  )
}

// ── Account rail ───────────────────────────────────────────────────────────
//
// The account picker was a native <select> beside a search box that did not
// visibly do anything: you typed, the dropdown quietly re-populated, and you
// still had to open it to find out what you had matched. Typing into a search
// field should narrow a list you can see.
//
// So the two controls are one control. The field filters the list underneath
// it as each character lands, and the list carries the things you pick an
// account BY: whether it is active, whether MFA is on it, what it is called in
// full. That is the same shape Okta's people list and the AWS console's
// resource pickers use, for the same reason.
function AccountRail({ query, onQuery, users, loading, error, activeId, onPick, onClose }) {
  return (
    <div className="flex h-full w-full flex-col border-r border-line bg-surface">
      <div className="flex items-center gap-2 border-b border-line-soft px-3 py-2.5">
        <span className="text-xs font-semibold uppercase tracking-wide text-tertiary">Accounts</span>
        {typeof users?.length === 'number' && !loading && (
          <span className="tabular text-2xs font-semibold text-secondary">{users.length}</span>
        )}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Hide the account list"
            className="ml-auto flex h-6 w-6 flex-none items-center justify-center rounded text-tertiary transition-colors hover:bg-hover hover:text-primary"
          >
            <PanelLeftClose className="h-4 w-4" strokeWidth={1.8} />
          </button>
        )}
      </div>

      <div className="border-b border-line-soft p-2.5">
        <label className="relative flex items-center">
          <Search
            className="pointer-events-none absolute left-2.5 h-3.5 w-3.5 text-tertiary"
            strokeWidth={1.8}
          />
          <input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Filter by name or email"
            aria-label="Filter accounts"
            className="h-8 w-full rounded-lg border border-line-strong bg-surface pl-8 pr-7 text-sm text-primary transition-colors placeholder:text-tertiary hover:border-primary/40 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
          />
          {query && (
            <button
              type="button"
              onClick={() => onQuery('')}
              aria-label="Clear the filter"
              className="absolute right-1.5 flex h-5 w-5 items-center justify-center rounded text-tertiary transition-colors hover:bg-hover hover:text-primary"
            >
              <X className="h-3.5 w-3.5" strokeWidth={2} />
            </button>
          )}
        </label>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-1.5">
        {loading ? (
          <p className="px-2 py-3 text-xs text-tertiary">Loading accounts</p>
        ) : error ? (
          <p className="px-2 py-3 text-xs leading-relaxed text-warn">{error}</p>
        ) : users.length === 0 ? (
          <p className="px-2 py-3 text-xs leading-relaxed text-tertiary">
            {query ? `No account matches "${query}".` : 'No accounts to show.'}
          </p>
        ) : (
          <ul className="space-y-0.5">
            {users.map((u) => {
              const active = u.user_id === activeId
              return (
                <li key={u.user_id}>
                  <button
                    type="button"
                    onClick={() => onPick(u.user_id)}
                    aria-current={active ? 'true' : undefined}
                    className={clsx(
                      'flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors',
                      active ? 'bg-accent-soft' : 'hover:bg-hover'
                    )}
                  >
                    <span
                      className={clsx(
                        'flex h-7 w-7 flex-none items-center justify-center rounded-lg text-2xs font-bold',
                        active ? 'bg-accent text-white' : 'bg-subtle text-tertiary'
                      )}
                    >
                      {(u.username || '?').slice(0, 2).toUpperCase()}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span
                        className={clsx(
                          'block truncate text-sm font-medium',
                          active ? 'text-accent' : 'text-primary'
                        )}
                      >
                        {u.username}
                      </span>
                      <span className="block truncate text-2xs text-tertiary">
                        {u.full_name || u.email}
                      </span>
                    </span>
                    {/* The two facts worth carrying at this size. A dormant or
                        locked account and an account with no MFA are both
                        reasons to look at it, and both are invisible once you
                        are inside the graph. */}
                    <span className="flex flex-none items-center gap-1">
                      {!u.mfa_enabled && (
                        <ShieldOff
                          className="h-3.5 w-3.5 text-danger"
                          strokeWidth={1.9}
                          aria-label="MFA not enrolled"
                        />
                      )}
                      {u.status && u.status !== 'ACTIVE' && (
                        <span className="rounded bg-subtle px-1 py-0.5 text-2xs font-semibold uppercase tracking-wide text-tertiary">
                          {u.status}
                        </span>
                      )}
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}

// ── Page ───────────────────────────────────────────────────────────────────

export default function IdentityGraphPage() {
  const [params, setParams] = useSearchParams()
  const userId = params.get('user') || ''

  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState(new Set())
  // How many children of each opened parent have been asked for. Absent means
  // the first batch; see REVEAL_BATCH.
  const [revealed, setRevealed] = useState({})
  const [selectedId, setSelectedId] = useState(null)
  const [panelOpen, setPanelOpen] = useState(true)
  const [listOpen, setListOpen] = useState(() => !userId)
  const [full, setFull] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  // TWO FILTERS, ON PURPOSE. The server query is what makes this work on an
  // org with ten thousand accounts, but it is debounced, so on its own the
  // list would visibly lag a keystroke behind the field. Filtering the loaded
  // page again on the raw input makes every character narrow the list
  // immediately, and the server result then widens it to anything the loaded
  // page did not contain.
  const users = useMemo(() => {
    const all = usersQuery.data?.users || []
    const needle = searchInput.trim().toLowerCase()
    if (!needle) return all
    return all.filter((u) =>
      [u.username, u.email, u.full_name].some((v) => String(v || '').toLowerCase().includes(needle))
    )
  }, [usersQuery.data, searchInput])

  const graphQuery = useQuery({
    queryKey: ['admin', 'identity', userId, 'graph'],
    queryFn: ({ signal }) => getMemberGraph(userId, signal),
    enabled: !!userId,
  })

  const tree = useMemo(() => buildTree(graphQuery.data), [graphQuery.data])

  // Open the account's own row on arrival, so the canvas never lands on a
  // single card with nothing to look at.
  useEffect(() => {
    if (tree) {
      setExpanded(new Set([tree.id]))
      setRevealed({})
      setSelectedId(null)
    }
  }, [tree])

  const toggle = useCallback((id) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        // Collapsing a branch closes everything under it too, otherwise
        // reopening later restores a shape the reader never chose.
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
    // And it forgets how far that branch had been revealed, for the same
    // reason: reopening starts at the first ten again rather than at whatever
    // was on screen when it was closed.
    setRevealed((prev) => {
      if (!(id in prev)) return prev
      const next = { ...prev }
      delete next[id]
      return next
    })
  }, [])

  const reveal = useCallback((parentId) => {
    setRevealed((prev) => ({ ...prev, [parentId]: (prev[parentId] ?? REVEAL_BATCH) + REVEAL_BATCH }))
  }, [])

  const selectUser = (id) => {
    const next = new URLSearchParams(params)
    if (id) next.set('user', id)
    else next.delete('user')
    setParams(next, { replace: true })
  }

  const visible = useMemo(() => visibleNodes(tree, expanded, revealed), [tree, expanded, revealed])

  const selected = useMemo(
    () => (selectedId ? visible.find((n) => n.id === selectedId) || null : null),
    [selectedId, visible]
  )

  // What the canvas is drawing against what exists. "more" cards are chrome,
  // so they are not counted as objects.
  const shownObjects = visible.filter((n) => !isMoreNode(n)).length
  const totalObjects = tree ? subtreeCount(tree) + 1 : 0

  const resetView = () => {
    if (tree) setExpanded(new Set([tree.id]))
    setRevealed({})
    setSelectedId(null)
  }

  const expandAll = () => {
    if (!tree) return
    // Deliberately bounded: opening every level of a hundred-node account is
    // the hairball this page exists to avoid. Two levels is the most that
    // stays readable, and the reader can go deeper by hand from there.
    const next = new Set([tree.id])
    for (const g of tree.children || []) next.add(g.id)
    setExpanded(next)
    setRevealed({})
  }

  // Escape leaves full view, then clears the selection. Anything that takes
  // over the whole screen has to have an exit that does not require finding a
  // button first.
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Escape') return
      if (full) setFull(false)
      else if (selectedId) setSelectedId(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [full, selectedId])

  // Full view hides the page behind it, so the page must not keep scrolling
  // underneath while it is up.
  useEffect(() => {
    if (!full) return undefined
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = prev
    }
  }, [full])

  const err = graphQuery.isError ? normalizeApiError(graphQuery.error) : null
  const activeUser = users.find((u) => u.user_id === userId) || graphQuery.data?.user || null

  const toolbar = (
    <div className="flex flex-wrap items-center gap-2 border-b border-line-soft bg-surface px-3 py-2">
      {!listOpen && (
        <button
          type="button"
          onClick={() => setListOpen(true)}
          aria-label="Show the account list"
          className="flex h-7 w-7 flex-none items-center justify-center rounded-lg text-tertiary transition-colors hover:bg-hover hover:text-primary"
        >
          <PanelLeftOpen className="h-4 w-4" strokeWidth={1.8} />
        </button>
      )}
      <span className="min-w-0 truncate text-sm font-semibold text-primary">
        {activeUser ? activeUser.username : 'No account selected'}
      </span>
      {activeUser?.full_name && (
        <span className="hidden min-w-0 truncate text-xs text-tertiary sm:inline">
          {activeUser.full_name}
        </span>
      )}
      {tree && <ShowingPill shown={shownObjects} total={totalObjects} />}

      <span className="ml-auto flex flex-wrap items-center gap-1.5">
        <Button size="sm" variant="ghost" onClick={expandAll} disabled={!tree}>
          Expand grants
        </Button>
        <Button size="sm" variant="ghost" icon={RotateCcw} onClick={resetView} disabled={!tree}>
          Reset
        </Button>
        {!panelOpen && (
          <Button size="sm" variant="ghost" icon={PanelRightOpen} onClick={() => setPanelOpen(true)}>
            Details
          </Button>
        )}
        <Button
          size="sm"
          variant={full ? 'secondary' : 'ghost'}
          icon={full ? Minimize2 : Maximize2}
          onClick={() => setFull((v) => !v)}
          disabled={!tree}
        >
          {full ? 'Exit full screen' : 'Full screen'}
        </Button>
      </span>
    </div>
  )

  const body = !userId ? (
    <div className="flex h-full items-center justify-center p-6">
      <EmptyState
        icon={UserRound}
        title="Choose an account"
        description="Pick an account from the list to see how it is assembled: its user type, the roles and policies attached to it, and the resources and credentials those actually reach."
      />
    </div>
  ) : graphQuery.isLoading ? (
    <div className="flex h-full items-center justify-center gap-3 text-sm text-secondary">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-line-strong border-t-accent" />
      Building the identity graph
    </div>
  ) : err ? (
    <div className="flex h-full items-center justify-center p-6">
      {err.status === 403 ? (
        <DeniedState description={err.message} />
      ) : err.code === 'network_error' ? (
        <OfflineState onRetry={() => graphQuery.refetch()} retrying={graphQuery.isFetching} />
      ) : (
        <ErrorState
          description={apiErrorMessage(graphQuery.error)}
          onRetry={() => graphQuery.refetch()}
          retrying={graphQuery.isFetching}
        />
      )}
    </div>
  ) : !tree ? (
    <div className="flex h-full items-center justify-center p-6">
      <EmptyState
        icon={Layers}
        title="Nothing to graph"
        description="This account holds no roles or policies, so there is no structure to draw."
      />
    </div>
  ) : (
    <>
      <div className="relative min-w-0 flex-1">
        <ReactFlowProvider>
          <Canvas
            tree={tree}
            expanded={expanded}
            revealed={revealed}
            onToggle={toggle}
            onReveal={reveal}
            selectedId={selectedId}
            onSelect={setSelectedId}
          />
        </ReactFlowProvider>
      </div>
      {panelOpen && (
        <div className={clsx('hidden flex-none lg:block', full ? 'w-[23rem]' : 'w-[21rem]')}>
          <DetailPanel
            graph={graphQuery.data}
            tree={tree}
            selected={selected}
            onSelect={setSelectedId}
            onClose={() => setPanelOpen(false)}
          />
        </div>
      )}
    </>
  )

  const shell = (
    <div
      className={clsx(
        'flex flex-col overflow-hidden bg-app',
        // FULL SCREEN MEANS FULL SCREEN. The previous version inset itself by
        // twelve pixels and started below the navbar, which is a bigger panel
        // rather than a different mode: the reader still lost a strip of
        // canvas to chrome they had explicitly asked to get out of the way.
        // This covers the viewport, and because the toolbar and both rails
        // live INSIDE the shell, nothing is left behind when it does.
        full
          ? 'fixed inset-0 z-[70] h-screen w-screen'
          : 'h-[calc(100vh-16rem)] min-h-[32rem] rounded-2xl border border-line'
      )}
    >
      {toolbar}
      <div className="flex min-h-0 flex-1">
        {listOpen && (
          <div className="hidden w-[15.5rem] flex-none md:block">
            <AccountRail
              query={searchInput}
              onQuery={setSearchInput}
              users={users}
              loading={usersQuery.isLoading}
              error={usersQuery.isError ? apiErrorMessage(usersQuery.error) : null}
              activeId={userId}
              onPick={selectUser}
              onClose={() => setListOpen(false)}
            />
          </div>
        )}
        <div className="flex min-w-0 flex-1">{body}</div>
      </div>
    </div>
  )

  return (
    <Stack gap="lg">
      <PageTitle
        title="Identity graph"
        description="How one account is assembled, and everything it can reach. Open one branch at a time: each card reports what sits underneath it, and a branch that runs wide opens ten at a time."
      />
      {/* IN FULL SCREEN THE SHELL LEAVES THE DOCUMENT FLOW ENTIRELY.
          Not for tidiness: `fixed inset-0` inside Stack was landing 24px down
          the page, because Stack spaces its children with `space-y`, which is
          a top MARGIN on every child after the first, and a margin still
          offsets a fixed element from its inset. The result was a strip of
          navbar showing above a view whose entire purpose is to have nothing
          above it. A portal onto document.body has no such parent, and it
          keeps working whatever this page is later nested inside.

          A placeholder keeps its slot so the page does not jump when full
          screen closes. */}
      {full ? (
        <>
          <div className="h-[calc(100vh-16rem)] min-h-[32rem]" aria-hidden="true" />
          {createPortal(shell, document.body)}
        </>
      ) : (
        shell
      )}
    </Stack>
  )
}
