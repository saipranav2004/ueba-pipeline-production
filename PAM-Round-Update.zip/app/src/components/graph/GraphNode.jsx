import { memo } from 'react'
import { Handle, Position } from '@xyflow/react'
import {
  ChevronDown,
  ChevronRight,
  Database,
  FileKey2,
  KeyRound,
  Layers,
  ShieldCheck,
  Sparkles,
  UserRound,
} from 'lucide-react'
import clsx from 'clsx'
import { NODE_W, NODE_H } from '../../lib/identityGraph'

// ---------------------------------------------------------------------------
// One card on the identity canvas
// ---------------------------------------------------------------------------
// The card carries four things and nothing else: what kind of object this is,
// what it is called, one line of qualifying detail, and how much is hidden
// underneath it. That last one is the whole reason the canvas is readable: a
// collapsed card that says "39 downstream" is honest about what it is not
// showing, and gives the reader a reason to open it.
//
// Colour is used sparingly and always means the same thing. The left rail
// carries the object's own risk tone, and it is the only saturated element on
// a resting card. Everything else is surface, border and text, so a canvas of
// forty cards reads as a structure rather than as forty alerts.

const KIND_ICON = {
  user: UserRound,
  role: ShieldCheck,
  policy: FileKey2,
  direct_policy: FileKey2,
  resource: Database,
  credential: KeyRound,
  capability: Sparkles,
}

const RAIL = {
  accent: 'bg-accent',
  ok: 'bg-ok',
  warn: 'bg-warn',
  danger: 'bg-danger',
  muted: 'bg-line-strong',
}

const BADGE = {
  accent: 'text-accent',
  ok: 'text-ok',
  warn: 'text-warn',
  danger: 'text-danger',
  muted: 'text-tertiary',
}

const DOT = {
  accent: 'bg-accent',
  ok: 'bg-ok',
  warn: 'bg-warn',
  danger: 'bg-danger',
  muted: 'bg-line-strong',
}

// The stand-in for a parent's hidden children.
//
// Drawn as a card in the same column as the siblings it replaces, not as a
// button floating over the canvas, because it occupies their place in the
// layout and has to read as "there is more of this here". It states both
// numbers: how many the next press adds, and how many are left after that.
function MoreCard({ data }) {
  const { label, hiddenCount, nextCount, dimmed } = data
  return (
    <div
      style={{ width: NODE_W, minHeight: NODE_H }}
      className={clsx(
        'group flex cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-line-strong bg-subtle/50 px-3 text-center transition-all duration-200',
        'hover:-translate-y-px hover:border-accent hover:bg-accent-soft',
        dimmed ? 'opacity-40' : 'opacity-100'
      )}
    >
      <span className="flex items-center gap-1.5 text-sm font-semibold text-accent">
        <ChevronDown className="h-3.5 w-3.5 flex-none" strokeWidth={2.2} />
        {label}
      </span>
      <span className="text-2xs text-tertiary">
        <span className="tabular font-semibold text-secondary">{hiddenCount}</span> still hidden
        {nextCount < hiddenCount ? ', shown ten at a time' : ''}
      </span>
      <Handle type="target" position={Position.Left} className="!h-1 !w-1 !border-0 !bg-transparent" />
    </div>
  )
}

function GraphNodeCard({ data }) {
  if (data.kind === 'more') return <MoreCard data={data} />
  return <ObjectCard data={data} />
}

function ObjectCard({ data }) {
  const {
    kind,
    label,
    sublabel,
    tone = 'muted',
    badge,
    childCount = 0,
    subtreeCount = 0,
    isExpanded,
    isLeaf,
    selected,
    onLit,
    dimmed,
  } = data

  const Icon = KIND_ICON[kind] || Layers

  return (
    <div
      style={{ width: NODE_W, minHeight: NODE_H }}
      className={clsx(
        'group relative flex flex-col justify-center overflow-hidden rounded-xl border bg-surface text-left transition-all duration-200',
        // Three resting states, and they are deliberately different in
        // STRUCTURE rather than only in colour: the selected card gets a ring
        // and lift, a card on the lit branch keeps full opacity with a soft
        // border, and everything else recedes. Dimming rather than hiding is
        // what lets a reader keep their bearings while following one path.
        selected
          ? 'border-accent shadow-pop ring-2 ring-accent/35'
          : onLit
            ? 'border-line shadow-card'
            : 'border-line-soft',
        dimmed ? 'opacity-40 saturate-[0.65]' : 'opacity-100',
        !isLeaf && 'cursor-pointer hover:-translate-y-px hover:border-line hover:shadow-pop'
      )}
    >
      {/* Risk rail. The only saturated element at rest. */}
      <span
        aria-hidden="true"
        className={clsx('absolute inset-y-0 left-0 w-[3px]', RAIL[tone] || RAIL.muted)}
      />

      <div className="flex items-start gap-2.5 px-3.5 py-2.5 pl-4">
        <span
          className={clsx(
            'mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-lg border transition-colors',
            selected ? 'border-accent/40 bg-accent-soft text-accent' : 'border-line-soft bg-subtle text-tertiary'
          )}
        >
          <Icon className="h-3.5 w-3.5" strokeWidth={1.8} />
        </span>

        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5">
            <span className="min-w-0 truncate text-sm font-semibold text-primary" title={label}>
              {label}
            </span>
          </span>
          <span className="mt-0.5 flex items-center gap-2">
            {sublabel && (
              <span className="min-w-0 truncate text-xs text-tertiary" title={sublabel}>
                {sublabel}
              </span>
            )}
            {badge && (
              <span
                className={clsx(
                  'flex-none whitespace-nowrap text-2xs font-semibold uppercase tracking-wide',
                  BADGE[tone] || BADGE.muted
                )}
              >
                {badge}
              </span>
            )}
          </span>
        </span>
      </div>

      {/* Footer only exists when there is something underneath. A leaf card
          has no affordance to press, so it does not grow one. */}
      {!isLeaf && (
        <div className="flex items-center justify-between gap-2 border-t border-line-soft bg-subtle/60 px-3.5 py-1.5 pl-4">
          <span className="flex items-center gap-1.5 text-2xs text-tertiary">
            <span className={clsx('h-1.5 w-1.5 rounded-full', DOT[tone] || DOT.muted)} aria-hidden="true" />
            <span className="tabular font-semibold text-secondary">{subtreeCount}</span> downstream
          </span>
          <span
            className={clsx(
              'flex items-center gap-0.5 text-2xs font-semibold uppercase tracking-wide transition-colors',
              isExpanded ? 'text-accent' : 'text-tertiary group-hover:text-accent'
            )}
          >
            {isExpanded ? 'Collapse' : `Expand ${childCount}`}
            <ChevronRight
              className={clsx('h-3 w-3 transition-transform duration-200', isExpanded && 'rotate-90')}
              strokeWidth={2.2}
            />
          </span>
        </div>
      )}

      {/* Handles are visually silent: the edge should appear to touch the card,
          not to plug into a port. */}
      <Handle type="target" position={Position.Left} className="!h-1 !w-1 !border-0 !bg-transparent" />
      <Handle type="source" position={Position.Right} className="!h-1 !w-1 !border-0 !bg-transparent" />
    </div>
  )
}

export default memo(GraphNodeCard)
