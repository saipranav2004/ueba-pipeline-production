// pam/internal/services/auth_service.go
package services

import (
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/argon2"
	"github.com/yourorg/pam/pkg/crypto"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	pamtotp "github.com/yourorg/pam/pkg/totp"
	"go.uber.org/zap"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

var (
	ErrInvalidCredentials = errors.New("invalid username or password")
	ErrAccountLocked      = errors.New("account is locked")
	ErrAccountDisabled    = errors.New("account is disabled")
	ErrMFARequired        = errors.New("mfa verification required")
	ErrInvalidMFACode     = errors.New("invalid mfa code")
	ErrMFANotSetup        = errors.New("mfa not set up for this user")
	ErrUserNotFound       = errors.New("user not found")
)

// RoleResolver resolves the role names a user holds. Implemented by
// *PolicyEngineService — kept as a narrow interface here (rather than
// importing the concrete type) so AuthService's dependency is exactly
// "something that can answer this one question," nothing more.
type RoleResolver interface {
	RoleNamesForUser(userID string) ([]string, error)
}

// AuthService handles PAM's complete authentication:
//   - Password verification against PAM's own local user table (Argon2id)
//   - PAM's own TOTP MFA (separate secret in pam_mfa_devices)
//   - PAM JWT issuance (HS256, self-signed), with roles resolved from
//     PAM's own RBAC tables and embedded directly in the token
//   - Session lifecycle
type AuthService struct {
	db          *gorm.DB
	jwt         *pamjwt.Issuer
	roles       RoleResolver
	mfaPolicy   *MFAPolicyService
	cryptoKey   string // AES-256 key for encrypting TOTP secrets
	maxAttempts int
	lockoutMin  int
	logger      *zap.Logger
}

// NewAuthService creates the auth service.
func NewAuthService(db *gorm.DB, jwt *pamjwt.Issuer, roles RoleResolver, cryptoKey string,
	maxAttempts, lockoutMin int, logger *zap.Logger) *AuthService {
	return &AuthService{
		db:          db,
		jwt:         jwt,
		roles:       roles,
		cryptoKey:   cryptoKey,
		maxAttempts: maxAttempts,
		lockoutMin:  lockoutMin,
		logger:      logger,
	}
}

// WithMFAPolicy attaches role-gated MFA enforcement. Additive on purpose: an
// AuthService without it behaves exactly as before, so the wiring in main.go
// is one line and nothing else has to change to adopt the feature.
func (s *AuthService) WithMFAPolicy(p *MFAPolicyService) *AuthService {
	s.mfaPolicy = p
	return s
}

// ──────────────────────────────────────────────────────────────────────────
// LOGIN (Step 1: password)
// ──────────────────────────────────────────────────────────────────────────

// LoginResult is returned from Login(). If MFA is required, MFARequired=true
// and ChallengeToken is set; the frontend should prompt for a TOTP code.
type LoginResult struct {
	MFARequired    bool      `json:"mfa_required"`
	ChallengeToken string    `json:"challenge_token,omitempty"`
	ExpiresIn      int       `json:"expires_in,omitempty"`
	AccessToken    string    `json:"access_token,omitempty"`
	RefreshToken   string    `json:"refresh_token,omitempty"`
	TokenType      string    `json:"token_type"`
	SessionID      string    `json:"session_id,omitempty"`
	ExpiresAt      time.Time `json:"expires_at,omitempty"`

	// ── Role-gated MFA enforcement (see mfa_policy.go) ──
	//
	// MFAEnrollmentRequired marks a RESTRICTED session: the password was
	// correct, but policy says this account must hold a second factor and it
	// does not. The token in AccessToken is real and is the only way the user
	// can reach the enrolment endpoints — middleware.RequireMFAEnrollment
	// refuses everything else with it. The console reads this flag and sends
	// the user straight into enrolment.
	MFAEnrollmentRequired bool `json:"mfa_enrollment_required,omitempty"`
	// MFAEnrollmentDeadline is set instead of the flag while a grace window
	// is still open: the session is a normal one, and the console counts down.
	MFAEnrollmentDeadline *time.Time `json:"mfa_enrollment_deadline,omitempty"`
	// MFARequiredByRoles names the gated roles that produced the decision, so
	// the user is told WHY ("required because you hold: admin") instead of
	// being stopped by an unexplained wall.
	MFARequiredByRoles []string `json:"mfa_required_by_roles,omitempty"`
	// MFAPolicyMode is the strongest mode that matched: monitor or enforce.
	MFAPolicyMode string `json:"mfa_policy_mode,omitempty"`

	// UsedBackupCode marks a sign-in that spent a single-use recovery code
	// rather than presenting the authenticator. The console warns on it: a
	// backup-code login usually means the device is gone, and the user should
	// re-enrol before the remaining codes run out.
	UsedBackupCode bool `json:"used_backup_code,omitempty"`
	// BackupCodesRemaining is how many are left after that spend.
	BackupCodesRemaining int `json:"backup_codes_remaining,omitempty"`
}

func (s *AuthService) Login(identifier, password, clientIP string) (*LoginResult, error) {
	// Look up the user by username or email in PAM's own local user table.
	user, err := s.findUser(identifier)
	if err != nil {
		s.logger.Info("login.user_not_found",
			zap.String("identifier", identifier),
			zap.Error(err), // ← show the ACTUAL error
		)
		return nil, ErrInvalidCredentials
	}

	// Account state checks.
	if user.Status == "LOCKED" {
		if user.LockedUntil != nil && user.LockedUntil.After(time.Now()) {
			return nil, ErrAccountLocked
		}
		// Lock window expired → auto-unlock.
		s.db.Model(&models.User{}).Where("user_id = ?", user.UserID).
			Updates(map[string]interface{}{"status": "ACTIVE", "locked_until": nil, "failed_login_attempts": 0})
		user.Status = "ACTIVE"
	}
	if user.Status == "DISABLED" || user.Status == "DELETED" {
		return nil, ErrAccountDisabled
	}

	// Verify password (Argon2id PHC format — see pkg/argon2).
	if user.PasswordHash == nil || *user.PasswordHash == "" {
		return nil, ErrInvalidCredentials
	}
	match, err := argon2.Verify(password, *user.PasswordHash)
	if err != nil {
		s.logger.Error("argon2.verify.error", zap.Error(err))
		return nil, ErrInvalidCredentials
	}
	if !match {
		s.handleFailedLogin(user.UserID, clientIP)
		return nil, ErrInvalidCredentials
	}

	// ── Password verified. Now check PAM's own MFA. ──
	mfa, err := s.getMFA(user.UserID)
	if err == nil && mfa.Status == "ACTIVE" {
		// MFA required → issue a short-lived challenge token.
		challenge := s.generateChallengeToken(user.UserID)
		s.logger.Info("login.mfa_required", zap.String("user_id", user.UserID))
		return &LoginResult{
			MFARequired:    true,
			ChallengeToken: challenge,
			ExpiresIn:      300, // 5 minutes
		}, ErrMFARequired
	}

	// ── No second factor on this account. Does policy demand one? ──
	//
	// ROLE-GATED MFA ENFORCEMENT. This is the sign-in-time evaluation: the
	// user's CURRENT roles are read on every login, so a role granted an hour
	// ago gates the next sign-in with no re-provisioning step. See
	// mfa_policy.go for the modes and the grace window.
	decision, roles := s.evaluateMFAPolicy(user, false)

	if decision.Block {
		// Restricted session: enrolment only. Not an outright refusal,
		// because enrolling REQUIRES an authenticated call — refusing the
		// login would leave a user who must enrol with no way to do it.
		s.logger.Warn("login.mfa_enrollment_required",
			zap.String("user_id", user.UserID),
			zap.Strings("gated_by", decision.MatchedRoles))
		result, issueErr := s.issueRestrictedTokensForUser(user, roles, clientIP)
		if issueErr != nil {
			return nil, issueErr
		}
		result.MFAEnrollmentRequired = true
		result.MFARequiredByRoles = decision.MatchedRoles
		result.MFAPolicyMode = decision.Mode
		return result, ErrMFAEnrollmentRequired
	}

	// THE SECURITY FIX THAT MAKES ALL OF THIS MEAN ANYTHING.
	//
	// This call used to pass `true` for mfaVerified on the no-MFA path, so
	// every account without a second factor received a token asserting it had
	// presented one. middleware.RequireMFA() — which guards vault reveal, JIT
	// approval and agent pairing — reads exactly that claim, so the gate
	// passed for precisely the users it exists to stop, and the console's
	// "MFA: verified this session" was true for accounts with no MFA at all.
	//
	// The claim now states the truth: this session did not present a second
	// factor. CONSEQUENCE, deliberately: an account with no MFA can no longer
	// reveal a credential, approve a JIT request or pair an agent until it
	// enrols. That is what RequireMFA was always supposed to do.
	result, err := s.issueTokensForUser(user, false, clientIP)
	if err != nil {
		return nil, err
	}
	if decision.Required {
		result.MFARequiredByRoles = decision.MatchedRoles
		result.MFAPolicyMode = decision.Mode
		result.MFAEnrollmentDeadline = decision.GraceUntil
		s.logger.Info("login.mfa_policy.non_compliant",
			zap.String("user_id", user.UserID),
			zap.String("mode", decision.Mode),
			zap.Strings("gated_by", decision.MatchedRoles),
			zap.Bool("in_grace", decision.GraceUntil != nil))
	}
	return result, nil
}

// RolesFor resolves the account's CURRENT role names.
//
// /auth/me uses this instead of echoing the token's roles claim: the claim is
// frozen at login, so a delegation granted or revoked mid-session would not
// reach the console until the user signed in again.
func (s *AuthService) RolesFor(userID string) ([]string, error) {
	return s.roles.RoleNamesForUser(userID)
}

// MFAStatusFor answers, for one user, the two questions /auth/me has to
// report: does this account hold a second factor, and does policy require one.
//
// It reads the live device row rather than trusting anything cached in the
// token: enrolment can complete DURING a session, and a console that only
// learned about it at the next login is precisely the bug the frontend's
// evidence workaround exists to paper over.
func (s *AuthService) MFAStatusFor(userID string) MFADecision {
	enrolled := false
	if mfa, err := s.getMFA(userID); err == nil && mfa.Status == "ACTIVE" {
		enrolled = true
	}
	if s.mfaPolicy == nil {
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}
	}
	roles, err := s.roles.RoleNamesForUser(userID)
	if err != nil {
		s.logger.Error("mfa_status.resolve_roles.fail", zap.String("user_id", userID), zap.Error(err))
		roles = []string{}
	}
	decision, err := s.mfaPolicy.Evaluate(userID, roles, enrolled, time.Now())
	if err != nil {
		s.logger.Error("mfa_status.evaluate.fail", zap.String("user_id", userID), zap.Error(err))
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}
	}
	return decision
}

// evaluateMFAPolicy resolves roles once and asks the policy service for a
// decision. Returns a zero decision when no policy service is wired, so the
// feature is genuinely optional and the auth path is unchanged without it.
func (s *AuthService) evaluateMFAPolicy(user *models.User, enrolled bool) (MFADecision, []string) {
	roles, err := s.roles.RoleNamesForUser(user.UserID)
	if err != nil {
		s.logger.Error("login.resolve_roles.fail", zap.String("user_id", user.UserID), zap.Error(err))
		roles = []string{}
	}
	if s.mfaPolicy == nil {
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}, roles
	}
	decision, err := s.mfaPolicy.Evaluate(user.UserID, roles, enrolled, time.Now())
	if err != nil {
		s.logger.Error("login.mfa_policy.evaluate.fail",
			zap.String("user_id", user.UserID), zap.Error(err))
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}, roles
	}
	return decision, roles
}

// ──────────────────────────────────────────────────────────────────────────
// MFA VERIFY (Step 2: TOTP code)
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) VerifyMFA(challengeToken, code, clientIP string) (*LoginResult, error) {
	// Decode the challenge to get user_id.
	userID, err := s.verifyChallengeToken(challengeToken)
	if err != nil {
		return nil, fmt.Errorf("invalid or expired challenge token")
	}

	// Fetch the user.
	user, err := s.findUserByID(userID)
	if err != nil {
		return nil, ErrUserNotFound
	}

	mfa, err := s.getMFA(userID)
	if err != nil || mfa.Status != "ACTIVE" {
		return nil, ErrMFANotSetup
	}

	code = strings.TrimSpace(code)

	// ── TOTP or backup code? ──
	//
	// Routed by SHAPE, not by trying both. Two reasons, and the second is the
	// one that matters: a 6-digit TOTP and a 10-hex-character backup code
	// cannot be confused, and verifying a backup code costs up to ten Argon2
	// comparisons — running those on every mistyped TOTP would hand an
	// attacker a CPU-exhaustion lever for free.
	var (
		usedBackupCode bool
		remainingCodes int
	)
	if looksLikeBackupCode(code) {
		ok, remaining, cErr := s.consumeBackupCode(userID, code)
		if cErr != nil {
			s.logger.Error("mfa.backup_code.consume.fail", zap.String("user_id", userID), zap.Error(cErr))
			return nil, ErrInvalidMFACode
		}
		if !ok {
			s.logger.Warn("mfa.backup_code.invalid", zap.String("user_id", userID))
			s.handleFailedLogin(user.UserID, clientIP)
			return nil, ErrInvalidMFACode
		}
		usedBackupCode = true
		remainingCodes = remaining
		s.logger.Warn("mfa.backup_code.used",
			zap.String("user_id", userID),
			zap.Int("remaining", remaining),
			zap.String("ip", clientIP))
	} else {
		secret, dErr := crypto.Decrypt(mfa.SecretEncrypted, s.cryptoKey)
		if dErr != nil {
			s.logger.Error("mfa.decrypt.fail", zap.Error(dErr))
			return nil, ErrInvalidMFACode
		}
		if !pamtotp.Validate(secret, code) {
			s.logger.Warn("mfa.code.invalid", zap.String("user_id", userID))
			// A wrong SECOND factor counts toward the same lockout a wrong
			// password does. Without this, the TOTP step is an unlimited
			// online guessing oracle against a six-digit space — which is
			// precisely the attack the second factor is meant to stop.
			s.handleFailedLogin(user.UserID, clientIP)
			return nil, ErrInvalidMFACode
		}
	}

	// MFA verified → update last used + issue tokens.
	now := time.Now()
	s.db.Model(&models.PAMMFA{}).Where("user_id = ?", userID).
		Update("last_used_at", now)

	result, err := s.issueTokensForUser(user, true, clientIP)
	if err != nil {
		return nil, err
	}
	result.UsedBackupCode = usedBackupCode
	if usedBackupCode {
		result.BackupCodesRemaining = remainingCodes
	}
	return result, nil
}

// ──────────────────────────────────────────────────────────────────────────
// BACKUP CODES
// ──────────────────────────────────────────────────────────────────────────
//
// WHAT WAS WRONG BEFORE. Ten codes were generated at enrolment, shown to the
// user once, and written to pam_mfa_devices.backup_codes_hash as a plain JSON
// array — unhashed, despite the column name and the model's own comment. And
// nothing, anywhere, ever read them back: VerifyMFA only validated TOTP. They
// were decoration with a plaintext-secret footprint.
//
// They now behave the way a recovery code is expected to:
//   * hashed at rest with the same Argon2id used for passwords,
//   * single use — a code is removed from the stored set the moment it works,
//   * consumed inside a locked transaction, so two simultaneous logins cannot
//     both spend the same code,
//   * counted, so the console can warn the user when they are running low.

// looksLikeBackupCode reports whether the input has the shape of a backup code
// (10 hex characters, as produced by pkg/totp.GenerateBackupCodes) rather than
// a 6-digit TOTP. Dashes and spaces people add by habit are ignored.
func looksLikeBackupCode(code string) bool {
	c := normalizeBackupCode(code)
	if len(c) != 10 {
		return false
	}
	for _, r := range c {
		if !((r >= '0' && r <= '9') || (r >= 'a' && r <= 'f')) {
			return false
		}
	}
	return true
}

// normalizeBackupCode makes comparison independent of the cosmetics: users
// paste codes with dashes, spaces or in capitals.
func normalizeBackupCode(code string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(strings.TrimSpace(code)) {
		if r == '-' || r == ' ' || r == '\t' {
			continue
		}
		b.WriteRune(r)
	}
	return b.String()
}

func hashBackupCodes(codes []string) (string, error) {
	hashes := make([]string, 0, len(codes))
	for _, c := range codes {
		h, err := argon2.Hash(normalizeBackupCode(c))
		if err != nil {
			return "", fmt.Errorf("hash backup code: %w", err)
		}
		hashes = append(hashes, h)
	}
	blob, err := json.Marshal(hashes)
	if err != nil {
		return "", fmt.Errorf("encode backup codes: %w", err)
	}
	return string(blob), nil
}

func decodeBackupCodes(stored *string) []string {
	if stored == nil || strings.TrimSpace(*stored) == "" {
		return nil
	}
	var entries []string
	if err := json.Unmarshal([]byte(*stored), &entries); err != nil {
		return nil
	}
	return entries
}

// matchesBackupEntry compares one supplied code against one stored entry.
//
// The legacy branch is not decoration: installs that enrolled before this
// change have PLAINTEXT codes in that column. Rejecting them would silently
// void the recovery codes of every existing user, so they are still accepted —
// in constant time, so the comparison itself leaks nothing — and the whole set
// is rewritten as hashes the first time a code is spent.
func matchesBackupEntry(entry, candidate string) bool {
	if strings.HasPrefix(entry, "$argon2") {
		ok, err := argon2.Verify(candidate, entry)
		return err == nil && ok
	}
	return subtle.ConstantTimeCompare([]byte(normalizeBackupCode(entry)), []byte(candidate)) == 1
}

// consumeBackupCode verifies and SPENDS one code. Returns whether it matched
// and how many remain afterwards.
func (s *AuthService) consumeBackupCode(userID, code string) (bool, int, error) {
	candidate := normalizeBackupCode(code)
	matched := false
	remaining := 0

	err := s.db.Transaction(func(tx *gorm.DB) error {
		var device models.PAMMFA
		// SELECT … FOR UPDATE. Two logins racing with the same code would
		// otherwise both read the code as unspent and both succeed, which
		// turns "single use" into "single use, usually".
		if err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).
			Where("user_id = ? AND status = ?", userID, "ACTIVE").
			First(&device).Error; err != nil {
			return err
		}

		entries := decodeBackupCodes(device.BackupCodesHash)
		kept := make([]string, 0, len(entries))
		needsRehash := false
		for _, entry := range entries {
			if !matched && matchesBackupEntry(entry, candidate) {
				matched = true // spent: deliberately NOT carried into `kept`
				continue
			}
			if !strings.HasPrefix(entry, "$argon2") {
				needsRehash = true
			}
			kept = append(kept, entry)
		}
		if !matched {
			return nil
		}

		// Upgrade any surviving plaintext entries while we hold the lock.
		if needsRehash {
			upgraded := make([]string, 0, len(kept))
			for _, entry := range kept {
				if strings.HasPrefix(entry, "$argon2") {
					upgraded = append(upgraded, entry)
					continue
				}
				h, hErr := argon2.Hash(normalizeBackupCode(entry))
				if hErr != nil {
					return hErr
				}
				upgraded = append(upgraded, h)
			}
			kept = upgraded
		}

		blob, mErr := json.Marshal(kept)
		if mErr != nil {
			return mErr
		}
		remaining = len(kept)
		payload := string(blob)
		return tx.Model(&models.PAMMFA{}).Where("id = ?", device.ID).
			Update("backup_codes_hash", &payload).Error
	})
	if err != nil {
		return false, 0, err
	}
	return matched, remaining, nil
}

// BackupCodesRemaining reports how many unspent codes an account holds, so the
// console can nudge before the user runs out entirely.
func (s *AuthService) BackupCodesRemaining(userID string) int {
	mfa, err := s.getMFA(userID)
	if err != nil || mfa.Status != "ACTIVE" {
		return 0
	}
	return len(decodeBackupCodes(mfa.BackupCodesHash))
}

// RegenerateBackupCodes issues a fresh set and invalidates every previous one.
//
// Single-use codes are exhaustible, so a way to mint more is not a luxury: an
// account that spends its last code and cannot generate more is one lost phone
// away from the lockout this whole change exists to prevent. The route is
// behind RequireMFA — only a session that actually presented a second factor
// may mint new recovery material for the account.
func (s *AuthService) RegenerateBackupCodes(userID string) ([]string, error) {
	mfa, err := s.getMFA(userID)
	if err != nil || mfa.Status != "ACTIVE" {
		return nil, ErrMFANotSetup
	}

	codes, err := pamtotp.GenerateBackupCodes()
	if err != nil {
		return nil, fmt.Errorf("failed to generate backup codes: %w", err)
	}
	hashed, err := hashBackupCodes(codes)
	if err != nil {
		return nil, err
	}
	if err := s.db.Model(&models.PAMMFA{}).Where("id = ?", mfa.ID).
		Update("backup_codes_hash", &hashed).Error; err != nil {
		return nil, fmt.Errorf("failed to store backup codes: %w", err)
	}

	s.logger.Info("mfa.backup_codes.regenerated", zap.String("user_id", userID))
	return codes, nil
}

// ──────────────────────────────────────────────────────────────────────────
// MFA SETUP
// ──────────────────────────────────────────────────────────────────────────

// MFASetupResult holds the QR code + secret for initial MFA enrollment.
type MFASetupResult struct {
	MFADeviceID     string `json:"mfa_device_id"`
	Secret          string `json:"secret"` // shown once for manual entry
	ProvisioningURI string `json:"provisioning_uri"`
	QRCodeBase64    string `json:"qr_code_base64"`
}

func (s *AuthService) SetupMFAInitiate(userID, userEmail string) (*MFASetupResult, error) {
	secret, err := pamtotp.GenerateSecret()
	if err != nil {
		return nil, fmt.Errorf("failed to generate TOTP secret: %w", err)
	}

	encrypted, err := crypto.Encrypt(secret, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to encrypt TOTP secret: %w", err)
	}

	// Delete any existing PENDING device, then create a new one.
	//
	// NOTE, because it is easy to miss: this has no status filter, so it also
	// deletes an ACTIVE device. From here until a code is confirmed the
	// account genuinely has no second factor, which is why the user row is
	// updated to match — an `mfa_enabled` column that still says true while
	// login would not challenge is a lie every compliance screen would repeat.
	s.db.Unscoped().Where("user_id = ?", userID).Delete(&models.PAMMFA{})
	s.db.Model(&models.User{}).Where("user_id = ?", userID).Update("mfa_enabled", false)

	mfa := &models.PAMMFA{
		UserID:          userID,
		SecretEncrypted: encrypted,
		Status:          "PENDING",
	}
	if err := s.db.Create(mfa).Error; err != nil {
		return nil, fmt.Errorf("failed to create MFA device: %w", err)
	}

	uri := pamtotp.ProvisioningURI(secret, userEmail)
	qr, err := pamtotp.GenerateQRCodeBase64(uri)
	if err != nil {
		return nil, fmt.Errorf("failed to generate QR code: %w", err)
	}

	return &MFASetupResult{
		MFADeviceID:     mfa.ID,
		Secret:          secret,
		ProvisioningURI: uri,
		QRCodeBase64:    qr,
	}, nil
}

func (s *AuthService) SetupMFAVerify(userID, deviceID, code string) ([]string, error) {
	mfa, err := s.getMFA(userID)
	if err != nil {
		return nil, ErrMFANotSetup
	}
	if mfa.ID != deviceID || mfa.Status != "PENDING" {
		return nil, errors.New("invalid MFA device or already activated")
	}

	secret, err := crypto.Decrypt(mfa.SecretEncrypted, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to decrypt secret: %w", err)
	}

	if !pamtotp.Validate(secret, code) {
		return nil, ErrInvalidMFACode
	}

	// Generate backup codes.
	backupCodes, err := pamtotp.GenerateBackupCodes()
	if err != nil {
		return nil, fmt.Errorf("failed to generate backup codes: %w", err)
	}

	// Hash backup codes for storage. This used to marshal the PLAINTEXT codes
	// straight into the column — the name said hash, the contents did not.
	hashedStr, err := hashBackupCodes(backupCodes)
	if err != nil {
		return nil, err
	}

	now := time.Now()
	s.db.Model(&models.PAMMFA{}).Where("id = ?", deviceID).Updates(map[string]interface{}{
		"status":            "ACTIVE",
		"activated_at":      now,
		"backup_codes_hash": hashedStr,
	})
	// Mirror enrolment onto the user row. models.User has carried an
	// `mfa_enabled` column all along but nothing ever wrote it, so it read
	// false for every account — which is why /auth/me could not report
	// enrolment and the console had to infer it from the shape of the login
	// response. One write here makes the column true and every compliance
	// view honest.
	s.db.Model(&models.User{}).Where("user_id = ?", userID).Update("mfa_enabled", true)

	return backupCodes, nil
}

// ──────────────────────────────────────────────────────────────────────────
// LOGOUT
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) Logout(userID string) error {
	// In production: revoke the JTI in Redis (token blacklist) + clear session.
	// For now: log it.
	s.logger.Info("logout", zap.String("user_id", userID))
	return nil
}

// ──────────────────────────────────────────────────────────────────────────
// INTERNAL HELPERS
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) findUser(identifier string) (*models.User, error) {
	var user models.User
	err := s.db.Where("username = ? OR email = ?", identifier, identifier).
		First(&user).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrUserNotFound
		}
		return nil, err
	}
	return &user, nil
}

func (s *AuthService) findUserByID(userID string) (*models.User, error) {
	var user models.User
	if err := s.db.Where("user_id = ?", userID).First(&user).Error; err != nil {
		return nil, err
	}
	return &user, nil
}

func (s *AuthService) getMFA(userID string) (*models.PAMMFA, error) {
	var mfa models.PAMMFA
	if err := s.db.Where("user_id = ?", userID).First(&mfa).Error; err != nil {
		return nil, err
	}
	return &mfa, nil
}

func (s *AuthService) handleFailedLogin(userID, clientIP string) {
	s.db.Model(&models.User{}).Where("user_id = ?", userID).
		UpdateColumn("failed_login_attempts", gorm.Expr("failed_login_attempts + 1"))

	var user models.User
	s.db.Where("user_id = ?", userID).First(&user)
	if user.FailedLoginAttempts+1 >= s.maxAttempts {
		lockUntil := time.Now().Add(time.Duration(s.lockoutMin) * time.Minute)
		s.db.Model(&models.User{}).Where("user_id = ?", userID).Updates(map[string]interface{}{
			"status":       "LOCKED",
			"locked_until": lockUntil,
		})
		s.logger.Warn("login.account_locked",
			zap.String("user_id", userID),
			zap.Int("attempts", user.FailedLoginAttempts+1),
		)
	}
}

func (s *AuthService) issueTokensForUser(user *models.User, mfaVerified bool, clientIP string) (*LoginResult, error) {
	// Roles are resolved from PAM's own RBAC tables (see rbac.go /
	// policy_engine_service.go) and embedded directly in the JWT, so most
	// requests never need a DB round trip just to know "is this user an
	// admin" — middleware.RequireAdmin reads this claim straight off the
	// verified token. A resolution error fails closed (empty roles) rather
	// than failing the whole login — an account temporarily unable to
	// resolve its roles should still be able to log in and see "no access"
	// rather than being locked out of authentication entirely.
	roles, err := s.roles.RoleNamesForUser(user.UserID)
	if err != nil {
		s.logger.Error("login.resolve_roles.fail", zap.String("user_id", user.UserID), zap.Error(err))
		roles = []string{}
	}

	sessionID := fmt.Sprintf("pam-%d", time.Now().UnixNano())
	accountID := ""
	if user.AccountID != nil {
		accountID = *user.AccountID
	}
	accessToken, _, expiresAt, err := s.jwt.IssueAccessToken(
		user.UserID, user.Username, user.Email, accountID, mfaVerified, roles, sessionID, false,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to issue access token: %w", err)
	}
	refreshToken := s.jwt.IssueRefreshToken()

	// Record successful login on PAM's own local user row.
	s.db.Model(&models.User{}).Where("user_id = ?", user.UserID).Updates(map[string]interface{}{
		"last_login_at":         time.Now(),
		"last_login_ip":         clientIP,
		"failed_login_attempts": 0,
		"locked_until":          nil,
	})

	s.logger.Info("login.success",
		zap.String("user_id", user.UserID),
		zap.String("username", user.Username),
		zap.String("ip", clientIP),
	)

	return &LoginResult{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		TokenType:    "Bearer",
		SessionID:    sessionID,
		ExpiresAt:    expiresAt,
	}, nil
}

// issueRestrictedTokensForUser mints the enrolment-only session described in
// mfa_policy.go: a real, signed token whose `mfa_enrollment_required` claim
// makes middleware.RequireMFAEnrollment refuse every route except /auth/me,
// /auth/logout and the two MFA setup endpoints.
//
// Roles are still embedded, because the console needs to know who it is
// talking to in order to render the interrupt screen — and because they are
// useless without a route that will accept them.
func (s *AuthService) issueRestrictedTokensForUser(user *models.User, roles []string, clientIP string) (*LoginResult, error) {
	sessionID := fmt.Sprintf("pam-enrol-%d", time.Now().UnixNano())
	accountID := ""
	if user.AccountID != nil {
		accountID = *user.AccountID
	}
	accessToken, _, expiresAt, err := s.jwt.IssueAccessToken(
		user.UserID, user.Username, user.Email, accountID, false, roles, sessionID, true,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to issue enrolment token: %w", err)
	}

	// The login IS recorded: it succeeded as far as the password went, and an
	// operator investigating "why can this account not get in" needs to see
	// the attempt. Failed-attempt counters are cleared for the same reason a
	// normal login clears them — the password was right.
	s.db.Model(&models.User{}).Where("user_id = ?", user.UserID).Updates(map[string]interface{}{
		"last_login_at":         time.Now(),
		"last_login_ip":         clientIP,
		"failed_login_attempts": 0,
		"locked_until":          nil,
	})

	return &LoginResult{
		AccessToken: accessToken,
		TokenType:   "Bearer",
		SessionID:   sessionID,
		ExpiresAt:   expiresAt,
	}, nil
}

// Challenge token = SHA-256(userID + "|" + timestamp). Stored in Redis in production.
// For simplicity: encode userID with a short TTL check.
func (s *AuthService) generateChallengeToken(userID string) string {
	h := sha256.Sum256([]byte(fmt.Sprintf("%s|%d", userID, time.Now().Unix())))
	return hex.EncodeToString(h[:]) + "." + userID
}

func (s *AuthService) verifyChallengeToken(token string) (string, error) {
	parts := splitN(token, ".", 2)
	if len(parts) != 2 {
		return "", errors.New("malformed challenge token")
	}
	return parts[1], nil
}

func splitN(s, sep string, n int) []string {
	var result []string
	start := 0
	for i := 0; i < n-1; i++ {
		idx := indexOf(s[start:], sep)
		if idx < 0 {
			break
		}
		result = append(result, s[start:start+idx])
		start += idx + len(sep)
	}
	result = append(result, s[start:])
	return result
}

func indexOf(s, sub string) int {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
