package handlers

import (
	"errors"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type AuthHandler struct {
	auth *services.AuthService
	log  *zap.Logger
}

func NewAuthHandler(auth *services.AuthService, log *zap.Logger) *AuthHandler {
	return &AuthHandler{auth: auth, log: log}
}

// ─── LOGIN (step 1: password) ──────────────────────────────────────────────

type loginRequest struct {
	Identifier string `json:"identifier" binding:"required"`
	Password   string `json:"password" binding:"required"`
}

func (h *AuthHandler) Login(c *gin.Context) {
	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "identifier and password are required")
		return
	}

	result, err := h.auth.Login(req.Identifier, req.Password, c.ClientIP())
	if err != nil {
		switch {
		case errors.Is(err, services.ErrMFARequired):
			response.Success(c, result, "MFA verification required")
			return
		case errors.Is(err, services.ErrMFAEnrollmentRequired):
			// Role-gated MFA enforcement. The password was correct, so this
			// is a 200 carrying a RESTRICTED session, not an error: the token
			// in the payload is the only way the user can reach the enrolment
			// endpoints, and middleware.RequireMFAEnrollment refuses it
			// everywhere else. Returning 401/403 here would be wrong twice
			// over — it would read as "bad password" to the user, and it
			// would leave a user who must enrol with no way to enrol.
			response.Success(c, result, "Multi-factor authentication setup is required before you can continue")
			return
		case errors.Is(err, services.ErrInvalidCredentials):
			response.Error(c, 401, "Invalid username or password")
			return
		case errors.Is(err, services.ErrAccountLocked):
			response.Error(c, 423, "Account is temporarily locked")
			return
		case errors.Is(err, services.ErrAccountDisabled):
			response.Error(c, 403, "Account is disabled")
			return
		default:
			h.log.Error("login.internal_error", zap.Error(err))
			response.Error(c, 500, "Login failed")
			return
		}
	}

	response.Success(c, result, "Login successful")
}

// ─── MFA VERIFY (step 2: TOTP code) ────────────────────────────────────────

type mfaVerifyRequest struct {
	ChallengeToken string `json:"challenge_token" binding:"required"`
	Code           string `json:"code" binding:"required"`
}

func (h *AuthHandler) MFAVerify(c *gin.Context) {
	var req mfaVerifyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "challenge_token and code are required")
		return
	}

	result, err := h.auth.VerifyMFA(req.ChallengeToken, req.Code, c.ClientIP())
	if err != nil {
		if errors.Is(err, services.ErrInvalidMFACode) {
			response.Error(c, 401, "Invalid or expired MFA code")
			return
		}
		response.Error(c, 401, err.Error())
		return
	}

	response.Success(c, result, "MFA verified, login successful")
}

// ─── MFA SETUP (initiate) ──────────────────────────────────────────────────

func (h *AuthHandler) MFASetupInitiate(c *gin.Context) {
	userID, _ := c.Get("user_id")
	email, _ := c.Get("email")

	result, err := h.auth.SetupMFAInitiate(userID.(string), email.(string))
	if err != nil {
		h.log.Error("mfa.setup.initiate.fail", zap.Error(err))
		response.Error(c, 500, "Failed to initiate MFA setup")
		return
	}

	response.Success(c, result, "Scan the QR code with your authenticator app")
}

// ─── MFA SETUP (verify + activate) ─────────────────────────────────────────

type mfaSetupVerifyRequest struct {
	MFADeviceID string `json:"mfa_device_id" binding:"required"`
	Code        string `json:"code" binding:"required"`
}

func (h *AuthHandler) MFASetupVerify(c *gin.Context) {
	var req mfaSetupVerifyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "mfa_device_id and code are required")
		return
	}

	userID, _ := c.Get("user_id")
	backupCodes, err := h.auth.SetupMFAVerify(userID.(string), req.MFADeviceID, req.Code)
	if err != nil {
		if errors.Is(err, services.ErrInvalidMFACode) {
			response.Error(c, 401, "Invalid MFA code")
			return
		}
		response.Error(c, 400, err.Error())
		return
	}

	response.Success(c, gin.H{
		// relogin_required: enrolment does not upgrade the session that
		// performed it. The token in hand was issued before a second factor
		// existed — it carries mfa_verified=false and, for a gated account,
		// mfa_enrollment_required=true. Only a fresh sign-in (which will now
		// challenge for a code) produces a session that satisfies
		// middleware.RequireMFA. The console reads this and says so.
		"relogin_required": true,
		"backup_codes":     backupCodes,
		"message":          "Save these backup codes — they will NOT be shown again",
	}, "MFA enabled successfully")
}

// ─── BACKUP CODES (regenerate) ─────────────────────────────────────────────

// RegenerateBackupCodes issues a fresh set and voids every previous one.
//
// Behind RequireMFA in main.go: only a session that actually presented a
// second factor may mint new recovery material for the account. Without that,
// anyone holding a stolen password on an MFA-less session could generate
// codes and use them as a permanent bypass.
func (h *AuthHandler) RegenerateBackupCodes(c *gin.Context) {
	userID, _ := c.Get("user_id")
	id, _ := userID.(string)

	codes, err := h.auth.RegenerateBackupCodes(id)
	if err != nil {
		if errors.Is(err, services.ErrMFANotSetup) {
			response.Error(c, 400, "This account has no active authenticator")
			return
		}
		h.log.Error("mfa.backup_codes.regenerate.fail", zap.Error(err))
		response.Error(c, 500, "Failed to generate new backup codes")
		return
	}

	response.Success(c, gin.H{
		"backup_codes": codes,
		"count":        len(codes),
	}, "New backup codes generated — the previous set no longer works")
}

// ─── ME (current user) ─────────────────────────────────────────────────────

func (h *AuthHandler) Me(c *gin.Context) {
	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	email, _ := c.Get("email")
	mfa, _ := c.Get("mfa_verified")
	enrolPending, _ := c.Get("mfa_enrollment_required")
	roles, _ := c.Get("roles")

	// ── What this payload gained, and why it matters ──
	//
	// `mfa_verified` describes the SESSION and was, until now, the only MFA
	// signal here. The console could not tell "this account has a second
	// factor" from "this session used one", so it inferred enrolment from the
	// shape of the login response and cached the answer in localStorage — a
	// workaround the frontend documents at length in lib/mfaEvidence.js.
	//
	// `mfa_enabled` is the account fact, read from the same ACTIVE-device
	// definition login uses to decide whether to challenge, so the two can
	// never disagree. The policy fields tell the console whether this user is
	// gated by a role rule and whether they are in breach, which is what the
	// enrolment banner and the interrupt screen are driven from.
	out := gin.H{
		"user_id":                 userID,
		"username":                username,
		"email":                   email,
		"mfa_verified":            mfa,
		"mfa_enrollment_required": enrolPending,
		"roles":                   roles,
	}

	if id, ok := userID.(string); ok && id != "" {
		// ROLES ARE RE-RESOLVED, not echoed from the token.
		//
		// The claim is a snapshot taken at login and there is no refresh
		// endpoint, so echoing it made this endpoint report who the user WAS.
		// The console drives its whole shape from this response — the Admin
		// Center nav, the route guards, "am I root" — so after root granted or
		// revoked an admin delegation the affected user kept seeing the old
		// console until they signed out and back in. Reading the live set
		// makes the change appear on their next refetch, and matches what
		// middleware.RequireAdmin will actually allow.
		if live, err := h.auth.RolesFor(id); err == nil {
			out["roles"] = live
		} else {
			h.log.Error("me.resolve_roles.fail", zap.String("user_id", id), zap.Error(err))
		}

		status := h.auth.MFAStatusFor(id)
		out["mfa_enabled"] = status.Enrolled
		// Surfaced so the console can warn BEFORE the user is down to their
		// last code — single-use codes are exhaustible, and running out while
		// the authenticator is already lost is the lockout this exists to
		// prevent.
		if status.Enrolled {
			out["backup_codes_remaining"] = h.auth.BackupCodesRemaining(id)
		}
		out["mfa_required"] = status.Required
		out["mfa_policy_mode"] = status.Mode
		if len(status.MatchedRoles) > 0 {
			out["mfa_required_by_roles"] = status.MatchedRoles
		}
		if status.GraceUntil != nil {
			out["mfa_enrollment_deadline"] = status.GraceUntil
		}
	}

	response.Success(c, out, "Identity retrieved")
}

// ─── LOGOUT ────────────────────────────────────────────────────────────────

func (h *AuthHandler) Logout(c *gin.Context) {
	userID, _ := c.Get("user_id")
	h.auth.Logout(userID.(string))
	response.Success(c, nil, "Logged out")
}

// ─── HEALTH ────────────────────────────────────────────────────────────────

func (h *AuthHandler) Health(c *gin.Context) {
	userID, _ := c.Get("user_id")
	response.Success(c, gin.H{"status": "ok", "user_id": userID}, "PAM auth is healthy")
}
