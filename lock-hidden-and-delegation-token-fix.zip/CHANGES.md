# Two tasks: Lock button commented out, and the delegation token issue

Apply on top of the previous two zips — `auth_service.go`, `auth_handler.go`,
`main.go` and `IdentityDetailPage.jsx` are edited again here.

```
frontend/src/pages/admin/IdentityDetailPage.jsx  task 1 — LOCK commented out
frontend/src/components/common/AppLayout.jsx     task 2 — /auth/me is polled
backend/internal/middleware/admin.go             task 2 — the gate reads live roles
backend/internal/api/handlers/auth_handler.go    task 2 — /auth/me returns live roles
backend/internal/services/auth_service.go        task 2 — RolesFor()
backend/cmd/pam-api/main.go                       task 2 — wiring
```

---

## Task 1 — Lock

Commented out, not deleted, with the reason in place and a one-line note on how
to restore it. The `Lock` icon import stays — it is still used by the locked
system-role chip on the Access tab.

Worth knowing *why* it was the right thing to hide: `LOCKED` is not really an
administrative state on this backend. The server sets it itself after too many
failed sign-ins, together with the `locked_until` timestamp that decides when
it lifts (`AuthService.handleFailedLogin`). An operator setting `LOCKED` by
hand produced a lock with no `locked_until`, which the auto-unlock branch in
`Login` then treats as already expired. **Disable** is the administrator-owned
way to take an account out of service.

## Task 2 — yes, there was a token issue, and it was one-sided

Your instinct was right. Both delegation paths update the database correctly —
`DelegateAdmin` assigns the `admin` role row, `RevokeAdminDelegation` deletes
it, both inside a transaction. Neither touches existing tokens, and that is
where it went wrong.

Roles are baked into the JWT at login (`issueTokensForUser`), the access token
lives 30 minutes (`PAM_JWT_ACCESS_TTL_MIN`), and there is no refresh endpoint.
So the claim is a snapshot of who the user was when they signed in. What read
that snapshot mattered enormously:

| Path | Source | Effect |
|---|---|---|
| `RequirePermission` (all standard routes) | database, per request | already correct |
| `RequireAdmin` (whole Admin Center) | **token claim** | stale |
| `/auth/me` (drives the entire console UI) | **token claim** | stale |

Which produced an asymmetry:

- **Granting** admin did not take effect for the user's current session. Mildly
  annoying, fails safe — they sign out and back in.
- **Revoking** admin did not take effect either. **That one is a security
  bug.** Root revokes, the console confirms it, the role row is gone — and the
  revoked administrator carries on operating the Admin Center for up to another
  30 minutes on a token that still says "admin". Revocation that takes effect
  "in a while" is not revocation.

### The fix

**`RequireAdmin` now resolves the caller's current roles from the RBAC tables**
and decides on those. One indexed lookup on a path that already does several.
It also writes the live set back into the request context, so handlers and the
delegation/MFA services downstream see the same answer the gate just used
rather than the stale claim.

The claim survives as a fallback for exactly one case: the lookup itself
failing. Failing closed there would let a database blip lock every
administrator out of the console — including whoever would fix the blip — so a
signed, server-issued claim from at most one token-lifetime ago is the safer
answer, and it is logged at `Error` so the degradation is visible.

**`/auth/me` re-resolves roles too**, instead of echoing the claim. The console
builds everything from that response — Admin Center nav, route guards, "am I
root" — so it now matches what the server will actually allow.

**The console polls `/auth/me`** every 60 seconds and on window focus. Without
it, a revoked admin would sit in front of an Admin Center nav where every click
403s until they happened to reload. With it, the nav disappears on its own
shortly after the revocation, and a newly granted admin gets the Admin Center
without signing out and in.

### Net behaviour after this change

| Action | Target's current session |
|---|---|
| Root grants admin | Admin Center works immediately; nav appears within ~60s |
| Root revokes admin | Admin Center refused immediately; nav disappears within ~60s |

### Verification

`go build ./...`, `go vet ./...`, `go test ./...` all clean. Frontend
`npm run lint` clean (same 4 pre-existing issues), `npm run build` passes.

### One limit worth stating

This makes *authorisation* immediate; it does not revoke the token itself. A
revoked user's token remains cryptographically valid until it expires, so it
still passes `PAMAuth` and still reaches non-admin routes — where
`RequirePermission` evaluates their (now reduced) policies from the database
anyway, so they get exactly the access their remaining roles grant. Killing the
token outright needs the JTI blacklist that `AuthService.Logout` still has as a
`// In production: revoke the JTI in Redis` note. Every privilege *decision* is
live; only the token's existence is not.
