package launcher

import (
	"runtime"
	"testing"
)

// PAM brokers ten kinds of resource. The agent must have an answer for every
// one of them, because a type with no template entry fails with
// NoCandidatesError — "an administrator needs to teach the agent about this" —
// which is a dead end for an operator who did nothing wrong.
//
// `web` was exactly that: the backend has offered a "Web Application" type all
// along (see ListResourceGroups' typeInfo) and the agent had no entry for it,
// so every native launch of one failed. This test is what stops the two lists
// drifting apart again.
func TestEveryBackendResourceTypeHasATemplate(t *testing.T) {
	// The backend's own list, from internal/services/resource_service.go's
	// ListResourceGroups typeInfo map, plus oracle.
	backendTypes := []string{
		"postgresql", "mongodb", "redis", "clickhouse", "minio",
		"qdrant", "metabase", "langfuse", "web", "oracle",
	}

	templates, err := LoadTemplates(t.TempDir())
	if err != nil {
		t.Fatalf("LoadTemplates: %v", err)
	}
	for _, rt := range backendTypes {
		cands, ok := templates[rt]
		if !ok || len(cands) == 0 {
			t.Errorf("resource type %q has no launch candidates — a native launch of one "+
				"fails with NoCandidatesError", rt)
			continue
		}
		for _, c := range cands {
			switch c.Kind {
			case "cli", "gui", "browser":
			default:
				t.Errorf("%s/%s: unknown kind %q", rt, c.ID, c.Kind)
			}
			if c.Command == "" {
				t.Errorf("%s/%s: no command", rt, c.ID)
			}
			// A candidate the operator could install must say how. Without a
			// hint the failure report reads "no installed tool found", which
			// is true and useless to somebody sitting at their own laptop.
			if c.Kind != "browser" && c.InstallHint == "" {
				t.Errorf("%s/%s: installable candidate has no install_hint", rt, c.ID)
			}
		}
	}
}

// Every resource type must be openable on Windows, macOS AND Linux — checked
// for all three from any host, not just the one the tests happen to run on.
// Building on Linux and shipping a Windows binary that cannot find a single
// tool for Oracle is exactly the kind of gap a GOOS-conditional test hides.
//
// "Openable" means at least one candidate that is either a browser (every
// machine has one) or carries a discovery rule that could match on that OS.
func TestEveryTypeHasACandidateOnEveryPlatform(t *testing.T) {
	templates, err := LoadTemplates(t.TempDir())
	if err != nil {
		t.Fatalf("LoadTemplates: %v", err)
	}

	usableOn := func(c Candidate, goos string) bool {
		if c.Kind == "browser" {
			return true
		}
		// binary_names is a PATH lookup, which works on every platform.
		if len(c.Discovery.BinaryNames) > 0 {
			return true
		}
		if len(c.Discovery.AbsolutePathGlobs[goos]) > 0 {
			return true
		}
		switch goos {
		case "windows":
			return len(c.Discovery.WindowsAppPaths) > 0
		case "darwin":
			return len(c.Discovery.MacAppBundles) > 0
		}
		return false
	}

	for _, goos := range []string{"windows", "darwin", "linux"} {
		for rt, cands := range templates {
			ok := false
			for _, c := range cands {
				if usableOn(c, goos) {
					ok = true
					break
				}
			}
			if !ok {
				t.Errorf("%s: resource type %q has no candidate this platform could use", goos, rt)
			}
		}
	}
}

// The capability report is what the console reads to decide whether to offer
// a desktop launch at all, so its shape matters as much as its contents.
func TestCapabilitiesReportsEveryTypeAndNamesMissingTools(t *testing.T) {
	templates, err := LoadTemplates(t.TempDir())
	if err != nil {
		t.Fatalf("LoadTemplates: %v", err)
	}
	caps := Capabilities(templates, "test-version", true)

	if caps.OS != runtime.GOOS || caps.Arch != runtime.GOARCH {
		t.Fatalf("report does not describe this machine: %+v", caps)
	}
	if !caps.ScreenRecorder {
		t.Fatal("screen recorder availability was not carried through")
	}
	if len(caps.Types) != len(templates) {
		t.Fatalf("report covers %d types, templates have %d", len(caps.Types), len(templates))
	}

	byType := map[string]TypeCapability{}
	for _, tc := range caps.Types {
		byType[tc.ResourceType] = tc
	}

	// A browser-only type is supported everywhere, with nothing to install.
	if md := byType["metabase"]; !md.Supported() || len(md.Missing) != 0 {
		t.Fatalf("metabase should be supported with nothing missing: %+v", md)
	}

	// Every entry must account for every candidate: found or missing, never
	// dropped. A dropped candidate is a tool the console would never mention.
	for rt, cands := range templates {
		tc := byType[rt]
		if len(tc.Tools)+len(tc.Missing) != len(cands) {
			t.Errorf("%s: %d candidates but %d found + %d missing",
				rt, len(cands), len(tc.Tools), len(tc.Missing))
		}
	}

	// And a missing installable tool must carry its hint, or the console
	// cannot tell the operator what to install.
	for _, tc := range caps.Types {
		for _, m := range tc.Missing {
			if m.Kind != "browser" && m.InstallHint == "" {
				t.Errorf("%s/%s: reported missing with no install hint", tc.ResourceType, m.ID)
			}
		}
	}
}

// The report is stable for an unchanged machine: two runs must be equal, or
// every launch would look like a change and rewrite the stored row.
func TestCapabilitiesIsStableAcrossRuns(t *testing.T) {
	templates, err := LoadTemplates(t.TempDir())
	if err != nil {
		t.Fatalf("LoadTemplates: %v", err)
	}
	a := Capabilities(templates, "v", false)
	b := Capabilities(templates, "v", false)
	if len(a.Types) != len(b.Types) {
		t.Fatal("type count differs between runs")
	}
	for i := range a.Types {
		if a.Types[i].ResourceType != b.Types[i].ResourceType {
			t.Fatalf("type ORDER differs between runs at %d: %q vs %q",
				i, a.Types[i].ResourceType, b.Types[i].ResourceType)
		}
	}
}
