# PAM fixes — agent & resources (round 2), combined with round 1

Copy over the originals. Three trees:

- `backend_upd/` — API
- `frontend_upd/` — console
- `pam-agent/` — agent source
- `backend_upd/agents/` — **the five built agent binaries**, rebuilt from the
  source in this zip, with a regenerated `SHA256SUMS.txt` and `VERSION`.

Round 1's ten files (5 reported bugs + 3 responsive defects) are included
unchanged — see "Round 1" at the bottom.

---

# Round 2

## The agent binaries  (your explicit ask)

Built from the attached source for all five targets and placed in
`backend_upd/agents/`, which is what `PAM_AGENT_BINARY_DIR` points at:

| Target | Label the console shows |
|---|---|
| windows/amd64 | Windows (64-bit) |
| darwin/arm64 | macOS (Apple Silicon) |
| darwin/amd64 | macOS (Intel) |
| linux/amd64 | Linux (x86-64) |
| linux/arm64 | Linux (ARM64) |

Verified by loading them through the backend's own `agentdist.Store`: all five
are discovered, labelled and hashed. **`SHA256SUMS.txt` was stale in the zip
you sent** — `install/build-release.sh` never wrote it, so it still carried the
digests of an older build. The backend hashes the bytes itself and never reads
that file, so nothing was broken by it, but anyone verifying a download by hand
would have seen a mismatch and concluded tampering. Regenerated and verified
with `sha256sum -c`.

## 1. "Handing off to the agent" when this machine is not the paired one

**Root cause, and it is not in the console.** `AgentDevice` stored a name and a
public key and nothing else. So the only question anyone could ask was "does
this ACCOUNT have any paired device", which the server answers with a 409 — and
an operator who had ever paired any machine got the cheerful handoff on every
other machine they ever signed in from.

**What changed.**

- *Agent* now reports `os`, `arch`, `hostname`, `agent_version` when it pairs,
  and again on every launch resolve (the only other moment it is running and
  authenticated).
- *Backend* stores them on `AgentDevice` and serves them to the console. The
  refresh happens **after** the Ed25519 signature verifies — before it, an
  unauthenticated caller could rewrite what the console believes about someone
  else's machine.
- *Console* (`lib/agentDevice.js`) sorts the situation into four states and is
  explicit about which are certain:

  | State | Meaning | Certain? | Behaviour |
  |---|---|---|---|
  | `none` | no paired device at all | yes | refuse |
  | `other` | devices exist, none runs this OS | **yes** | refuse |
  | `this` | a device this browser paired, still present | confident | hand off |
  | `unknown` | could be this machine, could not | no | hand off, neutrally |

`other` is the case you described — paired the Windows laptop, now on a Mac —
and it is answered with certainty before anything is handed off.

**The toast itself was the bug.** `toast.success('Handing off to the desktop
agent')` claimed success for something the browser has no way to observe. It is
now `toast.message('Opening on this device…')` with "If nothing opens, the
agent is not running on this machine" — and when the handoff window closes
unredeemed, the poll raises your exact wording:

> Device not paired. Pair this device before opening resources in a desktop app.

So the ambiguous case self-corrects within seconds instead of lying. I did
**not** add a resident localhost listener to make `unknown` certain: it is a
new always-running component, a new surface any website can probe, and service
install work on three OSes — for a case the OS check plus the expiry already
covers.

## 2. "Handing off" when the client is not installed

Same root cause. The agent now runs the **same discovery it would run at launch
time**, for every resource type it has a template for, and reports what it
found. The console refuses up front and names the tool:

> This device does not have mongosh or MongoDBCompass installed, so mongodb
> cannot be opened in a desktop app here. *(+ the template's install hint)*

Two distinctions that took a round of testing against the real report to get
right:

- **A browser candidate is not desktop support.** Every type has one (opening a
  URL needs nothing installed), so counting it made every type permanently
  "supported" and the check worthless.
- **But a type with *only* a browser candidate is not a missing tool.** Metabase,
  Qdrant and a generic web app have no desktop client in the world; refusing
  them would remove a working path. The distinguishing fact is whether anything
  *installable* was looked for and not found.

Unknown is never a refusal: an agent too old to report, or a type it has no
template for, falls through to the launch path's own more precise error.

## 3. The ten applications, across Windows / macOS / Linux

**Found: `web` had no template at all.** The backend has offered a "Web
Application" type all along (`ListResourceGroups`' typeInfo) and the agent had
no entry, so every native launch of one failed with `NoCandidatesError` — a
dead end for an operator who did nothing wrong. Added. ClickHouse also gained
Windows discovery (its Windows distribution is a loose `clickhouse.exe`, so
PATH is often not where it is).

Coverage is now locked down by tests that check **all three platforms from any
host**, not just the one the tests run on:

| Type | CLI | Desktop | Browser |
|---|---|---|---|
| postgresql | psql | pgAdmin 4 | |
| mongodb | mongosh | Compass | Atlas |
| redis | redis-cli | RedisInsight | |
| oracle | SQL\*Plus, SQLcl | SQL Developer | APEX |
| clickhouse | clickhouse-client | | |
| minio | mc | | MinIO Console |
| langfuse | langfuse | | Langfuse web |
| qdrant | | | Dashboard |
| metabase | | | Metabase |
| **web** | | | **any URL (added)** |

**Recording, honestly stated.** CLI sessions record on all three platforms
(ConPTY on Windows, a pty relay on macOS/Linux). Desktop applications record as
video — `internal/recorder/screen.go` already does this via ffmpeg
(x11grab/avfoundation/gdigrab), so the "GUI ❌" row in the agent's `CONTEXT.md`
is stale. **Browser launches cannot be recorded by the agent** — it opens your
own browser and is not in the data path. Per your answer, when a resource must
be recorded and its only route here is a browser, the console now refuses the
desktop button and steers to the brokered proxy, which genuinely records
because PAM *is* in that path. A desktop launch that needs recording without
ffmpeg is refused with that one thing to install.

## 4. The MinIO loading spinner — **already fixed in this build**

I could not reproduce it, and then found why: `proxy.go`'s Director already
rewrites `Origin` to the target's own host, and the comment there documents
your exact symptom with measured evidence against a real MinIO Console
(RELEASE.2025-09-07):

```
no Origin                     -> 101 Switching Protocols
Origin == Host                -> 101 Switching Protocols
Origin = proxy, Host = target -> 403 "request origin not allowed by Upgrader.CheckOrigin"
```

That 403 is the Object Browser's WebSocket being refused and retried forever —
the spinner. `TestDirectorRewritesOriginToTheTarget` covers it and passes.

**So if you are still seeing it, you are running a build without this fix, or
it is a different spinner.** I did not invent a change to a thing that is
already correct. To take it further I need either the MinIO version and a
browser devtools Network capture of the hung view, or a reachable console to
point `PAM_TEST_LIVE_MINIO=1` at — MinIO have withdrawn the binaries I tried to
download (HTTP 410), so I could not stand one up here.

---

# Verification

**A real Postgres was installed and run for this round**, which matters: the
agent launch tests (`launch_outcome_test.go`, `minio_native_agent_e2e_test.go`)
skip themselves without one, so they had never actually run. They run now.

- Agent: builds for all 5 targets; `go vet` clean; all tests pass, including
  new coverage that every backend resource type has a template usable on
  Windows, macOS and Linux (proven to fail when `web` is removed).
- Backend: `go build`, `go vet` clean; `go test ./...` 12/12 packages on real
  Postgres, including 4 new device-report tests.
- Console: `eslint --max-warnings 0` and `npm run build` clean.
- Browser (Chromium, real built console): **8/8** on the pre-flight cases —
  and **0/8 against the original build, where all eight say "Handing off to the
  desktop agent"**, which is the reported bug reproduced exactly.
- Round 1's suites re-run: **15/15** bug cases, **0** responsive findings.

**Full loop, real agent binary.** The built `pam-agent_linux_amd64` was run
against a server that captured its wire traffic. On this machine it correctly
reported `psql` and `redis-cli` present, `mongosh`/`clickhouse-client`/`mc`
absent, and ffmpeg absent — all matching ground truth. That real report was
then fed to the console: **6/6**, including postgresql handing off, mongodb
naming mongosh, and a record-required Metabase steering to the proxy.

## What I could not test here

This container is Linux with no Windows or macOS, and no Docker. So the
Windows ConPTY path, the macOS relay, GUI launches and ffmpeg screen capture
are **built and unit-tested but not run on their own platforms**. The agent's
own `CONTEXT.md` flags the same limit for the WiX/pkg installers. Per its "no
auto-update" note, operators must re-install the agent to pick this build up.

---

# Round 1 (unchanged, included)

1. MFA banner after enrolling — hardened; the canonical payload already worked.
2. Re-used recovery code redirected to /login — `/mfa/recover` was missing from
   the interceptor's auth-entry allow-list.
3. Killed session still Active on the dashboard — the card never re-polled.
4. Resources search on 2 letters — `setQuery` never reset the page.
5. Audit search by Username or ID — the console sent `actor`, the handler read
   `actor_user_id`; and `ActorUserID` was exact-match only.
6. Dashboard header row could not wrap (629px inside 404px).
7. Settings rail — a CSS grid min-content trap; one `min-w-0`.
8. Resources table clipped columns out of reach below ~1280px.
