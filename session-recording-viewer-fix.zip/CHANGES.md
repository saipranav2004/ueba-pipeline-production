# Session recording viewer — two changes

File changed: `src/components/audit/SessionRecordingViewer.jsx` (only this one)

## 1. Fullscreen for the replay itself

Before there was one fullscreen button and one target: the whole dialog. So
"fullscreen" still spent a third of the screen on the command log and header.

Now there are two:

* **Transport bar, bottom-right of the player** — fullscreens the replay pane
  only (terminal + its transport controls, the way a video player keeps its
  controls). This is the new one.
* **Header button** — unchanged, still fullscreens the whole panel when you
  want the command log alongside the replay.
* **`F`** now toggles the *replay* (video-player convention). Footer hint
  updated to "F fullscreen replay". `Esc` still exits fullscreen first, then
  closes the viewer on a second press.

Each button shows Minimize when *its own* target is fullscreen, so the two
never both look active. The replay section got an explicit background because a
fullscreen element paints on the browser backdrop, not on the dialog.

## 2. "Transcript" button now downloads the command log

The header button downloaded the raw `.cast` replay. It now downloads the
**command log** and is labelled **Command log** so the label matches the file.

It also exports the **whole** log, not just the page on screen — the log is
paginated (200/page) and the old export silently handed over only the loaded
page. Every page is fetched sequentially first, capped at 50 pages (10,000
commands); past that the file header says it was truncated.

The raw `.cast` replay is still downloadable from **Properties → Export →
Recording transcript**, unchanged.

Verified: `npm run lint` clean on this file, `npm run build` passes.
