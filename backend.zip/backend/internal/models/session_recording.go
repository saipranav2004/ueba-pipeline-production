// pam/internal/models/session_recording.go
//
// SessionRecording is metadata about a recorded session. The recording bytes
// themselves would live in S3/MinIO under StorageBucket/StorageKey.
//
// NOTE: this repository does not yet contain a capture pipeline (no SSH/RDP
// proxy exists). Rows are created in PENDING state whenever a session is
// opened under a grant that mandates recording, so the obligation is at
// least auditable and the IAM console has a real surface to read.
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

const (
	RecordingStatusPending   = "PENDING"
	RecordingStatusRecording = "RECORDING"
	RecordingStatusCompleted = "COMPLETED"
	RecordingStatusFailed    = "FAILED"
)

type SessionRecording struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	SessionID string  `gorm:"type:varchar(36);not null;index" json:"session_id"`
	GrantID   *string `gorm:"type:varchar(36);index" json:"grant_id,omitempty"`

	UserID       string `gorm:"type:varchar(36);not null;index" json:"user_id"`
	Username     string `gorm:"type:varchar(150)" json:"username"`
	ResourceID   string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name"`

	IsBreakglass bool `gorm:"not null;default:false;index" json:"is_breakglass"`

	Format        string `gorm:"type:varchar(30);default:'asciicast'" json:"format"`
	StorageBucket string `gorm:"type:varchar(255)" json:"storage_bucket,omitempty"`
	StorageKey    string `gorm:"type:varchar(512)" json:"storage_key,omitempty"`
	SizeBytes     int64  `gorm:"default:0" json:"size_bytes"`
	SHA256        string `gorm:"column:sha256;type:varchar(64)" json:"sha256,omitempty"`

	Status string `gorm:"type:varchar(20);not null;default:'PENDING';index" json:"status"`

	StartedAt       time.Time  `gorm:"not null;index" json:"started_at"`
	EndedAt         *time.Time `json:"ended_at,omitempty"`
	DurationSeconds int        `gorm:"default:0" json:"duration_seconds"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (SessionRecording) TableName() string { return "pam_session_recordings" }

func (r *SessionRecording) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}
