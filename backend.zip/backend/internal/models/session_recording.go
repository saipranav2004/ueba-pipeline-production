// pam/internal/models/session_recording.go
//
// SessionRecording is metadata about a recorded session. The recording
// bytes themselves live wherever internal/recorder.Storage puts them
// (StorageBucket/StorageKey identify the blob) — see internal/gateway's
// Connect handler for the capture pipeline and internal/recorder for the
// cast format, masking, and storage backend.
//
// Rows are created in PENDING state whenever a session is opened under an
// obligation that mandates recording (resource.AlwaysRecord, break-glass, or
// a grant that requires it), move to RECORDING once the in-browser terminal
// gateway actually starts capturing, and reach COMPLETED (bytes persisted,
// StorageKey/SHA256/SizeBytes set) or FAILED (see FailureReason) when the
// session ends. A capture failure never blocks or kills the underlying
// session — see gateway.go's finalize step — it only leaves this row FAILED
// for an admin to notice.
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

const (
	RecordingStatusPending   = "PENDING"
	RecordingStatusRecording = "RECORDING"
	RecordingStatusCompleted = "COMPLETED"
	RecordingStatusFailed    = "FAILED"
)

type SessionRecording struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	SessionID string  `gorm:"type:varchar(36);not null;index" json:"session_id"`
	GrantID   *string `gorm:"type:varchar(36);index" json:"grant_id,omitempty"`

	UserID       string `gorm:"type:varchar(36);not null;index" json:"user_id"`
	Username     string `gorm:"type:varchar(150)" json:"username"`
	ResourceID   string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name"`

	IsBreakglass bool `gorm:"not null;default:false;index" json:"is_breakglass"`

	Format        string `gorm:"type:varchar(30);default:'asciicast'" json:"format"`
	StorageBucket string `gorm:"type:varchar(255)" json:"storage_bucket,omitempty"`
	StorageKey    string `gorm:"type:varchar(512)" json:"storage_key,omitempty"`
	SizeBytes     int64  `gorm:"default:0" json:"size_bytes"`

	// TranscriptKey points at a SECONDARY artifact for recordings whose
	// primary is a visual replay: the same session's HTTP request transcript,
	// as an asciicast. A visual replay shows what the operator saw but not
	// the per-request detail (status, bytes, timing) an auditor often needs,
	// and the searchable command log deliberately keeps only mutations and
	// page navigations — so plain reads would otherwise be unrecoverable.
	// NULL for terminal recordings, where StorageKey already IS the
	// transcript. Served by GET /admin/recordings/:id/transcript.
	TranscriptKey *string `gorm:"type:varchar(512)" json:"transcript_key,omitempty"`
	SHA256        string  `gorm:"column:sha256;type:varchar(64)" json:"sha256,omitempty"`

	Status string `gorm:"type:varchar(20);not null;default:'PENDING';index" json:"status"`

	// FailureReason is set only when Status=FAILED — e.g. a disk-full error
	// persisting the cast to storage. Never blocks the underlying session;
	// see internal/gateway's finalize step.
	FailureReason string `gorm:"type:text" json:"failure_reason,omitempty"`

	StartedAt       time.Time  `gorm:"not null;index" json:"started_at"`
	EndedAt         *time.Time `json:"ended_at,omitempty"`
	DurationSeconds int        `gorm:"default:0" json:"duration_seconds"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (SessionRecording) TableName() string { return "pam_session_recordings" }

func (r *SessionRecording) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}
