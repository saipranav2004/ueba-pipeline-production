package models

import (
	"strings"
	"testing"
)

func TestDeniedCommandListSplitsAndTrims(t *testing.T) {
	d := DataProtection{DeniedCommands: `  \copy , pg_dump ,, \o  `}
	got := d.DeniedCommandList()
	want := []string{`\copy`, "pg_dump", `\o`}
	if strings.Join(got, "|") != strings.Join(want, "|") {
		t.Fatalf("DeniedCommandList = %v, want %v", got, want)
	}

	// Empty means "fall back to the built-in list", which is a decision made by
	// the caller — this returns nothing rather than inventing patterns.
	if got := (DataProtection{}).DeniedCommandList(); len(got) != 0 {
		t.Fatalf("an empty list must stay empty, got %v", got)
	}
}

// A deny list makes the policy active on its own: a resource that only blocks
// commands still needs the agent to enforce something.
func TestDeniedCommandsMakesThePolicyActive(t *testing.T) {
	if !(DataProtection{DeniedCommands: "pg_dump"}).Any() {
		t.Fatal("a policy with only a deny list must report itself active")
	}
	if (DataProtection{}).Any() {
		t.Fatal("an empty policy must report inactive")
	}
}

// Grant-level tightening adds patterns; it must never be able to shorten the
// resource's list, which is the same one-way rule every other control follows.
func TestGrantDenyListAddsToTheResourceListAndCannotShortenIt(t *testing.T) {
	got := MostRestrictive(
		DataProtection{DeniedCommands: `\copy,pg_dump`},
		DataProtection{DeniedCommands: "mongoexport"},
	)
	for _, want := range []string{`\copy`, "pg_dump", "mongoexport"} {
		if !strings.Contains(got.DeniedCommands, want) {
			t.Fatalf("%q missing from the merged list %q", want, got.DeniedCommands)
		}
	}

	// A grant that names nothing must not clear the resource's list.
	got = MostRestrictive(DataProtection{DeniedCommands: `\copy,pg_dump`}, DataProtection{})
	if !strings.Contains(got.DeniedCommands, `\copy`) || !strings.Contains(got.DeniedCommands, "pg_dump") {
		t.Fatalf("a permissive grant emptied the resource's deny list: %q", got.DeniedCommands)
	}
}

// Duplicates would mean the agent matching the same pattern twice and
// reporting one attempt as two.
func TestMergedDenyListIsDeduplicatedCaseInsensitively(t *testing.T) {
	got := MostRestrictive(
		DataProtection{DeniedCommands: "pg_dump,COPY"},
		DataProtection{DeniedCommands: "PG_DUMP, copy , mongodump"},
	)
	parts := got.DeniedCommandList()
	seen := map[string]int{}
	for _, p := range parts {
		seen[strings.ToLower(p)]++
	}
	for pattern, n := range seen {
		if n > 1 {
			t.Fatalf("%q appears %d times in %q", pattern, n, got.DeniedCommands)
		}
	}
	if len(parts) != 3 {
		t.Fatalf("merged list = %v, want 3 distinct patterns", parts)
	}
}

func TestDefaultDeniedCommandsCoverTheSupportedTools(t *testing.T) {
	for _, kind := range []string{"postgresql", "mysql", "mongodb", "redis", "minio", "ssh"} {
		if len(DefaultDeniedCommands(kind)) == 0 {
			t.Fatalf("no built-in deny list for %q, so enabling command blocking there does nothing", kind)
		}
	}
	// Case and padding come straight from a resource row, so both are handled.
	if len(DefaultDeniedCommands("  PostgreSQL ")) == 0 {
		t.Fatal("resource type lookup must tolerate case and whitespace")
	}
	// An unknown type gets nothing rather than someone else's list: guessing
	// here would refuse commands that are perfectly legitimate for that tool.
	if got := DefaultDeniedCommands("cassandra"); got != nil {
		t.Fatalf("unknown type returned %v, want nil", got)
	}
}

// The headline distinction: a resource is only egress-controlled once the
// connect path PAM cannot observe has been closed.
func TestEgressControlledStillRequiresClosingTheAgentPath(t *testing.T) {
	onlyCommands := DataProtection{DeniedCommands: "pg_dump"}
	if EgressControlled("", onlyCommands) {
		t.Fatal("a deny list on a resource that still permits the agent is not enforcement: the " +
			"operator holds the credential and can connect without pam-agent at all")
	}
	if !EgressControlled("web_proxy,web_terminal", onlyCommands) {
		t.Fatal("brokered-only with a live control IS egress-controlled")
	}
}
