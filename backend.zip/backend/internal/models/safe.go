// pam/internal/models/safe.go
package models

import (
	"fmt"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Safe represents a top-level security container in the PAM Vault hierarchy.
// Each safe maps directly to an IAM Policy resource ARN: pam:safe/{name}.
type Safe struct {
	ID            string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	Name          string         `gorm:"type:varchar(255);not null;uniqueIndex" json:"name"`
	Description   string         `gorm:"type:text" json:"description,omitempty"`
	OwnerID       string         `gorm:"type:varchar(36);not null;index" json:"owner_id"`
	IsDefault     bool           `gorm:"default:false" json:"is_default"`
	RetentionDays int            `gorm:"default:365" json:"retention_days"`
	CreatedAt     time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt     time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Safe) TableName() string { return "pam_safes" }

func (s *Safe) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.NewString()
	}
	if s.RetentionDays == 0 {
		s.RetentionDays = 365
	}
	return nil
}

// ResourceARN returns the canonical IAM resource string for OPA policy evaluations.
func (s *Safe) ResourceARN() string {
	return fmt.Sprintf("pam:safe/%s", s.Name)
}

// Folder represents a hierarchical folder inside a Safe for organizing credentials.
type Folder struct {
	ID             string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	SafeID         string         `gorm:"type:varchar(36);not null;index" json:"safe_id"`
	ParentFolderID *string        `gorm:"type:varchar(36);index" json:"parent_folder_id,omitempty"`
	Name           string         `gorm:"type:varchar(255);not null" json:"name"`
	Path           string         `gorm:"type:varchar(512);not null;index" json:"path"` // e.g. "/prod-databases/mysql"
	CreatedAt      time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt      time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt      gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Folder) TableName() string { return "pam_folders" }

func (f *Folder) BeforeCreate(tx *gorm.DB) error {
	if f.ID == "" {
		f.ID = uuid.NewString()
	}
	return nil
}

// SafeFolder is kept as a backward-compatible type alias for Folder.
type SafeFolder = Folder
