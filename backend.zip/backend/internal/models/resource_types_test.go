package models

import "testing"

// The nine types the console offers are creatable; the retired "web" type and
// anything unknown are not. Every creatable type must also have an entry in
// the channel table, or it would silently fall back to web-only.
func TestCreatableResourceTypes(t *testing.T) {
	for _, typ := range []string{"postgresql", "mongodb", "redis", "clickhouse", "minio", "qdrant", "metabase", "langfuse", "oracle"} {
		if !IsCreatableResourceType(typ) {
			t.Errorf("%s should be creatable", typ)
		}
		if _, ok := resourceTypeChannels[typ]; !ok {
			t.Errorf("%s has no channel table entry", typ)
		}
	}
	for _, typ := range []string{"web", "mongodb-compass", "", "guitest", "PostgreSQL "} {
		if IsCreatableResourceType(typ) {
			t.Errorf("%q must not be creatable", typ)
		}
	}
	// Retired, but existing rows of it still resolve to a channel.
	if got := SupportedChannels("web"); len(got) != 1 || got[0] != ChannelWeb {
		t.Errorf("legacy web rows lost their channel: %v", got)
	}
}
