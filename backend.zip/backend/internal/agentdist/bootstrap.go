// pam/internal/agentdist/bootstrap.go
//
// Rendering the installer a console click produces.
package agentdist

import (
	"bytes"
	"embed"
	"fmt"
	"net/url"
	"strings"
	"text/template"
	"time"
)

//go:embed templates/install-unix.sh.tmpl templates/install-windows.ps1.tmpl
var templateFS embed.FS

// text/template, not html/template, deliberately: the output is a shell or
// PowerShell script and HTML escaping would corrupt it. Every value
// interpolated below is therefore checked at the call site instead — see
// Render, which rejects anything that could break out of a quoted literal.
var installTemplates = template.Must(template.ParseFS(templateFS,
	"templates/install-unix.sh.tmpl",
	"templates/install-windows.ps1.tmpl"))

// Bootstrap is everything an installer needs baked into it.
type Bootstrap struct {
	ServerURL   string
	PairingCode string
	BinaryURL   string
	SHA256      string
	ExpiresAt   string

	Target Target

	// scriptURL is where the generated one-liner fetches this installer.
	// Unexported so a Bootstrap cannot be rendered with an empty command
	// line — set it through WithScriptURL.
	scriptURL string
}

// Script is a rendered installer plus how to serve it.
type Script struct {
	Filename    string `json:"filename"`
	ContentType string `json:"content_type"`
	Body        string `json:"body"`

	// Command is the single line an operator can paste instead of downloading
	// the file — the shortest path from "I need the agent" to "it is paired".
	Command string `json:"command"`
}

// Render produces the installer for a target.
//
// The pairing code and URLs are interpolated into a shell script, so each is
// validated first rather than trusted. A code containing a quote or a newline
// would end the string literal it sits in and turn the rest of the line into
// executable script — the classic injection, made worse here by the fact that
// the result is handed to an operator to run with their own privileges. The
// generator controls all three values today, which is exactly why the check
// belongs here: it stays correct when someone later makes one of them
// caller-supplied.
func Render(b Bootstrap) (Script, error) {
	if err := safeLiteral("server URL", b.ServerURL); err != nil {
		return Script{}, err
	}
	if err := safeLiteral("pairing code", b.PairingCode); err != nil {
		return Script{}, err
	}
	if err := safeLiteral("binary URL", b.BinaryURL); err != nil {
		return Script{}, err
	}
	if err := safeLiteral("checksum", b.SHA256); err != nil {
		return Script{}, err
	}
	if _, err := url.Parse(b.ServerURL); err != nil {
		return Script{}, fmt.Errorf("server URL is not a URL: %w", err)
	}

	windows := b.Target.OS == "windows"
	name := "install-unix.sh.tmpl"
	if windows {
		name = "install-windows.ps1.tmpl"
	}

	var out bytes.Buffer
	if err := installTemplates.ExecuteTemplate(&out, name, b); err != nil {
		return Script{}, fmt.Errorf("render installer: %w", err)
	}

	s := Script{Body: out.String()}
	if windows {
		s.Filename = "pam-agent-install.ps1"
		s.ContentType = "text/plain; charset=utf-8"
		// -ExecutionPolicy Bypass on the process only: it does not change the
		// machine's policy, and without it the default policy blocks a
		// downloaded script outright on most managed Windows builds.
		s.Command = fmt.Sprintf(
			`powershell -NoProfile -ExecutionPolicy Bypass -Command "irm '%s' | iex"`, b.ScriptURL())
	} else {
		s.Filename = "pam-agent-install.sh"
		s.ContentType = "text/x-shellscript; charset=utf-8"
		s.Command = fmt.Sprintf(`curl -fsSL '%s' | sh`, b.ScriptURL())
	}
	return s, nil
}

// ScriptURL is where the one-liner fetches this installer from. Held on the
// Bootstrap because the same value is needed by both the command and the
// console's download button.
func (b Bootstrap) ScriptURL() string { return b.scriptURL }

// scriptURL is set by the caller via WithScriptURL rather than exported
// directly, so a Bootstrap can never be rendered with an empty command line.
func (b Bootstrap) WithScriptURL(u string) Bootstrap {
	b.scriptURL = u
	return b
}

// safeLiteral rejects anything that could terminate the quoted string it is
// interpolated into, or smuggle a second statement onto the line.
func safeLiteral(field, v string) error {
	if v == "" {
		return fmt.Errorf("%s is empty", field)
	}
	if strings.ContainsAny(v, "'\"`\n\r\\$;&|<>()") {
		return fmt.Errorf("%s contains characters that are unsafe to embed in a script", field)
	}
	return nil
}

// FormatExpiry renders a code's expiry for the comment header, in UTC so it is
// unambiguous for an operator in any timezone.
func FormatExpiry(t time.Time) string {
	return t.UTC().Format("2006-01-02 15:04:05 MST")
}
