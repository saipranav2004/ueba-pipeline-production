package config

import (
	"os"
	"strings"
	"testing"
)

// Every secret published in .env.example must be refused in production, and
// the list here must match the file, or the guard silently stops guarding.
func TestExampleSecretsRefusedInProduction(t *testing.T) {
	raw, err := os.ReadFile("../../.env.example")
	if err != nil {
		t.Fatalf("read .env.example: %v", err)
	}
	env := map[string]string{}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if k, v, ok := strings.Cut(line, "="); ok {
			env[k] = v
		}
	}
	for _, k := range []string{"PAM_JWT_SECRET_KEY", "PAM_VAULT_ENCRYPTION_KEY", "PAM_VAULT_SERVICE_TOKEN_PEPPER", "PAM_AUDIT_HMAC_SECRET", "PAM_ROOT_PASSWORD"} {
		if !isExampleSecret(env[k]) {
			t.Errorf("%s in .env.example is not in exampleSecrets", k)
		}
	}

	good := strings.Repeat("r", 48)
	base := func() *Config {
		c := &Config{}
		c.Server.Env = "production"
		c.Database.Host, c.Database.Name = "db", "pam"
		c.JWT.SecretKey = good
		c.Vault.EncryptionKey = "cmVhbC1rZXktcmVhbC1rZXktcmVhbC1rZXktMzJieXQ="
		c.Vault.ServiceTokenPepper = good
		c.Audit.HMACSecret = good
		c.WebProxy.Scheme = "https"
		c.WebProxy.BaseDomain = "pam.example.com"
		return c
	}
	t.Setenv("PAM_ROOT_PASSWORD", "")
	if err := base().validate(); err != nil && strings.Contains(err.Error(), "sample value") {
		t.Fatalf("real secrets rejected as samples: %v", err)
	}

	sets := map[string]func(*Config, string){
		"PAM_JWT_SECRET_KEY":             func(c *Config, v string) { c.JWT.SecretKey = v },
		"PAM_VAULT_ENCRYPTION_KEY":       func(c *Config, v string) { c.Vault.EncryptionKey = v },
		"PAM_VAULT_SERVICE_TOKEN_PEPPER": func(c *Config, v string) { c.Vault.ServiceTokenPepper = v },
		"PAM_AUDIT_HMAC_SECRET":          func(c *Config, v string) { c.Audit.HMACSecret = v },
	}
	for k, set := range sets {
		c := base()
		set(c, env[k])
		err := c.validate()
		if err == nil || !strings.Contains(err.Error(), "sample value") {
			t.Errorf("production accepted the sample %s: %v", k, err)
		}
		// The same values are fine in development — that is their purpose.
		c.Server.Env = "development"
		if err := c.validate(); err != nil && strings.Contains(err.Error(), "sample value") {
			t.Errorf("development refused the sample %s: %v", k, err)
		}
	}

	t.Setenv("PAM_ROOT_PASSWORD", env["PAM_ROOT_PASSWORD"])
	if err := base().validate(); err == nil || !strings.Contains(err.Error(), "PAM_ROOT_PASSWORD") {
		t.Errorf("production accepted the sample root password: %v", err)
	}
}
