// pam/internal/response/response.go
package response

import "github.com/gin-gonic/gin"

// Success sends a standardized 200 JSON success envelope.
func Success(c *gin.Context, data interface{}, message string) {
	c.JSON(200, gin.H{
		"success": true,
		"message": message,
		"data":    data,
	})
}

// Created sends a standardized 201 JSON success envelope.
func Created(c *gin.Context, data interface{}, message string) {
	c.JSON(201, gin.H{
		"success": true,
		"message": message,
		"data":    data,
	})
}

// Error sends a standardized error JSON envelope.
func Error(c *gin.Context, status int, message string) {
	c.JSON(status, gin.H{
		"success": false,
		"error": gin.H{
			"message": message,
		},
	})
}

// ValidationError sends a 422 with field-level errors.
func ValidationError(c *gin.Context, errors map[string]string) {
	c.JSON(422, gin.H{
		"success": false,
		"error": gin.H{
			"message": "Validation failed",
			"fields":  errors,
		},
	})
}
