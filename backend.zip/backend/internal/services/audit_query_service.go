// pam/internal/services/audit_query_service.go
//
// Searchable audit log feature (Feature 107).
//
// We do not use an external search engine (Elasticsearch/Meilisearch) because:
//   - PostgreSQL's tsvector + GIN index handles 10M+ rows with sub-100ms latency
//   - One less moving part in the deployment
//   - Same DB = same backup, same RLS, same query planner
//
// If you outgrow it (>100M rows, or need fuzzy/phonetic matching), swap
// AuditQueryService.Search for an Elasticsearch-backed implementation.
//
// Placeholder rule (IMPORTANT — do not revert):
//   GORM's Raw() rewrites "?" → "$1", "$2", ... for pgx/lib-pq.
//   Never write raw "$N" in SQL passed to Raw(): GORM double-processes them
//   and produces malformed "$1$" that PostgreSQL interprets as a dollar-quoted
//   string, consuming the bound argument and returning "expected N args, got 0".

package services

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"gorm.io/gorm"
)

// AuditQueryService is the read side of the audit log. It's separate from
// AuditService (writes) so the IAM dashboard and admin tools can import
// just the reader without pulling in the HMAC secret.
type AuditQueryService struct {
	db *gorm.DB
}

func NewAuditQueryService(db *gorm.DB) *AuditQueryService {
	return &AuditQueryService{db: db}
}

// SearchFilters is the public query input. All fields are optional and
// combined with AND. Empty fields are skipped.
type SearchFilters struct {
	OrgID          string
	UserID         string
	Username       string
	Category       models.AuditCategory
	Action         string
	Outcome        models.AuditOutcome
	Resource       string
	ResourcePrefix string
	SourceIP       string
	FromTime       *time.Time
	ToTime         *time.Time
	Query          string
	Limit          int
	Offset         int
	Sort           string
}

// SearchResult is paginated.
type SearchResult struct {
	Total  int64             `json:"total"`
	Limit  int               `json:"limit"`
	Offset int               `json:"offset"`
	Items  []models.AuditLog `json:"items"`
}

// Search runs the query. It uses raw SQL because the generated tsvector
// column and GIN index are awkward to express in GORM's chainable API.
//
// Placeholder rule: always use "?" — GORM's Raw() translates these to
// $1, $2, ... for PostgreSQL automatically and correctly. Using $N directly
// causes GORM to double-process them into "$N$" (dollar-quoted literals),
// which drops all bound arguments.
func (s *AuditQueryService) Search(ctx context.Context, f SearchFilters) (*SearchResult, error) {
	if f.Limit <= 0 {
		f.Limit = 50
	}
	if f.Limit > 500 {
		f.Limit = 500
	}
	if f.Sort == "" {
		f.Sort = "occurred_at_desc"
	}

	// Build WHERE clause using "?" placeholders exclusively.
	// GORM rewrites each "?" to "$1", "$2", ... before sending to PostgreSQL.
	var (
		conds []string
		args  []interface{}
	)

	if f.OrgID != "" {
		conds = append(conds, "org_id = ?")
		args = append(args, f.OrgID)
	}
	if f.UserID != "" {
		conds = append(conds, "user_id = ?")
		args = append(args, f.UserID)
	}
	if f.Username != "" {
		conds = append(conds, "username = ?")
		args = append(args, f.Username)
	}
	if f.Category != "" {
		conds = append(conds, "category = ?")
		args = append(args, string(f.Category))
	}
	if f.Action != "" {
		conds = append(conds, "action = ?")
		args = append(args, f.Action)
	}
	if f.Outcome != "" {
		conds = append(conds, "outcome = ?")
		args = append(args, string(f.Outcome))
	}
	if f.Resource != "" {
		conds = append(conds, "resource = ?")
		args = append(args, f.Resource)
	}
	if f.ResourcePrefix != "" {
		// LIKE pattern: prefix% — the trailing % is part of the value,
		// not SQL syntax, so it's safe to pass as a bound argument.
		conds = append(conds, "resource LIKE ?")
		args = append(args, f.ResourcePrefix+"%")
	}
	if f.SourceIP != "" {
		conds = append(conds, "source_ip = ?")
		args = append(args, f.SourceIP)
	}
	if f.FromTime != nil {
		conds = append(conds, "occurred_at >= ?")
		args = append(args, *f.FromTime)
	}
	if f.ToTime != nil {
		conds = append(conds, "occurred_at <= ?")
		args = append(args, *f.ToTime)
	}
	if f.Query != "" {
		// plainto_tsquery is safe: it accepts arbitrary user input and
		// treats it as a phrase, not as tsquery syntax. No SQL injection.
		// The "?" is the bound argument placeholder — GORM will rewrite it
		// to "$N" when sending to PostgreSQL.
		conds = append(conds, "search_vector @@ plainto_tsquery('simple', ?)")
		args = append(args, f.Query)
	}

	where := ""
	if len(conds) > 0 {
		where = " WHERE " + strings.Join(conds, " AND ")
	}

	// ── Count query (one round trip) ────────────────────────────────────────
	// Pass args as a single []interface{} slice. GORM unwraps it correctly.
	var total int64
	countSQL := fmt.Sprintf("SELECT COUNT(*) FROM %s.pam_audit_log", getSchema()) + where
	if err := s.db.WithContext(ctx).Raw(countSQL, args...).Scan(&total).Error; err != nil {
		return nil, fmt.Errorf("count: %w", err)
	}

	// ── Ordering ─────────────────────────────────────────────────────────────
	// Order column is from a fixed switch, never from user input — no injection
	// risk. LIMIT/OFFSET are integer-formatted, also safe.
	order := "occurred_at DESC"
	switch f.Sort {
	case "occurred_at_asc":
		order = "occurred_at ASC"
	case "sequence_desc":
		order = "sequence_number DESC"
	}

	// ── Page query ───────────────────────────────────────────────────────────
	// LIMIT and OFFSET are integers controlled by this function (clamped above
	// and at the handler layer). They are formatted directly into the SQL
	// string — that is intentional and safe: no user string reaches them.
	pageSQL := fmt.Sprintf(
		"SELECT * FROM %s.pam_audit_log%s ORDER BY %s LIMIT %d OFFSET %d",
		getSchema(), where, order, f.Limit, f.Offset,
	)
	var rows []models.AuditLog
	if err := s.db.WithContext(ctx).Raw(pageSQL, args...).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("page: %w", err)
	}

	return &SearchResult{
		Total:  total,
		Limit:  f.Limit,
		Offset: f.Offset,
		Items:  rows,
	}, nil
}

// ByRequestID returns the full chain of events for one HTTP request.
func (s *AuditQueryService) ByRequestID(ctx context.Context, requestID string) ([]models.AuditLog, error) {
	var rows []models.AuditLog
	err := s.db.WithContext(ctx).
		Where("request_id = ?", requestID).
		Order("sequence_number ASC").
		Find(&rows).Error
	return rows, err
}

// ByUser returns the most recent N events for a single user.
func (s *AuditQueryService) ByUser(ctx context.Context, userID string, limit int) ([]models.AuditLog, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	var rows []models.AuditLog
	err := s.db.WithContext(ctx).
		Where("user_id = ?", userID).
		Order("occurred_at DESC").
		Limit(limit).
		Find(&rows).Error
	return rows, err
}

// ByResource returns the most recent N events for a target resource ARN.
func (s *AuditQueryService) ByResource(ctx context.Context, resource string, limit int) ([]models.AuditLog, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	var rows []models.AuditLog
	err := s.db.WithContext(ctx).
		Where("resource = ? OR resource LIKE ?", resource, resource+"/%").
		Order("occurred_at DESC").
		Limit(limit).
		Find(&rows).Error
	return rows, err
}
