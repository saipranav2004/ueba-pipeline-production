package services

import "os"

func getSchema() string {
	if s := os.Getenv("PAM_DATABASE_SCHEMA"); s != "" {
		return s
	}
	return "error no db schema"
}
