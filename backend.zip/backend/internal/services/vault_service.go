// pam/internal/services/vault_service.go
package services

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrSafeNotFound       = errors.New("safe not found")
	ErrCredentialNotFound = errors.New("credential not found")
	ErrInvalidCredType    = errors.New("invalid credential type specified")
	ErrCredentialArchived = errors.New("cannot checkout or reveal archived credential")

	// ErrAccountNameRequired is a CALLER error, not a server fault: handlers
	// map it to 400 so an operator sees what to fix rather than a 500 that
	// reads like PAM broke. See models.AccountNameRequiredFor.
	ErrAccountNameRequired = errors.New("account name required")
)

type StoreCredentialRequest struct {
	SafeID               string                `json:"safe_id"`
	FolderID             *string               `json:"folder_id,omitempty"`
	ResourceID           string                `json:"resource_id"`
	Name                 string                `json:"name"`
	Description          string                `json:"description"`
	// NOT binding:"required" — a required tag cannot express "required for a
	// password, meaningless for an API key". StoreCredential enforces the
	// real rule (models.AccountNameRequiredFor) for every caller, which a
	// binding tag could only do for one HTTP route.
	AccountName          string                `json:"account_name"`
	CredentialType       models.CredentialType `json:"credential_type" binding:"required"`
	SecretPlaintext      string                `json:"secret_plaintext" binding:"required"`
	MetadataJSON         string                `json:"metadata_json,omitempty"`
	RotationIntervalDays int                   `json:"rotation_interval_days"`
	CreatedBy            string                `json:"created_by"`
}

type CheckoutResult struct {
	EntryID        string `json:"entry_id"`
	AccountName    string `json:"account_name"`
	CredentialType string `json:"credential_type"`
	Plaintext      string `json:"plaintext"` // Transient plaintext; never log or persist
	ExpiresAt      string `json:"expires_at"`
}

type CredentialTypeMetadata struct {
	Type        string `json:"type"`
	Label       string `json:"label"`
	Description string `json:"description"`
}

type VaultService struct {
	db  *gorm.DB
	kms crypto.KMSProvider
	log *zap.Logger
}

// NewVaultService initializes the VaultService and sets up the KMS provider
// from the master key the caller passes in.
//
// keyB64 is the base64 32-byte master KEK. It is a PARAMETER, not something
// this constructor reads from the environment, and that is the whole point of
// the signature.
//
// It used to read PAM_VAULT_ENCRYPTION_KEY directly and fall back to a literal
// key written into this file when the variable was unset. Config validation
// requires vault.encryption_key to be present, but viper resolves that key
// from a config file (./config.yaml, ./configs, /etc/pam) as readily as from
// the environment — so a deployment that set the key in its config file, which
// is a perfectly ordinary thing to do, passed validation, started clean, and
// then encrypted its entire vault under the fallback key that ships in the
// source tree. Anyone holding the repository and a database dump or an S3
// vault backup could decrypt every credential in it.
//
// So: the key arrives from the validated config, and there is no fallback.
// An empty key is a refusal to start, never a silent downgrade — the failure
// mode of a wrong master key is loud and immediate, and the failure mode of a
// guessable one is silent and permanent.
func NewVaultService(db *gorm.DB, keyB64 string, log *zap.Logger) (*VaultService, error) {
	keyB64 = strings.TrimSpace(keyB64)
	if keyB64 == "" {
		return nil, errors.New(
			"vault master key is empty: set vault.encryption_key (PAM_VAULT_ENCRYPTION_KEY) " +
				"to a base64-encoded 32-byte key")
	}

	kms, err := crypto.NewLocalKMSProvider(keyB64)
	if err != nil {
		return nil, fmt.Errorf("failed to initialize KMS provider: %w", err)
	}

	return &VaultService{
		db:  db,
		kms: kms,
		log: log,
	}, nil
}

func (s *VaultService) DB() *gorm.DB {
	return s.db
}

func (s *VaultService) KMS() crypto.KMSProvider {
	return s.kms
}

func (s *VaultService) ListCredentialTypes(ctx context.Context) ([]CredentialTypeMetadata, error) {
	return []CredentialTypeMetadata{
		{"password", "Password", "Traditional alphanumeric username and password"},
		{"ssh_key", "SSH Private Key", "RSA or Ed25519 SSH private key with public key metadata"},
		{"x509_cert", "X.509 Certificate", "SSL/TLS client certificate and private key"},
		{"api_key", "API Key / Bearer Token", "REST API authentication key"},
		{"token", "OAuth / OIDC Token", "OAuth refresh token or identity token"},
		{"connection_string", "Connection String", "Database or service URI connection string"},
		{"kerberos_keytab", "Kerberos Keytab", "Domain authentication keytab"},
	}, nil
}

func (s *VaultService) CreateSafe(ctx context.Context, name, description, ownerID string, retention int) (*models.Safe, error) {
	safe := &models.Safe{
		Name:          name,
		Description:   description,
		OwnerID:       ownerID,
		RetentionDays: retention,
	}
	if err := s.db.Create(safe).Error; err != nil {
		return nil, fmt.Errorf("failed to create safe '%s': %w", name, err)
	}
	s.log.Info("vault.safe.created", zap.String("safe", name), zap.String("arn", safe.ResourceARN()))
	return safe, nil
}

func (s *VaultService) ListSafes(ctx context.Context) ([]models.Safe, error) {
	var safes []models.Safe
	err := s.db.Order("name ASC").Find(&safes).Error
	return safes, err
}

// SafeWithCount is a safe plus how many live credentials it holds.
type SafeWithCount struct {
	models.Safe
	CredentialCount int64 `json:"credential_count"`
}

// ListSafesWithCounts is what the safes table actually needs.
//
// The listing has always had a "Credentials" column and the endpoint has never
// returned a number for it, so every row read "-" — a column that cannot ever
// say anything, on the page whose whole job is choosing which safe to open.
//
// ONE grouped query, not one per safe. Counting per row is the fan-out this
// codebase has already removed twice (service identities, the secret path
// index); it degrades at a few dozen safes and is invisible until it does.
//
// Soft-deleted credentials are excluded, and so are non-active ones, so the
// number agrees with what opening the safe will actually show. A count that
// includes rows the next screen filters out is worse than no count.
func (s *VaultService) ListSafesWithCounts(ctx context.Context) ([]SafeWithCount, error) {
	safes, err := s.ListSafes(ctx)
	if err != nil {
		return nil, err
	}

	type row struct {
		SafeID string
		N      int64
	}
	var counts []row
	if err := s.db.WithContext(ctx).Model(&models.Credential{}).
		Select("safe_id, COUNT(*) AS n").
		Where("status = ?", "active").
		Group("safe_id").Scan(&counts).Error; err != nil {
		return nil, fmt.Errorf("failed to count credentials per safe: %w", err)
	}
	bySafe := make(map[string]int64, len(counts))
	for _, c := range counts {
		bySafe[c.SafeID] = c.N
	}

	out := make([]SafeWithCount, 0, len(safes))
	for _, sf := range safes {
		out = append(out, SafeWithCount{Safe: sf, CredentialCount: bySafe[sf.ID]})
	}
	return out, nil
}

func (s *VaultService) GetSafe(ctx context.Context, safeID string) (*models.Safe, error) {
	var safe models.Safe
	if err := s.db.Where("id = ? OR name = ?", safeID, safeID).First(&safe).Error; err != nil {
		return nil, ErrSafeNotFound
	}
	return &safe, nil
}

func (s *VaultService) CreateFolder(ctx context.Context, safeID, name, path string, parentID *string) (*models.Folder, error) {
	folder := &models.Folder{
		SafeID:         safeID,
		ParentFolderID: parentID,
		Name:           name,
		Path:           path,
	}
	if err := s.db.Create(folder).Error; err != nil {
		return nil, fmt.Errorf("failed to create folder: %w", err)
	}
	return folder, nil
}

func (s *VaultService) ListFolders(ctx context.Context, safeID string) ([]models.Folder, error) {
	var folders []models.Folder
	err := s.db.Where("safe_id = ?", safeID).Order("path ASC").Find(&folders).Error
	return folders, err
}

func (s *VaultService) StoreCredential(ctx context.Context, req StoreCredentialRequest) (*models.Credential, error) {
	if !models.IsValidCredentialType(string(req.CredentialType)) {
		return nil, ErrInvalidCredType
	}

	// Enforced here rather than in a binding tag so every caller gets the
	// same answer: the Vault route, the admin resource route, and anything
	// internal. Blank counts as absent — a principal made of spaces is the
	// fabricated one this is meant to prevent.
	if models.AccountNameRequiredFor(string(req.CredentialType)) &&
		strings.TrimSpace(req.AccountName) == "" {
		return nil, fmt.Errorf("%w: account_name is required for a %s credential, "+
			"which authenticates as a named account",
			ErrAccountNameRequired, req.CredentialType)
	}

	// NORMALISED BEFORE THE AAD IS COMPUTED, and that is load-bearing.
	//
	// SafeID's column default is applied by Postgres during the INSERT, which
	// happens AFTER this. Sealing under an empty safe_id and then reading back
	// under the "default" the database filled in is a GCM tag mismatch — the
	// credential stored fine and could never be read again. The model's
	// BeforeCreate hook normalises it too, but that runs after this point, so
	// both are needed. See models.Credential.EncryptionAAD.
	if req.SafeID == "" {
		req.SafeID = models.DefaultSafeID
	}

	// One helper, shared with every read below, so encrypt and decrypt cannot
	// drift apart again.
	aad := (&models.Credential{
		AccountName: req.AccountName,
		SafeID:      req.SafeID,
		ResourceID:  req.ResourceID,
	}).EncryptionAAD()

	encryptedSecret, err := crypto.EnvelopeEncryptor(ctx, s.kms, req.SecretPlaintext, aad)
	if err != nil {
		return nil, fmt.Errorf("envelope encryption failed: %w", err)
	}

	var nextRotation *time.Time
	if req.RotationIntervalDays > 0 {
		t := time.Now().AddDate(0, 0, req.RotationIntervalDays)
		nextRotation = &t
	}

	entry := &models.Credential{
		SafeID:               req.SafeID,
		FolderID:             req.FolderID,
		ResourceID:           req.ResourceID,
		Name:                 req.Name,
		Description:          req.Description,
		AccountName:          req.AccountName,
		CredentialType:       string(req.CredentialType),
		CredentialEnc:        encryptedSecret,
		MetadataJSON:         req.MetadataJSON,
		Status:               "active",
		Version:              1,
		RotationIntervalDays: req.RotationIntervalDays,
		NextRotationAt:       nextRotation,
		CreatedBy:            req.CreatedBy,
	}

	if entry.Name == "" {
		entry.Name = fmt.Sprintf("%s (%s)", req.AccountName, req.CredentialType)
	}

	if err := s.db.Create(entry).Error; err != nil {
		return nil, fmt.Errorf("failed to save credential: %w", err)
	}

	versionRow := models.CredentialVersion{
		CredentialID:  entry.ID,
		Version:       1,
		CredentialEnc: encryptedSecret,
		Reason:        "Initial credential intake",
		CreatedBy:     req.CreatedBy,
	}
	_ = s.db.Create(&versionRow)

	if req.ResourceID != "" {
		s.db.Model(&models.PAMResource{}).Where("id = ?", req.ResourceID).
			Update("vault_entry_id", entry.ID)
	}

	s.log.Info("vault.credential.stored",
		zap.String("credential_id", entry.ID),
		zap.String("type", string(req.CredentialType)),
		zap.String("account", req.AccountName),
	)
	return entry, nil
}

func (s *VaultService) ListCredentials(ctx context.Context, safeID string) ([]models.Credential, error) {
	query := s.db.Model(&models.Credential{}).Where("status != 'archived'")
	if safeID != "" {
		query = query.Where("safe_id = ?", safeID)
	}
	var entries []models.Credential
	err := query.Order("created_at DESC").Find(&entries).Error
	return entries, err
}

func (s *VaultService) GetCredential(ctx context.Context, credID string) (*models.Credential, error) {
	var cred models.Credential
	if err := s.db.First(&cred, "id = ?", credID).Error; err != nil {
		return nil, ErrCredentialNotFound
	}
	return &cred, nil
}

func (s *VaultService) RevealCredential(ctx context.Context, credID, operator, reason string) (*CheckoutResult, error) {
	var entry models.Credential
	if err := s.db.First(&entry, "id = ?", credID).Error; err != nil {
		return nil, ErrCredentialNotFound
	}
	if entry.Status == "archived" {
		return nil, ErrCredentialArchived
	}

	aad := entry.EncryptionAAD()

	plaintext, err := crypto.EnvelopeDecryptor(ctx, s.kms, entry.CredentialEnc, aad)
	if err != nil {
		return nil, fmt.Errorf("failed to decrypt envelope: %w", err)
	}

	expiresAt := time.Now().Add(60 * time.Minute).Format(time.RFC3339)
	s.log.Info("vault.credential.reveal",
		zap.String("credential_id", entry.ID),
		zap.String("operator", operator),
		zap.String("reason", reason),
	)

	return &CheckoutResult{
		EntryID:        entry.ID,
		AccountName:    entry.AccountName,
		CredentialType: entry.CredentialType,
		Plaintext:      plaintext,
		ExpiresAt:      expiresAt,
	}, nil
}

func (s *VaultService) CreateVersion(ctx context.Context, credID, plaintext, reason, operator string) (*models.CredentialVersion, error) {
	var entry models.Credential
	if err := s.db.First(&entry, "id = ?", credID).Error; err != nil {
		return nil, ErrCredentialNotFound
	}

	aad := entry.EncryptionAAD()

	encryptedSecret, err := crypto.EnvelopeEncryptor(ctx, s.kms, plaintext, aad)
	if err != nil {
		return nil, fmt.Errorf("envelope encryption failed: %w", err)
	}

	newVersion := entry.Version + 1
	versionRow := &models.CredentialVersion{
		CredentialID:  credID,
		Version:       newVersion,
		CredentialEnc: encryptedSecret,
		Reason:        reason,
		CreatedBy:     operator,
	}

	err = s.db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(versionRow).Error; err != nil {
			return err
		}
		entry.CredentialEnc = encryptedSecret
		entry.Version = newVersion
		entry.UpdatedBy = operator
		return tx.Save(&entry).Error
	})
	if err != nil {
		return nil, err
	}

	s.log.Info("vault.credential.version_created",
		zap.String("credential_id", credID),
		zap.Int("new_version", newVersion),
		zap.String("operator", operator),
	)
	return versionRow, nil
}

// PasswordChange updates the secret of a credential (manual or target rotation change).
func (s *VaultService) PasswordChange(ctx context.Context, credID, newPlaintext, operator string) (*models.CredentialVersion, error) {
	return s.CreateVersion(ctx, credID, newPlaintext, "Manual password change", operator)
}

func (s *VaultService) CheckoutCredential(ctx context.Context, entryID, operator, reason string) (*CheckoutResult, error) {
	return s.RevealCredential(ctx, entryID, operator, reason)
}

func (s *VaultService) ListVaultEntries(ctx context.Context, safeID string) ([]models.Credential, error) {
	return s.ListCredentials(ctx, safeID)
}

func (s *VaultService) GetDecryptedCredential(ctx context.Context, entryID string) (string, error) {
	var entry models.Credential
	if err := s.db.First(&entry, "id = ?", entryID).Error; err != nil {
		return "", err
	}
	return crypto.EnvelopeDecryptor(ctx, s.kms, entry.CredentialEnc, entry.EncryptionAAD())
}
