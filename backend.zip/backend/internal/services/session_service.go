// pam/internal/services/session_service.go
//
// Grant-aware session lifecycle. These methods extend ResourceService rather
// than introducing a second service, so there is exactly one owner of
// pam_connection_sessions.
//
// Why this file exists: without a way to OPEN a tracked session, "auto-revoke
// kills active sessions" is untestable — there is nothing to kill. StartTracked
// binds a session to the grant that authorised it, which is what makes
// cascading revocation possible.
package services

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrSessionNotFound = errors.New("session not found")
	ErrSessionNotOwned = errors.New("session belongs to a different user")
)

// StartSessionInput opens a tracked connection session.
type StartSessionInput struct {
	UserID          string
	Username        string
	ResourceID      string
	SourceIP        string
	Protocol        string
	AuthzDecisionID string

	// Grant binding — set by the RequireActiveGrant middleware when the
	// resource is JIT-gated. Empty for resources that are not JIT-gated.
	GrantID           string
	JITRequestID      string
	IsBreakglass      bool
	RecordingRequired bool
}

// SessionFilter drives session read queries (user view and IAM console).
type SessionFilter struct {
	UserID       string
	ResourceID   string
	Status       string
	GrantID      string
	ActiveOnly   bool
	IsBreakglass *bool
	From         *time.Time
	To           *time.Time
	Search       string
	Page         int
	PageSize     int
}

// RecordingFilter drives recording metadata queries.
type RecordingFilter struct {
	UserID       string
	ResourceID   string
	SessionID    string
	GrantID      string
	Status       string
	IsBreakglass *bool
	Page         int
	PageSize     int
}

// StartTrackedSession creates the session record (and, when the grant mandates
// it, the recording obligation) in a single transaction.
func (s *ResourceService) StartTrackedSession(in StartSessionInput) (*models.ConnectionSession, *models.SessionRecording, error) {
	resource, err := s.GetResource(in.ResourceID)
	if err != nil {
		return nil, nil, err
	}
	if !resource.IsActive {
		return nil, nil, ErrResourceInactive
	}

	// A resource can force recording regardless of how access was granted.
	recordingRequired := in.RecordingRequired || resource.AlwaysRecord || in.IsBreakglass

	protocol := in.Protocol
	if protocol == "" {
		protocol = resource.ResourceType
	}

	allowed := true
	session := &models.ConnectionSession{
		UserID:            in.UserID,
		Username:          in.Username,
		ResourceID:        resource.ID,
		ResourceName:      resource.Name,
		ResourceType:      resource.ResourceType,
		Protocol:          protocol,
		SourceIP:          in.SourceIP,
		Status:            "ACTIVE",
		IsBreakglass:      in.IsBreakglass,
		RecordingRequired: recordingRequired,
		AuthzAllowed:      &allowed,
	}
	if in.AuthzDecisionID != "" {
		d := in.AuthzDecisionID
		session.AuthzDecisionID = &d
	}
	if in.GrantID != "" {
		g := in.GrantID
		session.GrantID = &g
	}
	if in.JITRequestID != "" {
		r := in.JITRequestID
		session.JITRequestID = &r
	}

	var recording *models.SessionRecording

	err = s.db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(session).Error; err != nil {
			return fmt.Errorf("failed to create session: %w", err)
		}
		if !recordingRequired {
			return nil
		}
		rec := &models.SessionRecording{
			SessionID:    session.ID,
			UserID:       in.UserID,
			Username:     in.Username,
			ResourceID:   resource.ID,
			ResourceName: resource.Name,
			IsBreakglass: in.IsBreakglass,
			Format:       "asciicast",
			Status:       models.RecordingStatusPending,
			StartedAt:    time.Now().UTC(),
		}
		if in.GrantID != "" {
			g := in.GrantID
			rec.GrantID = &g
		}
		if err := tx.Create(rec).Error; err != nil {
			return fmt.Errorf("failed to create recording obligation: %w", err)
		}
		if err := tx.Model(&models.ConnectionSession{}).Where("id = ?", session.ID).
			Update("recording_id", rec.ID).Error; err != nil {
			return err
		}
		session.RecordingID = &rec.ID
		recording = rec
		return nil
	})
	if err != nil {
		return nil, nil, err
	}

	s.logger.Info("session.started",
		zap.String("session_id", session.ID),
		zap.String("user", in.Username),
		zap.String("resource", resource.Name),
		zap.String("grant_id", in.GrantID),
		zap.Bool("breakglass", in.IsBreakglass),
		zap.Bool("recording_required", recordingRequired),
	)
	return session, recording, nil
}

// GetSession fetches a session by id.
func (s *ResourceService) GetSession(id string) (*models.ConnectionSession, error) {
	var sess models.ConnectionSession
	if err := s.db.Where("id = ?", id).First(&sess).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrSessionNotFound
		}
		return nil, err
	}
	return &sess, nil
}

// EndTrackedSession closes a session. Users may only end their own sessions;
// pass allowAnyOwner=true for admin/system callers.
func (s *ResourceService) EndTrackedSession(sessionID, userID string, allowAnyOwner bool) (*models.ConnectionSession, error) {
	sess, err := s.GetSession(sessionID)
	if err != nil {
		return nil, err
	}
	if !allowAnyOwner && sess.UserID != userID {
		return nil, ErrSessionNotOwned
	}
	if sess.Status != "ACTIVE" {
		// Idempotent: ending an already-closed session is not an error.
		return sess, nil
	}

	now := time.Now().UTC()
	err = s.db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.ConnectionSession{}).
			Where("id = ? AND status = 'ACTIVE'", sessionID).
			Updates(map[string]interface{}{
				"status":           "COMPLETED",
				"ended_at":         now,
				"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
			}).Error; err != nil {
			return err
		}
		return closeRecordingTx(tx, sessionID, now)
	})
	if err != nil {
		return nil, err
	}
	return s.GetSession(sessionID)
}

// KillSessionsByGrantTx terminates every ACTIVE session opened under a grant.
// It runs inside the caller's transaction so revocation is atomic: either the
// grant is revoked AND its sessions are killed, or neither happens.
func (s *ResourceService) KillSessionsByGrantTx(tx *gorm.DB, grantID, killedBy, reason string) (int, error) {
	now := time.Now().UTC()

	var ids []string
	if err := tx.Model(&models.ConnectionSession{}).
		Where("grant_id = ? AND status = 'ACTIVE'", grantID).
		Pluck("id", &ids).Error; err != nil {
		return 0, err
	}
	if len(ids) == 0 {
		return 0, nil
	}

	if err := tx.Model(&models.ConnectionSession{}).
		Where("id IN ? AND status = 'ACTIVE'", ids).
		Updates(map[string]interface{}{
			"status":           "KILLED",
			"ended_at":         now,
			"kill_reason":      reason,
			"killed_by":        killedBy,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error; err != nil {
		return 0, err
	}

	// Close any open recording obligations for those sessions.
	if err := tx.Model(&models.SessionRecording{}).
		Where("session_id IN ? AND status IN ?", ids,
			[]string{models.RecordingStatusPending, models.RecordingStatusRecording}).
		Updates(map[string]interface{}{
			"status":           models.RecordingStatusCompleted,
			"ended_at":         now,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error; err != nil {
		return 0, err
	}

	return len(ids), nil
}

// KillSessionsForUserResourceTx is the containment hammer: kill every ACTIVE
// session a user holds on a resource, whether or not it came from a grant.
func (s *ResourceService) KillSessionsForUserResourceTx(tx *gorm.DB, userID, resourceID, killedBy, reason string) (int, error) {
	now := time.Now().UTC()
	res := tx.Model(&models.ConnectionSession{}).
		Where("user_id = ? AND resource_id = ? AND status = 'ACTIVE'", userID, resourceID).
		Updates(map[string]interface{}{
			"status":           "KILLED",
			"ended_at":         now,
			"kill_reason":      reason,
			"killed_by":        killedBy,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		})
	return int(res.RowsAffected), res.Error
}

// closeRecordingTx marks an open recording obligation as finished.
func closeRecordingTx(tx *gorm.DB, sessionID string, now time.Time) error {
	return tx.Model(&models.SessionRecording{}).
		Where("session_id = ? AND status IN ?", sessionID,
			[]string{models.RecordingStatusPending, models.RecordingStatusRecording}).
		Updates(map[string]interface{}{
			"status":           models.RecordingStatusCompleted,
			"ended_at":         now,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// READ QUERIES (IAM admin console + user view)
// ──────────────────────────────────────────────────────────────────────────

// ListSessions returns a filtered, paginated set of sessions plus total count.
func (s *ResourceService) ListSessions(f SessionFilter) ([]models.ConnectionSession, int64, error) {
	page, size := normalisePaging(f.Page, f.PageSize)

	q := s.db.Model(&models.ConnectionSession{})
	if f.UserID != "" {
		q = q.Where("user_id = ?", f.UserID)
	}
	if f.ResourceID != "" {
		q = q.Where("resource_id = ?", f.ResourceID)
	}
	if f.GrantID != "" {
		q = q.Where("grant_id = ?", f.GrantID)
	}
	if f.ActiveOnly {
		q = q.Where("status = ?", "ACTIVE")
	} else if f.Status != "" {
		q = q.Where("status = ?", strings.ToUpper(f.Status))
	}
	if f.IsBreakglass != nil {
		q = q.Where("is_breakglass = ?", *f.IsBreakglass)
	}
	if f.From != nil {
		q = q.Where("started_at >= ?", *f.From)
	}
	if f.To != nil {
		q = q.Where("started_at <= ?", *f.To)
	}
	if f.Search != "" {
		like := "%" + strings.ToLower(f.Search) + "%"
		q = q.Where("LOWER(username) LIKE ? OR LOWER(resource_name) LIKE ? OR LOWER(source_ip) LIKE ?",
			like, like, like)
	}

	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	var rows []models.ConnectionSession
	err := q.Order("started_at DESC").Limit(size).Offset((page - 1) * size).Find(&rows).Error
	return rows, total, err
}

// ListRecordings returns recording metadata for the IAM admin console.
func (s *ResourceService) ListRecordings(f RecordingFilter) ([]models.SessionRecording, int64, error) {
	page, size := normalisePaging(f.Page, f.PageSize)

	q := s.db.Model(&models.SessionRecording{})
	if f.UserID != "" {
		q = q.Where("user_id = ?", f.UserID)
	}
	if f.ResourceID != "" {
		q = q.Where("resource_id = ?", f.ResourceID)
	}
	if f.SessionID != "" {
		q = q.Where("session_id = ?", f.SessionID)
	}
	if f.GrantID != "" {
		q = q.Where("grant_id = ?", f.GrantID)
	}
	if f.Status != "" {
		q = q.Where("status = ?", strings.ToUpper(f.Status))
	}
	if f.IsBreakglass != nil {
		q = q.Where("is_breakglass = ?", *f.IsBreakglass)
	}

	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	var rows []models.SessionRecording
	err := q.Order("started_at DESC").Limit(size).Offset((page - 1) * size).Find(&rows).Error
	return rows, total, err
}

// CountActiveSessions powers the IAM admin dashboard tiles.
func (s *ResourceService) CountActiveSessions() (int64, error) {
	var n int64
	err := s.db.Model(&models.ConnectionSession{}).Where("status = ?", "ACTIVE").Count(&n).Error
	return n, err
}

// CountResources powers the IAM admin dashboard tiles.
func (s *ResourceService) CountResources() (int64, error) {
	var n int64
	err := s.db.Model(&models.PAMResource{}).Where("is_active = ?", true).Count(&n).Error
	return n, err
}
