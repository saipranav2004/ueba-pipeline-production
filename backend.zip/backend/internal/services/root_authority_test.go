// pam/internal/services/root_authority_test.go
//
// Root's classification has two halves, and only one of them lives in the
// scorer. These pin the other half, the parts that only fail against a
// database:
//
//  1. The seed attaches full-access to root on an install that ALREADY
//     exists. This is the half that decides whether a running deployment
//     picks the fix up on restart or stays broken forever. The bundle edit
//     is worth nothing if the seeder only wires attachments for rows it
//     created itself, and reading the seeder is not proof that it does not.
//
//  2. An override on root is refused before anything is written. The scorer
//     does not consult overrides for root, so an override that were accepted
//     would be stored, audited, answered with 200, and then ignored.
package services

import (
	"context"
	"errors"
	"testing"

	"github.com/glebarez/sqlite"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

func rootAuthorityDB(t *testing.T) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open in-memory sqlite: %v", err)
	}
	if err := db.AutoMigrate(
		&models.Role{}, &models.Policy{}, &models.RolePolicy{},
		&models.UserRole{}, &models.UserPolicy{}, &models.PAMResource{},
		&models.RoleCriticalityOverride{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func attachedPolicyNames(t *testing.T, db *gorm.DB, roleName string) []string {
	t.Helper()
	var role models.Role
	if err := db.Where("name = ?", roleName).First(&role).Error; err != nil {
		t.Fatalf("role %q not seeded: %v", roleName, err)
	}
	var links []models.RolePolicy
	if err := db.Where("role_id = ?", role.ID).Find(&links).Error; err != nil {
		t.Fatalf("read role policies: %v", err)
	}
	out := make([]string, 0, len(links))
	for _, l := range links {
		var p models.Policy
		if err := db.Where("id = ?", l.PolicyID).First(&p).Error; err == nil {
			out = append(out, p.Name)
		}
	}
	return out
}

func hasName(list []string, want string) bool {
	for _, v := range list {
		if v == want {
			return true
		}
	}
	return false
}

// NOTE — a test was removed here during the dev-v3 merge.
//
// TestSeedAttachesFullAccessToRootOnAnAlreadySeededInstall asserted that
// SeedRBACDefaults attaches the "full-access" policy to the root role, so that
// root's authority comes from a seeded policy row.
//
// This backend deliberately does the opposite. Root is a hard-coded bypass
// evaluated before any policy is consulted (opa/engine.go, Input.IsRoot):
//
//     "a corrupted or over-eagerly-tightened policy set must never be able to
//      lock the root account out of its own system"
//
// Attaching a policy to root would make root's authority DEPEND on the table
// that bypass exists to be independent of — and would tell an auditor reading
// the role's attached policies that policy governs root, which it does not.
//
// The test was never green at its source either: dev-v3's services test
// package did not compile (it referenced an undefined looksLikeBackupCode), so
// this expectation had never actually run. Removed rather than adapted,
// because there is no version of it that is true here.

func TestOverridingRootIsRefusedAndWritesNothing(t *testing.T) {
	db := rootAuthorityDB(t)
	svc := NewRoleCriticalityService(db, nil, zap.NewNop())
	if err := svc.Migrate(); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	root := models.Role{Name: "root", IsSystem: true}
	if err := db.Create(&root).Error; err != nil {
		t.Fatalf("create root: %v", err)
	}

	_, err := svc.SetOverride(context.Background(), SetOverrideInput{
		RoleID: root.ID, Band: "LOW",
		Reason:    "trying to talk the classifier down from the one role that bypasses it",
		ActorID:   "u-1",
		ActorName: "das_admin",
	})
	if !errors.Is(err, ErrRootNotOverridable) {
		t.Fatalf("expected ErrRootNotOverridable, got %v", err)
	}

	var n int64
	if err := db.Model(&models.RoleCriticalityOverride{}).Where("role_id = ?", root.ID).Count(&n).Error; err != nil {
		t.Fatalf("count overrides: %v", err)
	}
	if n != 0 {
		t.Fatalf("a refused override must not leave a row behind, found %d", n)
	}

	// And the band the console reads is untouched.
	got, err := svc.Get(root.ID)
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if got.Band != models.BandCritical || got.IsOverridden {
		t.Fatalf("root should still be CRITICAL and un-overridden, got band=%s overridden=%v", got.Band, got.IsOverridden)
	}
}

// A custom role is unaffected: the refusal is scoped to root, not to overrides.
func TestOverridingAnOrdinaryRoleStillWorks(t *testing.T) {
	db := rootAuthorityDB(t)
	svc := NewRoleCriticalityService(db, nil, zap.NewNop())
	if err := svc.Migrate(); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	r := models.Role{Name: "reporting-readonly"}
	if err := db.Create(&r).Error; err != nil {
		t.Fatalf("create role: %v", err)
	}
	got, err := svc.SetOverride(context.Background(), SetOverrideInput{
		RoleID: r.ID, Band: "HIGH",
		Reason: "reaches the finance warehouse through a pattern the scorer cannot see",
	})
	if err != nil {
		t.Fatalf("override an ordinary role: %v", err)
	}
	if got.Band != models.CriticalityBand("HIGH") || !got.IsOverridden {
		t.Fatalf("expected an applied HIGH override, got band=%s overridden=%v", got.Band, got.IsOverridden)
	}
}
