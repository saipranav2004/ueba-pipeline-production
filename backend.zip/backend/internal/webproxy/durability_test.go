// pam/internal/webproxy/durability_test.go
//
// The property these tests exist for: a recording must survive the process
// that made it.
//
// The original design buffered a session's entire stream in memory and wrote
// it once, at End. That made every recording an all-or-nothing bet on the
// end-of-session path completing: a restart, a crash, a deploy, or any fault
// at all in that path destroyed the whole session's evidence and left the row
// to be orphaned to FAILED with nothing behind it. Three consecutive
// production sessions failed exactly that way.
//
// Write-through changes the failure mode from "lose the session" to "lose the
// last interval". These tests pin that, and pin the two rules that make it
// safe: flushes overwrite one key rather than scattering objects, and a flush
// can never disturb a recording that has already been resolved.
package webproxy

import (
	"bytes"
	"compress/gzip"
	"context"
	"io"
	"strings"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
)

// A mid-session flush must leave a replayable artifact behind while the
// session is still running.
func TestFlushPersistsAnArtifactMidSession(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: "GET", Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	svc.flushOpenRecordings(context.Background())

	store.mu.Lock()
	objects := len(store.objects)
	store.mu.Unlock()
	if objects != 1 {
		t.Fatalf("stored %d objects, want 1 — a live session must already have an artifact", objects)
	}

	var rec models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if rec.StorageKey == "" || rec.SizeBytes <= 0 || rec.SHA256 == "" {
		t.Fatalf("flush did not record artifact metadata: key=%q size=%d sha=%q",
			rec.StorageKey, rec.SizeBytes, rec.SHA256)
	}
	// Still in flight: the flush records progress, it does not resolve the row.
	if rec.Status != models.RecordingStatusRecording {
		t.Fatalf("status = %q, want RECORDING — a flush must not resolve the recording", rec.Status)
	}
}

// Repeated flushes must overwrite one object. Scattering a session across many
// keys would leave an auditor with several partial artifacts and no way to
// tell which is current.
func TestRepeatedFlushesOverwriteOneKey(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	var keys []string
	for i := 0; i < 4; i++ {
		svc.RecordActivity(rs, ActivityRecord{
			Method: "GET", Path: "/page", StatusCode: 200,
			IsDocument: true, OccurredAt: time.Now().UTC(),
		})
		svc.flushOpenRecordings(context.Background())

		var rec models.SessionRecording
		if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
			t.Fatalf("reload: %v", err)
		}
		keys = append(keys, rec.StorageKey)
	}

	store.mu.Lock()
	objects := len(store.objects)
	store.mu.Unlock()
	if objects != 1 {
		t.Fatalf("4 flushes produced %d objects, want 1", objects)
	}
	for i, k := range keys {
		if k != keys[0] {
			t.Fatalf("flush %d used key %q, want the stable %q", i, k, keys[0])
		}
	}
}

// The final write must land on the same key the flushes used, so it replaces
// the partial artifact rather than leaving one beside it.
func TestFinalWriteReplacesTheFlushedArtifact(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: "GET", Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	svc.flushOpenRecordings(context.Background())
	var afterFlush models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&afterFlush).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "done"); err != nil {
		t.Fatalf("End: %v", err)
	}

	store.mu.Lock()
	objects := len(store.objects)
	store.mu.Unlock()
	if objects != 1 {
		t.Fatalf("flush + finalize produced %d objects, want 1 (the final write must overwrite)", objects)
	}

	var final models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&final).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if final.StorageKey != afterFlush.StorageKey {
		t.Fatalf("final key %q differs from the flushed key %q", final.StorageKey, afterFlush.StorageKey)
	}
	if final.Status != models.RecordingStatusCompleted {
		t.Fatalf("status = %q, want COMPLETED", final.Status)
	}
	// The final artifact carries the footer, so it must be larger than the
	// partial it replaced — proof the overwrite is the newer snapshot.
	if final.SizeBytes <= afterFlush.SizeBytes {
		t.Fatalf("final size %d is not greater than the flushed %d; the overwrite may be stale",
			final.SizeBytes, afterFlush.SizeBytes)
	}
}

// THE headline guarantee: a session whose process dies without ever calling
// End still yields a replayable recording, because the flush already wrote one.
// This is the exact scenario that lost three production sessions.
func TestRecordingSurvivesAProcessThatNeverCallsEnd(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: "POST", Path: "/api/v1/buckets", StatusCode: 200,
		OccurredAt: time.Now().UTC(),
	})
	svc.flushOpenRecordings(context.Background())

	// Simulate the crash: the session's tracked row ends, and the cast is gone
	// with the process. End is never called.
	endConnectionSession(t, svc, row.ConnectionSessionID)
	svc.castMu.Lock()
	delete(svc.casts, row.ID)
	svc.castMu.Unlock()

	if _, err := svc.resources.ReconcileOrphanedRecordings(context.Background()); err != nil {
		t.Fatalf("ReconcileOrphanedRecordings: %v", err)
	}

	var rec models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if rec.Status != models.RecordingStatusCompleted {
		t.Fatalf("status = %q, want COMPLETED: an interrupted recording with a flushed artifact is "+
			"partial evidence, not lost evidence. reason=%q", rec.Status, rec.FailureReason)
	}
	if rec.StorageKey == "" {
		t.Fatal("completed recording has no artifact key")
	}
	if !strings.Contains(rec.FailureReason, "interrupted") {
		t.Fatalf("the interruption must be stated on the row so an auditor knows the tail may be "+
			"missing, got %q", rec.FailureReason)
	}
	store.mu.Lock()
	_, present := store.objects[rec.StorageKey]
	store.mu.Unlock()
	if !present {
		t.Fatal("the row points at an artifact that is not in storage")
	}
}

// A recording with no artifact at all is still a genuine failure — the
// partial-completion rule must not paper over a recording that never wrote
// anything.
func TestOrphanWithNoArtifactStillFails(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	svc.recordingStorage = newMemStorage()

	row, recordingID := seedRecordedSession(t, svc)
	// No flush, no activity: nothing was ever written.
	endConnectionSession(t, svc, row.ConnectionSessionID)
	if _, err := svc.resources.ReconcileOrphanedRecordings(context.Background()); err != nil {
		t.Fatalf("ReconcileOrphanedRecordings: %v", err)
	}

	var rec models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if rec.Status != models.RecordingStatusFailed {
		t.Fatalf("status = %q, want FAILED — nothing was ever written for this recording", rec.Status)
	}
	if !strings.Contains(rec.FailureReason, "orphaned") {
		t.Fatalf("expected the orphan reason, got %q", rec.FailureReason)
	}
}

// A flush must never touch a recording that End (or the sweep) already
// resolved: a late write would otherwise reopen settled evidence.
func TestFlushLeavesResolvedRecordingsAlone(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: "GET", Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	// Resolve it out from under the flush, leaving the cast in place.
	if err := svc.db.Model(&models.SessionRecording{}).Where("id = ?", recordingID).
		Updates(map[string]interface{}{
			"status": models.RecordingStatusFailed, "failure_reason": "resolved by something else",
		}).Error; err != nil {
		t.Fatalf("mark failed: %v", err)
	}

	svc.flushOpenRecordings(context.Background())

	var rec models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if rec.Status != models.RecordingStatusFailed {
		t.Fatalf("status = %q, want the resolved FAILED to stand", rec.Status)
	}
	if rec.StorageKey != "" {
		t.Fatalf("a flush wrote to a resolved recording (key %q)", rec.StorageKey)
	}
	store.mu.Lock()
	objects := len(store.objects)
	store.mu.Unlock()
	if objects != 0 {
		t.Fatalf("a flush stored %d objects for a resolved recording, want 0", objects)
	}
}

// Flushing with nothing in flight must be a cheap no-op, since it runs on
// every sweeper tick for the lifetime of the process.
func TestFlushIsANoopWithNoOpenRecordings(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	svc.flushOpenRecordings(context.Background())

	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.objects) != 0 {
		t.Fatalf("stored %d objects with no sessions open", len(store.objects))
	}
}

// endConnectionSession puts a tracked session into the state the orphan
// reconciler looks for: ended, and ended long enough ago to be past the grace
// period. Set directly rather than via EndTrackedSession because that path
// stamps duration with Postgres-only SQL, which the in-memory test engine
// cannot parse — and these fixtures care about the row state, not how it got
// there.
func endConnectionSession(t *testing.T, svc *Service, connectionSessionID string) {
	t.Helper()
	if err := svc.db.Model(&models.ConnectionSession{}).
		Where("id = ?", connectionSessionID).
		Updates(map[string]interface{}{
			"status":   "COMPLETED",
			"ended_at": time.Now().UTC().Add(-5 * time.Minute),
		}).Error; err != nil {
		t.Fatalf("end connection session: %v", err)
	}
}

// A session's format can change mid-flight: early flushes write the request
// transcript, then rrweb frames arrive and the visual replay becomes primary.
// Reusing the first key regardless of format would store the replay under a
// .cast.gz name — and finalize writes the demoted transcript to exactly that
// name, so the transcript would overwrite the replay and the session's visual
// evidence would be silently replaced by its request log.
func TestFormatChangeMidSessionDoesNotOverwriteTheReplay(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	// Phase 1: transcript only — the browser has not delivered frames yet.
	svc.RecordActivity(rs, ActivityRecord{
		Method: "GET", Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})
	svc.flushOpenRecordings(context.Background())

	var afterTranscript models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&afterTranscript).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if !strings.HasSuffix(afterTranscript.StorageKey, ".cast.gz") {
		t.Fatalf("first flush key = %q, want a .cast.gz transcript", afterTranscript.StorageKey)
	}

	// Phase 2: frames arrive, so the visual replay takes over.
	svc.RecordReplayBatch(rs, []byte(sampleEvents))
	svc.flushOpenRecordings(context.Background())

	var afterReplay models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&afterReplay).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if afterReplay.Format != replayFormat {
		t.Fatalf("format = %q, want %q once frames arrived", afterReplay.Format, replayFormat)
	}
	if !strings.HasSuffix(afterReplay.StorageKey, ".rrweb.gz") {
		t.Fatalf("key = %q; a format change must move the artifact to a matching key, or the "+
			"transcript sidecar will overwrite the replay", afterReplay.StorageKey)
	}

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "tab closed"); err != nil {
		t.Fatalf("End: %v", err)
	}

	var final models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&final).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if final.TranscriptKey == nil || *final.TranscriptKey == "" {
		t.Fatal("the transcript must be stored as the secondary artifact")
	}
	if *final.TranscriptKey == final.StorageKey {
		t.Fatalf("the transcript and the replay share key %q — one has overwritten the other",
			final.StorageKey)
	}

	// Both artifacts must survive, and the primary must still be rrweb.
	store.mu.Lock()
	defer store.mu.Unlock()
	primary, okPrimary := store.objects[final.StorageKey]
	_, okTranscript := store.objects[*final.TranscriptKey]
	if !okPrimary || !okTranscript {
		t.Fatalf("expected both artifacts in storage: primary=%v transcript=%v", okPrimary, okTranscript)
	}
	gr, err := gzip.NewReader(bytes.NewReader(primary))
	if err != nil {
		t.Fatalf("primary is not gzip: %v", err)
	}
	defer gr.Close()
	raw, err := io.ReadAll(gr)
	if err != nil {
		t.Fatalf("read primary: %v", err)
	}
	if strings.Contains(string(raw), "brokered web session") {
		t.Fatal("the primary artifact is the transcript banner — the replay was overwritten")
	}
}

// A recording that holds a replayable artifact must never read FAILED.
//
// This is the bug the console surfaced as "status says FAILED but it plays":
// the reconciler decided from the row it had SELECTed, and a write-through
// flush set storage_key before the per-row UPDATE landed. The UPDATE's status
// guard still matched, so it stamped FAILED over a recording that by then had
// a perfectly good 300KB artifact. Evidence present, label wrong — which is
// worse than either being consistently true, because it teaches an auditor to
// distrust the status column everywhere.
func TestArtifactAcquiredDuringReconcileIsNotMarkedFailed(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: "GET", Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	// The session ended long enough ago to be an orphan, and nothing
	// finalised it — the state this whole path exists for.
	endConnectionSession(t, svc, row.ConnectionSessionID)

	// The flush lands its artifact. In production this raced the reconciler's
	// own UPDATE; here it simply happens first, which is the same state the
	// UPDATE must then evaluate rather than trusting its earlier snapshot.
	svc.flushOpenRecordings(context.Background())

	if _, err := svc.resources.ReconcileOrphanedRecordings(context.Background()); err != nil {
		t.Fatalf("ReconcileOrphanedRecordings: %v", err)
	}

	var rec models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&rec).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if rec.Status == models.RecordingStatusFailed {
		t.Fatalf("a recording with a %d-byte artifact at %q was marked FAILED (%q) — the status "+
			"column must never contradict a replayable artifact",
			rec.SizeBytes, rec.StorageKey, rec.FailureReason)
	}
	if rec.Status != models.RecordingStatusCompleted {
		t.Fatalf("status = %q, want COMPLETED", rec.Status)
	}
	if !strings.Contains(rec.FailureReason, "interrupted") {
		t.Fatalf("the interruption must still be stated, got %q", rec.FailureReason)
	}
}

// And the repair pass corrects rows that were already mislabelled by the
// version of this code that had the race, so an operator's existing history
// stops lying to them.
func TestExistingMislabelledRecordingsAreRepaired(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	// Exactly the shape the console showed: FAILED, orphan message, but a
	// real artifact with a real size.
	bad := &models.SessionRecording{
		SessionID: "conn-mislabelled", UserID: "alice", Username: "alice",
		ResourceID: "res-1", ResourceName: "Prod MinIO",
		Format: "rrweb", Status: models.RecordingStatusFailed,
		StorageBucket: "minio",
		StorageKey:    "recordings/2026/08/20/abc.rrweb.gz",
		SizeBytes:     305125,
		FailureReason: "orphaned: the session ended without this recording ever being finalized " +
			"(likely a server restart/crash mid-session) — no artifact exists for it",
		StartedAt: now.Add(-10 * time.Minute),
	}
	if err := svc.db.Create(bad).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}

	// A genuine failure — no artifact — must be left exactly as it is.
	genuine := &models.SessionRecording{
		SessionID: "conn-genuine", UserID: "alice", Username: "alice",
		ResourceID: "res-1", ResourceName: "Prod MinIO",
		Format: "asciicast", Status: models.RecordingStatusFailed,
		FailureReason: "orphaned: the session ended without this recording ever being finalized " +
			"(likely a server restart/crash mid-session) — no artifact exists for it",
		StartedAt: now.Add(-10 * time.Minute),
	}
	if err := svc.db.Create(genuine).Error; err != nil {
		t.Fatalf("seed genuine: %v", err)
	}

	// An upload failure that really did lose the artifact must also stand:
	// the repair is scoped to the orphan message precisely so a storage error
	// is never quietly relabelled as fine.
	uploadFailed := &models.SessionRecording{
		SessionID: "conn-upload", UserID: "alice", Username: "alice",
		ResourceID: "res-1", ResourceName: "Prod MinIO",
		Format: "asciicast", Status: models.RecordingStatusFailed,
		StorageKey: "recordings/2026/08/20/partial.cast.gz", SizeBytes: 10,
		FailureReason: "failed to persist brokered web session recording: connection refused",
		StartedAt:     now.Add(-10 * time.Minute),
	}
	if err := svc.db.Create(uploadFailed).Error; err != nil {
		t.Fatalf("seed upload-failed: %v", err)
	}

	if _, err := svc.resources.ReconcileOrphanedRecordings(context.Background()); err != nil {
		t.Fatalf("ReconcileOrphanedRecordings: %v", err)
	}

	// A fresh struct per read: GORM adds a populated struct's primary key to
	// the next query's WHERE, so reusing one here silently looks up the wrong
	// row and reports "record not found".
	reload := func(id string) models.SessionRecording {
		t.Helper()
		var out models.SessionRecording
		if err := svc.db.Where("id = ?", id).First(&out).Error; err != nil {
			t.Fatalf("reload %s: %v", id, err)
		}
		return out
	}

	if got := reload(bad.ID); got.Status != models.RecordingStatusCompleted {
		t.Fatalf("a FAILED row holding a %d-byte artifact was not repaired (status %q)",
			got.SizeBytes, got.Status)
	}
	if got := reload(genuine.ID); got.Status != models.RecordingStatusFailed {
		t.Fatalf("a recording with no artifact must stay FAILED, got %q", got.Status)
	}
	if got := reload(uploadFailed.ID); got.Status != models.RecordingStatusFailed {
		t.Fatalf("a genuine upload failure must stay FAILED, got %q — relabelling it would hide "+
			"a real storage problem", got.Status)
	}
}
