// pam/internal/webproxy/replay.go
//
// Visual session replay for brokered web sessions.
//
// The HTTP transaction stream this package already records (see the cast
// helpers in service.go) answers "what did they do"; it cannot answer "what
// did they see". For a console like MinIO's — a single-page app where one
// page load is followed by hundreds of XHRs — a request log is a poor
// substitute for watching the session back.
//
// So every proxied HTML page also gets an rrweb recorder, which captures DOM
// mutations, mouse, scroll and input as a structured event stream and replays
// pixel-accurate. Three properties make it fit the existing design rather
// than bolt onto it:
//
//   - The bundle is served from the proxy origin (/__pam/replay.js), so a
//     target's `script-src 'self'` admits it with no CSP rewrite at all. Only
//     the small inline heartbeat needs the nonce machinery in csp.go.
//   - Events post back same-origin, which `connect-src 'self'` already allows.
//   - The finished artifact goes to the SAME object store, under the SAME
//     recordings/<date>/ prefix, on the SAME pam_session_recordings row as a
//     CLI recording — only SessionRecording.Format distinguishes them, which
//     is the one field a player needs to choose how to render.
//
// Capture is client-side and therefore not tamper-proof: an operator with
// devtools can stop it. That is a deliberate, documented trade — the
// server-side HTTP audit trail remains authoritative and independently
// records the session either way, so a suppressed replay is visible as a
// recording with no frames against an audit log full of activity, rather
// than as a silent gap.
package webproxy

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	_ "embed"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

//go:embed assets/rrweb.min.js
var rrwebBundle []byte

//go:embed assets/pam-replay.js
var pamReplayGlue []byte

// replayBundle is the single asset served to the browser: the rrweb library
// followed by PAM's recorder glue. Concatenated once at startup rather than
// per request, and served as one file so a page load costs one request and
// the glue can never execute before the library it depends on.
var replayBundle = func() []byte {
	out := make([]byte, 0, len(rrwebBundle)+len(pamReplayGlue)+2)
	out = append(out, rrwebBundle...)
	// The SEMICOLON is load-bearing, and its absence was a live bug.
	//
	// The vendored rrweb UMD ends in an expression with no trailing
	// semicolon; the glue begins with `(function(){...})()`. Joined by a
	// newline alone, JavaScript's automatic semicolon insertion does NOT
	// break between them — it reads the glue's opening paren as a CALL on the
	// value the UMD expression produced, and throws
	// "(intermediate value)(...) is not a function" at runtime.
	//
	// The damage was silent and total: rrweb had already attached to window by
	// then, so the library looked fine, but the throw killed the rest of the
	// file before the recorder ever started. Every brokered session captured
	// zero frames and fell back to the request transcript, which reads as
	// "visual replay is not implemented" rather than as a one-byte bug.
	//
	// A syntax check cannot catch this (the concatenation parses); only
	// evaluating the bundle does, which is what TestReplayBundleTerminates...
	// asserts structurally.
	out = append(out, ';', '\n')
	out = append(out, pamReplayGlue...)
	return out
}()

const (
	// replayScriptPath serves replayBundle. Under /__pam/ with the other
	// control endpoints, so it shares their "never proxied upstream"
	// dispatch and cannot collide with a target's own routes.
	replayScriptPath = "/__pam/replay.js"

	// replayIngestPath receives batched rrweb events.
	replayIngestPath = "/__pam/replay"

	// maxReplayBatchBytes bounds a single ingest POST. Generous because a
	// full snapshot of a rich console (inlined stylesheets included) is the
	// first event of every session and legitimately large.
	maxReplayBatchBytes = 8 << 20

	// replayFormat is the SessionRecording.Format value a player keys off to
	// choose the rrweb replayer over the asciicast one.
	replayFormat = "rrweb"
)

// replayBuffer accumulates one session's events as newline-delimited JSON —
// the same line-per-event shape as the asciicast artifact, so both formats
// stream, truncate and store identically.
type replayBuffer struct {
	buf       bytes.Buffer
	events    int
	truncated bool
}

// appendBatch decodes one posted batch and appends its events, stopping at
// the cap. Events are re-encoded one per line rather than stored as the raw
// posted array so that a truncated recording is still a valid, replayable
// prefix instead of a corrupt JSON document.
func (b *replayBuffer) appendBatch(raw []byte, limit int64) error {
	var events []json.RawMessage
	if err := json.Unmarshal(raw, &events); err != nil {
		return fmt.Errorf("decode replay batch: %w", err)
	}
	for _, ev := range events {
		if limit > 0 && int64(b.buf.Len())+int64(len(ev))+1 > limit {
			b.truncated = true
			return nil
		}
		b.buf.Write(ev)
		b.buf.WriteByte('\n')
		b.events++
	}
	return nil
}

// ── Handler wiring ────────────────────────────────────────────────────────

// serveReplayScript returns the recorder bundle. Cached aggressively and
// privately: the bytes are identical for every session and never contain
// anything session-specific, but they are only meaningful behind a live
// brokered session so no shared cache should hold them.
func (h *Handler) serveReplayScript(c *gin.Context) {
	c.Header("Content-Type", "application/javascript; charset=utf-8")
	c.Header("Cache-Control", "private, max-age=3600")
	c.Header("X-Content-Type-Options", "nosniff")
	c.Status(http.StatusOK)
	_, _ = c.Writer.Write(replayBundle)
}

// handleReplayIngest accepts a batch of rrweb events for the session the
// request's cookie identifies.
//
// Deliberately quiet on every failure path: the browser's sendBeacon caller
// neither inspects nor retries the response, so there is nothing useful to
// tell it, and a session whose replay ingest is failing must still keep
// working for the operator.
func (h *Handler) handleReplayIngest(c *gin.Context, subdomain string) {
	rs, err := h.resolveFromRequest(c, subdomain)
	if err != nil {
		c.Status(http.StatusNoContent)
		return
	}

	// A batch arriving is itself proof the tab is open — free liveness on top
	// of the dedicated heartbeat, and it keeps a session alive during a long
	// stretch of pure UI interaction that issues no upstream requests.
	h.svc.RecordHeartbeat(rs.Session.ID)

	body, err := io.ReadAll(io.LimitReader(c.Request.Body, maxReplayBatchBytes+1))
	if err != nil || int64(len(body)) > maxReplayBatchBytes {
		h.logger.Warn("webproxy.replay.batch.rejected",
			zap.String("web_proxy_session_id", rs.Session.ID),
			zap.Int("bytes", len(body)), zap.Error(err))
		c.Status(http.StatusNoContent)
		return
	}

	h.svc.RecordReplayBatch(rs, body)
	c.Status(http.StatusNoContent)
}

// ── Service-side buffering ────────────────────────────────────────────────

// RecordReplayBatch appends a posted batch to the session's replay buffer.
// A session with no recording obligation is ignored outright — capturing
// frames PAM would never store is pure cost, and storing them anyway would
// quietly record sessions an administrator chose not to record.
func (s *Service) RecordReplayBatch(rs *ResolvedSession, batch []byte) {
	if !rs.RecordingRequired || rs.Session.RecordingID == nil {
		return
	}

	s.replayMu.Lock()
	defer s.replayMu.Unlock()

	rb := s.replays[rs.Session.ID]
	if rb == nil {
		rb = &replayBuffer{}
		s.replays[rs.Session.ID] = rb
	}
	if err := rb.appendBatch(batch, s.maxReplayBytes); err != nil {
		s.logger.Warn("webproxy.replay.batch.decode_fail",
			zap.String("web_proxy_session_id", rs.Session.ID), zap.Error(err))
	}
}

// takeReplay removes and returns a session's buffered replay. Removed rather
// than read so End is idempotent — a second End (a race between an explicit
// end and the expiry sweep) finds nothing left and cannot double-store.
func (s *Service) takeReplay(webProxySessionID string) *replayBuffer {
	s.replayMu.Lock()
	defer s.replayMu.Unlock()
	rb := s.replays[webProxySessionID]
	delete(s.replays, webProxySessionID)
	return rb
}

// discardReplay drops a session's buffer without storing it, for the paths
// that abandon a recording entirely.
func (s *Service) discardReplay(webProxySessionID string) {
	s.replayMu.Lock()
	defer s.replayMu.Unlock()
	delete(s.replays, webProxySessionID)
}

// gzipReplay compresses a buffered replay for storage, returning exactly what
// recorder.Cast.Finalize returns — the gzipped bytes, the SHA-256 OF THOSE
// BYTES (an integrity check on the object as stored), and the UNCOMPRESSED
// size. Matching that contract term for term is what lets finalizeRecording
// swap one artifact for the other without special-casing anything downstream.
func gzipReplay(rb *replayBuffer) (gzipped []byte, sha256Hex string, uncompressedSize int64, err error) {
	raw := rb.buf.Bytes()

	var out bytes.Buffer
	w := gzip.NewWriter(&out)
	if _, err = w.Write(raw); err != nil {
		return nil, "", 0, fmt.Errorf("gzip write: %w", err)
	}
	if err = w.Close(); err != nil {
		return nil, "", 0, fmt.Errorf("gzip close: %w", err)
	}

	sum := sha256.Sum256(out.Bytes())
	return out.Bytes(), hex.EncodeToString(sum[:]), int64(len(raw)), nil
}
