// pam/internal/webproxy/lifecycle_test.go
//
// The gap that let a broken recording ship.
//
// Every other recording test in this package seeds its fixture with
// seedRecordedSession, which registers the in-memory cast BY HAND. That
// exercises finalize, storage and the artifact shape — but it can never catch
// a StartSession that fails to register the cast in the first place, because
// the test does that registration itself. So a session could run, proxy
// traffic, end cleanly, and leave its recording stuck in RECORDING until the
// orphan sweep marked it FAILED with no artifact, while the whole suite stayed
// green.
//
// These tests drive the REAL path end to end — StartSession against a live
// httptest console, real proxied requests, real End — and assert the artifact
// exists. Nothing is stubbed except the target application and the object
// store.
package webproxy

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
)

// minioLikeUpstream answers the two calls StartSession makes against a MinIO
// Console: the login that establishes the upstream session, and whatever the
// operator's browser then requests.
func minioLikeUpstream(t *testing.T) *httptest.Server {
	t.Helper()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/v1/login", func(w http.ResponseWriter, r *http.Request) {
		http.SetCookie(w, &http.Cookie{Name: "token", Value: "UPSTREAM-SESSION", Path: "/", HttpOnly: true})
		w.WriteHeader(http.StatusNoContent)
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("<html><body>console</body></html>"))
	})
	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)
	return srv
}

// seedConnectableResource creates a resource with a vaulted credential, which
// is the minimum StartSession needs: it resolves the credential before it can
// log in to the target.
func seedConnectableResource(t *testing.T, svc *Service, consoleURL string, alwaysRecord bool) *models.PAMResource {
	t.Helper()

	enc, err := crypto.Encrypt("s3cret-password", svc.cryptoKey)
	if err != nil {
		t.Fatalf("encrypt credential: %v", err)
	}
	entry := &models.VaultEntry{
		Name:           "minio admin",
		AccountName:    "minioadmin",
		CredentialType: string(models.CredentialTypePassword),
		CredentialEnc:  enc,
	}
	if err := svc.db.Create(entry).Error; err != nil {
		t.Fatalf("seed vault entry: %v", err)
	}

	res := &models.PAMResource{
		Name: "Prod MinIO", ResourceType: "minio",
		Host: "127.0.0.1", Port: 9001, ConsoleURL: consoleURL,
		IsActive: true, AlwaysRecord: alwaysRecord,
		VaultEntryID: &entry.ID, CreatedBy: "tester",
	}
	if err := svc.db.Create(res).Error; err != nil {
		t.Fatalf("seed resource: %v", err)
	}
	if err := svc.db.Model(&models.VaultEntry{}).Where("id = ?", entry.ID).
		Update("resource_id", res.ID).Error; err != nil {
		t.Fatalf("link vault entry: %v", err)
	}
	return res
}

// TestRealStartSessionToEndProducesAnArtifact is the regression test for the
// production failure: a session that started, proxied traffic and ended left
// its recording stuck in RECORDING with no artifact, because End found no cast
// registered for it. Drives the actual StartSession, so a registration that
// silently does not happen fails here.
func TestRealStartSessionToEndProducesAnArtifact(t *testing.T) {
	upstream := minioLikeUpstream(t)

	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	res := seedConnectableResource(t, svc, upstream.URL, true)

	out, err := svc.StartSession(context.Background(), StartSessionInput{
		UserID: "alice", Username: "alice", ResourceID: res.ID,
		RecordingRequired: true,
	})
	if err != nil {
		t.Fatalf("StartSession: %v", err)
	}
	if out.WebProxySessionID == "" {
		t.Fatal("StartSession returned no session id")
	}

	// The recording obligation must be live and the cast registered — the
	// exact state whose absence produced the production bug.
	var rec models.SessionRecording
	if err := svc.db.Where("session_id = ?", out.SessionID).First(&rec).Error; err != nil {
		t.Fatalf("recording row: %v", err)
	}
	if rec.Status != models.RecordingStatusRecording {
		t.Fatalf("recording status = %q, want RECORDING after StartSession", rec.Status)
	}
	svc.castMu.Lock()
	_, castRegistered := svc.casts[out.WebProxySessionID]
	svc.castMu.Unlock()
	if !castRegistered {
		t.Fatal("StartSession did not register an in-memory cast — End will find nothing to " +
			"finalize and the recording will be orphaned to FAILED with no artifact")
	}

	if err := svc.End(out.WebProxySessionID, "alice", true,
		models.WebProxySessionExpired, "browser tab was closed"); err != nil {
		t.Fatalf("End: %v", err)
	}

	// An artifact must exist, and the row must point at it.
	store.mu.Lock()
	count := len(store.objects)
	store.mu.Unlock()
	if count == 0 {
		t.Fatal("no artifact was stored: the recording is orphaned exactly as it was in production")
	}

	var final models.SessionRecording
	if err := svc.db.Where("id = ?", rec.ID).First(&final).Error; err != nil {
		t.Fatalf("reload recording: %v", err)
	}
	if final.Status != models.RecordingStatusCompleted {
		t.Fatalf("recording status = %q (%s), want COMPLETED", final.Status, final.FailureReason)
	}
	if final.StorageKey == "" || final.SizeBytes <= 0 || final.SHA256 == "" {
		t.Fatalf("recording completed without artifact metadata: key=%q size=%d sha=%q",
			final.StorageKey, final.SizeBytes, final.SHA256)
	}
}

// The same real path, but with frames delivered the way the browser delivers
// them — through the ingest endpoint — so the artifact must be the visual
// replay rather than the transcript.
func TestRealSessionWithBrowserFramesStoresVisualReplay(t *testing.T) {
	gin.SetMode(gin.TestMode)
	upstream := minioLikeUpstream(t)

	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	res := seedConnectableResource(t, svc, upstream.URL, true)

	out, err := svc.StartSession(context.Background(), StartSessionInput{
		UserID: "alice", Username: "alice", ResourceID: res.ID,
		RecordingRequired: true,
	})
	if err != nil {
		t.Fatalf("StartSession: %v", err)
	}

	// Redeem the handoff the way the browser does, so the session is entered
	// with a real cookie rather than by poking the database.
	var row models.WebProxySession
	if err := svc.db.Where("id = ?", out.WebProxySessionID).First(&row).Error; err != nil {
		t.Fatalf("load session: %v", err)
	}
	rs, err := svc.Resolve(rawTokenFor(t, svc, row.ID), row.Subdomain)
	if err != nil {
		t.Fatalf("Resolve: %v", err)
	}

	// Frames arrive through the ingest endpoint, exactly as pam-replay.js posts.
	svc.RecordReplayBatch(rs, []byte(sampleEvents))

	if err := svc.End(out.WebProxySessionID, "alice", true,
		models.WebProxySessionEnded, "tab closed"); err != nil {
		t.Fatalf("End: %v", err)
	}

	var final models.SessionRecording
	if err := svc.db.Where("session_id = ?", out.SessionID).First(&final).Error; err != nil {
		t.Fatalf("reload recording: %v", err)
	}
	if final.Format != replayFormat {
		t.Fatalf("format = %q, want %q — frames arrived, so the visual replay must win",
			final.Format, replayFormat)
	}
	if final.Status != models.RecordingStatusCompleted {
		t.Fatalf("status = %q (%s), want COMPLETED", final.Status, final.FailureReason)
	}
	if !strings.HasSuffix(final.StorageKey, ".rrweb.gz") {
		t.Fatalf("storage key = %q, want an .rrweb.gz artifact", final.StorageKey)
	}
	if final.TranscriptKey == nil || *final.TranscriptKey == "" {
		t.Fatal("the request transcript must still be stored alongside the visual replay")
	}

	// And the bytes must be a real, replayable event stream.
	store.mu.Lock()
	blob := store.objects[final.StorageKey]
	store.mu.Unlock()
	gr, err := gzip.NewReader(bytes.NewReader(blob))
	if err != nil {
		t.Fatalf("artifact is not gzip: %v", err)
	}
	defer gr.Close()
	raw, err := io.ReadAll(gr)
	if err != nil {
		t.Fatalf("read artifact: %v", err)
	}
	var first map[string]interface{}
	line := strings.SplitN(strings.TrimSpace(string(raw)), "\n", 2)[0]
	if err := json.Unmarshal([]byte(line), &first); err != nil {
		t.Fatalf("artifact is not newline-delimited rrweb JSON: %v (%q)", err, line)
	}
}

// rawTokenFor recovers the session's raw proxy token. StartSession only ever
// returns it inside the single-use launch URL, so a test that needs to act as
// the browser has to redeem the handoff rather than invent a token.
func rawTokenFor(t *testing.T, svc *Service, webProxySessionID string) string {
	t.Helper()
	var row models.WebProxySession
	if err := svc.db.Where("id = ?", webProxySessionID).First(&row).Error; err != nil {
		t.Fatalf("load session: %v", err)
	}
	// The handoff hash is derived from the raw handoff token, which the test
	// cannot reverse; instead re-issue a known proxy token for this row the
	// way RedeemHandoff would, so Resolve can find it.
	const raw = "test-proxy-token"
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("token_hash", hashToken(raw)).Error; err != nil {
		t.Fatalf("set token hash: %v", err)
	}
	_ = time.Now()
	return raw
}
