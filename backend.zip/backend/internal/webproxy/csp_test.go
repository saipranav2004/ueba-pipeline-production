// pam/internal/webproxy/csp_test.go
//
// The beacon being *present* in the HTML proves nothing — a target's CSP can
// refuse to run it with no visible symptom at all. These tests pin the two
// halves of getting that right: the beacon must become runnable under a
// policy that forbids inline script, and a policy that already permits inline
// script must be left strictly alone (adding a nonce there would break the
// target app's own inline scripts, since browsers ignore 'unsafe-inline' the
// moment any nonce- or hash-source appears).
package webproxy

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

// minioConsoleCSP is copied verbatim from a live MinIO Console
// (RELEASE.2025-08-13) response — the policy that silently killed tab-close
// detection in production. script-src overrides default-src for <script> and
// carries no 'unsafe-inline'.
const minioConsoleCSP = "default-src 'self' 'unsafe-eval' 'unsafe-inline'; " +
	"script-src 'self' https://unpkg.com;  connect-src 'self' https://unpkg.com;"

func TestPrepareCSPForBeaconGrantsNonceOnMinIOConsolePolicy(t *testing.T) {
	h := http.Header{}
	h.Set(cspHeader, minioConsoleCSP)

	if !prepareCSPForBeacon(h, "TESTNONCE") {
		t.Fatal("MinIO Console's policy forbids inline script, so the beacon must be granted a nonce")
	}

	got := h.Get(cspHeader)
	scriptSrc := directiveFrom(t, got, "script-src")
	if !strings.Contains(scriptSrc, "'nonce-TESTNONCE'") {
		t.Fatalf("nonce must land on script-src (the directive that governs <script> here), got: %s", got)
	}
	// Everything else must survive untouched — this is the target's policy,
	// not ours to rewrite beyond the one exemption.
	if !strings.Contains(scriptSrc, "'self'") || !strings.Contains(scriptSrc, "https://unpkg.com") {
		t.Fatalf("existing script-src sources were lost: %s", got)
	}
	if d := directiveFrom(t, got, "default-src"); !strings.Contains(d, "'unsafe-eval'") ||
		strings.Contains(d, "nonce-") {
		t.Fatalf("default-src must be untouched (script-src governs), got: %s", got)
	}
	// connect-src already has 'self', so the beacon's own POST is allowed and
	// nothing needed adding.
	if c := directiveFrom(t, got, "connect-src"); strings.Count(c, "'self'") != 1 {
		t.Fatalf("connect-src already permitted same-origin; it should be unchanged, got: %s", got)
	}
}

// The regression this guards is worse than a dead beacon: it would break the
// target application itself.
func TestPrepareCSPForBeaconLeavesUnsafeInlinePolicyAlone(t *testing.T) {
	h := http.Header{}
	h.Set(cspHeader, "default-src 'self'; script-src 'self' 'unsafe-inline'")

	if prepareCSPForBeacon(h, "TESTNONCE") {
		t.Fatal("a policy already allowing inline script needs no nonce")
	}
	if got := h.Get(cspHeader); strings.Contains(got, "nonce-") {
		t.Fatalf("adding a nonce here makes browsers ignore 'unsafe-inline', breaking the app's own "+
			"inline scripts. Policy must be untouched, got: %s", got)
	}
}

// 'unsafe-inline' stops being honoured as soon as a nonce or hash is present,
// so such a policy DOES need our nonce despite naming 'unsafe-inline'.
func TestPrepareCSPForBeaconAddsNonceWhenUnsafeInlineIsAlreadyNeutralised(t *testing.T) {
	h := http.Header{}
	h.Set(cspHeader, "script-src 'self' 'unsafe-inline' 'nonce-abc123'")

	if !prepareCSPForBeacon(h, "TESTNONCE") {
		t.Fatal("'unsafe-inline' is ignored once a nonce-source is present, so the beacon needs its own nonce")
	}
	if got := h.Get(cspHeader); !strings.Contains(got, "'nonce-TESTNONCE'") {
		t.Fatalf("expected our nonce to be added, got: %s", got)
	}
}

// script-src-elem outranks script-src for a <script> element; a nonce on the
// wrong directive is silently ineffective.
func TestPrepareCSPForBeaconPrefersScriptSrcElem(t *testing.T) {
	h := http.Header{}
	h.Set(cspHeader, "default-src 'none'; script-src 'self'; script-src-elem 'self'")

	prepareCSPForBeacon(h, "TESTNONCE")

	got := h.Get(cspHeader)
	if !strings.Contains(directiveFrom(t, got, "script-src-elem"), "'nonce-TESTNONCE'") {
		t.Fatalf("nonce must go on script-src-elem, which governs <script> elements here: %s", got)
	}
	if strings.Contains(directiveFrom(t, got, "script-src"), "nonce-") {
		t.Fatalf("script-src is not consulted when script-src-elem is present; leave it alone: %s", got)
	}
}

func TestPrepareCSPForBeaconOpensConnectSrcOnlyWhenNeeded(t *testing.T) {
	h := http.Header{}
	h.Set(cspHeader, "script-src 'unsafe-inline'; connect-src 'none'")

	prepareCSPForBeacon(h, "TESTNONCE")

	if c := directiveFrom(t, h.Get(cspHeader), "connect-src"); !strings.Contains(c, "'self'") {
		t.Fatalf("the beacon posts same-origin; connect-src must permit 'self', got: %s", c)
	}
}

// Several CSP headers are enforced independently and a script must satisfy
// every one, so the strictest still blocks the beacon if any is missed.
func TestPrepareCSPForBeaconHandlesMultiplePolicyHeaders(t *testing.T) {
	h := http.Header{}
	h.Add(cspHeader, "script-src 'self'")
	h.Add(cspHeader, "script-src 'self' https://cdn.example.com")

	if !prepareCSPForBeacon(h, "TESTNONCE") {
		t.Fatal("expected a nonce to be required")
	}
	values := h.Values(cspHeader)
	if len(values) != 2 {
		t.Fatalf("both policies must be preserved, got %d: %v", len(values), values)
	}
	for i, v := range values {
		if !strings.Contains(v, "'nonce-TESTNONCE'") {
			t.Fatalf("policy %d still blocks the beacon: %s", i, v)
		}
	}
}

func TestPrepareCSPForBeaconIsANoopWithoutAPolicy(t *testing.T) {
	h := http.Header{}
	if prepareCSPForBeacon(h, "TESTNONCE") {
		t.Fatal("no CSP means nothing to relax and no nonce needed")
	}
	if len(h.Values(cspHeader)) != 0 {
		t.Fatal("must not invent a CSP header on a response that had none")
	}
}

func TestNewCSPNonceIsUniqueAndNonEmpty(t *testing.T) {
	seen := map[string]bool{}
	for i := 0; i < 100; i++ {
		n, err := newCSPNonce()
		if err != nil {
			t.Fatalf("newCSPNonce: %v", err)
		}
		if n == "" {
			t.Fatal("empty nonce would silently disable the exemption")
		}
		if seen[n] {
			t.Fatalf("nonce reused (%q) — a predictable nonce lets injected page content borrow the exemption", n)
		}
		seen[n] = true
	}
}

// ── End to end through the real proxy ─────────────────────────────────────

// The whole point, exercised the way it actually happens: a MinIO-Console-like
// target with a script-blocking CSP must come back with a beacon the browser
// will genuinely run.
func TestReverseProxyMakesBeaconRunnableUnderMinIOConsoleCSP(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Security-Policy", minioConsoleCSP)
		w.Header().Set("Content-Type", "text/html")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("<html><body>console</body></html>"))
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "minio-abc12345"},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://minio-abc12345.pam.example.com/", nil)
	rec := httptest.NewRecorder()
	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	body := rec.Body.String()
	policy := rec.Result().Header.Get(cspHeader)

	nonce := nonceFromScriptTag(t, body)
	if nonce == "" {
		t.Fatalf("beacon was injected without a nonce under a policy that forbids inline script — "+
			"the browser will refuse to run it and tab close will never be detected. Body:\n%s", body)
	}
	if !strings.Contains(directiveFrom(t, policy, "script-src"), "'nonce-"+nonce+"'") {
		t.Fatalf("script tag nonce %q is not authorised by the response policy: %s", nonce, policy)
	}
}

// A target with no CSP must be served exactly the tag it always was — no
// stray nonce attribute, no invented header.
func TestReverseProxyLeavesBeaconUnnoncedWithoutACSP(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("<html><body>plain</body></html>"))
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/", nil)
	rec := httptest.NewRecorder()
	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if !strings.Contains(rec.Body.String(), string(heartbeatScriptTag)) {
		t.Fatalf("expected the plain beacon tag, got:\n%s", rec.Body.String())
	}
	if rec.Result().Header.Get(cspHeader) != "" {
		t.Fatal("must not add a CSP to a response that had none")
	}
}

// ── helpers ───────────────────────────────────────────────────────────────

func directiveFrom(t *testing.T, policy, name string) string {
	t.Helper()
	for _, seg := range strings.Split(policy, ";") {
		if directiveName(seg) == name {
			return seg
		}
	}
	return ""
}

func nonceFromScriptTag(t *testing.T, html string) string {
	t.Helper()
	const marker = `<script nonce="`
	i := strings.Index(html, marker)
	if i < 0 {
		return ""
	}
	rest := html[i+len(marker):]
	j := strings.IndexByte(rest, '"')
	if j < 0 {
		return ""
	}
	return rest[:j]
}
