// pam/internal/webproxy/replay_test.go
//
// Coverage for visual session replay: the recorder reaching the page, the
// events reaching the server, and the finished stream landing in the same
// object store and the same pam_session_recordings row as every other
// recording — distinguished only by Format, which is what a player keys off.
package webproxy

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
)

// sampleEvents is a minimal but structurally real rrweb batch: a full
// snapshot followed by an incremental mutation.
const sampleEvents = `[{"type":2,"data":{"node":{"type":0,"childNodes":[]},"initialOffset":{"top":0,"left":0}},"timestamp":1700000000000},` +
	`{"type":3,"data":{"source":0,"texts":[],"attributes":[],"removes":[],"adds":[]},"timestamp":1700000001000}]`

// ── The bundle the browser loads ──────────────────────────────────────────

func TestReplayBundleContainsRecorderAndGlue(t *testing.T) {
	if len(rrwebBundle) < 100_000 {
		t.Fatalf("vendored rrweb bundle looks truncated: %d bytes", len(rrwebBundle))
	}
	body := string(replayBundle)
	if !strings.Contains(body, "rrweb") {
		t.Fatal("bundle does not contain the rrweb library")
	}
	if !strings.Contains(body, replayIngestPath) {
		t.Fatalf("glue must post to %s, which is missing from the served bundle", replayIngestPath)
	}
	// Ordering matters: the glue calls rrweb.record at parse time, so the
	// library has to be earlier in the same file.
	if strings.Index(body, "__pamReplayStarted") < strings.Index(body, "rrweb") {
		t.Fatal("glue must come after the library it depends on")
	}
}

func TestServeReplayScriptIsJavaScriptAndPrivatelyCached(t *testing.T) {
	gin.SetMode(gin.TestMode)
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet,
		"http://app-abc12345.pam.example.com"+replayScriptPath, nil)

	h.serveReplayScript(c)

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if ct := rec.Header().Get("Content-Type"); !strings.HasPrefix(ct, "application/javascript") {
		t.Fatalf("Content-Type = %q, want application/javascript — a browser will refuse to "+
			"execute it otherwise (X-Content-Type-Options: nosniff is set)", ct)
	}
	if cc := rec.Header().Get("Cache-Control"); !strings.Contains(cc, "private") {
		t.Fatalf("Cache-Control = %q; the bundle is only meaningful behind a live brokered "+
			"session and must not sit in a shared cache", cc)
	}
	if rec.Body.Len() != len(replayBundle) {
		t.Fatalf("served %d bytes, want the whole bundle (%d)", rec.Body.Len(), len(replayBundle))
	}
}

// ── Injection into the page ───────────────────────────────────────────────

func TestRecordedSessionGetsTheRecorderAndUnrecordedDoesNot(t *testing.T) {
	for _, tc := range []struct {
		name     string
		required bool
		want     bool
	}{
		{"recorded session loads the recorder", true, true},
		{"unrecorded session must not pay for it", false, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			tags := string(pamScriptTags("", tc.required, nil))
			if got := strings.Contains(tags, replayScriptPath); got != tc.want {
				t.Fatalf("recorder present = %v, want %v. Tags: %s", got, tc.want, tags)
			}
			// The heartbeat is unconditional — session lifecycle does not
			// depend on whether anyone is recording.
			if !strings.Contains(tags, heartbeatPath) {
				t.Fatalf("heartbeat must be injected regardless of recording: %s", tags)
			}
		})
	}
}

func TestRecorderTagCarriesTheNonceWhenOneIsNeeded(t *testing.T) {
	tags := string(pamScriptTags("N0NCE", true, nil))
	if strings.Count(tags, `nonce="N0NCE"`) != 2 {
		t.Fatalf("both the heartbeat and the recorder tag need the nonce under a "+
			"policy that omits 'self': %s", tags)
	}
}

// ── Ingest ────────────────────────────────────────────────────────────────

func TestRecordReplayBatchBuffersEventsOnePerLine(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	svc.RecordReplayBatch(rs, []byte(sampleEvents))
	svc.RecordReplayBatch(rs, []byte(sampleEvents))

	rb := svc.takeReplay(row.ID)
	if rb == nil {
		t.Fatal("no replay buffered")
	}
	if rb.events != 4 {
		t.Fatalf("buffered %d events, want 4", rb.events)
	}
	lines := strings.Split(strings.TrimRight(rb.buf.String(), "\n"), "\n")
	if len(lines) != 4 {
		t.Fatalf("expected one JSON object per line, got %d lines", len(lines))
	}
	for i, line := range lines {
		var ev map[string]interface{}
		if err := json.Unmarshal([]byte(line), &ev); err != nil {
			t.Fatalf("line %d is not a standalone JSON event: %v (%q)", i, err, line)
		}
	}
	// takeReplay must consume, so a second End cannot store the same frames
	// twice.
	if again := svc.takeReplay(row.ID); again != nil {
		t.Fatal("takeReplay must remove the buffer so End is idempotent")
	}
}

func TestRecordReplayBatchIgnoresUnrecordedSessions(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)

	svc.RecordReplayBatch(&ResolvedSession{Session: row, RecordingRequired: false}, []byte(sampleEvents))

	if rb := svc.takeReplay(row.ID); rb != nil {
		t.Fatal("frames must not be captured for a session an administrator chose not to record")
	}
}

func TestRecordReplayBatchSurvivesMalformedPayload(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	svc.RecordReplayBatch(rs, []byte(`{"not":"an array"}`))
	svc.RecordReplayBatch(rs, []byte(sampleEvents))

	rb := svc.takeReplay(row.ID)
	if rb == nil || rb.events != 2 {
		t.Fatalf("a bad batch must be dropped without losing the good ones, got %+v", rb)
	}
}

func TestReplayBufferStopsAtTheCapAndStaysReplayable(t *testing.T) {
	rb := &replayBuffer{}
	// Cap sized to admit the first event and reject the second.
	if err := rb.appendBatch([]byte(sampleEvents), 200); err != nil {
		t.Fatalf("appendBatch: %v", err)
	}
	if !rb.truncated {
		t.Fatal("expected the buffer to report truncation")
	}
	if rb.events != 1 {
		t.Fatalf("kept %d events, want the 1 that fit", rb.events)
	}
	// The whole point of storing one event per line: a truncated recording
	// is still a valid prefix rather than a corrupt document.
	var ev map[string]interface{}
	if err := json.Unmarshal([]byte(strings.TrimRight(rb.buf.String(), "\n")), &ev); err != nil {
		t.Fatalf("truncated buffer is not replayable: %v", err)
	}
}

func TestReplayIngestEndpointRecordsBatchAndKeepsSessionAlive(t *testing.T) {
	gin.SetMode(gin.TestMode)
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)

	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	defer upstream.Close()
	seedResolvableResource(t, svc, row, upstream.URL)

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodPost,
		"http://minio-abc12345.pam.example.com"+replayIngestPath, strings.NewReader(sampleEvents))
	c.Request.AddCookie(&http.Cookie{Name: cookieName(false), Value: "tok"})

	h := NewHandler(svc, zap.NewNop())
	h.handleReplayIngest(c, row.Subdomain)

	// gin defers flushing the status until the router unwinds, so the
	// recorder still reads 200 here; c.Writer.Status() is what was set.
	if got := c.Writer.Status(); got != http.StatusNoContent {
		t.Fatalf("status = %d, want 204 (sendBeacon ignores the body)", got)
	}
	if rb := svc.takeReplay(row.ID); rb == nil || rb.events != 2 {
		t.Fatalf("ingest did not buffer the batch: %+v", rb)
	}
	// A batch arriving proves the tab is open, so it must also refresh
	// liveness — a session spent entirely inside the UI issues no upstream
	// requests and would otherwise look idle.
	var reloaded models.WebProxySession
	if err := svc.db.Where("id = ?", row.ID).First(&reloaded).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if reloaded.LastHeartbeatAt == nil {
		t.Fatal("replay ingest must count as a heartbeat")
	}
}

// ── The artifact ──────────────────────────────────────────────────────────

func TestVisualReplayIsStoredAsTheRecordingArtifact(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	// Some HTTP activity too, so this proves the visual stream is chosen over
	// the transcript rather than merely being the only thing available.
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})
	svc.RecordReplayBatch(rs, []byte(sampleEvents))

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "tab closed"); err != nil {
		t.Fatalf("End: %v", err)
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	// Two artifacts: the visual replay (primary) and the request transcript
	// (secondary) — a replay shows what the operator saw, the transcript
	// shows every request they caused, and an auditor wants both.
	if len(store.objects) != 2 {
		t.Fatalf("expected the replay AND the transcript, got %d artifact(s): %v",
			len(store.objects), keysOf(store.objects))
	}
	var key string
	var blob []byte
	for k, v := range store.objects {
		if strings.HasSuffix(k, ".rrweb.gz") {
			key, blob = k, v
		}
	}
	if key == "" {
		t.Fatalf("no visual replay artifact stored: %v", keysOf(store.objects))
	}
	if !strings.HasPrefix(key, "recordings/") || !strings.HasSuffix(key, ".rrweb.gz") {
		t.Fatalf("visual replay must use the shared recordings/<date>/ prefix with an rrweb "+
			"extension, got %q", key)
	}

	var stored models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&stored).Error; err != nil {
		t.Fatalf("reload recording: %v", err)
	}
	if stored.Format != replayFormat {
		t.Fatalf("Format = %q, want %q — a player selects its renderer off this field",
			stored.Format, replayFormat)
	}
	if stored.Status != models.RecordingStatusCompleted || stored.StorageKey != key {
		t.Fatalf("recording row not attached to the artifact: status=%q key=%q",
			stored.Status, stored.StorageKey)
	}
	if stored.SHA256 == "" || stored.SizeBytes <= 0 {
		t.Fatalf("missing integrity metadata: sha=%q size=%d", stored.SHA256, stored.SizeBytes)
	}

	// The bytes must be a gzipped, line-per-event rrweb stream — what the
	// player consumes.
	gr, err := gzip.NewReader(bytes.NewReader(blob))
	if err != nil {
		t.Fatalf("artifact is not gzip: %v", err)
	}
	defer gr.Close()
	raw, err := io.ReadAll(gr)
	if err != nil {
		t.Fatalf("read artifact: %v", err)
	}
	lines := strings.Split(strings.TrimRight(string(raw), "\n"), "\n")
	if len(lines) != 2 {
		t.Fatalf("expected 2 events, got %d", len(lines))
	}
	var first struct {
		Type int `json:"type"`
	}
	if err := json.Unmarshal([]byte(lines[0]), &first); err != nil {
		t.Fatalf("event is not valid JSON: %v", err)
	}
	if first.Type != 2 {
		t.Fatalf("first event should be the full snapshot (type 2), got %d", first.Type)
	}

	// The transcript must be reachable from the row (this is what
	// GET /admin/recordings/:id/transcript serves) and be a real asciicast.
	if stored.TranscriptKey == nil || *stored.TranscriptKey == "" {
		t.Fatal("recording row does not point at its request transcript")
	}
	transcript, ok := store.objects[*stored.TranscriptKey]
	if !ok {
		t.Fatalf("transcript_key %q is not in the object store: %v",
			*stored.TranscriptKey, keysOf(store.objects))
	}
	tgr, err := gzip.NewReader(bytes.NewReader(transcript))
	if err != nil {
		t.Fatalf("transcript is not gzip: %v", err)
	}
	defer tgr.Close()
	traw, err := io.ReadAll(tgr)
	if err != nil {
		t.Fatalf("read transcript: %v", err)
	}
	var header struct {
		Version int `json:"version"`
	}
	firstLine := strings.SplitN(string(traw), "\n", 2)[0]
	if err := json.Unmarshal([]byte(firstLine), &header); err != nil || header.Version != 2 {
		t.Fatalf("transcript is not a valid asciicast v2 stream: %v (%q)", err, firstLine)
	}
	if !strings.Contains(string(traw), "/browser") {
		t.Fatalf("transcript is missing the request it should contain:\n%s", traw)
	}

	// The searchable command log is independent of which artifact won.
	var cmds []models.SessionRecordingCommand
	if err := svc.db.Where("recording_id = ?", recordingID).Find(&cmds).Error; err != nil {
		t.Fatalf("load commands: %v", err)
	}
	if len(cmds) != 1 {
		t.Fatalf("command log must still be written alongside a visual replay, got %d rows", len(cmds))
	}
}

// A browser that never delivered frames (script blocked, ancient browser)
// must still leave a replayable artifact rather than an empty recording.
func TestSessionWithoutFramesFallsBackToTheTranscript(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	svc.RecordActivity(&ResolvedSession{Session: row, RecordingRequired: true}, ActivityRecord{
		Method: http.MethodGet, Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "done"); err != nil {
		t.Fatalf("End: %v", err)
	}

	var stored models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&stored).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if stored.Format != "asciicast" {
		t.Fatalf("Format = %q, want asciicast when no frames arrived", stored.Format)
	}
	if !strings.HasSuffix(stored.StorageKey, ".cast.gz") || stored.Status != models.RecordingStatusCompleted {
		t.Fatalf("expected a completed transcript artifact, got key=%q status=%q",
			stored.StorageKey, stored.Status)
	}
	// No SECONDARY transcript here: the primary artifact already is one, and
	// a non-nil transcript_key would make the API advertise a duplicate.
	if stored.TranscriptKey != nil {
		t.Fatalf("transcript_key must stay NULL when the primary artifact is the transcript, got %q",
			*stored.TranscriptKey)
	}
}

func keysOf(m map[string][]byte) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}

// seedResolvableResource makes Resolve() able to answer for a seeded session.
func seedResolvableResource(t *testing.T, svc *Service, row *models.WebProxySession, consoleURL string) {
	t.Helper()
	if err := svc.db.Create(&models.PAMResource{
		ID: row.ResourceID, Name: "Prod MinIO", ResourceType: "minio",
		Host: "127.0.0.1", Port: 9001, ConsoleURL: consoleURL, IsActive: true,
	}).Error; err != nil {
		t.Fatalf("seed resource: %v", err)
	}
	stateEnc, err := crypto.Encrypt(`{}`, svc.cryptoKey)
	if err != nil {
		t.Fatalf("encrypt upstream state: %v", err)
	}
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("upstream_state_enc", stateEnc).Error; err != nil {
		t.Fatalf("seed upstream state: %v", err)
	}
}

// TestReplayBundleTerminatesTheLibraryBeforeTheGlue guards a bug that cost a
// whole feature and left no trace in any syntax check.
//
// The vendored rrweb UMD ends in an expression with no trailing semicolon.
// The glue starts with `(function(){...})()`. Concatenated with only a
// newline, ASI does not break between them: the glue's opening paren becomes
// a CALL on the UMD's result and the script throws at runtime. rrweb had
// already attached to window, so the library appeared healthy while the
// recorder silently never started — every session recorded zero frames and
// fell back to the request transcript.
//
// Asserted structurally because Go has no JS engine here: what has to hold is
// that the glue is preceded by a statement terminator.
func TestReplayBundleTerminatesTheLibraryBeforeTheGlue(t *testing.T) {
	idx := bytes.Index(replayBundle, pamReplayGlue)
	if idx <= 0 {
		t.Fatalf("glue not found in the served bundle (index %d)", idx)
	}

	// Walk back over whitespace to the last real character of the library.
	i := idx - 1
	for i >= 0 && (replayBundle[i] == '\n' || replayBundle[i] == '\r' ||
		replayBundle[i] == ' ' || replayBundle[i] == '\t') {
		i--
	}
	if i < 0 {
		t.Fatal("no library content precedes the glue")
	}
	if got := replayBundle[i]; got != ';' && got != '}' {
		t.Fatalf("the library must be terminated before the glue, found %q. Without a semicolon "+
			"ASI joins them into a call expression and the recorder never starts.", got)
	}

	// And the glue itself must still open the way the guard above assumes.
	if !bytes.HasPrefix(bytes.TrimLeft(pamReplayGlue, " \t\r\n"), []byte("/*")) &&
		!bytes.Contains(pamReplayGlue[:min(200, len(pamReplayGlue))], []byte("(function")) {
		t.Fatal("glue no longer starts with a comment or an IIFE; re-check the separator rule")
	}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
