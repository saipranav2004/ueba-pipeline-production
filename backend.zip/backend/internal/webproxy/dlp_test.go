// pam/internal/webproxy/dlp_test.go
//
// Coverage for the data-protection controls, organised around the distinction
// that matters most about them: which are PREVENTION (server-side, in the
// data path) and which are FRICTION (client-side, defeatable). Tests for the
// second group assert only that the control is delivered and the attempt is
// reported — never that a copy was stopped, because that is not something
// this layer can guarantee and a test claiming it would be lying.
package webproxy

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

// ── Policy composition ───────────────────────────────────────────────────

func TestMostRestrictiveOnlyEverTightens(t *testing.T) {
	resource := models.DataProtection{BlockDownload: true, MaxEgressBytes: 100}
	grant := models.DataProtection{BlockClipboard: true, Watermark: true, MaxEgressBytes: 50}

	got := models.MostRestrictive(resource, grant)

	if !got.BlockDownload || !got.BlockClipboard || !got.Watermark {
		t.Fatalf("every control set on either side must survive: %+v", got)
	}
	if got.MaxEgressBytes != 50 {
		t.Fatalf("MaxEgressBytes = %d, want the tighter 50", got.MaxEgressBytes)
	}
}

func TestMostRestrictiveTreatsZeroEgressAsUnlimitedNotStrictest(t *testing.T) {
	// The trap: 0 means "no cap", so naive min() would make an unrestricted
	// grant silently impose a zero-byte budget and break every session.
	got := models.MostRestrictive(
		models.DataProtection{MaxEgressBytes: 4096},
		models.DataProtection{MaxEgressBytes: 0},
	)
	if got.MaxEgressBytes != 4096 {
		t.Fatalf("MaxEgressBytes = %d; an unset grant limit must not override a real one",
			got.MaxEgressBytes)
	}

	got = models.MostRestrictive(
		models.DataProtection{MaxEgressBytes: 0},
		models.DataProtection{MaxEgressBytes: 4096},
	)
	if got.MaxEgressBytes != 4096 {
		t.Fatalf("MaxEgressBytes = %d; a grant must be able to impose a cap where the resource had none",
			got.MaxEgressBytes)
	}
}

func TestGrantCannotLoosenAResourcePolicy(t *testing.T) {
	got := models.MostRestrictive(
		models.DataProtection{BlockClipboard: true, BlockDownload: true, Watermark: true},
		models.DataProtection{}, // an approver who set nothing
	)
	if !got.BlockClipboard || !got.BlockDownload || !got.Watermark {
		t.Fatalf("a permissive grant must not relax the resource baseline: %+v", got)
	}
}

func TestConnectMethodAllowListFailsOpenWhenUnset(t *testing.T) {
	// Introduced against a populated table: an empty value has to mean "as
	// before" or the migration locks every existing resource out.
	if !models.ConnectMethodAllowed("", models.ConnectMethodAgent) {
		t.Fatal("an unset allow-list must permit every method")
	}
	if !models.ConnectMethodAllowed(" web_proxy , agent ", models.ConnectMethodAgent) {
		t.Fatal("whitespace and case must not change the decision")
	}
	if models.ConnectMethodAllowed("web_proxy,web_terminal", models.ConnectMethodAgent) {
		t.Fatal("agent must be denied when the list omits it")
	}
}

// The distinction the whole feature rests on: controls are only meaningful
// once the connect path PAM cannot observe has been closed.
func TestEgressControlledRequiresClosingTheAgentPath(t *testing.T) {
	policy := models.DataProtection{BlockDownload: true, MaxEgressBytes: 1024}

	if models.EgressControlled("", policy) {
		t.Fatal("a resource that still permits the agent is not egress-controlled: the operator " +
			"holds the credential and connects direct, so PAM never sees the data")
	}
	if models.EgressControlled("web_proxy,agent", policy) {
		t.Fatal("explicitly permitting the agent must not count as controlled either")
	}
	if !models.EgressControlled("web_proxy,web_terminal", policy) {
		t.Fatal("brokered-only with a live control IS egress-controlled")
	}
	if models.EgressControlled("web_proxy", models.DataProtection{}) {
		t.Fatal("no controls set means nothing is being controlled")
	}
}

// ── PREVENTION: download refusal ─────────────────────────────────────────

func TestBlockedDownloadReasonDetectsRealDownloadsOnly(t *testing.T) {
	cases := []struct {
		name        string
		disposition string
		contentType string
		blocked     bool
	}{
		{"attachment is the clearest signal", `attachment; filename="export.csv"`, "text/csv", true},
		{"octet-stream body", "", "application/octet-stream", true},
		{"zip archive", "", "application/zip", true},
		{"gzip archive with charset param", "", "application/gzip; charset=binary", true},
		{"inline disposition is a display hint, not a download", `inline; filename="a.png"`, "image/png", false},
		{"console HTML", "", "text/html; charset=utf-8", false},
		{"console API JSON", "", "application/json", false},
		{"console JS", "", "application/javascript", false},
		// Deliberately allowed: a CSV served for display is indistinguishable
		// from one served to be read, so it is left to the egress budget
		// rather than guessed at and breaking the app.
		{"csv without attachment is left to the budget", "", "text/csv", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resp := &http.Response{Header: http.Header{}}
			if tc.disposition != "" {
				resp.Header.Set("Content-Disposition", tc.disposition)
			}
			if tc.contentType != "" {
				resp.Header.Set("Content-Type", tc.contentType)
			}
			got := blockedDownloadReason(resp) != ""
			if got != tc.blocked {
				t.Fatalf("blocked = %v, want %v", got, tc.blocked)
			}
		})
	}
}

func TestProxyRefusesADownloadWhenPolicyBlocksIt(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Disposition", `attachment; filename="customers.csv"`)
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("id,name,email\n1,alice,alice@example.com\n"))
	}))
	defer upstream.Close()

	svc := dbTestService(t, defaultTestConfig())
	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session: &models.WebProxySession{
			ID: "wps-1", Subdomain: "minio-abc12345", UserID: "alice", Username: "alice",
			ResourceID: "res-1", ConnectionSessionID: "conn-1", BlockDownload: true,
		},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(svc, zap.NewNop())
	req := httptest.NewRequest(http.MethodGet,
		"http://minio-abc12345.pam.example.com/api/v1/buckets/x/objects/download", nil)
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want 403", rec.Code)
	}
	body := rec.Body.String()
	if strings.Contains(body, "alice@example.com") {
		t.Fatalf("SECURITY: the blocked payload reached the browser anyway:\n%s", body)
	}
	if !strings.Contains(body, "Download blocked") {
		t.Fatalf("expected an explanatory refusal page, got:\n%s", body)
	}
	// Left in place, the attachment header makes the browser save the refusal
	// page under the filename the operator asked for — which reads as success.
	if cd := rec.Result().Header.Get("Content-Disposition"); cd != "" {
		t.Fatalf("Content-Disposition must be stripped from a refusal, got %q", cd)
	}
}

func TestProxyDeliversTheSameDownloadWhenPolicyAllowsIt(t *testing.T) {
	const payload = "id,name\n1,alice\n"
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Disposition", `attachment; filename="export.csv"`)
		_, _ = w.Write([]byte(payload))
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"}, // BlockDownload false
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/export", nil)
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if rec.Code != http.StatusOK || rec.Body.String() != payload {
		t.Fatalf("an unrestricted session must be unaffected: status=%d body=%q",
			rec.Code, rec.Body.String())
	}
}

// ── PREVENTION: egress budget ────────────────────────────────────────────

func TestEgressBudgetExhaustedOnlyWhenACapExists(t *testing.T) {
	cases := []struct {
		name      string
		max, used int64
		exhausted bool
	}{
		{"no cap configured", 0, 1 << 30, false},
		{"under the cap", 1000, 999, false},
		{"exactly at the cap", 1000, 1000, true},
		{"over the cap", 1000, 5000, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			s := models.WebProxySession{MaxEgressBytes: tc.max, EgressBytes: tc.used}
			if got := s.EgressBudgetExhausted(); got != tc.exhausted {
				t.Fatalf("exhausted = %v, want %v", got, tc.exhausted)
			}
		})
	}
}

func TestProxyRefusesRequestsOnceTheEgressBudgetIsSpent(t *testing.T) {
	gin.SetMode(gin.TestMode)
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t.Error("the target must not be contacted at all once the budget is spent")
	}))
	defer upstream.Close()

	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)
	seedResolvableResource(t, svc, row, upstream.URL)
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Updates(map[string]interface{}{"max_egress_bytes": 1000, "egress_bytes": 1500}).Error; err != nil {
		t.Fatalf("seed spent budget: %v", err)
	}

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet,
		"http://minio-abc12345.pam.example.com/api/v1/buckets", nil)
	c.Request.AddCookie(&http.Cookie{Name: cookieName(false), Value: "tok"})

	NewHandler(svc, zap.NewNop()).handleProxy(c, row.Subdomain)

	if rec.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want 403 — body: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), "Data transfer limit") {
		t.Fatalf("expected an explanatory refusal, got:\n%s", rec.Body.String())
	}
}

func TestProxiedResponseBytesAccumulateAgainstTheBudget(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	now := time.Now().UTC()
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/a", StatusCode: 200,
		ResponseBodyBytes: 400, OccurredAt: now,
	})
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/b", StatusCode: 200,
		ResponseBodyBytes: 650, OccurredAt: now,
	})

	var reloaded models.WebProxySession
	if err := svc.db.Where("id = ?", row.ID).First(&reloaded).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if reloaded.EgressBytes != 1050 {
		t.Fatalf("egress_bytes = %d, want 1050", reloaded.EgressBytes)
	}
}

// ── FRICTION: clipboard guard + watermark ────────────────────────────────
//
// These assert delivery and reporting only. Whether a copy was actually
// prevented is not knowable here by design.

func TestGuardAndWatermarkInjectedOnlyWhenPolicyAsksForThem(t *testing.T) {
	cases := []struct {
		name          string
		session       *models.WebProxySession
		wantGuard     bool
		wantWatermark bool
	}{
		{"no policy", &models.WebProxySession{}, false, false},
		{"clipboard only", &models.WebProxySession{BlockClipboard: true}, true, false},
		{"watermark only", &models.WebProxySession{Watermark: true, Username: "alice"}, false, true},
		{"both", &models.WebProxySession{BlockClipboard: true, Watermark: true, Username: "alice"}, true, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			tags := string(pamScriptTags("", false, tc.session))
			if got := strings.Contains(tags, violationPath); got != tc.wantGuard {
				t.Fatalf("clipboard guard present = %v, want %v", got, tc.wantGuard)
			}
			if got := strings.Contains(tags, "__pam_wm"); got != tc.wantWatermark {
				t.Fatalf("watermark present = %v, want %v", got, tc.wantWatermark)
			}
			// The heartbeat is never conditional on data-protection policy.
			if !strings.Contains(tags, heartbeatPath) {
				t.Fatal("heartbeat must always be injected")
			}
		})
	}
}

func TestWatermarkCarriesOperatorIdentityForAttribution(t *testing.T) {
	tag := string(watermarkScriptTag("", "das_admin", "b027abb1-dead-beef-0000-000000000000"))
	if !strings.Contains(tag, "das_admin") {
		t.Fatalf("watermark must name the operator — attribution is its entire purpose: %s", tag)
	}
	if !strings.Contains(tag, "b027abb1") {
		t.Fatalf("watermark must carry the session id so a screenshot maps to an audit row: %s", tag)
	}
	if strings.Contains(tag, "pointer-events") == false && strings.Contains(tag, "pointerEvents") == false {
		t.Fatal("the overlay must be click-through or it makes the console unusable")
	}
}

func TestGuardScriptCarriesTheCSPNonce(t *testing.T) {
	// Without this the guard is silently dropped on exactly the targets that
	// forbid inline script — the same failure mode the heartbeat had.
	tag := string(guardScriptTag("N0NCE"))
	if !strings.HasPrefix(tag, `<script nonce="N0NCE">`) {
		t.Fatalf("guard must carry the nonce: %s", tag)
	}
}

func TestViolationEndpointRecordsTheAttempt(t *testing.T) {
	gin.SetMode(gin.TestMode)
	svc := dbTestService(t, defaultTestConfig())
	row, _ := seedRecordedSession(t, svc)
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	defer upstream.Close()
	seedResolvableResource(t, svc, row, upstream.URL)

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodPost,
		"http://minio-abc12345.pam.example.com"+violationPath,
		strings.NewReader(`{"kind":"copy"}`))
	c.Request.Header.Set("Content-Type", "application/json")
	c.Request.AddCookie(&http.Cookie{Name: cookieName(false), Value: "tok"})

	NewHandler(svc, zap.NewNop()).handleViolation(c, row.Subdomain)

	if got := c.Writer.Status(); got != http.StatusNoContent {
		t.Fatalf("status = %d, want 204 (sendBeacon ignores the body)", got)
	}
}

func TestViolationEndpointIgnoresAnUnknownSession(t *testing.T) {
	gin.SetMode(gin.TestMode)
	svc := dbTestService(t, defaultTestConfig())

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodPost,
		"http://app-abc12345.pam.example.com"+violationPath, strings.NewReader(`{"kind":"copy"}`))

	NewHandler(svc, zap.NewNop()).handleViolation(c, "app-abc12345")

	if got := c.Writer.Status(); got != http.StatusNoContent {
		t.Fatalf("status = %d; an unauthenticated beacon must be a silent no-op, not an error", got)
	}
}

// ── Connect-method gate ──────────────────────────────────────────────────

func TestStartSessionRefusesAResourceThatForbidsTheWebPath(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	if err := svc.db.Create(&models.PAMResource{
		ID: "res-closed", Name: "Locked MinIO", ResourceType: "minio",
		Host: "127.0.0.1", Port: 9001, ConsoleURL: "http://127.0.0.1:9001",
		IsActive: true, AllowedConnectMethods: "web_terminal",
	}).Error; err != nil {
		t.Fatalf("seed resource: %v", err)
	}

	_, err := svc.StartSession(context.Background(), StartSessionInput{
		UserID: "alice", Username: "alice", ResourceID: "res-closed",
	})
	if !errors.Is(err, ErrConnectMethodNotAllowed) {
		t.Fatalf("err = %v, want ErrConnectMethodNotAllowed", err)
	}
}

// A control enforced on one path and not the others is bypassed by clicking a
// different connect button, so the gate has to exist at every entry point.
// This pins the shared decision function all three consult; the per-path
// wiring is covered by TestStartSessionRefusesAResourceThatForbidsTheWebPath
// here, and by the gates in internal/gateway and AgentService.ResolveLaunch.
func TestEveryConnectMethodIsGatedByTheSameAllowList(t *testing.T) {
	const brokeredOnly = "web_proxy,web_terminal"

	for _, method := range []string{
		models.ConnectMethodWebProxy,
		models.ConnectMethodWebTerminal,
	} {
		if !models.ConnectMethodAllowed(brokeredOnly, method) {
			t.Fatalf("%s must remain permitted by %q", method, brokeredOnly)
		}
	}
	if models.ConnectMethodAllowed(brokeredOnly, models.ConnectMethodAgent) {
		t.Fatalf("the agent path must be closed by %q — it is the only path PAM cannot "+
			"observe, and leaving it open makes every egress control decoration", brokeredOnly)
	}
}

// ── Re-entering a live brokered session ──────────────────────────────────

// A resource's proxy subdomain is deterministic, so a second session on the
// same resource overwrites the first one's cookie on that host and abandons
// the original row as ACTIVE. The console can only offer re-entry instead of a
// duplicate if it is told where to go back to — and it cannot work that out
// itself, because the scheme and base domain are server config.
func TestListMineCarriesAReEntryURLForEachSession(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	for _, sub := range []string{"minio-abc12345", "clickhouse-def67890"} {
		if err := svc.db.Create(&models.WebProxySession{
			ConnectionSessionID: "conn-" + sub,
			ResourceID:          "res-" + sub,
			UserID:              "alice",
			Username:            "alice",
			Subdomain:           sub,
			TokenHash:           hashToken("tok-" + sub),
			Status:              models.WebProxySessionActive,
			LastActivityAt:      now,
			ExpiresAt:           now.Add(time.Hour),
		}).Error; err != nil {
			t.Fatalf("seed session %s: %v", sub, err)
		}
	}

	mine, err := svc.ListMine("alice")
	if err != nil {
		t.Fatalf("ListMine: %v", err)
	}
	if len(mine) != 2 {
		t.Fatalf("got %d sessions, want 2", len(mine))
	}
	for _, ms := range mine {
		want := "http://" + ms.Subdomain + ".pam.example.com"
		if ms.AppURL != want {
			t.Fatalf("AppURL = %q, want %q — the console cannot re-enter a session it has no URL for",
				ms.AppURL, want)
		}
	}

	// Another operator's sessions must not appear, and neither must ended ones.
	if other, err := svc.ListMine("bob"); err != nil || len(other) != 0 {
		t.Fatalf("ListMine(bob) = %d sessions, %v; want 0 and no error", len(other), err)
	}
}

func TestListMineExcludesEndedSessions(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	if err := svc.db.Create(&models.WebProxySession{
		ConnectionSessionID: "conn-dead", ResourceID: "res-1",
		UserID: "alice", Username: "alice", Subdomain: "minio-dead0000",
		TokenHash: hashToken("dead"), Status: models.WebProxySessionEnded,
		LastActivityAt: now, ExpiresAt: now.Add(time.Hour),
	}).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}

	mine, err := svc.ListMine("alice")
	if err != nil {
		t.Fatalf("ListMine: %v", err)
	}
	if len(mine) != 0 {
		t.Fatalf("an ended session must not be offered for re-entry, got %d", len(mine))
	}
}

// ── Regressions: the three bugs that made a launched session unusable ────

// TestAppURLCarriesThePublicPort pins the bug that broke the whole feature in
// development: appURL built http://<sub>.<domain> with no port, so with the
// API on 8080 every launch_url pointed at port 80 where nothing listens. The
// operator got a blank tab, the console never loaded, the rrweb recorder
// therefore never ran, and the recording silently fell back to the request
// transcript. One missing port, three reported symptoms.
func TestAppURLCarriesThePublicPort(t *testing.T) {
	cases := []struct {
		name   string
		scheme string
		port   int
		want   string
	}{
		{"dev on 8080 needs the port", "http", 8080, "http://minio-abc123.pam.example.com:8080"},
		{"unset omits it (fronted by a proxy)", "http", 0, "http://minio-abc123.pam.example.com"},
		{"http default is redundant", "http", 80, "http://minio-abc123.pam.example.com"},
		{"https default is redundant", "https", 443, "https://minio-abc123.pam.example.com"},
		{"https on a custom port keeps it", "https", 8443, "https://minio-abc123.pam.example.com:8443"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := defaultTestConfig()
			cfg.Scheme = tc.scheme
			cfg.PublicPort = tc.port
			svc := testService(cfg)
			if got := svc.appURL("minio-abc123"); got != tc.want {
				t.Fatalf("appURL = %q, want %q", got, tc.want)
			}
		})
	}
}

// The port must never leak into host matching: IsProxyHost strips the port
// from the request host and compares against a bare BaseDomain, so a
// PublicPort that reached BaseDomain would break every proxied request.
func TestPublicPortDoesNotAffectHostMatching(t *testing.T) {
	cfg := defaultTestConfig()
	cfg.PublicPort = 8080
	h := NewHandler(testService(cfg), zap.NewNop())

	for _, host := range []string{
		"minio-abc12345.pam.example.com",
		"minio-abc12345.pam.example.com:8080",
	} {
		sub, ok := h.IsProxyHost(host)
		if !ok || sub != "minio-abc12345" {
			t.Fatalf("IsProxyHost(%q) = (%q, %v); a configured public port must not change matching",
				host, sub, ok)
		}
	}
}

// A session that was created but never entered — no heartbeat, no proxied
// request — used to match no reconciliation rule at all and sat ACTIVE for the
// full idle timeout, leaving a live-session banner on screen with nothing
// behind it. That is the state a blocked popup or an unreachable launch URL
// leaves behind, so it needs its own rule.
func TestNeverEnteredSessionIsReconciled(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	row := &models.WebProxySession{
		ConnectionSessionID: "conn-unentered",
		ResourceID:          "res-1",
		UserID:              "alice",
		Username:            "alice",
		Subdomain:           "minio-unentered",
		TokenHash:           hashToken("tok-unentered"),
		Status:              models.WebProxySessionActive,
		LastActivityAt:      now, // NOT idle by the idle-timeout measure
		LastHeartbeatAt:     nil, // never entered
		RequestCount:        0,   // nothing was ever proxied
		ExpiresAt:           now.Add(3 * time.Hour),
	}
	if err := svc.db.Create(row).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}
	// Age it past the unentered grace. created_at is autoCreateTime, so it is
	// written on insert and has to be pushed back explicitly.
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("created_at", now.Add(-(unenteredGraceSeconds+30)*time.Second)).Error; err != nil {
		t.Fatalf("age the row: %v", err)
	}

	closed, err := svc.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 1 {
		t.Fatalf("closed %d sessions, want 1 — a session nobody ever entered must not hold open", closed)
	}

	var reloaded models.WebProxySession
	if err := svc.db.Where("id = ?", row.ID).First(&reloaded).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	if reloaded.Status == models.WebProxySessionActive {
		t.Fatal("expected the never-entered session to be closed")
	}
}

// The counterpart: a session created seconds ago has not had time to be
// entered, and closing it would race the operator's own browser.
func TestFreshlyCreatedSessionIsGivenTimeToBeEntered(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	row := &models.WebProxySession{
		ConnectionSessionID: "conn-fresh", ResourceID: "res-1",
		UserID: "alice", Username: "alice", Subdomain: "minio-fresh",
		TokenHash: hashToken("tok-fresh"), Status: models.WebProxySessionActive,
		LastActivityAt: now, RequestCount: 0, ExpiresAt: now.Add(3 * time.Hour),
	}
	if err := svc.db.Create(row).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}

	closed, err := svc.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 0 {
		t.Fatalf("closed %d; a session created moments ago must be left alone", closed)
	}
}

// A session that HAS been entered is not swept by the unentered rule, even
// before its first heartbeat lands — the request count is the evidence.
func TestEnteredSessionIsNotSweptAsUnentered(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	now := time.Now().UTC()

	row := &models.WebProxySession{
		ConnectionSessionID: "conn-entered", ResourceID: "res-1",
		UserID: "alice", Username: "alice", Subdomain: "minio-entered",
		TokenHash: hashToken("tok-entered"), Status: models.WebProxySessionActive,
		LastActivityAt: now, RequestCount: 12, ExpiresAt: now.Add(3 * time.Hour),
	}
	if err := svc.db.Create(row).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("created_at", now.Add(-(unenteredGraceSeconds+30)*time.Second)).Error; err != nil {
		t.Fatalf("age the row: %v", err)
	}

	closed, err := svc.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 0 {
		t.Fatalf("closed %d; a session with proxied requests has been entered and must survive", closed)
	}
}

// The console must open a brokered session in a new tab, which means it cannot
// pass `noopener` to window.open (that returns null). Opener isolation moves
// to this header instead, so the proxied application cannot reach back into
// the console tab that launched it.
func TestProxyDeclaresOpenerIsolation(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		_, _ = w.Write([]byte("<html><body>console</body></html>"))
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "minio-abc12345"},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://minio-abc12345.pam.example.com/", nil)
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if got := rec.Result().Header.Get("Cross-Origin-Opener-Policy"); got != "same-origin" {
		t.Fatalf("Cross-Origin-Opener-Policy = %q, want same-origin — without it the console tab "+
			"is reachable from the proxied application via window.opener", got)
	}
}
