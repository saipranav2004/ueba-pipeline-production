// pam/internal/middleware/audit.go
package middleware

import (
	"bytes"
	"context"
	"io"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

func AuditMiddleware(audit *services.AuditService, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		reqID := c.GetHeader("X-Request-ID")
		if reqID == "" {
			reqID = uuid.NewString()
			c.Request.Header.Set("X-Request-ID", reqID)
		}
		c.Writer.Header().Set("X-Request-ID", reqID)
		c.Set("request_id", reqID)

		var bodyBytes []byte
		if c.Request.Body != nil && c.Request.Method != "GET" {
			b, _ := io.ReadAll(c.Request.Body)
			bodyBytes = b
			c.Request.Body = io.NopCloser(bytes.NewReader(b))
		}

		c.Next()

		cat, action := classify(c)
		outcome := models.OutcomeSuccess
		status := c.Writer.Status()
		if status >= 400 && status < 500 {
			outcome = models.OutcomeDenied
		} else if status >= 500 {
			outcome = models.OutcomeError
		}

		userID, _ := c.Get("user_id")
		username, _ := c.Get("username")
		email, _ := c.Get("email")
		authzDec, _ := c.Get("authz_decision_id")

		uid, _ := userID.(string)
		un, _ := username.(string)
		em, _ := email.(string)
		adi, _ := authzDec.(string)

		entry := services.AuditEntry{
			UserID:          uid,
			Username:        un,
			Email:           em,
			Category:        cat,
			Action:          action,
			Outcome:         outcome,
			Resource:        c.Request.URL.Path,
			Details:         truncate(string(bodyBytes), 4096),
			SourceIP:        c.ClientIP(),
			UserAgent:       c.Request.UserAgent(),
			RequestID:       reqID,
			SessionID:       sessID(c),
			AuthzDecisionID: adi,
		}

		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			if _, err := audit.Append(ctx, entry); err != nil {
				logger.Error("audit.middleware.write.fail",
					zap.String("request_id", reqID),
					zap.String("action", action),
					zap.Error(err),
				)
			}
		}()

		logger.Debug("audit.middleware",
			zap.String("request_id", reqID),
			zap.String("path", c.Request.URL.Path),
			zap.Int("status", status),
			zap.Duration("latency", time.Since(start)),
		)
	}
}

// classify maps a request to (AuditCategory, action).
// Order matters: more specific checks come first.
func classify(c *gin.Context) (models.AuditCategory, string) {
	path := c.Request.URL.Path
	method := c.Request.Method

	// Auth routes (length 13 covers "/api/v1/auth" exactly)
	if len(path) >= 13 && path[:13] == "/api/v1/auth" {
		switch {
		case path == "/api/v1/auth/login" && method == "POST":
			return models.AuditAuth, "pam:auth:Login"
		case path == "/api/v1/auth/mfa/verify" && method == "POST":
			return models.AuditAuth, "pam:auth:MFAVerify"
		case path == "/api/v1/auth/mfa/setup/initiate":
			return models.AuditAuth, "pam:auth:MFASetupInitiate"
		case path == "/api/v1/auth/mfa/setup/verify":
			return models.AuditAuth, "pam:auth:MFASetupVerify"
		case path == "/api/v1/auth/logout":
			return models.AuditAuth, "pam:auth:Logout"
		case path == "/api/v1/auth/me":
			return models.AuditAuth, "pam:auth:Me"
		}
	}

	// PAM feature routes (length 11 covers "/api/v1/pam" exactly)
	if len(path) >= 11 && path[:11] == "/api/v1/pam" {
		// Vault operations (check before sessions because /credential contains "sessions" letters? No, doesn't.)
		if contains(path, "/credential") {
			return models.VaultAccess, "pam:vault:Store"
		}
		if contains(path, "/rotate") {
			return models.VaultAccess, "pam:vault:Rotate"
		}
		// Connect-info is a session-style action
		if contains(path, "/connect-info") {
			return models.SessionLifecycle, "pam:session:Connect"
		}
		// Sessions — kill takes precedence over list because /sessions/:id/kill also contains /sessions
		if contains(path, "/sessions") && contains(path, "/kill") {
			return models.SessionLifecycle, "pam:session:Kill"
		}
		if contains(path, "/sessions") {
			return models.SessionLifecycle, "pam:session:List"
		}
		// Resources — vault actions already checked, so this is the resource CRUD path
		if contains(path, "/resources") {
			return models.ResourceLifecycle, "pam:resource:" + method
		}
		// Audit + reports
		if contains(path, "/audit") && contains(path, "/report") {
			return models.ReportExport, "pam:report:Generate"
		}
		if contains(path, "/audit") && contains(path, "/verify") {
			return models.ReportExport, "pam:audit:Verify"
		}
		if contains(path, "/audit") {
			return models.ReportExport, "pam:audit:Read"
		}
	}
	return "OTHER", "pam:other:" + method + ":" + path
}

func sessID(c *gin.Context) string {
	if v, ok := c.Get("session_id"); ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "...[truncated]"
}
