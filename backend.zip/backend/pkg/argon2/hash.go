// pam/pkg/argon2/hash.go
//
// Hash() is the write-side counterpart to Verify() in verify.go.
//
// Historically PAM only ever VERIFIED passwords — user accounts and their
// password hashes were created by an external IAM service, and PAM merely
// checked a plaintext password against the Argon2id PHC hash IAM had already
// written. Now that PAM owns its own local Identity store (see
// internal/services/identity_service.go), PAM itself must be able to CREATE
// those hashes: on user creation, admin-triggered password reset, and the
// bootstrap root account seeded at startup.
//
// The parameters below (m=65536 KiB, t=3, p=4) match the values Verify's
// parsePHC already expects to see from IAM-authored hashes, so hashes
// created here are byte-for-byte compatible with the existing verification
// path — no changes to Verify() or parsePHC() were needed.
package argon2

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"

	xargon2 "golang.org/x/crypto/argon2"
)

const (
	hashMemory      uint32 = 65536 // 64 MiB
	hashIterations  uint32 = 3
	hashParallelism uint8  = 4
	hashSaltLen            = 16
	hashKeyLen      uint32 = 32
)

// Hash produces a standard Argon2id PHC-format hash of the given plaintext
// password, suitable for storage in PAMUser.PasswordHash and later
// verification via Verify().
func Hash(password string) (string, error) {
	if password == "" {
		return "", fmt.Errorf("password must not be empty")
	}

	salt := make([]byte, hashSaltLen)
	if _, err := rand.Read(salt); err != nil {
		return "", fmt.Errorf("failed to generate salt: %w", err)
	}

	key := xargon2.IDKey([]byte(password), salt, hashIterations, hashMemory, hashParallelism, hashKeyLen)

	encoded := fmt.Sprintf(
		"$argon2id$v=19$m=%d,t=%d,p=%d$%s$%s",
		hashMemory, hashIterations, hashParallelism,
		base64.RawStdEncoding.EncodeToString(salt),
		base64.RawStdEncoding.EncodeToString(key),
	)
	return encoded, nil
}
