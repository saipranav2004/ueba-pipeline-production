// pam/pkg/iamclient/client.go
//
// IAM client — PAM's Policy Enforcement Point (PEP) transport to IAM's Policy
// Decision Point (PDP).
//
// Responsibilities:
//  1. CheckAuthz / CheckAuthzCtx — POST /api/v1/authz/check for every
//     privileged action. Fail-CLOSED: any error is a deny.
//  2. PushGrant / RevokeGrant    — best-effort projection of a PAM time-boxed
//     grant into IAM as a temporary policy attachment. Fail-SOFT: IAM being
//     unavailable must never block PAM's own enforcement, which is
//     authoritative for PAM actions.
//  3. SendAlert                  — CRITICAL notifications (break-glass).
//
// Retry policy: the authz check is retried because it is a read-only,
// side-effect-free decision request. Grant push/revoke are retried too but are
// made idempotent by the caller-supplied GrantID.
package iamclient

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/yourorg/pam/internal/config"
	"go.uber.org/zap"
)

// Client is the HTTP client that talks to the IAM control center (PDP).
type Client struct {
	httpClient    *http.Client
	baseURL       string
	authzCheckURL string
	grantURL      string
	revokeURL     string
	alertURL      string
	serviceToken  string
	maxRetries    int
	retryBackoff  time.Duration
	timeout       time.Duration
	logger        *zap.Logger

	cache *decisionCache // nil when caching is disabled
}

// AuthzRequest is the payload sent to IAM POST /api/v1/authz/check.
type AuthzRequest struct {
	UserID      string `json:"user_id"`
	Action      string `json:"action"`
	ResourceARN string `json:"resource_arn"`
}

// AuthzDecision is the decision body returned by IAM.
type AuthzDecision struct {
	Allowed    bool   `json:"allowed"`
	Reason     string `json:"reason"`
	DecisionID string `json:"decision_id"`
}

// AuthzResponse is what IAM returns.
type AuthzResponse struct {
	Success bool          `json:"success"`
	Data    AuthzDecision `json:"data"`
	Message string        `json:"message"`
	// Cached is set by this client (never by IAM) when the decision was
	// served from the local ALLOW cache. Useful for audit correlation.
	Cached bool `json:"-"`
}

// GrantRequest projects a PAM time-boxed grant onto IAM.
type GrantRequest struct {
	GrantID      string    `json:"grant_id"`
	UserID       string    `json:"user_id"`
	Action       string    `json:"action"`
	ResourceARN  string    `json:"resource_arn"`
	ExpiresAt    time.Time `json:"expires_at"`
	Reason       string    `json:"reason"`
	IsBreakglass bool      `json:"is_breakglass"`
	RequestID    string    `json:"request_id"`
}

// GrantResponse is IAM's acknowledgement of a temporary policy attachment.
type GrantResponse struct {
	Success bool `json:"success"`
	Data    struct {
		PolicyID string `json:"policy_id"`
	} `json:"data"`
	Message string `json:"message"`
}

// Alert is a notification pushed to IAM (break-glass, forced revocation).
type Alert struct {
	Severity  string            `json:"severity"` // INFO | WARN | CRITICAL
	Source    string            `json:"source"`   // always "PAM"
	Event     string            `json:"event"`
	Message   string            `json:"message"`
	UserID    string            `json:"user_id,omitempty"`
	RequestID string            `json:"request_id,omitempty"`
	GrantID   string            `json:"grant_id,omitempty"`
	Metadata  map[string]string `json:"metadata,omitempty"`
	Timestamp time.Time         `json:"timestamp"`
}

// ErrNotConfigured is returned when an optional IAM endpoint is not configured.
var ErrNotConfigured = errors.New("iam endpoint not configured")

// New creates an IAM client.
func New(cfg config.IAMConfig, log *zap.Logger) *Client {
	timeout := time.Duration(cfg.TimeoutSec) * time.Second
	if timeout <= 0 {
		timeout = 5 * time.Second
	}
	backoff := time.Duration(cfg.RetryBackoffMs) * time.Millisecond
	if backoff <= 0 {
		backoff = 150 * time.Millisecond
	}

	c := &Client{
		httpClient: &http.Client{
			Timeout: timeout,
			Transport: &http.Transport{
				MaxIdleConns:        100,
				MaxIdleConnsPerHost: 20,
				IdleConnTimeout:     90 * time.Second,
			},
		},
		baseURL:       strings.TrimRight(cfg.BaseURL, "/"),
		authzCheckURL: cfg.AuthzCheckURL,
		grantURL:      cfg.GrantURL,
		revokeURL:     cfg.RevokeURL,
		alertURL:      cfg.AlertURL,
		serviceToken:  cfg.ServiceToken,
		maxRetries:    cfg.MaxRetries,
		retryBackoff:  backoff,
		timeout:       timeout,
		logger:        log,
	}
	if cfg.AuthzCacheTTLSec > 0 {
		c.cache = newDecisionCache(time.Duration(cfg.AuthzCacheTTLSec) * time.Second)
		log.Warn("iam.authz.cache.enabled",
			zap.Int("ttl_sec", cfg.AuthzCacheTTLSec),
			zap.String("note", "revoked IAM permissions may be honoured for up to ttl_sec; PAM JIT grants are never cached"),
		)
	}
	return c
}

// ──────────────────────────────────────────────────────────────────────────
// AUTHZ CHECK (PEP → PDP)
// ──────────────────────────────────────────────────────────────────────────

// CheckAuthz keeps the original signature used by existing middleware.
// It delegates to CheckAuthzCtx with a background context.
func (c *Client) CheckAuthz(req AuthzRequest) (*AuthzResponse, error) {
	return c.CheckAuthzCtx(context.Background(), req)
}

// CheckAuthzCtx calls IAM's POST /api/v1/authz/check and returns the decision.
//
// Fail-closed: any error (network, parse, non-200) yields allowed=false. The
// error is also returned so the caller can log/alert on PDP unavailability, but
// callers MUST gate on resp.Data.Allowed, never on err == nil.
func (c *Client) CheckAuthzCtx(ctx context.Context, req AuthzRequest) (*AuthzResponse, error) {
	if req.UserID == "" || req.Action == "" {
		return denyResponse("invalid_authz_request"), errors.New("user_id and action are required")
	}

	cacheKey := req.UserID + "|" + req.Action + "|" + req.ResourceARN
	if c.cache != nil {
		if dec, ok := c.cache.get(cacheKey); ok {
			return &AuthzResponse{Success: true, Data: dec, Cached: true}, nil
		}
	}

	body, err := json.Marshal(req)
	if err != nil {
		c.logger.Error("iam.authz.marshal.fail", zap.Error(err))
		return denyResponse("marshal_error"), err
	}

	url := c.baseURL + c.authzCheckURL

	var lastErr error
	for attempt := 0; attempt <= c.maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return denyResponse("context_cancelled"), ctx.Err()
			case <-time.After(c.backoffFor(attempt)):
			}
		}

		status, raw, doErr := c.do(ctx, http.MethodPost, url, body)
		if doErr != nil {
			lastErr = doErr
			c.logger.Warn("iam.authz.http.fail",
				zap.String("action", req.Action),
				zap.String("resource", req.ResourceARN),
				zap.Int("attempt", attempt+1),
				zap.Error(doErr),
			)
			continue // network-level failure → retry
		}

		if status >= 500 {
			lastErr = fmt.Errorf("iam returned %d", status)
			c.logger.Warn("iam.authz.server_error",
				zap.Int("status", status),
				zap.String("action", req.Action),
				zap.Int("attempt", attempt+1),
			)
			continue // server-side failure → retry
		}

		var authzResp AuthzResponse
		if uErr := json.Unmarshal(raw, &authzResp); uErr != nil {
			c.logger.Error("iam.authz.parse.fail", zap.Error(uErr), zap.ByteString("body", truncate(raw)))
			return denyResponse("parse_error"), uErr
		}

		if status != http.StatusOK {
			// 4xx is a definitive answer (bad token, unknown user) — do not retry.
			c.logger.Warn("iam.authz.non_200",
				zap.Int("status", status),
				zap.String("action", req.Action),
			)
			return denyResponse(fmt.Sprintf("iam_http_%d", status)), nil
		}

		c.logger.Info("iam.authz.decision",
			zap.String("user", req.UserID),
			zap.String("action", req.Action),
			zap.String("resource", req.ResourceARN),
			zap.Bool("allowed", authzResp.Data.Allowed),
			zap.String("reason", authzResp.Data.Reason),
			zap.String("decision_id", authzResp.Data.DecisionID),
		)

		if c.cache != nil && authzResp.Data.Allowed {
			c.cache.put(cacheKey, authzResp.Data)
		}
		return &authzResp, nil
	}

	// All attempts exhausted → fail closed.
	c.logger.Error("iam.authz.unreachable",
		zap.String("action", req.Action),
		zap.String("resource", req.ResourceARN),
		zap.Int("attempts", c.maxRetries+1),
		zap.Error(lastErr),
	)
	return denyResponse("iam_unreachable"), lastErr
}

// InvalidateUser drops every cached ALLOW decision for a user. Called on grant
// revocation so a revoked entitlement is not served from cache.
func (c *Client) InvalidateUser(userID string) {
	if c.cache != nil {
		c.cache.invalidatePrefix(userID + "|")
	}
}

// ──────────────────────────────────────────────────────────────────────────
// TEMPORARY POLICY PROJECTION (best-effort, fail-soft)
// ──────────────────────────────────────────────────────────────────────────

// GrantConfigured reports whether IAM grant projection is enabled.
func (c *Client) GrantConfigured() bool { return c.grantURL != "" }

// RevokeConfigured reports whether IAM revoke projection is enabled.
func (c *Client) RevokeConfigured() bool { return c.revokeURL != "" }

// AlertConfigured reports whether CRITICAL alert forwarding is enabled.
func (c *Client) AlertConfigured() bool { return c.alertURL != "" }

// PushGrant attaches a temporary policy in IAM for an approved PAM grant.
// Returns ErrNotConfigured when iam.grant_url is empty (the default), in which
// case PAM-local grants remain the single source of truth.
func (c *Client) PushGrant(ctx context.Context, req GrantRequest) (*GrantResponse, error) {
	if !c.GrantConfigured() {
		return nil, ErrNotConfigured
	}
	body, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshal grant: %w", err)
	}

	var lastErr error
	for attempt := 0; attempt <= c.maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(c.backoffFor(attempt)):
			}
		}
		status, raw, doErr := c.do(ctx, http.MethodPost, c.baseURL+c.grantURL, body)
		if doErr != nil {
			lastErr = doErr
			continue
		}
		if status >= 500 {
			lastErr = fmt.Errorf("iam grant returned %d", status)
			continue
		}
		if status != http.StatusOK && status != http.StatusCreated {
			return nil, fmt.Errorf("iam grant rejected with http %d: %s", status, string(truncate(raw)))
		}
		var gr GrantResponse
		if uErr := json.Unmarshal(raw, &gr); uErr != nil {
			// IAM accepted it but we cannot read the policy id — not fatal.
			c.logger.Warn("iam.grant.parse.fail", zap.Error(uErr))
			return &GrantResponse{Success: true}, nil
		}
		return &gr, nil
	}
	return nil, fmt.Errorf("iam grant unreachable after %d attempts: %w", c.maxRetries+1, lastErr)
}

// RevokeGrant detaches the temporary policy in IAM.
// The configured revoke URL may contain the "{grant_id}" placeholder.
func (c *Client) RevokeGrant(ctx context.Context, grantID string) error {
	if !c.RevokeConfigured() {
		return ErrNotConfigured
	}
	path := c.revokeURL
	if strings.Contains(path, "{grant_id}") {
		path = strings.ReplaceAll(path, "{grant_id}", grantID)
	}
	body, _ := json.Marshal(map[string]string{"grant_id": grantID})

	var lastErr error
	for attempt := 0; attempt <= c.maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(c.backoffFor(attempt)):
			}
		}
		status, raw, doErr := c.do(ctx, http.MethodDelete, c.baseURL+path, body)
		if doErr != nil {
			lastErr = doErr
			continue
		}
		if status >= 500 {
			lastErr = fmt.Errorf("iam revoke returned %d", status)
			continue
		}
		// 404 means IAM has no such attachment — treat as already revoked.
		if status == http.StatusNotFound {
			return nil
		}
		if status != http.StatusOK && status != http.StatusNoContent && status != http.StatusAccepted {
			return fmt.Errorf("iam revoke rejected with http %d: %s", status, string(truncate(raw)))
		}
		return nil
	}
	return fmt.Errorf("iam revoke unreachable after %d attempts: %w", c.maxRetries+1, lastErr)
}

// SendAlert forwards a notification to IAM. Best-effort: errors are returned
// but callers should log and continue — an alert failure must never block a
// security control from completing.
func (c *Client) SendAlert(ctx context.Context, a Alert) error {
	if !c.AlertConfigured() {
		return ErrNotConfigured
	}
	if a.Source == "" {
		a.Source = "PAM"
	}
	if a.Timestamp.IsZero() {
		a.Timestamp = time.Now().UTC()
	}
	body, err := json.Marshal(a)
	if err != nil {
		return err
	}
	status, raw, err := c.do(ctx, http.MethodPost, c.baseURL+c.alertURL, body)
	if err != nil {
		return err
	}
	if status >= 300 {
		return fmt.Errorf("iam alert http %d: %s", status, string(truncate(raw)))
	}
	return nil
}

// ──────────────────────────────────────────────────────────────────────────
// INTERNALS
// ──────────────────────────────────────────────────────────────────────────

func (c *Client) do(ctx context.Context, method, url string, body []byte) (int, []byte, error) {
	reqCtx, cancel := context.WithTimeout(ctx, c.timeout)
	defer cancel()

	httpReq, err := http.NewRequestWithContext(reqCtx, method, url, bytes.NewReader(body))
	if err != nil {
		return 0, nil, fmt.Errorf("build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Accept", "application/json")
	httpReq.Header.Set("X-IAM-Service-Token", c.serviceToken)

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return 0, nil, err
	}
	defer resp.Body.Close()

	// Cap the body we are willing to read from IAM (1 MiB).
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return resp.StatusCode, nil, fmt.Errorf("read body: %w", err)
	}
	return resp.StatusCode, raw, nil
}

// backoffFor returns an exponential backoff capped at 2s.
func (c *Client) backoffFor(attempt int) time.Duration {
	if attempt < 1 {
		attempt = 1
	}
	d := c.retryBackoff << (attempt - 1)
	if d > 2*time.Second {
		d = 2 * time.Second
	}
	return d
}

func truncate(b []byte) []byte {
	if len(b) > 512 {
		return b[:512]
	}
	return b
}

// denyResponse constructs a fail-closed AuthzResponse.
func denyResponse(reason string) *AuthzResponse {
	return &AuthzResponse{
		Success: false,
		Data: AuthzDecision{
			Allowed: false,
			Reason:  reason,
		},
	}
}

// ── ALLOW-decision cache (disabled by default) ────────────────────────────

type cacheEntry struct {
	decision  AuthzDecision
	expiresAt time.Time
}

type decisionCache struct {
	mu      sync.RWMutex
	ttl     time.Duration
	entries map[string]cacheEntry
}

func newDecisionCache(ttl time.Duration) *decisionCache {
	return &decisionCache{ttl: ttl, entries: make(map[string]cacheEntry)}
}

func (d *decisionCache) get(key string) (AuthzDecision, bool) {
	d.mu.RLock()
	e, ok := d.entries[key]
	d.mu.RUnlock()
	if !ok || time.Now().After(e.expiresAt) {
		return AuthzDecision{}, false
	}
	return e.decision, true
}

func (d *decisionCache) put(key string, dec AuthzDecision) {
	d.mu.Lock()
	defer d.mu.Unlock()
	// Opportunistic sweep so the map cannot grow without bound.
	if len(d.entries) > 10000 {
		now := time.Now()
		for k, v := range d.entries {
			if now.After(v.expiresAt) {
				delete(d.entries, k)
			}
		}
	}
	d.entries[key] = cacheEntry{decision: dec, expiresAt: time.Now().Add(d.ttl)}
}

func (d *decisionCache) invalidatePrefix(prefix string) {
	d.mu.Lock()
	defer d.mu.Unlock()
	for k := range d.entries {
		if strings.HasPrefix(k, prefix) {
			delete(d.entries, k)
		}
	}
}
