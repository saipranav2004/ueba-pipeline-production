// pam/pkg/crypto/envelope.go
package crypto

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"sort"
	"strings"
)

var (
	ErrInvalidEnvelope = errors.New("invalid sealed envelope format")
	ErrAADMismatch     = errors.New("additional authenticated data (AAD) mismatch during decryption")
	ErrUnsupportedAlgo = errors.New("unsupported envelope encryption algorithm")
)

const (
	CurrentAlgo    = "AES-256-GCM"
	CurrentVersion = 1
)

// EncryptedCredentialPayload represents the database-safe sealed envelope for a credential.
type EncryptedCredentialPayload struct {
	Ciphertext          string            `json:"ciphertext"`
	Nonce               string            `json:"nonce"`
	EncryptedDEK        string            `json:"encrypted_dek"`
	KMSKeyReference     string            `json:"kms_key_reference"`
	EncryptionAlgorithm string            `json:"encryption_algorithm"`
	EncryptionVersion   int               `json:"encryption_version"`
	AADContext          map[string]string `json:"aad_context,omitempty"`
}

func buildAADBytes(aad map[string]string) []byte {
	if len(aad) == 0 {
		return nil
	}
	keys := make([]string, 0, len(aad))
	for k := range aad {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var sb strings.Builder
	for _, k := range keys {
		sb.WriteString(k)
		sb.WriteString("=")
		sb.WriteString(aad[k])
		sb.WriteString(";")
	}
	return []byte(sb.String())
}

// EnvelopeEncryptor encrypts plaintext using the Sealed Envelope pattern:
// 1. Generate random 32-byte DEK and 12-byte Nonce.
// 2. Encrypt plaintext with AES-256-GCM using DEK + AAD bytes.
// 3. Encrypt DEK with KMSProvider.
// 4. Return serialized JSON envelope.
func EnvelopeEncryptor(ctx context.Context, kms KMSProvider, plaintext string, aadContext map[string]string) (string, error) {
	if kms == nil {
		return "", errors.New("kms provider is required for envelope encryption")
	}

	dek := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, dek); err != nil {
		return "", fmt.Errorf("failed to generate random DEK: %w", err)
	}

	block, err := aes.NewCipher(dek)
	if err != nil {
		return "", fmt.Errorf("failed to create aes cipher with DEK: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", fmt.Errorf("failed to create gcm with DEK: %w", err)
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", fmt.Errorf("failed to generate nonce: %w", err)
	}

	aadBytes := buildAADBytes(aadContext)
	ciphertext := gcm.Seal(nil, nonce, []byte(plaintext), aadBytes)

	encryptedDEK, keyRef, err := kms.EncryptKey(ctx, dek)
	if err != nil {
		return "", fmt.Errorf("kms DEK encryption failed: %w", err)
	}

	envelope := EncryptedCredentialPayload{
		Ciphertext:          base64.StdEncoding.EncodeToString(ciphertext),
		Nonce:               base64.StdEncoding.EncodeToString(nonce),
		EncryptedDEK:        base64.StdEncoding.EncodeToString(encryptedDEK),
		KMSKeyReference:     keyRef,
		EncryptionAlgorithm: CurrentAlgo,
		EncryptionVersion:   CurrentVersion,
		AADContext:          aadContext,
	}

	raw, err := json.Marshal(envelope)
	if err != nil {
		return "", fmt.Errorf("failed to serialize envelope JSON: %w", err)
	}
	return string(raw), nil
}

// EnvelopeDecryptor decrypts a sealed envelope JSON string:
// 1. Check if input is JSON envelope (fallback to legacy single-key AES if not).
// 2. Decrypt DEK via KMSProvider.
// 3. Decrypt secret ciphertext using DEK + AAD bytes.
func EnvelopeDecryptor(ctx context.Context, kms KMSProvider, envelopeJSON string, aadContext map[string]string) (string, error) {
	if kms == nil {
		return "", errors.New("kms provider is required for envelope decryption")
	}

	// Support fallback for legacy single-layer AES-256 encrypted strings
	if !strings.HasPrefix(strings.TrimSpace(envelopeJSON), "{") {
		if local, ok := kms.(*LocalKMSProvider); ok {
			keyB64 := base64.StdEncoding.EncodeToString(local.masterKey)
			return Decrypt(envelopeJSON, keyB64)
		}
		return "", ErrInvalidEnvelope
	}

	var env EncryptedCredentialPayload
	if err := json.Unmarshal([]byte(envelopeJSON), &env); err != nil {
		return "", fmt.Errorf("%w: %v", ErrInvalidEnvelope, err)
	}

	if env.EncryptionAlgorithm != CurrentAlgo {
		return "", fmt.Errorf("%w: %s", ErrUnsupportedAlgo, env.EncryptionAlgorithm)
	}

	encryptedDEK, err := base64.StdEncoding.DecodeString(env.EncryptedDEK)
	if err != nil {
		return "", fmt.Errorf("invalid base64 encrypted DEK: %w", err)
	}

	dek, err := kms.DecryptKey(ctx, encryptedDEK, env.KMSKeyReference)
	if err != nil {
		return "", fmt.Errorf("kms DEK decryption failed: %w", err)
	}

	block, err := aes.NewCipher(dek)
	if err != nil {
		return "", fmt.Errorf("failed to create cipher with DEK: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", fmt.Errorf("failed to create gcm with DEK: %w", err)
	}

	nonce, err := base64.StdEncoding.DecodeString(env.Nonce)
	if err != nil {
		return "", fmt.Errorf("invalid base64 nonce: %w", err)
	}
	ciphertext, err := base64.StdEncoding.DecodeString(env.Ciphertext)
	if err != nil {
		return "", fmt.Errorf("invalid base64 ciphertext: %w", err)
	}

	aadToUse := aadContext
	if aadToUse == nil {
		aadToUse = env.AADContext
	}
	aadBytes := buildAADBytes(aadToUse)

	plaintext, err := gcm.Open(nil, nonce, ciphertext, aadBytes)
	if err != nil {
		return "", fmt.Errorf("%w: %v", ErrAADMismatch, err)
	}
	return string(plaintext), nil
}

func IsSealedEnvelope(s string) bool {
	trimmed := strings.TrimSpace(s)
	return strings.HasPrefix(trimmed, "{") && strings.Contains(trimmed, `"encrypted_dek"`)
}
