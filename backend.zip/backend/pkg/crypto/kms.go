// pam/pkg/crypto/kms.go
package crypto

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
)

var (
	ErrKMSKeyNotFound = errors.New("kms master key not configured")
	ErrKMSDecryption  = errors.New("kms key decryption failed")
	ErrKMSUnsupported = errors.New("kms provider not supported")
)

// KMSProvider defines the interface for Key Management Services / HSM providers
// used to encrypt and decrypt Data Encryption Keys (DEKs) in the Sealed Envelope pattern.
type KMSProvider interface {
	EncryptKey(ctx context.Context, dek []byte) (encryptedDEK []byte, keyRef string, err error)
	DecryptKey(ctx context.Context, encryptedDEK []byte, keyRef string) (dek []byte, err error)
	KeyID() string
}

// LocalKMSProvider implements KMSProvider using an AES-256 master key loaded from
// the PAM_VAULT_ENCRYPTION_KEY environment variable.
type LocalKMSProvider struct {
	masterKey []byte
	keyRef    string
}

func NewLocalKMSProvider(keyB64 string) (*LocalKMSProvider, error) {
	if keyB64 == "" {
		return nil, ErrKMSKeyNotFound
	}
	key, err := base64.StdEncoding.DecodeString(keyB64)
	if err != nil {
		return nil, fmt.Errorf("invalid base64 KMS master key: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("local KMS master key must be 32 bytes for AES-256-GCM, got %d", len(key))
	}
	return &LocalKMSProvider{
		masterKey: key,
		keyRef:    "local-kms-master-v1",
	}, nil
}

func (p *LocalKMSProvider) KeyID() string {
	return p.keyRef
}

func (p *LocalKMSProvider) EncryptKey(ctx context.Context, dek []byte) ([]byte, string, error) {
	block, err := aes.NewCipher(p.masterKey)
	if err != nil {
		return nil, "", fmt.Errorf("kms cipher creation failed: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, "", fmt.Errorf("kms gcm creation failed: %w", err)
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, "", fmt.Errorf("kms nonce generation failed: %w", err)
	}

	ciphertext := gcm.Seal(nonce, nonce, dek, nil)
	return ciphertext, p.keyRef, nil
}

func (p *LocalKMSProvider) DecryptKey(ctx context.Context, encryptedDEK []byte, keyRef string) ([]byte, error) {
	block, err := aes.NewCipher(p.masterKey)
	if err != nil {
		return nil, fmt.Errorf("kms cipher creation failed: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("kms gcm creation failed: %w", err)
	}

	nonceSize := gcm.NonceSize()
	if len(encryptedDEK) < nonceSize {
		return nil, ErrKMSDecryption
	}

	nonce, ciphertext := encryptedDEK[:nonceSize], encryptedDEK[nonceSize:]
	dek, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrKMSDecryption, err)
	}
	return dek, nil
}

// AWSKMSProvider is an implementation skeleton for AWS KMS envelope encryption.
type AWSKMSProvider struct {
	keyARN string
}

func NewAWSKMSProvider(keyARN string) *AWSKMSProvider {
	return &AWSKMSProvider{keyARN: keyARN}
}

func (p *AWSKMSProvider) KeyID() string { return p.keyARN }

func (p *AWSKMSProvider) EncryptKey(ctx context.Context, dek []byte) ([]byte, string, error) {
	return nil, "", errors.New("aws kms provider not configured in local environment")
}

func (p *AWSKMSProvider) DecryptKey(ctx context.Context, encryptedDEK []byte, keyRef string) ([]byte, error) {
	return nil, errors.New("aws kms provider not configured in local environment")
}

// HSMProvider is an implementation skeleton for PKCS#11 / Cloud HSM envelope encryption.
type HSMProvider struct {
	hsmKeyLabel string
}

func NewHSMProvider(label string) *HSMProvider {
	return &HSMProvider{hsmKeyLabel: label}
}

func (p *HSMProvider) KeyID() string { return p.hsmKeyLabel }

func (p *HSMProvider) EncryptKey(ctx context.Context, dek []byte) ([]byte, string, error) {
	return nil, "", errors.New("hsm provider not configured in local environment")
}

func (p *HSMProvider) DecryptKey(ctx context.Context, encryptedDEK []byte, keyRef string) ([]byte, error) {
	return nil, errors.New("hsm provider not configured in local environment")
}
