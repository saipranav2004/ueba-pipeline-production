// pam/pkg/totp/qr_png.go
package totp

import (
	"bytes"
	"image"
	"image/png"

	"github.com/boombuler/barcode"
)

// pngEncode renders a qr barcode to PNG bytes.
func pngEncode(code barcode.Barcode) ([]byte, error) {
	// Scale to 256x256 if needed.
	if code.Bounds().Dx() < 256 {
		scaled, err := barcode.Scale(code, 256, 256)
		if err != nil {
			return nil, err
		}
		code = scaled
	}

	var buf bytes.Buffer
	if err := png.Encode(&buf, code.(image.Image)); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
