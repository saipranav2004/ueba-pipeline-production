# Fixing brokered web sessions on a deployed PAM (`iam-opa.adapid.link`)

**Symptom:** launching MinIO (or any `browser`/web-proxy resource) from the
console gives "page not found / URL not found".

**Cause:** nothing in the application. PAM is generating the right URL; the
infrastructure has no route for it. Three separate things are missing, and a
request dies at the first one, so all three must be fixed.

---

## Why the URL looks like that

Every brokered web session gets its **own hostname**:

```
https://<random-slug>.iam-opa.adapid.link/
```

The slug *is* the session identifier — PAM resolves the session from the `Host`
header alone (`internal/webproxy/proxy.go`, `IsProxyHost`), and rejects the bare
base domain and any deeper nesting. The session's traffic then lives at the
**root** of that hostname: `/`, the target app's own asset paths, and PAM's
control paths under `/__pam/`.

This is not incidental. Per-hostname isolation is what keeps one proxied app's
cookies, storage, and scripts out of every other session's origin, and out of
the console's. It is also why the fix is DNS and TLS work rather than a code
change.

The backend is already configured correctly — no change needed:

```
PAM_WEBPROXY_ENABLED=true
PAM_WEBPROXY_BASE_DOMAIN=iam-opa.adapid.link
PAM_WEBPROXY_SCHEME=https
# PAM_WEBPROXY_PUBLIC_PORT deliberately unset
```

Leave `PAM_WEBPROXY_PUBLIC_PORT` unset. 443 is the default for `https` and is
omitted from the generated URL; setting it to anything else writes a port into
every launch URL, and nothing is listening there. (That exact mistake is what
broke launches once already.)

---

## What is actually broken

Verified against the live host:

| # | Layer | Current state | Result |
|---|-------|---------------|--------|
| 1 | DNS | `*.iam-opa.adapid.link` → **NXDOMAIN** | browser never opens a connection |
| 2 | TLS | listener cert has one SAN: `DNS:iam-opa.adapid.link` | handshake fails on a name mismatch |
| 3 | Routing | no rule matches a proxy host | request lands on the console's SPA, which renders its own "page not found" |

`adapid.link` is in **Route 53** (`ns-*.awsdns-*`), and the apex resolves to
three `ap-south-1` addresses behind an **ALB** presenting an **ACM** cert.

---

## Fix 1 — Wildcard DNS

In the `adapid.link` hosted zone, add a record alongside the existing
`iam-opa` one:

- **Name:** `*.iam-opa`
- **Type:** `A`
- **Alias:** yes → the same load balancer the apex record already targets

Nothing else changes; the apex record stays exactly as it is.

## Fix 2 — A certificate that covers the wildcard

A wildcard covers **exactly one label and not the apex**, so both names belong
on the certificate. Request **one** ACM cert in the load balancer's region
(`ap-south-1`) for:

```
iam-opa.adapid.link
*.iam-opa.adapid.link
```

Validate by DNS — Route 53 can write the validation records itself, since the
zone is already there. Then attach it to the **443 listener** (replacing the
current single-name cert, or added alongside it; SNI picks per connection).

Certificates are regional for ALBs: it must be issued in the same region as
the load balancer, not `us-east-1` (that rule is CloudFront's).

## Fix 3 — A route for the proxy hosts

**This is the one that will still fail silently after 1 and 2 are done**, and
it is the one that produces the exact error you are seeing.

On this deployment the ALB appears to route `/api/*` straight to pam-api and
everything else to nginx — `/api/health` comes back with **no** `Server`
header while `/` comes back with `Server: nginx`, and nginx stamps its own
`Server` on responses it proxies. Confirm that in the console before acting on
it: **EC2 → Load Balancers → your ALB → Listeners → 443 → Rules.**

A proxy host's traffic is **not** under `/api/`. It is at the root. So it falls
to the default action, reaches nginx, and nginx serves the console's
`index.html` — the SPA then reports "page not found". Precisely the symptom.

### If the ALB routes to pam-api (expected here)

Add a listener rule on **443**, at a **priority above the default**:

- **Condition:** Host header **is** `*.iam-opa.adapid.link`
- **Action:** Forward to the **pam-api** target group

Order matters: put it above any rule that would otherwise swallow it. The
existing `/api/*` rule can stay where it is — a proxy host never uses that
prefix, and this rule is scoped by host, so the two do not overlap.

Also check the target group's health check still points at a path pam-api
answers on the apex host; adding a rule does not change that, but a
misconfigured check will drain the group and make this look like a routing bug.

### If nginx fronts pam-api instead

Then the equivalent fix belongs in nginx: use
[`nginx/pam-webproxy.conf`](nginx/pam-webproxy.conf) in this directory. It
matches the wildcard host, sends every path to pam-api, and — the load-bearing
part — passes `Host` through unmodified.

Either way, two details are easy to miss and both cause real failures:

- **`Host` must survive the hop.** PAM resolves the session from it. Rewrite or
  drop it and every proxied request 404s no matter how correct DNS and TLS are.
- **WebSocket upgrades must be allowed.** The MinIO console uses them, and so
  does PAM's own in-browser terminal. ALBs handle this natively; nginx needs
  `proxy_http_version 1.1` plus the `Upgrade`/`Connection` headers.

---

## Verifying

Run these from anywhere, in order. Each one isolates a single layer, so the
first that fails tells you which fix has not landed.

```sh
# 1. DNS resolves (this is NXDOMAIN today)
nslookup probe-abc123.iam-opa.adapid.link

# 2. The cert now covers the wildcard — expect BOTH names in the SAN list
echo | openssl s_client -connect iam-opa.adapid.link:443 \
    -servername probe-abc123.iam-opa.adapid.link 2>/dev/null \
  | openssl x509 -noout -ext subjectAltName

# 3. Routing reaches pam-api rather than the console.
#    A slug with no live session is SUPPOSED to be refused by PAM — what
#    matters is WHO refuses it. JSON from pam-api means the route works;
#    text/html means you are still being handed the console's SPA.
curl -sS -o /dev/null -w '%{http_code} %{content_type}\n' \
    https://probe-abc123.iam-opa.adapid.link/
```

Then launch a MinIO session from the console for the real end-to-end check.

## If it still fails after all three

- **Blank page, console errors about blocked scripts** — the app loaded and the
  routing is fine; this is CSP. PAM rewrites nonces for proxied pages
  (`internal/webproxy/csp.go`). Capture the browser console output.
- **413 on an upload** — `webproxy.max_request_body_bytes` defaults to 32 MB.
  Raise it with `PAM_WEBPROXY_MAX_REQUEST_BODY_BYTES`, and if nginx is in the
  path, set `client_max_body_size` to match.
- **Session dies after ~60s idle** — an idle-timeout ceiling in the proxy layer,
  not PAM. ALB: raise the idle timeout. nginx: `proxy_read_timeout`.
- **Redirect loop, or redirects leaving the proxy host** — the target app is
  sending absolute URLs PAM did not rewrite. Check the resource's
  `console_url`: it must be the app's real origin, and it is the only source
  PAM uses for the upstream (there is deliberately no `host:port` fallback).
