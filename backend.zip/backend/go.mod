module github.com/yourorg/pam

go 1.24

// NOTE ON THE replace DIRECTIVES BELOW:
//
// This module was assembled and built in a network-restricted sandbox that
// blocks proxy.golang.org and several "vanity" module domains (gorm.io,
// go.uber.org, golang.org, gopkg.in) at the DNS/HTTP level, while allowing
// direct access to github.com. Each replace below points a vanity-domain
// module path at its real GitHub source, with GOPROXY=direct and
// GOSUMDB=off, so `go build ./...` / `go vet ./...` / `go test ./...` could
// actually be run end-to-end during this merge (all three pass clean).
//
// These replaces are safe to keep on a normal machine with full internet
// access too — Go's module system explicitly supports substituting a
// different source location for a required module regardless of that
// module's own internal path declaration. They are NOT required there,
// though: if you have unrestricted access to proxy.golang.org, you can
// delete every `replace` line below and run `go mod tidy` to resolve
// everything through the normal module proxy instead. Left in place by
// default so `go build` works out of the box in either environment.

require (
	github.com/boombuler/barcode v1.0.2
	github.com/gin-gonic/gin v1.10.0
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/google/uuid v1.6.0
	github.com/joho/godotenv v1.5.1
	github.com/jung-kurt/gofpdf v1.16.2
	github.com/pquerna/otp v1.4.0
	github.com/spf13/viper v1.19.0
	go.uber.org/zap v1.27.0
	golang.org/x/crypto v0.31.0
	gorm.io/driver/postgres v1.5.9
	gorm.io/gorm v1.25.12
)

require (
	github.com/bytedance/sonic v1.11.6 // indirect
	github.com/bytedance/sonic/loader v0.1.1 // indirect
	github.com/cloudwego/base64x v0.1.4 // indirect
	github.com/cloudwego/iasm v0.2.0 // indirect
	github.com/fsnotify/fsnotify v1.7.0 // indirect
	github.com/gabriel-vasile/mimetype v1.4.3 // indirect
	github.com/gin-contrib/sse v0.1.0 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/go-playground/validator/v10 v10.20.0 // indirect
	github.com/goccy/go-json v0.10.2 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20221227161230-091c0ba34f0a // indirect
	github.com/jackc/pgx/v5 v5.5.5 // indirect
	github.com/jackc/puddle/v2 v2.2.1 // indirect
	github.com/jinzhu/inflection v1.0.0 // indirect
	github.com/jinzhu/now v1.1.5 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/klauspost/cpuid/v2 v2.2.7 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	github.com/magiconair/properties v1.8.7 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/niemeyer/pretty v0.0.0-20200227124842-a10e7caefd8e // indirect
	github.com/pelletier/go-toml/v2 v2.2.2 // indirect
	github.com/sagikazarmark/locafero v0.4.0 // indirect
	github.com/sagikazarmark/slog-shim v0.1.0 // indirect
	github.com/sourcegraph/conc v0.3.0 // indirect
	github.com/spf13/afero v1.11.0 // indirect
	github.com/spf13/cast v1.6.0 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/ugorji/go/codec v1.2.12 // indirect
	go.uber.org/multierr v1.10.0 // indirect
	golang.org/x/arch v0.8.0 // indirect
	golang.org/x/exp v0.0.0-20230905200255-921286631fa9 // indirect
	golang.org/x/net v0.25.0 // indirect
	golang.org/x/sync v0.9.0 // indirect
	golang.org/x/sys v0.28.0 // indirect
	golang.org/x/text v0.21.0 // indirect
	google.golang.org/protobuf v1.34.1 // indirect
	gopkg.in/ini.v1 v1.67.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace golang.org/x/image => github.com/golang/image v0.18.0

replace golang.org/x/text => github.com/golang/text v0.16.0

replace golang.org/x/net => github.com/golang/net v0.30.0

replace golang.org/x/sys => github.com/golang/sys v0.26.0

replace golang.org/x/sync => github.com/golang/sync v0.9.0

replace golang.org/x/tools => github.com/golang/tools v0.1.12

replace golang.org/x/mod => github.com/golang/mod v0.21.0

replace golang.org/x/term => github.com/golang/term v0.25.0

replace go.uber.org/zap => github.com/uber-go/zap v1.27.0

replace go.uber.org/multierr => github.com/uber-go/multierr v1.11.0

replace gorm.io/gorm => github.com/go-gorm/gorm v1.25.12

replace gorm.io/driver/postgres => github.com/go-gorm/postgres v1.5.9

replace golang.org/x/crypto => github.com/golang/crypto v0.31.0

replace golang.org/x/telemetry => github.com/golang/telemetry v0.0.0-20241106142447-58a1122356f6

replace golang.org/x/exp => github.com/golang/exp v0.0.0-20241108190413-2d47ceb2692f

replace gopkg.in/yaml.v3 => github.com/go-yaml/yaml v3.0.1+incompatible

replace gopkg.in/yaml.v2 => github.com/go-yaml/yaml v2.4.0+incompatible

replace gopkg.in/check.v1 => github.com/go-check/check v0.0.0-20200902074654-038fdea0a05b

replace google.golang.org/protobuf => github.com/protocolbuffers/protobuf-go v1.35.2

replace gopkg.in/ini.v1 => github.com/go-ini/ini v1.67.0
