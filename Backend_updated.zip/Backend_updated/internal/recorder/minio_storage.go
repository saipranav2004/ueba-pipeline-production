// pam/internal/recorder/minio_storage.go
package recorder

import (
	"bytes"
	"context"
	"fmt"
	"io"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"

	"github.com/yourorg/pam/pkg/crypto"
)

// MinIOStorage persists recordings in an S3-compatible object store (MinIO
// or real AWS S3) via the minio-go SDK, which signs every request with
// SigV4 — see internal/services/backup_service.go's uploadToS3/downloadFromS3
// for what this repo's other S3 client looks like WITHOUT that: a raw,
// unsigned http.Client PUT/GET that only works against a bucket with
// anonymous public access. Recordings are session transcripts of
// privileged access; they don't get that shortcut.
//
// Same at-rest encryption posture as LocalStorage: encryptionKeyB64 reuses
// PAM_VAULT_ENCRYPTION_KEY (see LocalStorage's doc comment for why one key,
// not a second one to provision/rotate) — pass "" to store plaintext gzip
// objects instead, e.g. for a local dev MinIO with no key configured yet.
type MinIOStorage struct {
	client           *minio.Client
	bucket           string
	encryptionKeyB64 string
}

// NewMinIOStorage connects to endpoint (host:port, no scheme — scheme comes
// from useSSL) and ensures bucket exists, creating it if this credential has
// permission to. Fails fast at startup rather than at the first recording
// write, matching NewLocalStorage.
func NewMinIOStorage(ctx context.Context, endpoint, accessKey, secretKey, region, bucket string, useSSL bool, encryptionKeyB64 string) (*MinIOStorage, error) {
	if endpoint == "" {
		return nil, fmt.Errorf("recording storage endpoint must not be empty")
	}
	if bucket == "" {
		return nil, fmt.Errorf("recording storage bucket must not be empty")
	}

	client, err := minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(accessKey, secretKey, ""),
		Secure: useSSL,
		Region: region,
	})
	if err != nil {
		return nil, fmt.Errorf("create minio client for %q: %w", endpoint, err)
	}

	exists, err := client.BucketExists(ctx, bucket)
	if err != nil {
		return nil, fmt.Errorf("check bucket %q exists on %q: %w", bucket, endpoint, err)
	}
	if !exists {
		if err := client.MakeBucket(ctx, bucket, minio.MakeBucketOptions{Region: region}); err != nil {
			return nil, fmt.Errorf("create bucket %q on %q: %w", bucket, endpoint, err)
		}
	}

	return &MinIOStorage{client: client, bucket: bucket, encryptionKeyB64: encryptionKeyB64}, nil
}

func (m *MinIOStorage) Label() string { return "minio" }

func (m *MinIOStorage) Save(ctx context.Context, key string, data []byte) error {
	toWrite := data
	if m.encryptionKeyB64 != "" {
		sealed, err := crypto.EncryptBytes(data, m.encryptionKeyB64)
		if err != nil {
			return fmt.Errorf("encrypt recording: %w", err)
		}
		toWrite = sealed
	}
	_, err := m.client.PutObject(ctx, m.bucket, key, bytes.NewReader(toWrite), int64(len(toWrite)), minio.PutObjectOptions{
		ContentType: "application/gzip",
	})
	if err != nil {
		return fmt.Errorf("put object %q in bucket %q: %w", key, m.bucket, err)
	}
	return nil
}

func (m *MinIOStorage) Load(ctx context.Context, key string) ([]byte, error) {
	obj, err := m.client.GetObject(ctx, m.bucket, key, minio.GetObjectOptions{})
	if err != nil {
		return nil, fmt.Errorf("get object %q from bucket %q: %w", key, m.bucket, err)
	}
	defer obj.Close()

	data, err := io.ReadAll(obj)
	if err != nil {
		return nil, fmt.Errorf("read object %q from bucket %q: %w", key, m.bucket, err)
	}

	if m.encryptionKeyB64 != "" {
		plain, err := crypto.DecryptBytes(data, m.encryptionKeyB64)
		if err != nil {
			return nil, fmt.Errorf("decrypt recording: %w", err)
		}
		return plain, nil
	}
	return data, nil
}
