// pam/internal/webproxy/target_base_url_test.go
//
// Regression coverage for two related bugs caught in live testing:
//
//  1. targetBaseURL used to fall back to http://<host>:<port> when
//     console_url was empty. For a postgresql/mongodb/redis/ssh/clickhouse
//     resource, that port speaks a binary wire protocol, not HTTP — PAM
//     would silently attempt to proxy HTTP to a database port and fail with
//     an opaque "application unreachable" error. console_url is now the only
//     source; its absence is a clear, immediate ErrResourceNotWebApp instead.
//
//  2. Resolve() (called on every proxied request, not just session start)
//     had its OWN separate, un-fixed copy of that same host:port fallback —
//     fixing StartSession's copy alone left a live request path still able
//     to silently target a database port. targetBaseURL now takes a plain
//     string so both call sites — StartSession's *services.ConnectionInfo
//     and Resolve's *models.PAMResource — share the exact same function
//     instead of each carrying their own copy of the logic.
package webproxy

import (
	"errors"
	"testing"
)

func TestTargetBaseURLRequiresConsoleURL(t *testing.T) {
	// Empty console_url is the exact shape a real postgresql resource has
	// (a real host/port for the wire-protocol endpoint, no web console).
	if _, err := targetBaseURL(""); !errors.Is(err, ErrResourceNotWebApp) {
		t.Fatalf("expected ErrResourceNotWebApp for an empty console_url, got %v", err)
	}
	if _, err := targetBaseURL("   "); !errors.Is(err, ErrResourceNotWebApp) {
		t.Fatalf("expected ErrResourceNotWebApp for a whitespace-only console_url, got %v", err)
	}
}

func TestTargetBaseURLUsesConsoleURLWhenSet(t *testing.T) {
	got, err := targetBaseURL("http://13.206.221.6:9001/")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if got != "http://13.206.221.6:9001" {
		t.Fatalf("targetBaseURL = %q, want the console_url with trailing slash trimmed", got)
	}
}

func TestTargetBaseURLRejectsMalformedConsoleURL(t *testing.T) {
	if _, err := targetBaseURL("not-a-url"); !errors.Is(err, ErrResourceNotWebApp) {
		t.Fatalf("expected ErrResourceNotWebApp for a malformed console_url, got %v", err)
	}
	if _, err := targetBaseURL("psql-database-1.example.rds.amazonaws.com:5432"); !errors.Is(err, ErrResourceNotWebApp) {
		t.Fatal("expected ErrResourceNotWebApp for a bare host:port with no scheme (not an absolute URL)")
	}
}
