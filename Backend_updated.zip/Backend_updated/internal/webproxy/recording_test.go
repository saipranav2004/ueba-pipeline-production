// pam/internal/webproxy/recording_test.go
//
// Coverage for the property that makes web-session recording actually
// useful: it is NOT a parallel recording system. A brokered web session's
// recording is an asciicast in the SAME object store, attached to the SAME
// pam_session_recordings row, with its command log in the SAME
// pam_session_recording_commands table as a CLI/native-agent session — which
// is precisely what lets GET /admin/recordings list it and the existing
// player replay it with no branch on session type anywhere.
//
// The tests below assert that end to end against an in-memory object store,
// including that the produced bytes are a real, parseable asciicast v2
// stream rather than merely "something we saved."
package webproxy

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/recorder"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
)

// memStorage is an in-memory recorder.Storage — the same interface
// MinIOStorage and LocalStorage implement, so a test exercises the real
// finalize→Save→AttachRecordingArtifact path without needing a live bucket.
type memStorage struct {
	mu      sync.Mutex
	objects map[string][]byte
}

func newMemStorage() *memStorage { return &memStorage{objects: map[string][]byte{}} }

func (m *memStorage) Label() string { return "memory" }

func (m *memStorage) Save(_ context.Context, key string, data []byte) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.objects[key] = append([]byte(nil), data...)
	return nil
}

func (m *memStorage) Load(_ context.Context, key string) ([]byte, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	b, ok := m.objects[key]
	if !ok {
		return nil, io.ErrUnexpectedEOF
	}
	return b, nil
}

// seedRecordedSession creates a ConnectionSession + SessionRecording +
// WebProxySession wired together exactly the way StartSession does, and
// registers a live cast for it — the state a session is in mid-flight.
func seedRecordedSession(t *testing.T, svc *Service) (*models.WebProxySession, string) {
	t.Helper()
	now := time.Now().UTC()

	conn := &models.ConnectionSession{
		UserID: "alice", Username: "alice", ResourceID: "res-1",
		ResourceName: "Prod MinIO", ResourceType: "minio",
		Status: "ACTIVE", RecordingRequired: true, StartedAt: now,
	}
	if err := svc.db.Create(conn).Error; err != nil {
		t.Fatalf("seed connection session: %v", err)
	}
	rec := &models.SessionRecording{
		SessionID: conn.ID, UserID: "alice", Username: "alice",
		ResourceID: "res-1", ResourceName: "Prod MinIO",
		Format: "asciicast", Status: models.RecordingStatusRecording, StartedAt: now,
	}
	if err := svc.db.Create(rec).Error; err != nil {
		t.Fatalf("seed recording: %v", err)
	}
	row := &models.WebProxySession{
		ConnectionSessionID: conn.ID, ResourceID: "res-1",
		UserID: "alice", Username: "alice", Subdomain: "minio-abc12345",
		TokenHash: hashToken("tok"), Status: models.WebProxySessionActive,
		RecordingID: &rec.ID, LastActivityAt: now, ExpiresAt: now.Add(time.Hour),
	}
	if err := svc.db.Create(row).Error; err != nil {
		t.Fatalf("seed web proxy session: %v", err)
	}

	// Register the live cast exactly as StartSession does when a recording
	// obligation exists.
	svc.castMu.Lock()
	svc.casts[row.ID] = recorder.NewCast(120, 40, "test web session", svc.maxCastBytes)
	svc.castMu.Unlock()

	return row, rec.ID
}

// ── The core property: recording lands in the shared pipeline ─────────────

func TestBrokeredSessionRecordingLandsInSharedPipelineAsValidAsciicast(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	now := time.Now().UTC()
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/browser/pam-agent", StatusCode: 200,
		ResponseBodyBytes: 1432, DurationMs: 45, OccurredAt: now, IsDocument: true,
	})
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodDelete, Path: "/api/v1/buckets/pam-agent/objects", StatusCode: 204,
		DurationMs: 88, OccurredAt: now, IsDocument: false,
	})

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "test teardown"); err != nil {
		t.Fatalf("End: %v", err)
	}

	// 1. The artifact is in the object store, under the SAME key layout the
	//    terminal gateway uses.
	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.objects) != 1 {
		t.Fatalf("expected exactly 1 stored recording artifact, got %d", len(store.objects))
	}
	var key string
	var blob []byte
	for k, v := range store.objects {
		key, blob = k, v
	}
	if !strings.HasPrefix(key, "recordings/") || !strings.HasSuffix(key, ".cast.gz") {
		t.Fatalf("storage key %q does not match the shared recordings/<date>/<id>.cast.gz layout", key)
	}
	if !strings.Contains(key, recordingID) {
		t.Fatalf("storage key %q should be named for the shared recording id %s", key, recordingID)
	}

	// 2. The SessionRecording row — the one GET /admin/recordings lists —
	//    was completed and points at that artifact.
	var stored models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&stored).Error; err != nil {
		t.Fatalf("reload recording: %v", err)
	}
	if stored.Status != models.RecordingStatusCompleted {
		t.Fatalf("recording status = %q, want COMPLETED", stored.Status)
	}
	if stored.StorageKey != key {
		t.Fatalf("recording.storage_key = %q, want %q", stored.StorageKey, key)
	}
	if stored.StorageBucket != "memory" {
		t.Fatalf("recording.storage_bucket = %q, want the storage backend's label", stored.StorageBucket)
	}
	if stored.SizeBytes <= 0 || stored.SHA256 == "" {
		t.Fatalf("recording is missing integrity metadata: size=%d sha256=%q", stored.SizeBytes, stored.SHA256)
	}

	// 3. The artifact is a REAL asciicast v2 stream — this is what makes the
	//    existing player able to replay it unmodified.
	gr, err := gzip.NewReader(bytes.NewReader(blob))
	if err != nil {
		t.Fatalf("stored artifact is not gzip (the shared cast endpoint gunzips it): %v", err)
	}
	defer gr.Close()
	raw, err := io.ReadAll(gr)
	if err != nil {
		t.Fatalf("read artifact: %v", err)
	}
	lines := strings.Split(strings.TrimRight(string(raw), "\n"), "\n")
	if len(lines) < 2 {
		t.Fatalf("expected a header line plus at least one event, got %d line(s)", len(lines))
	}
	var header struct {
		Version int    `json:"version"`
		Width   int    `json:"width"`
		Height  int    `json:"height"`
		Title   string `json:"title"`
	}
	if err := json.Unmarshal([]byte(lines[0]), &header); err != nil {
		t.Fatalf("first line is not a valid asciicast header: %v (%q)", err, lines[0])
	}
	if header.Version != 2 {
		t.Fatalf("asciicast version = %d, want 2", header.Version)
	}
	for i, line := range lines[1:] {
		var event []interface{}
		if err := json.Unmarshal([]byte(line), &event); err != nil {
			t.Fatalf("event line %d is not valid asciicast JSON: %v (%q)", i+1, err, line)
		}
		if len(event) != 3 {
			t.Fatalf("event line %d has %d fields, want [time, stream, data]", i+1, len(event))
		}
	}

	// 4. The rendered stream actually contains the requests, so a replay is
	//    meaningful rather than merely well-formed.
	body := string(raw)
	if !strings.Contains(body, "/browser/pam-agent") || !strings.Contains(body, "DELETE") {
		t.Fatalf("recording does not contain the proxied requests it should:\n%s", body)
	}
}

// ── Command log: same table the CLI player's command pane reads ───────────

func TestCommandLogRecordsOperatorActionsIntoSharedTable(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	svc.recordingStorage = newMemStorage()

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	now := time.Now().UTC()

	// A page navigation and a mutation — both operator-meaningful.
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/browser", StatusCode: 200, IsDocument: true, OccurredAt: now})
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodPost, Path: "/api/v1/buckets", StatusCode: 201, DurationMs: 30, OccurredAt: now})
	// Asset noise — must NOT reach the human-readable command log.
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/static/js/main.chunk.js", StatusCode: 200, OccurredAt: now})
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/api/v1/session", StatusCode: 200, OccurredAt: now})

	cmds, total, err := svc.resources.ListRecordingCommands(recordingID, 1, 100)
	if err != nil {
		t.Fatalf("ListRecordingCommands: %v", err)
	}
	if total != 2 {
		t.Fatalf("expected 2 command rows (1 navigation + 1 mutation), got %d: %+v", total, cmds)
	}
	if !strings.Contains(cmds[0].Input, "/browser") || !strings.Contains(cmds[1].Input, "/api/v1/buckets") {
		t.Fatalf("unexpected command inputs: %q, %q", cmds[0].Input, cmds[1].Input)
	}
	if cmds[0].Sequence != 1 || cmds[1].Sequence != 2 {
		t.Fatalf("command sequence should be 1,2 — got %d,%d", cmds[0].Sequence, cmds[1].Sequence)
	}
	if cmds[1].Outcome != string(models.AuditOutcomeSuccess) {
		t.Fatalf("a 201 should record SUCCESS, got %q", cmds[1].Outcome)
	}

	// Every request, including the asset noise, still lands in the full
	// forensic activity trail — nothing is lost, only summarized.
	_, activityTotal, err := svc.ListActivity(row.ID, 1, 100)
	if err != nil {
		t.Fatalf("ListActivity: %v", err)
	}
	if activityTotal != 4 {
		t.Fatalf("expected all 4 requests in the activity trail, got %d", activityTotal)
	}
}

func TestCommandLogMarksFailureForErrorStatus(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	svc.recordingStorage = newMemStorage()

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}

	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodDelete, Path: "/api/v1/buckets/locked", StatusCode: 403,
		DurationMs: 12, OccurredAt: time.Now().UTC()})

	cmds, _, err := svc.resources.ListRecordingCommands(recordingID, 1, 10)
	if err != nil {
		t.Fatalf("ListRecordingCommands: %v", err)
	}
	if len(cmds) != 1 {
		t.Fatalf("expected 1 command row, got %d", len(cmds))
	}
	if cmds[0].Outcome != string(models.AuditOutcomeFailure) {
		t.Fatalf("a 403 should record FAILURE, got %q", cmds[0].Outcome)
	}
}

// ── Not-recorded sessions stay clean ──────────────────────────────────────

func TestUnrecordedSessionProducesNoArtifactAndNoCommands(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	now := time.Now().UTC()
	row := &models.WebProxySession{
		ConnectionSessionID: "conn-nr", ResourceID: "res-1", UserID: "alice",
		Subdomain: "app-nr", TokenHash: hashToken("tok-nr"),
		Status: models.WebProxySessionActive, LastActivityAt: now, ExpiresAt: now.Add(time.Hour),
		// No RecordingID, and no cast registered — an unrecorded session.
	}
	if err := svc.db.Create(row).Error; err != nil {
		t.Fatalf("seed: %v", err)
	}
	rs := &ResolvedSession{Session: row, RecordingRequired: false}

	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodPost, Path: "/api/v1/buckets", StatusCode: 201, OccurredAt: now})

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "done"); err != nil {
		t.Fatalf("End: %v", err)
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.objects) != 0 {
		t.Fatalf("an unrecorded session must not write a recording artifact, got %d", len(store.objects))
	}
}

// ── Cast rendering helpers ────────────────────────────────────────────────

func TestRequestFrameRendersReadableLine(t *testing.T) {
	ts := time.Date(2026, 8, 18, 15, 4, 5, 0, time.UTC)
	frame := requestFrame(ActivityRecord{
		Method: http.MethodGet, Path: "/browser/pam-agent", StatusCode: 200,
		ResponseBodyBytes: 1432, DurationMs: 45,
	}, ts)

	for _, want := range []string{"15:04:05", "GET", "/browser/pam-agent", "200", "1.4 KB", "45ms"} {
		if !strings.Contains(frame, want) {
			t.Errorf("frame missing %q:\n%s", want, frame)
		}
	}
	if !strings.HasSuffix(frame, "\r\n") {
		t.Error("terminal frames must end CRLF so the player renders line breaks correctly")
	}
}

func TestHumanBytes(t *testing.T) {
	cases := []struct {
		in   int64
		want string
	}{
		{0, "-"}, {-1, "-"}, {512, "512 B"}, {1536, "1.5 KB"}, {5 * 1024 * 1024, "5.0 MB"},
	}
	for _, tc := range cases {
		if got := humanBytes(tc.in); got != tc.want {
			t.Errorf("humanBytes(%d) = %q, want %q", tc.in, got, tc.want)
		}
	}
}

func TestIsCommandWorthy(t *testing.T) {
	cases := []struct {
		name string
		rec  ActivityRecord
		want bool
	}{
		{"html navigation", ActivityRecord{Method: "GET", IsDocument: true}, true},
		{"mutation", ActivityRecord{Method: "POST"}, true},
		{"delete", ActivityRecord{Method: "DELETE"}, true},
		{"asset fetch", ActivityRecord{Method: "GET", IsDocument: false}, false},
		{"api poll", ActivityRecord{Method: "GET", IsDocument: false}, false},
		{"preflight", ActivityRecord{Method: "OPTIONS"}, false},
	}
	for _, tc := range cases {
		if got := isCommandWorthy(tc.rec); got != tc.want {
			t.Errorf("%s: isCommandWorthy = %v, want %v", tc.name, got, tc.want)
		}
	}
}

// ── Full stack: a genuinely proxied request reaches the stored artifact ───

// Every other test in this file feeds RecordActivity directly, which leaves
// one seam uncovered: whether handleProxy still calls it, and still reports
// the real status code and document-ness of the response it forwarded. That
// seam is where a recording silently becomes an empty one — the session
// works perfectly for the operator either way, so nothing else would notice.
// This drives a real request end to end: cookie resolution → upstream
// forward → capture → End → object store.
func TestProxiedRequestFlowsAllTheWayIntoTheStoredArtifact(t *testing.T) {
	gin.SetMode(gin.TestMode)

	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write([]byte("<html><body>bucket browser</body></html>"))
	}))
	defer upstream.Close()

	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)

	// Resolve() re-reads the resource for its console_url and active flag on
	// every single request, so the seeded resource has to genuinely exist and
	// point at the upstream — the same requirement a real deployment has.
	if err := svc.db.Create(&models.PAMResource{
		ID: row.ResourceID, Name: "Prod MinIO", ResourceType: "minio",
		Host: "127.0.0.1", Port: 9001, ConsoleURL: upstream.URL, IsActive: true,
	}).Error; err != nil {
		t.Fatalf("seed resource: %v", err)
	}
	stateEnc, err := crypto.Encrypt(`{}`, svc.cryptoKey)
	if err != nil {
		t.Fatalf("encrypt upstream state: %v", err)
	}
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("upstream_state_enc", stateEnc).Error; err != nil {
		t.Fatalf("seed upstream state: %v", err)
	}

	h := NewHandler(svc, zap.NewNop())
	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet,
		"http://minio-abc12345.pam.example.com/browser/pam-agent", nil)
	c.Request.AddCookie(&http.Cookie{Name: cookieName(false), Value: "tok"})

	h.handleProxy(c, row.Subdomain)

	if rec.Code != http.StatusOK {
		t.Fatalf("proxied request returned %d, want 200 — body: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), "bucket browser") {
		t.Fatalf("upstream body did not reach the client: %q", rec.Body.String())
	}

	if err := svc.End(row.ID, "alice", true, models.WebProxySessionEnded, "tab closed"); err != nil {
		t.Fatalf("End: %v", err)
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.objects) != 1 {
		t.Fatalf("expected 1 stored artifact, got %d", len(store.objects))
	}
	var blob []byte
	for _, v := range store.objects {
		blob = v
	}
	gr, err := gzip.NewReader(bytes.NewReader(blob))
	if err != nil {
		t.Fatalf("artifact is not gzip: %v", err)
	}
	defer gr.Close()
	raw, err := io.ReadAll(gr)
	if err != nil {
		t.Fatalf("read artifact: %v", err)
	}
	if !strings.Contains(string(raw), "/browser/pam-agent") {
		t.Fatalf("the request that was actually proxied is missing from the recording:\n%s", raw)
	}

	// An HTML document navigation is operator-meaningful, so it must also be
	// in the searchable command log the player's command pane reads.
	var cmds []models.SessionRecordingCommand
	if err := svc.db.Where("recording_id = ?", recordingID).Find(&cmds).Error; err != nil {
		t.Fatalf("load commands: %v", err)
	}
	if len(cmds) != 1 {
		t.Fatalf("expected 1 command row for the page navigation, got %d", len(cmds))
	}
	if !strings.Contains(cmds[0].Input, "/browser/pam-agent") {
		t.Fatalf("command row does not describe the navigation: %q", cmds[0].Input)
	}
}

// TestTabCloseReconcileStillFinalisesTheRecording covers the closure path an
// operator actually uses most: they close the browser tab and walk away. No
// explicit End call ever happens — the stale-heartbeat sweep is what ends the
// session, so it is also the only thing that can flush the cast to the object
// store. If it did not, every "just closed the tab" session would leave a
// RECORDING-status row with no artifact behind it, which is precisely the
// case an auditor is most likely to go looking for.
func TestTabCloseReconcileStillFinalisesTheRecording(t *testing.T) {
	svc := dbTestService(t, defaultTestConfig())
	store := newMemStorage()
	svc.recordingStorage = store

	row, recordingID := seedRecordedSession(t, svc)
	rs := &ResolvedSession{Session: row, RecordingRequired: true}
	svc.RecordActivity(rs, ActivityRecord{
		Method: http.MethodGet, Path: "/browser", StatusCode: 200,
		IsDocument: true, OccurredAt: time.Now().UTC(),
	})

	// The tab went away: the beacon stopped landing more than a grace period
	// ago, while the session is neither idle nor past its absolute expiry.
	stale := time.Now().UTC().Add(-(heartbeatGraceSeconds + 30) * time.Second)
	if err := svc.db.Model(&models.WebProxySession{}).Where("id = ?", row.ID).
		Update("last_heartbeat_at", stale).Error; err != nil {
		t.Fatalf("age the heartbeat: %v", err)
	}

	closed, err := svc.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 1 {
		t.Fatalf("expected the stale-heartbeat session to be closed, got %d", closed)
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.objects) != 1 {
		t.Fatalf("tab-close reconcile stored %d artifacts, want exactly 1", len(store.objects))
	}
	var stored models.SessionRecording
	if err := svc.db.Where("id = ?", recordingID).First(&stored).Error; err != nil {
		t.Fatalf("reload recording: %v", err)
	}
	if stored.Status != models.RecordingStatusCompleted || stored.StorageKey == "" {
		t.Fatalf("recording after tab-close reconcile: status=%q storage_key=%q, want COMPLETED with an artifact",
			stored.Status, stored.StorageKey)
	}
}
