// pam/internal/webproxy/authenticator_test.go
//
// The MinIO test server here is modelled on the REAL contract, verified live
// against MinIO Console RELEASE.2025-08-13 while building this feature:
//
//	POST /api/v1/login, Content-Type: application/json  → 204 + Set-Cookie: token=...
//	POST /api/v1/login, form-encoded                    → 415 (rejected)
//	OPTIONS /api/v1/login                               → 405 (no CORS preflight)
//
// Those last two are precisely why the login has to happen server-side and
// cannot be done from the operator's browser — the test server enforces them
// so that a future "simplification" back toward a browser-side login fails
// here instead of in production.
package webproxy

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func newMinIOTestServer(t *testing.T, wantAccessKey, wantSecretKey string) *httptest.Server {
	t.Helper()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/v1/login", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodOptions {
			w.Header().Set("Allow", "POST,GET")
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		if ct := r.Header.Get("Content-Type"); !strings.HasPrefix(ct, "application/json") {
			w.WriteHeader(http.StatusUnsupportedMediaType)
			_, _ = w.Write([]byte(`{"code":415,"message":"unsupported media type"}`))
			return
		}
		var body struct {
			AccessKey string `json:"accessKey"`
			SecretKey string `json:"secretKey"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		if body.AccessKey != wantAccessKey || body.SecretKey != wantSecretKey {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.SetCookie(w, &http.Cookie{
			Name: "token", Value: "MINIO-SESSION-TOKEN", Path: "/", HttpOnly: true,
		})
		w.WriteHeader(http.StatusNoContent)
	})
	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)
	return srv
}

func TestMinIOConsoleAuthenticatorCapturesSessionCookie(t *testing.T) {
	srv := newMinIOTestServer(t, "minioadmin", "DasAdmin@123")

	auth := &MinIOConsoleAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, Target{
		BaseURL:  srv.URL,
		Username: "minioadmin",
		Password: "DasAdmin@123",
	})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if state.Cookies["token"] != "MINIO-SESSION-TOKEN" {
		t.Fatalf("session cookie not captured, got %#v", state.Cookies)
	}
}

func TestMinIOConsoleAuthenticatorFailsLoudlyOnBadCredential(t *testing.T) {
	srv := newMinIOTestServer(t, "minioadmin", "correct-secret")

	auth := &MinIOConsoleAuthenticator{}
	_, err := auth.Login(context.Background(), &http.Client{}, Target{
		BaseURL:  srv.URL,
		Username: "minioadmin",
		Password: "WRONG-secret",
	})
	if err == nil {
		t.Fatal("expected an error for a rejected credential — silently proxying an unauthenticated " +
			"session would dump the operator on the target's own login page, which is the exact " +
			"credential-exposing flow this feature removes")
	}
}

func TestJSONPostAuthenticatorHonoursExtraConfigFieldNames(t *testing.T) {
	var gotPath string
	var gotBody map[string]interface{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotPath = r.URL.Path
		_ = json.NewDecoder(r.Body).Decode(&gotBody)
		http.SetCookie(w, &http.Cookie{Name: "JSESSIONID", Value: "abc", Path: "/"})
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	auth := &JSONPostAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, Target{
		BaseURL:  srv.URL,
		Username: "svc-admin",
		Password: "s3cret",
		ExtraConfig: map[string]interface{}{
			"web_login_path":         "/auth/signin",
			"web_username_field":     "user",
			"web_password_field":     "pass",
			"web_extra_login_fields": map[string]interface{}{"realm": "internal"},
		},
	})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if gotPath != "/auth/signin" {
		t.Fatalf("login path = %q, want the configured /auth/signin", gotPath)
	}
	if gotBody["user"] != "svc-admin" || gotBody["pass"] != "s3cret" || gotBody["realm"] != "internal" {
		t.Fatalf("login body did not honour extra_config field names: %#v", gotBody)
	}
	if state.Cookies["JSESSIONID"] != "abc" {
		t.Fatalf("session cookie not captured, got %#v", state.Cookies)
	}
}

func TestFormPostAuthenticatorSendsFormEncodedBody(t *testing.T) {
	var gotContentType, gotUser string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotContentType = r.Header.Get("Content-Type")
		_ = r.ParseForm()
		gotUser = r.PostForm.Get("username")
		http.SetCookie(w, &http.Cookie{Name: "session", Value: "xyz", Path: "/"})
		w.WriteHeader(http.StatusFound)
	}))
	defer srv.Close()

	auth := &FormPostAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, Target{
		BaseURL: srv.URL, Username: "admin", Password: "pw",
	})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if !strings.HasPrefix(gotContentType, "application/x-www-form-urlencoded") {
		t.Fatalf("Content-Type = %q, want form-encoded", gotContentType)
	}
	if gotUser != "admin" {
		t.Fatalf("username field = %q", gotUser)
	}
	if state.Cookies["session"] != "xyz" {
		t.Fatalf("session cookie not captured, got %#v", state.Cookies)
	}
}

// TestLoginTreatsNoCookieAsFailure covers the subtle case: a target that
// answers 200 to anything (a login page re-render on bad credentials, say)
// must not be mistaken for a successful login.
func TestLoginTreatsNoCookieAsFailure(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("<html><body>Invalid username or password</body></html>"))
	}))
	defer srv.Close()

	auth := &FormPostAuthenticator{}
	if _, err := auth.Login(context.Background(), &http.Client{}, Target{
		BaseURL: srv.URL, Username: "admin", Password: "wrong",
	}); err == nil {
		t.Fatal("a 200 response that sets no session cookie is not a successful login")
	}
}

func TestBasicAuthAuthenticatorInjectsHeaderWithoutLoginRoundTrip(t *testing.T) {
	auth := &BasicAuthAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, Target{
		Username: "admin", Password: "pw",
	})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	// base64("admin:pw")
	if got := state.Headers["Authorization"]; got != "Basic YWRtaW46cHc=" {
		t.Fatalf("Authorization = %q", got)
	}
}

func TestBearerTokenAuthenticatorHonoursCustomHeader(t *testing.T) {
	auth := &BearerTokenAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, Target{
		Password: "api-key-value",
		ExtraConfig: map[string]interface{}{
			"web_auth_header":        "X-API-Key",
			"web_auth_header_prefix": "",
		},
	})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if got := state.Headers["X-API-Key"]; got != "api-key-value" {
		t.Fatalf("X-API-Key = %q", got)
	}
	if _, hasAuthz := state.Headers["Authorization"]; hasAuthz {
		t.Fatal("a custom auth header must not also set Authorization")
	}
}

// ── Registry resolution ───────────────────────────────────────────────────

func TestRegistryInfersMinIOAndDefaultsToNone(t *testing.T) {
	r := NewRegistry()

	a, err := r.Get("minio", nil)
	if err != nil || a.Name() != strategyMinIOConsole {
		t.Fatalf("minio should infer the console strategy, got %v (%v)", a, err)
	}

	a, err = r.Get("some-unknown-app", nil)
	if err != nil || a.Name() != strategyNone {
		t.Fatalf("an unknown type should fall back to no-auth brokering, got %v (%v)", a, err)
	}
}

func TestRegistryExplicitStrategyWinsAndUnknownIsAnError(t *testing.T) {
	r := NewRegistry()

	a, err := r.Get("minio", map[string]interface{}{"web_auth_strategy": "basic_auth"})
	if err != nil || a.Name() != strategyBasicAuth {
		t.Fatalf("explicit strategy should win over inference, got %v (%v)", a, err)
	}

	// A typo in a security-relevant setting must fail loudly rather than
	// silently degrading to "no authentication".
	if _, err := r.Get("minio", map[string]interface{}{"web_auth_strategy": "bassic_auth"}); err == nil {
		t.Fatal("an unknown web_auth_strategy must be an error, not a silent fallback")
	}
}
