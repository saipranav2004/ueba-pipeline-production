// pam/internal/webproxy/proxy_test.go
//
// The two invariants tested here are the entire security case for this
// feature, so they are tested directly against a real httptest upstream and
// a real httputil.ReverseProxy rather than by inspection:
//
//	1. The TARGET's session cookie never reaches the browser.
//	2. PAM's own proxy cookie never reaches the target.
//
// If either regresses, this feature silently degrades from "brokered
// privileged access" to "a convenient way to hand out a live credential" —
// which is exactly the failure mode it exists to prevent, and exactly the
// kind of regression that is invisible in manual testing (the app still
// works perfectly either way).
package webproxy

import (
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/config"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/recorder"
	"go.uber.org/zap"
)

func testService(cfg config.WebProxyConfig) *Service {
	return &Service{
		cfg:         cfg,
		logger:      zap.NewNop(),
		registry:    NewRegistry(),
		client:      &http.Client{},
		activitySeq: map[string]int{},
		cmdSeq:      map[string]int{},
		casts:       map[string]*recorder.Cast{},
	}
}

func defaultTestConfig() config.WebProxyConfig {
	return config.WebProxyConfig{
		Enabled:             true,
		BaseDomain:          "pam.example.com",
		Scheme:              "http",
		SessionTTLMin:       240,
		IdleTimeoutMin:      30,
		HandoffTTLSec:       30,
		MaxRequestBodyBytes: 32 * 1024 * 1024,
	}
}

// ── Invariant 1: the target's session never reaches the browser ───────────

func TestProxyStripsUpstreamSetCookieAndCapturesItServerSide(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// A target rotating its session mid-flight — the realistic case,
		// not just the initial login.
		http.SetCookie(w, &http.Cookie{Name: "token", Value: "UPSTREAM-SECRET-SESSION", Path: "/"})
		w.WriteHeader(http.StatusOK)
		_, _ = io.WriteString(w, "ok")
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{Cookies: map[string]string{}},
		Target:   targetURL,
	}

	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	// persistUpstream is exercised via the real ModifyResponse path; with no
	// DB wired in this test the persist call fails and is logged, which is
	// deliberately non-fatal (see the ModifyResponse comment).
	proxy := h.buildReverseProxy(rs)

	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/dashboard", nil)
	rec := httptest.NewRecorder()
	proxy.ServeHTTP(rec, req)

	if got := rec.Result().Header.Get("Set-Cookie"); got != "" {
		t.Fatalf("upstream Set-Cookie leaked to the browser: %q — the target's session must never leave the server", got)
	}
	if body := rec.Body.String(); strings.Contains(body, "UPSTREAM-SECRET-SESSION") {
		t.Fatal("upstream session value appeared in the response body")
	}
	if rs.Upstream.Cookies["token"] != "UPSTREAM-SECRET-SESSION" {
		t.Fatalf("upstream cookie was not captured into the server-side jar, got %#v", rs.Upstream.Cookies)
	}
}

// ── Invariant 2: PAM's own session never reaches the target ───────────────

func TestProxyDoesNotForwardPAMCookieUpstreamButDoesForwardOthers(t *testing.T) {
	var seenCookies string
	var seenAuth string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seenCookies = r.Header.Get("Cookie")
		seenAuth = r.Header.Get("Authorization")
		w.WriteHeader(http.StatusOK)
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session: &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{
			Cookies: map[string]string{"token": "UPSTREAM-SESSION"},
			Headers: map[string]string{"Authorization": "Basic aW5qZWN0ZWQ="},
		},
		Target: targetURL,
	}

	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	proxy := h.buildReverseProxy(rs)

	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/api/data", nil)
	// Both cookie-name forms the proxy may have issued, plus an unrelated
	// app cookie that legitimately belongs upstream.
	req.AddCookie(&http.Cookie{Name: proxyCookieName, Value: "PAM-PROXY-TOKEN"})
	req.AddCookie(&http.Cookie{Name: "__Host-" + proxyCookieName, Value: "PAM-PROXY-TOKEN-SECURE"})
	req.AddCookie(&http.Cookie{Name: "app_ui_theme", Value: "dark"})

	proxy.ServeHTTP(httptest.NewRecorder(), req)

	if strings.Contains(seenCookies, "PAM-PROXY-TOKEN") {
		t.Fatalf("PAM proxy cookie leaked to the target: %q — a malicious target could replay it against PAM", seenCookies)
	}
	if !strings.Contains(seenCookies, "token=UPSTREAM-SESSION") {
		t.Fatalf("upstream jar cookie was not injected, got %q", seenCookies)
	}
	if !strings.Contains(seenCookies, "app_ui_theme=dark") {
		t.Fatalf("unrelated browser cookie should still reach the app, got %q", seenCookies)
	}
	if seenAuth != "Basic aW5qZWN0ZWQ=" {
		t.Fatalf("injected auth header missing, got %q", seenAuth)
	}
}

// TestProxyOverwritesClientSuppliedForwardingHeaders guards against an
// operator forging the source IP that lands in the TARGET's own audit log by
// sending their own X-Forwarded-For.
func TestProxyOverwritesClientSuppliedForwardingHeaders(t *testing.T) {
	var seenHost, seenProto string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seenHost = r.Header.Get("X-Forwarded-Host")
		seenProto = r.Header.Get("X-Forwarded-Proto")
		w.WriteHeader(http.StatusOK)
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}

	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/", nil)
	req.Header.Set("X-Forwarded-Host", "evil.example.com")
	req.Header.Set("X-Forwarded-Proto", "gopher")
	h.buildReverseProxy(rs).ServeHTTP(httptest.NewRecorder(), req)

	if seenHost != "app-abc12345.pam.example.com" {
		t.Fatalf("X-Forwarded-Host = %q, want the proxy host (client value must not survive)", seenHost)
	}
	if seenProto != "http" {
		t.Fatalf("X-Forwarded-Proto = %q, want the configured scheme", seenProto)
	}
}

// TestProxyClearsUpstreamCookieOnUpstreamDeletion covers a subtle
// correctness bug: when the target explicitly retires a cookie, continuing
// to replay the old value would leave the brokered session authenticating
// with a credential the target has already invalidated.
func TestProxyClearsUpstreamCookieOnUpstreamDeletion(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.SetCookie(w, &http.Cookie{Name: "token", Value: "", MaxAge: -1, Path: "/"})
		w.WriteHeader(http.StatusOK)
	}))
	defer upstream.Close()

	targetURL, _ := url.Parse(upstream.URL)
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{Cookies: map[string]string{"token": "STALE"}},
		Target:   targetURL,
	}

	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://app-abc12345.pam.example.com/logout", nil)
	h.buildReverseProxy(rs).ServeHTTP(httptest.NewRecorder(), req)

	if _, still := rs.Upstream.Cookies["token"]; still {
		t.Fatal("cookie the target explicitly deleted is still in the jar and would keep being replayed")
	}
}

// ── Redirect rewriting ────────────────────────────────────────────────────

func TestRewriteRedirectMapsTargetOriginOntoProxyOrigin(t *testing.T) {
	target, _ := url.Parse("http://10.0.0.5:9001")

	cases := []struct {
		name string
		in   string
		want string
	}{
		{"absolute target URL is rewritten", "http://10.0.0.5:9001/browser/main", "https://app-1.pam.example.com/browser/main"},
		{"relative stays untouched", "/browser/main", "/browser/main"},
		{"third-party origin stays untouched", "https://accounts.google.com/o/oauth2", "https://accounts.google.com/o/oauth2"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resp := &http.Response{Header: http.Header{}}
			resp.Header.Set("Location", tc.in)
			rewriteRedirect(resp, target, "https", "app-1.pam.example.com")
			if got := resp.Header.Get("Location"); got != tc.want {
				t.Fatalf("Location = %q, want %q", got, tc.want)
			}
		})
	}
}

// ── Host routing ──────────────────────────────────────────────────────────

func TestIsProxyHost(t *testing.T) {
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())

	cases := []struct {
		host    string
		wantSub string
		wantOK  bool
	}{
		{"minio-abc12345.pam.example.com", "minio-abc12345", true},
		{"minio-abc12345.pam.example.com:8080", "minio-abc12345", true},
		{"MinIO-ABC12345.PAM.EXAMPLE.COM", "minio-abc12345", true},
		// The bare base domain is PAM's own surface, not an app.
		{"pam.example.com", "", false},
		// A different domain entirely (the API's own host).
		{"api.internal.example.com", "", false},
		// Deeper nesting: a wildcard cert covers one level only, and
		// accepting this would let a crafted host slip past the
		// single-label subdomain lookup.
		{"evil.minio-abc12345.pam.example.com", "", false},
		// Suffix-collision attempt: "notpam.example.com" must not match
		// the ".pam.example.com" suffix test.
		{"minio.notpam.example.com", "", false},
	}
	for _, tc := range cases {
		t.Run(tc.host, func(t *testing.T) {
			sub, ok := h.IsProxyHost(tc.host)
			if ok != tc.wantOK || sub != tc.wantSub {
				t.Fatalf("IsProxyHost(%q) = (%q, %v), want (%q, %v)", tc.host, sub, ok, tc.wantSub, tc.wantOK)
			}
		})
	}
}

func TestIsProxyHostAlwaysFalseWhenDisabled(t *testing.T) {
	cfg := defaultTestConfig()
	cfg.Enabled = false
	h := NewHandler(testService(cfg), zap.NewNop())
	if _, ok := h.IsProxyHost("minio-abc12345.pam.example.com"); ok {
		t.Fatal("a disabled gateway must never claim a host — it would shadow the API's own 404 handling")
	}
}

// ── Unauthenticated access ────────────────────────────────────────────────

// TestProxyRejectsRequestWithoutSessionCookie is the "someone found the URL"
// case: proxy subdomains are guessable by design (they are derived from the
// resource name), so an unauthenticated hit must never reach the target.
func TestProxyRejectsRequestWithoutSessionCookie(t *testing.T) {
	gin.SetMode(gin.TestMode)
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet, "http://minio-abc12345.pam.example.com/", nil)

	h.ServeHTTP(c)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401 for a request with no brokered session", rec.Code)
	}
}

// ── Cookie hardening ──────────────────────────────────────────────────────

func TestCookieNameUsesHostPrefixOnlyWhenSecure(t *testing.T) {
	if got := cookieName(true); got != "__Host-"+proxyCookieName {
		t.Fatalf("secure cookie name = %q, want the __Host- prefix (browser-enforced origin pinning)", got)
	}
	if got := cookieName(false); got != proxyCookieName {
		t.Fatalf("insecure cookie name = %q — __Host- requires Secure and would be rejected outright over http", got)
	}
}

// ── Subdomain derivation ──────────────────────────────────────────────────

func TestSubdomainIsDeterministicDNSSafeAndCollisionResistant(t *testing.T) {
	a := Subdomain("Prod MinIO", "11111111-1111-1111-1111-111111111111")
	again := Subdomain("Prod MinIO", "11111111-1111-1111-1111-111111111111")
	if a != again {
		t.Fatalf("not deterministic: %q vs %q — a resource's URL must be stable across launches", a, again)
	}

	// Same display name, different resource: must not collide, or one
	// resource's brokered session would be reachable at the other's host.
	b := Subdomain("Prod MinIO", "22222222-2222-2222-2222-222222222222")
	if a == b {
		t.Fatalf("two distinct resources produced the same subdomain %q", a)
	}

	for _, name := range []string{"Prod MinIO", "  weird!!name??  ", "", "ALLCAPS", strings.Repeat("x", 200)} {
		got := Subdomain(name, "id-"+name)
		if got == "" {
			t.Fatalf("empty subdomain for %q", name)
		}
		if len(got) > 63 {
			t.Fatalf("subdomain %q exceeds the 63-char DNS label limit", got)
		}
		for _, r := range got {
			isLower := r >= 'a' && r <= 'z'
			isDigit := r >= '0' && r <= '9'
			if !isLower && !isDigit && r != '-' {
				t.Fatalf("subdomain %q contains DNS-invalid character %q", got, r)
			}
		}
		if strings.HasPrefix(got, "-") || strings.HasSuffix(got, "-") {
			t.Fatalf("subdomain %q may not start or end with a hyphen", got)
		}
	}
}

// ── Session usability ─────────────────────────────────────────────────────

func TestWebProxySessionIsUsable(t *testing.T) {
	now := time.Now().UTC()
	idle := 30 * time.Minute

	base := func() *models.WebProxySession {
		return &models.WebProxySession{
			Status:         models.WebProxySessionActive,
			ExpiresAt:      now.Add(time.Hour),
			LastActivityAt: now,
		}
	}

	if !base().IsUsable(now, idle) {
		t.Fatal("a fresh active session should be usable")
	}

	revoked := base()
	revoked.Status = models.WebProxySessionRevoked
	if revoked.IsUsable(now, idle) {
		t.Fatal("a revoked session must not be usable — this is the admin kill switch")
	}

	expired := base()
	expired.ExpiresAt = now.Add(-time.Minute)
	if expired.IsUsable(now, idle) {
		t.Fatal("a session past its maximum lifetime must not be usable")
	}

	idled := base()
	idled.LastActivityAt = now.Add(-31 * time.Minute)
	if idled.IsUsable(now, idle) {
		t.Fatal("a session idle beyond the timeout must not be usable")
	}
}
