// pam/internal/api/handlers/privpath_handler.go
//
// Privilege-path analysis — Admin Center read-only surface.
//
// Mounted under /api/v1/pam/admin, so it inherits PAMAuth + AuditMiddleware
// + RequireAdmin. That placement is deliberate and worth stating plainly:
// this endpoint is a MAP OF HOW TO ATTACK THE SYSTEM. It enumerates, in
// priority order, the cheapest route from any principal to superuser. In an
// attacker's hands it is a shortcut; it must never be reachable by a
// standard user, and every call is itself audited.
//
// Everything here is read-only. The analyzer never writes to the identity
// tables and is never consulted for an authorization decision — it reads the
// same data the PDP reads and reports on it.
package handlers

import (
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services/graph"
	"go.uber.org/zap"
)

type PrivPathHandler struct {
	svc    *graph.PrivilegePathService
	logger *zap.Logger
}

func NewPrivPathHandler(svc *graph.PrivilegePathService, logger *zap.Logger) *PrivPathHandler {
	return &PrivPathHandler{svc: svc, logger: logger}
}

func (h *PrivPathHandler) fail(c *gin.Context, err error, msg string) {
	if errors.Is(err, graph.ErrNoSnapshot) {
		// 503 rather than 500: the request is valid, the snapshot just isn't
		// ready. Tells the caller to retry rather than to file a bug.
		response.Error(c, http.StatusServiceUnavailable,
			"No privilege-path snapshot yet — POST /admin/privilege-paths/rebuild or wait for the scheduled build")
		return
	}
	h.logger.Error("privpath.request.fail", zap.Error(err))
	response.Error(c, http.StatusInternalServerError, msg)
}

// withFreshness stamps a response payload with the snapshot's age.
//
// Every read here is served from a cached snapshot, so a caller looking at
// path data has no way to know whether it predates the entitlement change
// they just made. Returning built_at/age_seconds on EVERY read (not just
// /status) makes that unavoidable rather than something you have to think to
// check.
func (h *PrivPathHandler) withFreshness(payload gin.H) gin.H {
	if builtAt, ok := h.svc.BuiltAt(); ok {
		payload["built_at"] = builtAt
		payload["age_seconds"] = int(time.Since(builtAt).Seconds())
	}
	return payload
}

// Summary handles GET /api/v1/pam/admin/privilege-paths
// The dashboard view: counts, per-target reachability, trend metrics.
func (h *PrivPathHandler) Summary(c *gin.Context) {
	sum, err := h.svc.Summary()
	if err != nil {
		h.fail(c, err, "Failed to summarize privilege paths")
		return
	}
	response.Success(c, h.withFreshness(gin.H{"summary": sum}), "Privilege-path summary")
}

// Targets handles GET /api/v1/pam/admin/privilege-paths/targets
// Lists the crown-jewel capability nodes analysis runs against, so the UI
// can build its own drill-down without hardcoding IDs.
func (h *PrivPathHandler) Targets(c *gin.Context) {
	response.Success(c, gin.H{"targets": []gin.H{
		{"id": graph.CapSuperuser, "label": "Effective superuser"},
		{"id": graph.CapAdminWrite, "label": "Admin Center write access"},
		{"id": graph.CapVaultPlaintext, "label": "Decrypt any vaulted credential"},
		{"id": graph.CapAuditRead, "label": "Org-wide audit read"},
	}}, "Analysis targets")
}

// PathsTo handles GET /api/v1/pam/admin/privilege-paths/to?target=...&limit=
func (h *PrivPathHandler) PathsTo(c *gin.Context) {
	target := c.Query("target")
	if target == "" {
		target = graph.CapSuperuser
	}
	limit := 50
	if v := c.Query("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			limit = n
		}
	}
	paths, err := h.svc.PathsTo(target, limit)
	if err != nil {
		h.fail(c, err, "Failed to compute privilege paths")
		return
	}
	response.Success(c, h.withFreshness(gin.H{
		"target": target, "count": len(paths), "paths": paths,
	}), "Privilege paths")
}

// ForUser handles GET /api/v1/pam/admin/privilege-paths/user/:id
// Powers the "what can this account actually reach?" panel on the Identity
// user-detail screen — the question GetEffectiveAccess cannot answer,
// because effective access is a flat list and this is transitive closure.
func (h *PrivPathHandler) ForUser(c *gin.Context) {
	paths, err := h.svc.PathsForUser(c.Param("id"))
	if err != nil {
		h.fail(c, err, "Failed to compute privilege paths for user")
		return
	}
	standing := 0
	for _, p := range paths {
		if p.AllStanding {
			standing++
		}
	}
	response.Success(c, h.withFreshness(gin.H{
		"user_id": c.Param("id"), "count": len(paths),
		"standing_paths": standing, "paths": paths,
	}), "Privilege paths for user")
}

// Chokepoints handles GET /api/v1/pam/admin/privilege-paths/chokepoints
func (h *PrivPathHandler) Chokepoints(c *gin.Context) {
	limit := 20
	if v := c.Query("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			limit = n
		}
	}
	cps, err := h.svc.Chokepoints(limit)
	if err != nil {
		h.fail(c, err, "Failed to compute chokepoints")
		return
	}
	response.Success(c, h.withFreshness(gin.H{"chokepoints": cps}),
		"Remediation chokepoints, highest impact first")
}

type simulateRequest struct {
	From string `json:"from" binding:"required"`
	To   string `json:"to" binding:"required"`
	Kind string `json:"kind" binding:"required"`
}

// Simulate handles POST /api/v1/pam/admin/privilege-paths/simulate
// Counterfactual: "if we cut this edge, what happens?" Read-only — it
// clones the snapshot in memory and changes nothing in the database.
func (h *PrivPathHandler) Simulate(c *gin.Context) {
	var req simulateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}
	before, err := h.svc.Summary()
	if err != nil {
		h.fail(c, err, "Failed to load current summary")
		return
	}
	after, err := h.svc.SimulateRemoval(req.From, req.To, graph.EdgeKind(req.Kind))
	if err != nil {
		h.fail(c, err, "Failed to simulate edge removal")
		return
	}
	response.Success(c, gin.H{
		"removed": req,
		"before":  gin.H{"users_with_any_path": before.UsersWithAnyPath, "targets": before.Targets},
		"after":   gin.H{"users_with_any_path": after.UsersWithAnyPath, "targets": after.Targets},
		"users_remediated": before.UsersWithAnyPath - after.UsersWithAnyPath,
	}, "Simulated removal (no changes were made)")
}

// Rebuild handles POST /api/v1/pam/admin/privilege-paths/rebuild
//
// Forces a fresh snapshot. This is the primary refresh path: an entitlement
// change (role assigned, policy detached) is invisible to the graph until a
// rebuild runs, because reads are served from an in-memory snapshot and
// never touch the database.
//
// Concurrency honesty: if a rebuild is already in flight, the service
// coalesces this call into it and returns performed=false. We report that
// explicitly rather than returning a bare success — otherwise a user who
// clicks refresh twice gets a green "snapshot rebuilt" while looking at
// pre-change data, which is precisely the failure mode this endpoint exists
// to prevent.
func (h *PrivPathHandler) Rebuild(c *gin.Context) {
	performed, err := h.svc.Rebuild(c.Request.Context())
	if err != nil {
		h.fail(c, err, "Failed to rebuild privilege-path snapshot")
		return
	}

	sum, err := h.svc.Summary()
	if err != nil {
		h.fail(c, err, "Rebuilt, but failed to summarize")
		return
	}

	if !performed {
		// 202: the request was accepted and folded into the running rebuild,
		// but the body below is still the PREVIOUS snapshot. Distinct status
		// code so a client can tell the two cases apart without string
		// matching on the message.
		c.JSON(http.StatusAccepted, gin.H{
			"success":   true,
			"message":   "A rebuild is already in progress — the data below is the previous snapshot",
			"performed": false,
			"data":      sum,
		})
		return
	}

	response.Success(c, gin.H{
		"performed": true,
		"summary":   sum,
	}, "Privilege-path snapshot rebuilt")
}

// Status handles GET /api/v1/pam/admin/privilege-paths/status
//
// Cheap liveness/staleness probe for the UI: lets a refresh button show when
// the snapshot was last taken and disable itself while a rebuild is running,
// without pulling the whole summary payload.
func (h *PrivPathHandler) Status(c *gin.Context) {
	builtAt, ok := h.svc.BuiltAt()
	payload := gin.H{
		"has_snapshot": ok,
		"building":     h.svc.IsBuilding(),
	}
	if ok {
		payload["built_at"] = builtAt
		payload["age_seconds"] = int(time.Since(builtAt).Seconds())
	}
	response.Success(c, payload, "Privilege-path snapshot status")
}
