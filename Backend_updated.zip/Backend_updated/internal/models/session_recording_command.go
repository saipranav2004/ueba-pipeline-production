// pam/internal/models/session_recording_command.go
//
// SessionRecordingCommand is one command/query a user ran inside a recorded
// in-browser terminal session — the structured, searchable counterpart to
// the raw cast replay in SessionRecording's storage blob. The distinction
// matters for auditing: "did anyone run DROP TABLE against prod-db-01 last
// month" is a SQL query against this table; replaying exactly what the
// screen showed for one specific session is what the cast blob is for.
// Every Input here has already gone through internal/recorder.MaskSecrets,
// same as the cast stream — this table is not a second place a password
// could leak that the cast redaction forgot about.
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type SessionRecordingCommand struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	RecordingID string `gorm:"type:varchar(36);not null;index" json:"recording_id"`
	SessionID   string `gorm:"type:varchar(36);not null;index" json:"session_id"`

	// Sequence orders commands within a session (ties can happen at the same
	// millisecond; StartedAt alone is not a reliable sort key).
	Sequence int `gorm:"not null" json:"sequence"`

	Input       string `gorm:"type:text;not null" json:"input"`
	InputMasked bool   `gorm:"not null;default:false" json:"input_masked"`

	// SUCCESS | FAILURE — mirrors AuditOutcome rather than introducing a
	// third vocabulary for the same concept.
	Outcome       string `gorm:"type:varchar(20);not null" json:"outcome"`
	OutputSummary string `gorm:"type:text" json:"output_summary,omitempty"`
	DurationMs    int64  `gorm:"default:0" json:"duration_ms"`

	OccurredAt time.Time `gorm:"not null;index" json:"occurred_at"`
	CreatedAt  time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (SessionRecordingCommand) TableName() string { return "pam_session_recording_commands" }

func (c *SessionRecordingCommand) BeforeCreate(tx *gorm.DB) error {
	if c.ID == "" {
		c.ID = uuid.NewString()
	}
	return nil
}
