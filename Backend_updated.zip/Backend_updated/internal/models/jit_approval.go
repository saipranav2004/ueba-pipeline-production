// pam/internal/models/jit_approval.go
//
// Four-eyes (maker-checker / dual control) decision tracking for JIT access
// requests.
//
// A STANDARD JIT request is approved ONLY when quorum is met:
//   - any ROOT approval is final, or
//   - two DISTINCT admins have approved.
//
// Denial by any eligible approver is final immediately — deny is the
// fail-safe direction and must never require a second person.
//
// Break-glass (WAITING) requests are deliberately NOT part of this workflow:
// emergency access skips approvers entirely and is instead controlled by the
// mandatory waiting period + CRITICAL alert + forced recording.
//
// Quorum is DERIVED from these rows (distinct approvers per decision), never
// stored as a column on JITRequest, so the full decision trail lives in one
// place and the rule (2 admins / root-final) can be changed later without a
// schema change.
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// JITStatusPartiallyApproved marks a STANDARD request that has one admin
// approval and is waiting on a second DISTINCT approver (or a root). The
// grant is NOT issued in this state. Additive to the status machine in
// jit.go; kept here so that file needs no edits.
const JITStatusPartiallyApproved = "PARTIALLY_APPROVED"

// JIT approval decisions.
const (
	JITApprovalDecisionApproved = "approved"
	JITApprovalDecisionDenied   = "denied"
)

// Approver ranks — mirrors services.RoleRank so a decision row records WHY a
// lone approval was final (root) without coupling models to services.
const (
	JITApproverRankRoot  = 100
	JITApproverRankAdmin = 80
)

// JITApproval records one approver's decision on a JIT access request.
// One row per (request, approver, decision); an approver may appear at most
// once per decision (duplicates are rejected in services.JITService.Approve).
type JITApproval struct {
	ID               string `gorm:"type:varchar(36);primaryKey" json:"id"`
	RequestID        string `gorm:"type:varchar(36);not null;index" json:"request_id"`
	ApproverUserID   string `gorm:"type:varchar(36);not null;index" json:"approver_user_id"`
	ApproverUsername string `gorm:"type:varchar(150);not null" json:"approver_username"`
	// ApproverRank records the approver's privilege at decision time
	// (100 root | 80 admin), so an auditor can see that a lone approval
	// was final because it was root, not because quorum miscounted.
	ApproverRank int    `gorm:"not null" json:"approver_rank"`
	Decision     string `gorm:"type:varchar(16);not null;index" json:"decision"` // approved | denied
	Reason       string `gorm:"type:text" json:"reason"`
	SourceIP     string `gorm:"type:varchar(45)" json:"source_ip"`
	UserAgent    string `gorm:"type:text" json:"-"`

	CreatedAt time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (JITApproval) TableName() string { return "pam_jit_approvals" }

func (a *JITApproval) BeforeCreate(tx *gorm.DB) error {
	if a.ID == "" {
		a.ID = uuid.NewString()
	}
	return nil
}
