// pam/internal/services/mfa_policy.go
//
// ROLE-GATED MFA ENFORCEMENT
// ===========================================================================
// "If an account holds one of these roles, it must have a second factor."
//
// This is the same control Entra ID calls a Conditional Access policy scoped
// to a group, and Okta calls an authenticator enrollment policy bound to a
// group. PAM already has the grouping primitive — ROLES (see models/rbac.go) —
// so no new group concept is introduced here: a rule targets a role name, and
// membership of that role is the gate.
//
// WHY THIS CANNOT LIVE IN THE FRONTEND
// -----------------------------------
// The decision has to be made where the token is minted. AuthService.Login is
// the only place that knows the password was correct and has not yet issued a
// session; anything the console does after that point is decoration, because
// the JWT it would be "enforcing" against is already valid and usable with
// curl. So the evaluation runs here, at sign-in, on every sign-in — the same
// property Entra documents ("evaluated at sign-in time based on the user's
// current group membership"), which matters because a role granted this
// morning must gate this afternoon's login with no re-provisioning.
//
// THREE MODES, because a rollout that only has "off" and "locked out" never
// gets switched on:
//
//	off      the rule exists but does nothing (kept for auditability)
//	monitor  non-compliant sign-ins are allowed and RECORDED; the console
//	         shows the user a banner. This is the "report-only" mode every
//	         serious IAM product ships, and it is how you discover that
//	         switching on enforcement would have locked out three people.
//	enforce  a non-compliant account gets a restricted session that can do
//	         exactly one thing: enrol a second factor.
//
// The restricted session is the part people get wrong. Refusing the login
// outright is unimplementable in practice — enrolment itself requires an
// authenticated call (POST /auth/mfa/setup/initiate), so a hard refusal leaves
// a user who is required to enrol with no way to enrol. Entra solves this with
// an interrupt screen, Okta with an enrollment-required redirect. Here the
// server issues a token carrying mfa_enrollment_required=true, and
// middleware.RequireMFAEnrollment refuses every route except the enrolment
// ones. See internal/middleware/auth.go.
//
// TWO WAYS TO PHASE A RULE IN, because operators think in both:
//
//	grace_hours   RELATIVE, per account. "Everyone gets 48 hours from the
//	              moment they fall under this rule." Right for a standing
//	              rule that keeps catching new joiners — each of them gets
//	              the same window, whenever they arrive.
//	enforce_from  ABSOLUTE, one date for everybody. "This bites on 1
//	              September." Right for a planned cutover you can announce
//	              in an email, which is how a rollout is actually run.
//
// Either, both, or neither. With both set the LATER deadline wins — a person
// must never lose a window one half of the rule promised them.
package services

import (
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

var (
	ErrMFAPolicyForbidden = errors.New("only root or an admin may change MFA policy")
	ErrMFAPolicyRole      = errors.New("unknown role")
	ErrMFAPolicyMode      = errors.New("mode must be off, monitor or enforce")
	// ErrMFAEnrollmentRequired is returned by Login when the account is
	// required to hold a second factor and does not. It is NOT a failure:
	// the handler still returns a (restricted) session alongside it.
	ErrMFAEnrollmentRequired = errors.New("mfa enrollment required")
)

// ---------------------------------------------------------------------------
// Modes
// ---------------------------------------------------------------------------

const (
	MFAModeOff     = "off"
	MFAModeMonitor = "monitor"
	MFAModeEnforce = "enforce"
)

// MFAModes is what the console renders as the mode selector, so the list of
// modes has exactly one definition and the UI cannot offer a fourth one.
func MFAModes() []string {
	return []string{MFAModeOff, MFAModeMonitor, MFAModeEnforce}
}

func validMFAMode(m string) bool {
	switch m {
	case MFAModeOff, MFAModeMonitor, MFAModeEnforce:
		return true
	}
	return false
}

// ---------------------------------------------------------------------------
// Storage
// ---------------------------------------------------------------------------

// MFAPolicyRule gates one ROLE. The role name is the join key rather than the
// role id: role ids are per-install, and a rule that survives a role being
// deleted and re-created with the same name is the behaviour an operator
// expects from a security policy.
type MFAPolicyRule struct {
	ID       string `gorm:"type:varchar(36);primaryKey" json:"id"`
	RoleName string `gorm:"type:varchar(100);uniqueIndex;not null" json:"role_name"`
	Mode     string `gorm:"type:varchar(16);not null" json:"mode"`
	// GraceHours: relative window, counted per account.
	GraceHours int `gorm:"not null;default:0" json:"grace_hours"`
	// EnforceFrom: absolute cutover instant, the same for every member of the
	// role. Null means "no fixed date".
	EnforceFrom *time.Time `json:"enforce_from,omitempty"`
	Reason      string     `gorm:"type:text" json:"reason,omitempty"`
	UpdatedBy   string     `gorm:"type:varchar(36)" json:"updated_by,omitempty"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   time.Time  `json:"updated_at"`
}

func (MFAPolicyRule) TableName() string { return "pam_mfa_policy_rules" }

// MFAPolicyService owns the rules and the sign-in decision.
type MFAPolicyService struct {
	db     *gorm.DB
	roles  RoleResolver
	logger *zap.Logger
}

func NewMFAPolicyService(db *gorm.DB, roles RoleResolver, logger *zap.Logger) *MFAPolicyService {
	s := &MFAPolicyService{db: db, roles: roles, logger: logger}
	if err := db.AutoMigrate(&MFAPolicyRule{}); err != nil {
		logger.Error("mfa_policy.automigrate.fail", zap.Error(err))
	}
	return s
}

// ---------------------------------------------------------------------------
// Decision — the whole point of the file
// ---------------------------------------------------------------------------

// MFADecision is what Login needs to know once the password checks out.
type MFADecision struct {
	// Required: at least one role this user holds is gated in monitor or
	// enforce mode.
	Required bool `json:"required"`
	// Enrolled: the account has an ACTIVE second factor right now.
	Enrolled bool `json:"enrolled"`
	// Mode is the STRONGEST mode across the user's matching roles —
	// enforce beats monitor beats off. A user in two gated roles is held to
	// the stricter of the two, which is the only safe way to combine them.
	Mode string `json:"mode"`
	// MatchedRoles names the gated roles the user holds, for the audit line
	// and for the console's explanation ("required because: admin").
	MatchedRoles []string `json:"matched_roles,omitempty"`
	// GraceUntil is set when enforcement applies but the grace window has
	// not closed yet. Login succeeds normally; the console counts down.
	GraceUntil *time.Time `json:"grace_until,omitempty"`
	// Block: the session must be restricted to enrolment only.
	Block bool `json:"block"`
}

// Compliant reports whether the account currently satisfies policy.
func (d MFADecision) Compliant() bool { return !d.Required || d.Enrolled }

// Evaluate answers "does this user have to hold a second factor, and are
// they in breach right now". `roles` is passed in rather than resolved here
// because Login has already paid for that query.
//
// referenceTime exists so the grace window is computed from ONE clock read —
// two reads inside a decision can straddle a boundary and produce a decision
// that contradicts the deadline it reports.
func (s *MFAPolicyService) Evaluate(userID string, roles []string, enrolled bool, referenceTime time.Time) (MFADecision, error) {
	if len(roles) == 0 {
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}, nil
	}

	rules, err := s.rulesByRole()
	if err != nil {
		// FAIL OPEN, DELIBERATELY, AND LOUDLY. A database blip must not lock
		// every administrator out of the console: the alternative to "let
		// them in and shout" is "nobody can sign in, including the person
		// who would fix it". The error is logged at Error level so the
		// blip is visible rather than silently degrading the control.
		s.logger.Error("mfa_policy.evaluate.rules_unavailable",
			zap.String("user_id", userID), zap.Error(err))
		return MFADecision{Enrolled: enrolled, Mode: MFAModeOff}, nil
	}
	return s.decide(userID, roles, enrolled, referenceTime, rules), nil
}

// decide is Evaluate with the rules already in hand — the pure half, so the
// decision table can be tested without a database standing in the way.
func (s *MFAPolicyService) decide(userID string, roles []string, enrolled bool,
	referenceTime time.Time, rules map[string]MFAPolicyRule) MFADecision {
	d := MFADecision{Enrolled: enrolled, Mode: MFAModeOff}

	var (
		matched     []string
		strictest   = MFAModeOff
		graceHrs    = -1
		enforceFrom *time.Time
	)
	for _, role := range roles {
		rule, ok := rules[strings.ToLower(strings.TrimSpace(role))]
		if !ok || rule.Mode == MFAModeOff {
			continue
		}
		matched = append(matched, role)
		if rankMFAMode(rule.Mode) > rankMFAMode(strictest) {
			strictest = rule.Mode
		}
		// Latest cutover date wins, for the same reason the longest grace does.
		if rule.EnforceFrom != nil && (enforceFrom == nil || rule.EnforceFrom.After(*enforceFrom)) {
			enforceFrom = rule.EnforceFrom
		}
		// The MOST GENEROUS grace across matching rules wins. The strictest
		// mode and the longest grace are not a contradiction: mode decides
		// whether the gate exists, grace decides when it closes, and a user
		// should never lose grace they were promised by one rule because a
		// second, stricter-mode rule also matched.
		if rule.GraceHours > graceHrs {
			graceHrs = rule.GraceHours
		}
	}

	if len(matched) == 0 {
		return d
	}

	sort.Strings(matched)
	d.Required = true
	d.Mode = strictest
	d.MatchedRoles = matched

	if enrolled || strictest != MFAModeEnforce {
		return d
	}

	// Enforce mode, not enrolled: is any phase-in window still open?
	//
	// Both kinds are evaluated and the LATER one wins. Taking the earlier
	// would quietly cancel a window the other half of the rule promised.
	var deadline *time.Time

	if enforceFrom != nil && referenceTime.Before(*enforceFrom) {
		at := *enforceFrom
		deadline = &at
	}

	if graceHrs > 0 {
		start, err := s.gateStart(userID, matched, rules)
		if err == nil {
			at := start.Add(time.Duration(graceHrs) * time.Hour)
			if referenceTime.Before(at) && (deadline == nil || at.After(*deadline)) {
				deadline = &at
			}
		}
		// gateStart failing is not a reason to lock someone out on a clock
		// technicality — but it is not a reason to exempt them either. The
		// absolute date, if there is one, still stands on its own; otherwise
		// enforce mode was explicitly chosen and it applies.
	}

	if deadline != nil {
		d.GraceUntil = deadline
		return d
	}

	d.Block = true
	return d
}

// gateStart is the moment the clock started for this user: the latest of the
// account's creation and the moment the rule that gates them was last changed.
// Re-arming grace when a policy is edited is deliberate — turning a rule from
// monitor to enforce should give people the configured window, not eject them
// the second an administrator clicks Save.
func (s *MFAPolicyService) gateStart(userID string, matched []string, rules map[string]MFAPolicyRule) (time.Time, error) {
	if s.db == nil {
		return time.Time{}, errors.New("mfa policy: no database handle")
	}
	var user models.User
	if err := s.db.Select("created_at").Where("user_id = ?", userID).First(&user).Error; err != nil {
		return time.Time{}, err
	}
	start := user.CreatedAt
	for _, role := range matched {
		if rule, ok := rules[strings.ToLower(role)]; ok && rule.UpdatedAt.After(start) {
			start = rule.UpdatedAt
		}
	}
	return start, nil
}

func rankMFAMode(m string) int {
	switch m {
	case MFAModeEnforce:
		return 2
	case MFAModeMonitor:
		return 1
	default:
		return 0
	}
}

// HasActiveMFA reports whether the account holds an ACTIVE second factor.
//
// "ACTIVE" is the only status that counts, and that is not a style choice:
// AuthService.Login challenges only when mfa.Status == "ACTIVE", so any other
// definition here would disagree with the code that does the challenging —
// and a policy that believes someone is protected when login does not
// challenge them is worse than no policy.
func (s *MFAPolicyService) HasActiveMFA(userID string) bool {
	var count int64
	err := s.db.Model(&models.PAMMFA{}).
		Where("user_id = ? AND status = ?", userID, "ACTIVE").
		Count(&count).Error
	if err != nil {
		s.logger.Error("mfa_policy.has_active_mfa.fail", zap.String("user_id", userID), zap.Error(err))
		return false
	}
	return count > 0
}

// ---------------------------------------------------------------------------
// Rules CRUD (Admin Center)
// ---------------------------------------------------------------------------

func (s *MFAPolicyService) rulesByRole() (map[string]MFAPolicyRule, error) {
	var rules []MFAPolicyRule
	if err := s.db.Find(&rules).Error; err != nil {
		return nil, fmt.Errorf("load mfa policy rules: %w", err)
	}
	out := make(map[string]MFAPolicyRule, len(rules))
	for _, r := range rules {
		out[strings.ToLower(r.RoleName)] = r
	}
	return out, nil
}

// ListRules returns every rule, ordered by role name.
func (s *MFAPolicyService) ListRules() ([]MFAPolicyRule, error) {
	var rules []MFAPolicyRule
	if err := s.db.Order("role_name asc").Find(&rules).Error; err != nil {
		return nil, fmt.Errorf("list mfa policy rules: %w", err)
	}
	return rules, nil
}

type UpsertRuleInput struct {
	RoleName    string
	Mode        string
	GraceHours  int
	EnforceFrom *time.Time
	Reason      string
	ActorID     string
	ActorRoles  []string
}

// UpsertRule creates or updates the rule for one role.
//
// ROOT OR ADMIN. This was root-only, on the argument that an admin able to
// edit the rule gating admins can switch it off and so is not gated at all.
// That argument still holds and is worth knowing: this is a self-editable
// control, and the audit log is what makes it accountable rather than the
// permission boundary. Every write is recorded with the acting user
// (mfa_policy.rule.created / .updated / .deleted below), which is the same
// posture Okta and Entra take for authentication policy — administrators
// author it, and the record of who changed what is the control.
//
// The check is still HERE and not only on the route: RequireAdmin lets any
// admin through to every route in the group, so a service that trusted the
// route would be trusting the group, not the caller.
func (s *MFAPolicyService) UpsertRule(in UpsertRuleInput) (*MFAPolicyRule, error) {
	if !canManageMFAPolicy(in.ActorRoles) {
		return nil, ErrMFAPolicyForbidden
	}
	mode := strings.ToLower(strings.TrimSpace(in.Mode))
	if !validMFAMode(mode) {
		return nil, ErrMFAPolicyMode
	}
	roleName := strings.TrimSpace(in.RoleName)
	if roleName == "" {
		return nil, ErrMFAPolicyRole
	}
	// The role has to exist. A rule against a typo'd role name is a rule that
	// silently never fires, which is the worst possible failure for a control
	// whose entire job is to fire.
	var role models.Role
	if err := s.db.Where("LOWER(name) = ?", strings.ToLower(roleName)).First(&role).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrMFAPolicyRole
		}
		return nil, err
	}
	if in.GraceHours < 0 {
		in.GraceHours = 0
	}

	var existing MFAPolicyRule
	err := s.db.Where("LOWER(role_name) = ?", strings.ToLower(role.Name)).First(&existing).Error
	switch {
	case err == nil:
		existing.Mode = mode
		existing.GraceHours = in.GraceHours
		existing.EnforceFrom = in.EnforceFrom
		existing.Reason = in.Reason
		existing.UpdatedBy = in.ActorID
		// UpdatedAt is bumped by GORM, and gateStart reads it to re-arm the
		// grace window — see the note there.
		if err := s.db.Save(&existing).Error; err != nil {
			return nil, err
		}
		s.logger.Info("mfa_policy.rule.updated",
			zap.String("role", role.Name), zap.String("mode", mode),
			zap.Int("grace_hours", in.GraceHours), zap.String("actor", in.ActorID))
		return &existing, nil
	case errors.Is(err, gorm.ErrRecordNotFound):
		rule := MFAPolicyRule{
			ID:          uuid.NewString(),
			RoleName:    role.Name,
			Mode:        mode,
			GraceHours:  in.GraceHours,
			EnforceFrom: in.EnforceFrom,
			Reason:      in.Reason,
			UpdatedBy:   in.ActorID,
		}
		if err := s.db.Create(&rule).Error; err != nil {
			return nil, err
		}
		s.logger.Info("mfa_policy.rule.created",
			zap.String("role", role.Name), zap.String("mode", mode),
			zap.Int("grace_hours", in.GraceHours), zap.String("actor", in.ActorID))
		return &rule, nil
	default:
		return nil, err
	}
}

// DeleteRule removes the gate on a role entirely. Root or admin, same as
// UpsertRule — and the same note applies: this is the write that can switch
// a control off, so the audit line below is the accountability.
func (s *MFAPolicyService) DeleteRule(roleName string, actorRoles []string, actorID string) error {
	if !canManageMFAPolicy(actorRoles) {
		return ErrMFAPolicyForbidden
	}
	res := s.db.Where("LOWER(role_name) = ?", strings.ToLower(strings.TrimSpace(roleName))).
		Delete(&MFAPolicyRule{})
	if res.Error != nil {
		return res.Error
	}
	s.logger.Info("mfa_policy.rule.deleted", zap.String("role", roleName), zap.String("actor", actorID))
	return nil
}

// canManageMFAPolicy is the single place that decides who may write policy.
// One function, called by both writes, so the two can never drift apart —
// which is exactly how a control ends up enforced on create and not on delete.
func canManageMFAPolicy(roles []string) bool {
	return hasRoleNamed(roles, RoleRoot) || hasRoleNamed(roles, RoleAdmin)
}

func hasRoleNamed(roles []string, want string) bool {
	for _, r := range roles {
		if strings.EqualFold(strings.TrimSpace(r), want) {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------------------
// Compliance — "who would this policy lock out?"
// ---------------------------------------------------------------------------
//
// The question an operator asks BEFORE switching a rule to enforce, and the
// reason monitor mode exists. Answered in three queries rather than N+1: one
// for the users, one for the role memberships, one for the active devices.

type MFAComplianceRow struct {
	UserID     string   `json:"user_id"`
	Username   string   `json:"username"`
	Email      string   `json:"email"`
	Status     string   `json:"status"`
	Roles      []string `json:"roles"`
	MFAEnabled bool     `json:"mfa_enabled"`
	Required   bool     `json:"required"`
	Mode       string   `json:"mode"`
	GatedBy    []string `json:"gated_by,omitempty"`
	Compliant  bool     `json:"compliant"`
}

type MFAComplianceSummary struct {
	TotalUsers   int                `json:"total_users"`
	Gated        int                `json:"gated"`
	Enrolled     int                `json:"enrolled"`
	NonCompliant int                `json:"non_compliant"`
	WouldBlock   int                `json:"would_block"`
	Rows         []MFAComplianceRow `json:"rows"`
}

// Compliance reports every account against the current rules.
func (s *MFAPolicyService) Compliance() (*MFAComplianceSummary, error) {
	var users []models.User
	if err := s.db.Order("username asc").Find(&users).Error; err != nil {
		return nil, fmt.Errorf("list users: %w", err)
	}

	rolesByUser, err := s.roleNamesForAllUsers()
	if err != nil {
		return nil, err
	}
	enrolledSet, err := s.activeMFAUserIDs()
	if err != nil {
		return nil, err
	}
	rules, err := s.rulesByRole()
	if err != nil {
		return nil, err
	}

	out := &MFAComplianceSummary{Rows: make([]MFAComplianceRow, 0, len(users))}
	for _, u := range users {
		roles := rolesByUser[u.UserID]
		enrolled := enrolledSet[u.UserID]

		row := MFAComplianceRow{
			UserID:     u.UserID,
			Username:   u.Username,
			Email:      u.Email,
			Status:     u.Status,
			Roles:      roles,
			MFAEnabled: enrolled,
			Mode:       MFAModeOff,
		}

		strictest := MFAModeOff
		for _, r := range roles {
			rule, ok := rules[strings.ToLower(r)]
			if !ok || rule.Mode == MFAModeOff {
				continue
			}
			row.GatedBy = append(row.GatedBy, r)
			if rankMFAMode(rule.Mode) > rankMFAMode(strictest) {
				strictest = rule.Mode
			}
		}
		row.Required = len(row.GatedBy) > 0
		row.Mode = strictest
		row.Compliant = !row.Required || enrolled

		out.TotalUsers++
		if enrolled {
			out.Enrolled++
		}
		if row.Required {
			out.Gated++
			if !enrolled {
				out.NonCompliant++
				if strictest == MFAModeEnforce {
					out.WouldBlock++
				}
			}
		}
		out.Rows = append(out.Rows, row)
	}
	return out, nil
}

func (s *MFAPolicyService) roleNamesForAllUsers() (map[string][]string, error) {
	type row struct {
		UserID string
		Name   string
	}
	var rows []row
	err := s.db.Table("pam_user_roles").
		Select("pam_user_roles.user_id AS user_id, pam_roles.name AS name").
		Joins("JOIN pam_roles ON pam_roles.id = pam_user_roles.role_id").
		Where("pam_roles.deleted_at IS NULL").
		Scan(&rows).Error
	if err != nil {
		return nil, fmt.Errorf("resolve role memberships: %w", err)
	}
	out := make(map[string][]string)
	for _, r := range rows {
		out[r.UserID] = append(out[r.UserID], r.Name)
	}
	for k := range out {
		sort.Strings(out[k])
	}
	return out, nil
}

func (s *MFAPolicyService) activeMFAUserIDs() (map[string]bool, error) {
	var devices []models.PAMMFA
	if err := s.db.Where("status = ?", "ACTIVE").Find(&devices).Error; err != nil {
		return nil, fmt.Errorf("list active mfa devices: %w", err)
	}
	out := make(map[string]bool, len(devices))
	for _, d := range devices {
		out[d.UserID] = true
	}
	return out, nil
}
