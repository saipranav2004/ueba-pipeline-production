// pam/internal/services/graph/service.go
//
// PrivilegePathService — the cached-snapshot service the Admin Center calls.
//
// Rebuilds are scheduled, not per-request. Rationale: a full snapshot is a
// dozen full-table reads, and the answer changes only when an entitlement
// changes. Serving a cached snapshot keeps the endpoint fast and, more
// importantly, keeps this code off the hot path entirely — nothing here is
// ever consulted for an allow/deny decision, so a bug in it can slow down
// an audit report but can never wrongly grant access.
package graph

import (
	"context"
	"errors"
	"sync"
	"time"

	"go.uber.org/zap"
	"gorm.io/gorm"
)

type PrivilegePathService struct {
	builder *Builder
	logger  *zap.Logger

	mu       sync.RWMutex
	current  *Graph
	analyzer *Analyzer
	lastErr  error
	building bool
}

func NewPrivilegePathService(db *gorm.DB, rules TierRules, logger *zap.Logger) *PrivilegePathService {
	return &PrivilegePathService{builder: NewBuilder(db, rules), logger: logger}
}

// Rebuild takes a fresh snapshot.
//
// Returns performed=false when a rebuild was already in flight and this call
// was coalesced into it. That distinction matters for the manual-refresh
// path: an impatient user clicking "refresh" twice must not be told the
// snapshot is current when the second click did nothing and the data on
// screen is still the pre-change snapshot. The handler turns performed=false
// into an explicit "already in progress" message rather than a false
// success.
//
// Safe to call concurrently. Coalescing (rather than queueing) is
// deliberate: two simultaneous snapshots of the same tables are redundant by
// definition, and serialising them would just double the load to produce the
// same answer twice.
func (s *PrivilegePathService) Rebuild(ctx context.Context) (performed bool, err error) {
	s.mu.Lock()
	if s.building {
		s.mu.Unlock()
		return false, nil
	}
	s.building = true
	s.mu.Unlock()

	defer func() {
		s.mu.Lock()
		s.building = false
		s.mu.Unlock()
	}()

	started := time.Now()
	g, err := s.builder.Build(ctx)

	s.mu.Lock()
	defer s.mu.Unlock()
	if err != nil {
		s.lastErr = err
		s.logger.Error("privpath.rebuild.fail", zap.Error(err))
		// Deliberately keep the previous snapshot rather than nil-ing it: a
		// stale answer with a visible timestamp is more useful to an auditor
		// than no answer, and the caller can see BuiltAt to judge.
		return true, err
	}
	s.current, s.analyzer, s.lastErr = g, NewAnalyzer(g), nil

	stats := g.Stats()
	s.logger.Info("privpath.rebuild.ok",
		zap.Duration("took", time.Since(started)),
		zap.Int("nodes", stats.TotalNodes),
		zap.Int("edges", stats.TotalEdges),
		zap.Int("standing_edges", stats.StandingEdges),
	)
	return true, nil
}

// BuiltAt reports when the current snapshot was taken, and whether one
// exists at all. Exposed so the handler can surface staleness on every
// response — a stale graph with a visible timestamp is honest; a stale graph
// that looks live is how someone concludes a finding is fixed when it isn't.
func (s *PrivilegePathService) BuiltAt() (time.Time, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if s.current == nil {
		return time.Time{}, false
	}
	return s.current.BuiltAt, true
}

// IsBuilding reports whether a rebuild is in flight right now. Lets the UI
// disable its refresh button instead of firing calls that silently coalesce.
func (s *PrivilegePathService) IsBuilding() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.building
}

var ErrNoSnapshot = errors.New("no privilege-path snapshot has been built yet")

func (s *PrivilegePathService) snapshot() (*Analyzer, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if s.analyzer == nil {
		if s.lastErr != nil {
			return nil, s.lastErr
		}
		return nil, ErrNoSnapshot
	}
	return s.analyzer, nil
}

func (s *PrivilegePathService) Summary() (*Summary, error) {
	a, err := s.snapshot()
	if err != nil {
		return nil, err
	}
	sum := a.Summarize(DefaultTargets())
	return &sum, nil
}

func (s *PrivilegePathService) PathsTo(target string, limit int) ([]Path, error) {
	a, err := s.snapshot()
	if err != nil {
		return nil, err
	}
	paths := a.PathsTo(target, 0)
	if limit > 0 && len(paths) > limit {
		paths = paths[:limit]
	}
	return paths, nil
}

// PathsForUser answers the per-principal question the user-detail screen
// asks: "everything this one account can eventually reach."
func (s *PrivilegePathService) PathsForUser(userID string) ([]Path, error) {
	a, err := s.snapshot()
	if err != nil {
		return nil, err
	}
	want := NodeID(KindUser, userID)
	var out []Path
	for _, t := range DefaultTargets() {
		for _, p := range a.PathsTo(t, 0) {
			if p.SourceID == want {
				out = append(out, p)
			}
		}
	}
	return out, nil
}

func (s *PrivilegePathService) Chokepoints(limit int) ([]Chokepoint, error) {
	a, err := s.snapshot()
	if err != nil {
		return nil, err
	}
	return a.Chokepoints(DefaultTargets(), limit), nil
}

// SimulateRemoval answers "what if we cut this edge?" without mutating
// anything — the counterfactual that makes remediation planning possible.
// It rebuilds an in-memory copy minus the edge and re-runs the summary, so
// you can show "fixing X drops reachable users from 40 to 3" before anyone
// touches production.
func (s *PrivilegePathService) SimulateRemoval(from, to string, kind EdgeKind) (*Summary, error) {
	s.mu.RLock()
	base := s.current
	s.mu.RUnlock()
	if base == nil {
		return nil, ErrNoSnapshot
	}

	clone := New()
	clone.BuiltAt = base.BuiltAt
	for id, n := range base.Nodes {
		cp := *n
		clone.Nodes[id] = &cp
	}
	for _, e := range base.Edges {
		if e.From == from && e.To == to && e.Kind == kind {
			continue // the edge under test
		}
		clone.Out[e.From] = append(clone.Out[e.From], e)
		clone.Edges = append(clone.Edges, e)
	}
	clone.Freeze()

	sum := NewAnalyzer(clone).Summarize(DefaultTargets())
	return &sum, nil
}

// ── SCHEDULER ─────────────────────────────────────────────────────────────

// Job rebuilds the snapshot periodically. Modelled on the existing
// AuditVerificationJob so it behaves identically on shutdown.
type Job struct {
	svc      *PrivilegePathService
	interval time.Duration
	logger   *zap.Logger

	mu      sync.Mutex
	running bool
	stopCh  chan struct{}
	doneCh  chan struct{}
}

func NewJob(svc *PrivilegePathService, interval time.Duration, logger *zap.Logger) *Job {
	if interval <= 0 {
		interval = 6 * time.Hour
	}
	return &Job{svc: svc, interval: interval, logger: logger,
		stopCh: make(chan struct{}), doneCh: make(chan struct{})}
}

func (j *Job) Start() {
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.running {
		return
	}
	j.running = true
	go j.loop()
}

// Stop signals the worker and waits up to timeout for the in-flight pass.
//
// The bounded wait is deliberate and differs from AuditVerificationJob.Stop,
// which waits forever. loop() only observes stopCh BETWEEN ticks, so if a
// rebuild is running when SIGTERM arrives the goroutine cannot notice the
// signal until that rebuild finishes — an unbounded wait would stall
// shutdown for up to the rebuild's own 2-minute context timeout.
//
// Abandoning an in-flight snapshot costs nothing: it is a pure read, and the
// next start rebuilds from scratch anyway. This mirrors Sweeper.Stop, which
// is the pattern in this codebase that already gets shutdown right.
func (j *Job) Stop(timeout time.Duration) {
	j.mu.Lock()
	if !j.running {
		j.mu.Unlock()
		return
	}
	j.running = false
	close(j.stopCh)
	j.mu.Unlock()

	select {
	case <-j.doneCh:
	case <-time.After(timeout):
		j.logger.Warn("privpath.stop.timeout",
			zap.Duration("timeout", timeout),
			zap.String("impact", "abandoning an in-flight snapshot; it is a pure read, nothing is left inconsistent"))
	}
}

func (j *Job) loop() {
	defer close(j.doneCh)
	// Build once at startup so the endpoint is useful immediately rather
	// than 404-ing until the first tick.
	if _, err := j.svc.Rebuild(context.Background()); err != nil {
		j.logger.Warn("privpath.initial_build.fail", zap.Error(err))
	}
	t := time.NewTicker(j.interval)
	defer t.Stop()
	for {
		select {
		case <-j.stopCh:
			return
		case <-t.C:
			// Derive from a context cancelled by stopCh so a long rebuild
			// aborts on shutdown instead of running to completion while
			// Stop() waits on it.
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
			go func() {
				select {
				case <-j.stopCh:
					cancel()
				case <-ctx.Done():
				}
			}()
			_, _ = j.svc.Rebuild(ctx)
			cancel()
		}
	}
}
