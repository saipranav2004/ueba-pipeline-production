// pam/internal/services/graph/graph.go
//
// The identity graph: an in-memory projection of PAM's own RBAC/PBAC/JIT/
// vault tables as nodes and capability edges, built for privilege-path
// analysis.
//
// WHY A SEPARATE PROJECTION AND NOT LIVE QUERIES
//
// Path-finding is inherently a whole-graph question ("who can reach root
// from anywhere?"), not a row question. Answering it with SQL means either
// a recursive CTE per target or N+1 queries per hop. Both are slow and both
// re-read the same rows repeatedly. Building one snapshot (a handful of
// full-table SELECTs, all small — these are identity tables, not event
// tables) and traversing it in memory is simpler, faster, and lets the
// traversal encode rules that have no SQL representation at all.
//
// That last point is the important one. A graph built ONLY from the join
// tables draws the org chart: user -> role -> policy. It tells you nothing
// you couldn't read off the Identity screen. The value is in the DERIVED
// edges (see derive.go) — the ones that encode "an admin can call
// AssignRole with role_name=root, and nothing stops them." Those edges are
// where privilege escalation actually lives, and they exist in the
// handlers' control flow, not in any table.
//
// SNAPSHOT SEMANTICS
//
// A Graph is immutable once built and safe for concurrent reads. It is a
// point-in-time view — a grant that expires one second after the snapshot
// is still in it. Callers get BuiltAt and should treat findings as
// "as of that instant". Rebuild on a schedule (see AnalyzerJob) rather
// than per-request: the whole point is that this is an offline audit, not
// an enforcement path. Nothing in this package is ever consulted to make
// an allow/deny decision.
package graph

import (
	"fmt"
	"sort"
	"time"
)

// ── NODES ─────────────────────────────────────────────────────────────────

type NodeKind string

const (
	KindUser       NodeKind = "user"
	KindRole       NodeKind = "role"
	KindPolicy     NodeKind = "policy"
	KindResource   NodeKind = "resource"
	KindSafe       NodeKind = "safe"
	KindCredential NodeKind = "credential"
	KindDevice     NodeKind = "agent_device"
	// KindCapability is a synthetic node representing an abstract power
	// ("Admin Center write access", "effective superuser") that isn't a row
	// in any table. These are the usual path TARGETS.
	KindCapability NodeKind = "capability"
)

// Node is one vertex. ID is namespaced by kind ("user:<uuid>") so the two
// ID spaces can never collide — role IDs and user IDs are both UUIDs.
type Node struct {
	ID    string   `json:"id"`
	Kind  NodeKind `json:"kind"`
	Label string   `json:"label"`
	// Tier marks crown jewels. 0 = ordinary, 1 = sensitive, 2 = Tier-0.
	Tier int `json:"tier"`
	// Attrs carries kind-specific detail the report renders (e.g. a
	// resource's requires_jit flag, a policy's effect).
	Attrs map[string]string `json:"attrs,omitempty"`
}

func NodeID(kind NodeKind, id string) string { return string(kind) + ":" + id }

// ── EDGES ─────────────────────────────────────────────────────────────────

type EdgeKind string

const (
	// Structural — these are literal rows in join tables.
	EdgeHasRole     EdgeKind = "HAS_ROLE"      // pam_user_roles
	EdgeRoleGrants  EdgeKind = "ROLE_GRANTS"   // pam_role_policies
	EdgeHasPolicy   EdgeKind = "HAS_POLICY"    // pam_user_policies (PBAC direct)
	EdgeHoldsGrant  EdgeKind = "HOLDS_GRANT"   // pam_access_grants (ACTIVE, unexpired)
	EdgeSafeHolds   EdgeKind = "SAFE_HOLDS"    // credential lives in safe
	EdgeUnlocks     EdgeKind = "UNLOCKS"       // credential -> resource
	EdgeOwnsSafe    EdgeKind = "OWNS_SAFE"     // pam_safes.owner_id
	EdgePairedWith  EdgeKind = "PAIRED_WITH"   // pam_agent_devices (ACTIVE)

	// Derived — these encode enforcement behaviour, not rows. Each carries
	// a Finding tag pointing at the review item that makes it possible.
	EdgeAllowsAction EdgeKind = "ALLOWS_ACTION" // policy -> capability/resource
	EdgeCanAssign    EdgeKind = "CAN_ASSIGN"    // actor -> role they can grant themselves
	EdgeCanAttach    EdgeKind = "CAN_ATTACH"    // actor -> policy they can attach
	EdgeCanReveal    EdgeKind = "CAN_REVEAL"    // actor -> credential plaintext
	EdgeStandingUse  EdgeKind = "STANDING_USE"  // actor -> resource, no JIT gate
	EdgeAdminCenter  EdgeKind = "ADMIN_CENTER"  // role -> admin write capability
	EdgeRootBypass   EdgeKind = "ROOT_BYPASS"   // root role -> everything
)

// Edge is a directed capability: holding From lets you reach To.
type Edge struct {
	From string   `json:"from"`
	To   string   `json:"to"`
	Kind EdgeKind `json:"kind"`
	// Cost is traversal difficulty, used to rank paths:
	//   0 = already true (structural membership, no action needed)
	//   1 = one unprivileged API call away
	//   2 = requires MFA, an approval, or a second actor
	//   3 = requires an out-of-band step (stolen credential, social)
	Cost int `json:"cost"`
	// Via is the concrete mechanism, rendered verbatim in the report so the
	// finding is actionable: "POST /admin/identity/users/:id/roles".
	Via string `json:"via"`
	// Finding cross-references the code review ("C1"), empty for structural
	// edges. This is what turns a graph picture into a work queue.
	Finding string `json:"finding,omitempty"`
	// Standing marks an edge that is permanent until someone revokes it, as
	// opposed to time-boxed. Standing privilege is the thing PAM exists to
	// eliminate, so it's tracked as a first-class metric.
	Standing bool `json:"standing"`
}

// ── GRAPH ─────────────────────────────────────────────────────────────────

type Graph struct {
	BuiltAt time.Time        `json:"built_at"`
	Nodes   map[string]*Node `json:"nodes"`
	// Out is the adjacency list. Built once, never mutated after Freeze.
	Out map[string][]Edge `json:"-"`
	// Edges is the flat list, retained for export/rendering.
	Edges []Edge `json:"edges"`
}

func New() *Graph {
	return &Graph{
		BuiltAt: time.Now().UTC(),
		Nodes:   make(map[string]*Node),
		Out:     make(map[string][]Edge),
	}
}

// AddNode is idempotent — the builder adds the same resource from several
// directions (as a grant target, as a credential's unlock target) and the
// first write wins on Tier so an explicit crown-jewel marking is not
// clobbered by a later incidental mention.
func (g *Graph) AddNode(n Node) {
	if existing, ok := g.Nodes[n.ID]; ok {
		if n.Tier > existing.Tier {
			existing.Tier = n.Tier
		}
		return
	}
	cp := n
	if cp.Attrs == nil {
		cp.Attrs = map[string]string{}
	}
	g.Nodes[n.ID] = &cp
}

func (g *Graph) AddEdge(e Edge) {
	// Never create an edge to or from a node that doesn't exist — a dangling
	// edge silently produces phantom paths, which is the single worst
	// failure mode for a tool whose entire output is "these paths exist".
	if _, ok := g.Nodes[e.From]; !ok {
		return
	}
	if _, ok := g.Nodes[e.To]; !ok {
		return
	}
	g.Out[e.From] = append(g.Out[e.From], e)
	g.Edges = append(g.Edges, e)
}

// Freeze sorts adjacency lists by cost so BFS explores cheapest-first and
// the shortest path reported is also the easiest path. Call once after the
// build completes.
func (g *Graph) Freeze() {
	for k := range g.Out {
		edges := g.Out[k]
		sort.SliceStable(edges, func(i, j int) bool { return edges[i].Cost < edges[j].Cost })
		g.Out[k] = edges
	}
}

func (g *Graph) Node(id string) *Node { return g.Nodes[id] }

func (g *Graph) Stats() Stats {
	s := Stats{BuiltAt: g.BuiltAt, TotalNodes: len(g.Nodes), TotalEdges: len(g.Edges)}
	s.ByKind = map[string]int{}
	for _, n := range g.Nodes {
		s.ByKind[string(n.Kind)]++
	}
	s.ByEdgeKind = map[string]int{}
	for _, e := range g.Edges {
		s.ByEdgeKind[string(e.Kind)]++
		if e.Standing {
			s.StandingEdges++
		}
	}
	return s
}

type Stats struct {
	BuiltAt       time.Time      `json:"built_at"`
	TotalNodes    int            `json:"total_nodes"`
	TotalEdges    int            `json:"total_edges"`
	StandingEdges int            `json:"standing_edges"`
	ByKind        map[string]int `json:"by_kind"`
	ByEdgeKind    map[string]int `json:"by_edge_kind"`
}

// ── WELL-KNOWN TARGET NODES ───────────────────────────────────────────────
//
// These synthetic capability nodes are the things we ask "who can reach
// this?" about. Declaring them explicitly (rather than inferring "anything
// named root") keeps the target set reviewable — an auditor can read this
// list and agree or disagree with it, which they cannot do with a heuristic.

var (
	// CapSuperuser is unrestricted authority: the root role's policy bypass,
	// or any allow policy matching action "*" on resource "*".
	CapSuperuser = NodeID(KindCapability, "superuser")
	// CapAdminWrite is the Admin Center's mutating surface — identity CRUD,
	// role/policy CRUD, JIT approval, session kill. Reachable by holding
	// "admin" or "root", with NO policy check (verified: the admin route
	// group has zero RequirePermission calls).
	CapAdminWrite = NodeID(KindCapability, "admin_center_write")
	// CapVaultPlaintext is the ability to decrypt any stored credential.
	CapVaultPlaintext = NodeID(KindCapability, "vault_plaintext_any")
	// CapAuditRead is org-wide audit visibility — a target in its own right
	// because the log contains unredacted request bodies (finding H6).
	CapAuditRead = NodeID(KindCapability, "audit_read_org_wide")
)

func seedCapabilities(g *Graph) {
	g.AddNode(Node{ID: CapSuperuser, Kind: KindCapability, Tier: 2,
		Label: "Effective superuser (policy bypass / *:*)"})
	g.AddNode(Node{ID: CapAdminWrite, Kind: KindCapability, Tier: 2,
		Label: "Admin Center write access (role-gated only, no policy check)"})
	g.AddNode(Node{ID: CapVaultPlaintext, Kind: KindCapability, Tier: 2,
		Label: "Decrypt any vaulted credential"})
	g.AddNode(Node{ID: CapAuditRead, Kind: KindCapability, Tier: 1,
		Label: "Org-wide audit read (contains unredacted secrets, H6)"})
}

// DefaultTargets is the crown-jewel set path analysis runs against.
func DefaultTargets() []string {
	return []string{CapSuperuser, CapAdminWrite, CapVaultPlaintext, CapAuditRead}
}

func (n Node) String() string { return fmt.Sprintf("%s(%s)", n.Kind, n.Label) }
