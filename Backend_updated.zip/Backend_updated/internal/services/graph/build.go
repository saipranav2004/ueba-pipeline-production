//
// Snapshot builder: reads PAM's identity tables and projects them into a
// Graph. Structural edges only — the derived escalation edges are added
// afterward by derive.go, which needs the complete structural graph to
// reason over.
//
// Every query here is a full-table read of an identity table. Those are
// small by nature (users, roles, policies, safes, resources — thousands of
// rows, not millions), and this runs on a schedule, not per-request. The
// one table that could get large is pam_access_grants, so that read is
// filtered to ACTIVE + unexpired, which is also the only state that
// represents live privilege.
package graph

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"gorm.io/gorm"
)

// Builder projects the database into a Graph.
type Builder struct {
	db *gorm.DB
	// tierRules decides which resources are crown jewels. Injected rather
	// than hardcoded because "what is Tier-0" is a deployment policy
	// question, not a code question.
	tierRules TierRules
}

// TierRules classifies resources by sensitivity.
type TierRules struct {
	// Tier2ResourceTypes are always crown jewels (e.g. "postgresql" in prod).
	Tier2ResourceTypes []string
	// Tier2NamePatterns match a resource name substring, case-insensitive
	// (e.g. "prod", "payroll").
	Tier2NamePatterns []string
}

func DefaultTierRules() TierRules {
	return TierRules{
		Tier2NamePatterns: []string{"prod", "production", "payroll", "billing", "hsm", "kms"},
	}
}

func NewBuilder(db *gorm.DB, rules TierRules) *Builder {
	return &Builder{db: db, tierRules: rules}
}

func (b *Builder) resourceTier(r models.PAMResource) int {
	name := strings.ToLower(r.Name + " " + r.Host + " " + r.DatabaseName)
	for _, p := range b.tierRules.Tier2NamePatterns {
		if strings.Contains(name, strings.ToLower(p)) {
			return 2
		}
	}
	for _, t := range b.tierRules.Tier2ResourceTypes {
		if strings.EqualFold(r.ResourceType, t) {
			return 2
		}
	}
	return 0
}

// Build reads everything and returns a frozen, ready-to-query graph.
//
// ctx is honoured between phases and passed to every query, so a shutdown
// mid-snapshot aborts promptly rather than running all twelve reads to
// completion. Nothing is written, so an aborted build leaves no trace.
func (b *Builder) Build(ctx context.Context) (*Graph, error) {
	g := New()
	seedCapabilities(g)

	for _, phase := range []struct {
		name string
		fn   func(context.Context, *Graph) error
	}{
		{"users", b.addUsers},
		{"roles_policies", b.addRolesAndPolicies},
		{"resources_vault", b.addResourcesAndVault},
		{"assignments", b.addAssignments},
		{"grants", b.addGrants},
		{"devices", b.addDevices},
	} {
		if err := ctx.Err(); err != nil {
			return nil, fmt.Errorf("graph: build cancelled before %s: %w", phase.name, err)
		}
		if err := phase.fn(ctx, g); err != nil {
			return nil, err
		}
	}

	// Derived escalation edges — the whole point of the exercise.
	if err := Derive(g); err != nil {
		return nil, err
	}

	g.Freeze()
	return g, nil
}

func (b *Builder) addUsers(ctx context.Context, g *Graph) error {
	var users []models.User
	// Unscoped is deliberate: a soft-deleted user whose role rows survive is
	// exactly the kind of orphaned privilege this tool should surface.
	if err := b.db.WithContext(ctx).Unscoped().Find(&users).Error; err != nil {
		return fmt.Errorf("graph: load users: %w", err)
	}
	for _, u := range users {
		attrs := map[string]string{
			"status":    u.Status,
			"mfa":       fmt.Sprintf("%t", u.MFAEnabled),
			"protected": fmt.Sprintf("%t", u.IsProtected),
		}
		if u.DeletedAt.Valid {
			attrs["soft_deleted"] = "true"
		}
		g.AddNode(Node{
			ID:    NodeID(KindUser, u.UserID),
			Kind:  KindUser,
			Label: u.Username,
			Attrs: attrs,
		})
	}
	return nil
}

func (b *Builder) addRolesAndPolicies(ctx context.Context, g *Graph) error {
	var roles []models.Role
	if err := b.db.WithContext(ctx).Find(&roles).Error; err != nil {
		return fmt.Errorf("graph: load roles: %w", err)
	}
	for _, r := range roles {
		tier := 0
		attrs := map[string]string{"is_system": fmt.Sprintf("%t", r.IsSystem)}
		if IsSystemAccountType(r.Name) {
			attrs["is_system_account_type"] = "true"
			attrs["account_type"] = strings.ToLower(r.Name)
			switch strings.ToLower(r.Name) {
			case AccountTypeRoot, AccountTypeAdmin:
				tier = 2
			case AccountTypeUser:
				tier = 1
			}
		}
		g.AddNode(Node{
			ID: NodeID(KindRole, r.ID), Kind: KindRole, Label: r.Name, Tier: tier,
			Attrs: attrs,
		})
	}

	var policies []models.Policy
	if err := b.db.WithContext(ctx).Find(&policies).Error; err != nil {
		return fmt.Errorf("graph: load policies: %w", err)
	}
	for _, p := range policies {
		// AfterFind has already decoded Actions/Resources from JSON.
		g.AddNode(Node{
			ID: NodeID(KindPolicy, p.ID), Kind: KindPolicy, Label: p.Name,
			Tier: policyTier(p),
			Attrs: map[string]string{
				"effect":    p.Effect,
				"actions":   strings.Join(p.Actions, ","),
				"resources": strings.Join(p.Resources, ","),
			},
		})
	}
	return nil
}

// policyTier flags a policy as crown-jewel if it is an unrestricted allow.
func policyTier(p models.Policy) int {
	if !strings.EqualFold(p.Effect, string(models.PolicyEffectAllow)) {
		return 0
	}
	if hasWildcard(p.Actions) && hasWildcard(p.Resources) {
		return 2
	}
	return 0
}

func hasWildcard(patterns []string) bool {
	for _, p := range patterns {
		if p == "*" {
			return true
		}
	}
	return false
}

func (b *Builder) addResourcesAndVault(ctx context.Context, g *Graph) error {
	var resources []models.PAMResource
	if err := b.db.WithContext(ctx).Find(&resources).Error; err != nil {
		return fmt.Errorf("graph: load resources: %w", err)
	}
	for _, r := range resources {
		g.AddNode(Node{
			ID: NodeID(KindResource, r.ID), Kind: KindResource, Label: r.Name,
			Tier: b.resourceTier(r),
			Attrs: map[string]string{
				"type":          r.ResourceType,
				"requires_jit":  fmt.Sprintf("%t", r.RequiresJIT),
				"always_record": fmt.Sprintf("%t", r.AlwaysRecord),
				"active":        fmt.Sprintf("%t", r.IsActive),
			},
		})
	}

	var safes []models.Safe
	if err := b.db.WithContext(ctx).Find(&safes).Error; err != nil {
		return fmt.Errorf("graph: load safes: %w", err)
	}
	for _, s := range safes {
		g.AddNode(Node{
			ID: NodeID(KindSafe, s.ID), Kind: KindSafe, Label: s.Name, Tier: 1,
			Attrs: map[string]string{"owner_id": s.OwnerID},
		})
		// OwnsSafe is recorded even though nothing enforces it (finding C5).
		// Making the unenforced relationship visible is precisely how the
		// report can say "this ownership edge exists and is ignored".
		owner := NodeID(KindUser, s.OwnerID)
		if _, ok := g.Nodes[owner]; ok {
			g.AddEdge(Edge{From: owner, To: NodeID(KindSafe, s.ID),
				Kind: EdgeOwnsSafe, Cost: 0, Via: "pam_safes.owner_id", Standing: true})
		}
	}

	var creds []models.Credential
	if err := b.db.WithContext(ctx).Where("status != ?", "archived").Find(&creds).Error; err != nil {
		return fmt.Errorf("graph: load credentials: %w", err)
	}
	for _, c := range creds {
		cid := NodeID(KindCredential, c.ID)
		// A credential inherits the tier of the resource it unlocks — a
		// password to a prod database is a prod-tier asset.
		tier := 1
		if c.ResourceID != "" {
			if rn := g.Node(NodeID(KindResource, c.ResourceID)); rn != nil && rn.Tier > tier {
				tier = rn.Tier
			}
		}
		g.AddNode(Node{
			ID: cid, Kind: KindCredential, Label: c.Name, Tier: tier,
			Attrs: map[string]string{"type": c.CredentialType, "account": c.AccountName},
		})
		if c.SafeID != "" {
			if _, ok := g.Nodes[NodeID(KindSafe, c.SafeID)]; ok {
				g.AddEdge(Edge{From: NodeID(KindSafe, c.SafeID), To: cid,
					Kind: EdgeSafeHolds, Cost: 0, Via: "credential.safe_id"})
			}
		}
		// The credential -> resource edge is what makes "reveal" an
		// escalation rather than a curiosity: plaintext plus a hostname is
		// access, independent of PAM's own session gateway.
		if c.ResourceID != "" {
			if _, ok := g.Nodes[NodeID(KindResource, c.ResourceID)]; ok {
				g.AddEdge(Edge{From: cid, To: NodeID(KindResource, c.ResourceID),
					Kind: EdgeUnlocks, Cost: 1,
					Via:      "direct connection using revealed plaintext, bypassing PAM session gateway",
					Standing: true})
			}
		}
	}
	return nil
}

func (b *Builder) addAssignments(ctx context.Context, g *Graph) error {
	var userRoles []models.UserRole
	if err := b.db.WithContext(ctx).Find(&userRoles).Error; err != nil {
		return fmt.Errorf("graph: load user_roles: %w", err)
	}
	for _, ur := range userRoles {
		g.AddEdge(Edge{
			From: NodeID(KindUser, ur.UserID), To: NodeID(KindRole, ur.RoleID),
			Kind: EdgeHasRole, Cost: 0, Via: "pam_user_roles", Standing: true,
		})
	}

	var rolePolicies []models.RolePolicy
	if err := b.db.WithContext(ctx).Find(&rolePolicies).Error; err != nil {
		return fmt.Errorf("graph: load role_policies: %w", err)
	}
	for _, rp := range rolePolicies {
		g.AddEdge(Edge{
			From: NodeID(KindRole, rp.RoleID), To: NodeID(KindPolicy, rp.PolicyID),
			Kind: EdgeRoleGrants, Cost: 0, Via: "pam_role_policies", Standing: true,
		})
	}

	var userPolicies []models.UserPolicy
	if err := b.db.WithContext(ctx).Find(&userPolicies).Error; err != nil {
		return fmt.Errorf("graph: load user_policies: %w", err)
	}
	for _, up := range userPolicies {
		g.AddEdge(Edge{
			From: NodeID(KindUser, up.UserID), To: NodeID(KindPolicy, up.PolicyID),
			Kind: EdgeHasPolicy, Cost: 0,
			Via: "pam_user_policies (PBAC direct attachment — bypasses roles)", Standing: true,
		})
	}
	return nil
}

func (b *Builder) addGrants(ctx context.Context, g *Graph) error {
	now := time.Now().UTC()
	var grants []models.AccessGrant
	if err := b.db.WithContext(ctx).Where("status = ? AND expires_at > ?", models.GrantStatusActive, now).
		Find(&grants).Error; err != nil {
		return fmt.Errorf("graph: load grants: %w", err)
	}
	for _, gr := range grants {
		via := fmt.Sprintf("JIT grant %s, expires %s", gr.ID, gr.ExpiresAt.Format(time.RFC3339))
		if gr.IsBreakglass {
			via = "BREAK-GLASS " + via
		}
		g.AddEdge(Edge{
			From: NodeID(KindUser, gr.UserID), To: NodeID(KindResource, gr.ResourceID),
			Kind: EdgeHoldsGrant, Cost: 0, Via: via,
			// Explicitly NOT standing — this is the one edge type in the
			// system that is correctly time-boxed, and the metric that
			// tracks progress is standing-vs-JIT ratio.
			Standing: false,
		})
	}
	return nil
}

func (b *Builder) addDevices(ctx context.Context, g *Graph) error {
	var devices []models.AgentDevice
	if err := b.db.WithContext(ctx).Where("status = ?", "ACTIVE").Find(&devices).Error; err != nil {
		// Agent tables are optional in some deployments; a missing table is
		// not a reason to fail the whole snapshot.
		return nil
	}
	for _, d := range devices {
		did := NodeID(KindDevice, d.ID)
		g.AddNode(Node{
			ID: did, Kind: KindDevice, Label: d.DeviceName,
			Attrs: map[string]string{"user_id": d.UserID},
		})
		g.AddEdge(Edge{
			From: NodeID(KindUser, d.UserID), To: did,
			Kind: EdgePairedWith, Cost: 0,
			Via:      "enrolled Ed25519 agent device (valid until revoked)",
			Standing: true,
		})
	}
	return nil
}
