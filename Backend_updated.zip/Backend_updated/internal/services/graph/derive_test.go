//
// These tests pin each derived edge to the enforcement behaviour that makes
// it possible. That is the whole maintenance contract for this package: if
// somebody fixes an enforcement gap and does NOT update derive.go, the
// corresponding test here fails and tells them which rule went stale.
//
// A privilege-path analyzer that reports paths which no longer exist is
// worse than no analyzer — it trains people to ignore the output. These
// tests are what prevent that.
package graph

import "testing"

func mkGraph() *Graph {
	g := New()
	seedCapabilities(g)
	return g
}

func addRole(g *Graph, id, name string) string {
	nid := NodeID(KindRole, id)
	tier := 0
	if name == "root" || name == "admin" {
		tier = 2
	}
	g.AddNode(Node{ID: nid, Kind: KindRole, Label: name, Tier: tier})
	return nid
}

func addPolicy(g *Graph, id, name, effect, actions, resources string) string {
	nid := NodeID(KindPolicy, id)
	tier := 0
	if effect == "allow" && actions == "*" && resources == "*" {
		tier = 2
	}
	g.AddNode(Node{ID: nid, Kind: KindPolicy, Label: name, Tier: tier,
		Attrs: map[string]string{"effect": effect, "actions": actions, "resources": resources}})
	return nid
}

func hasEdge(g *Graph, from, to string, kind EdgeKind) bool {
	for _, e := range g.Out[from] {
		if e.To == to && e.Kind == kind {
			return true
		}
	}
	return false
}

func findEdge(g *Graph, from, to string, kind EdgeKind) *Edge {
	for i := range g.Out[from] {
		if g.Out[from][i].To == to && g.Out[from][i].Kind == kind {
			return &g.Out[from][i]
		}
	}
	return nil
}

// ── C5: the shipped standard-user-access policy reaches every secret ──────

func TestSeededUserPolicyReachesVaultPlaintext(t *testing.T) {
	g := mkGraph()
	// Exactly the shipped bundle's standard-user-access.
	p := addPolicy(g, "p1", "standard-user-access", "allow",
		"pam:resource:List,pam:resource:Read,pam:resource:Connect,pam:session:Start,"+
			"pam:session:End,pam:vault:List,pam:vault:Read,pam:vault:Create,pam:vault:Store,"+
			"pam:vault:Reveal,pam:vault:Rotate,pam:jit:Request,pam:jit:Cancel,"+
			"pam:audit:Read,pam:report:Generate",
		"*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	e := findEdge(g, p, CapVaultPlaintext, EdgeAllowsAction)
	if e == nil {
		t.Fatal("expected the seeded user policy to reach vault plaintext (finding C5)")
	}
	if e.Finding != "C5" {
		t.Errorf("expected finding C5, got %q", e.Finding)
	}
	if !e.Standing {
		t.Error("this is permanent privilege and must be marked standing")
	}
}

// If C5 is remediated by narrowing the policy's resources away from a bare
// wildcard, the edge must disappear. This is the test that fails loudly if
// someone fixes the policy but leaves derive.go asserting the old world.
func TestNarrowedVaultPolicyDoesNotReachAllSecrets(t *testing.T) {
	g := mkGraph()
	p := addPolicy(g, "p1", "scoped-user", "allow",
		"pam:vault:Reveal", "pam:vault/safe-owned-by-caller")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if hasEdge(g, p, CapVaultPlaintext, EdgeAllowsAction) {
		t.Error("a resource-scoped reveal policy must NOT grant blanket vault plaintext")
	}
}

// ── Superuser detection ───────────────────────────────────────────────────

func TestWildcardPolicyIsSuperuser(t *testing.T) {
	g := mkGraph()
	p := addPolicy(g, "p1", "full-access", "allow", "*", "*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if !hasEdge(g, p, CapSuperuser, EdgeAllowsAction) {
		t.Error("a *:* allow policy must reach superuser")
	}
}

func TestDenyPolicyGrantsNothing(t *testing.T) {
	g := mkGraph()
	p := addPolicy(g, "p1", "blanket-deny", "deny", "*", "*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if hasEdge(g, p, CapSuperuser, EdgeAllowsAction) {
		t.Error("a deny policy must never create a reachability edge")
	}
}

// ── The root bypass is a role property, not a policy property ─────────────

func TestRootRoleBypassesPolicyEntirely(t *testing.T) {
	g := mkGraph()
	r := addRole(g, "r1", "root")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	// Root must reach superuser with NO policy in the graph at all — that is
	// precisely what opa.Engine.Evaluate's IsRoot short-circuit does.
	if !hasEdge(g, r, CapSuperuser, EdgeRootBypass) {
		t.Error("root must reach superuser via bypass, independent of any policy")
	}
}

// ── The admin role is an unmediated capability ────────────────────────────
//
// Pins the grep result: the /admin route group has ZERO RequirePermission
// calls, so holding the role IS the permission. If someone later gates that
// group with the policy engine, this test should be updated — and the fact
// that it must be updated is the point.
func TestAdminRoleIsUnmediatedCapability(t *testing.T) {
	g := mkGraph()
	r := addRole(g, "r1", "admin")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	e := findEdge(g, r, CapAdminWrite, EdgeAdminCenter)
	if e == nil {
		t.Fatal("admin role must reach Admin Center write access")
	}
	if e.Cost != 0 {
		t.Errorf("holding the role costs nothing to exercise; got cost %d", e.Cost)
	}
}

// ── Account types are not assignable by admin ─────────────────────────────

func TestAdminCannotAssignSystemAccountTypes(t *testing.T) {
	g := mkGraph()
	addRole(g, "r1", "admin")
	root := addRole(g, "r2", "root")
	userT := addRole(g, "r3", "user")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if hasEdge(g, CapAdminWrite, root, EdgeCanAssign) {
		t.Error("admin must not CAN_ASSIGN account type root")
	}
	if hasEdge(g, CapAdminWrite, userT, EdgeCanAssign) {
		t.Error("admin must not CAN_ASSIGN account type user")
	}
	admin := NodeID(KindRole, "r1")
	if hasEdge(g, CapAdminWrite, admin, EdgeCanAssign) {
		t.Error("admin must not CAN_ASSIGN account type admin")
	}
}

func TestAdminCanAssignCreatedRolesOnly(t *testing.T) {
	g := mkGraph()
	addRole(g, "r1", "admin")
	created := addRole(g, "r2", "db-ops")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if !hasEdge(g, CapAdminWrite, created, EdgeCanAssign) {
		t.Fatal("admin must be able to assign created roles")
	}
}

func TestOnlyRootCanDelegateAdmin(t *testing.T) {
	g := mkGraph()
	admin := addRole(g, "r1", "admin")
	root := addRole(g, "r2", "root")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if !hasEdge(g, root, admin, EdgeCanDelegate) {
		t.Fatal("root must CAN_DELEGATE admin")
	}
	if hasEdge(g, admin, root, EdgeCanDelegate) {
		t.Error("admin must not delegate root")
	}
	if hasEdge(g, CapAdminWrite, admin, EdgeCanDelegate) {
		t.Error("Admin Center write (shared by admin) must not be the delegation source")
	}
}

// ── C2: admin can attach a *:* policy, invisibly ──────────────────────────

func TestAdminCenterCanAttachSuperuserPolicy(t *testing.T) {
	g := mkGraph()
	addRole(g, "r1", "admin")
	p := addPolicy(g, "p1", "full-access", "allow", "*", "*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	e := findEdge(g, CapAdminWrite, p, EdgeCanAttach)
	if e == nil {
		t.Fatal("Admin Center must be shown as able to attach a *:* policy (finding C2)")
	}
	if e.Finding != "C2" {
		t.Errorf("expected finding C2, got %q", e.Finding)
	}
}

// ── C6: requires_jit defaults false, so Connect is standing access ────────

func TestNonJITResourceYieldsStandingAccess(t *testing.T) {
	g := mkGraph()
	g.AddNode(Node{ID: NodeID(KindResource, "res1"), Kind: KindResource, Label: "prod-db",
		Attrs: map[string]string{"requires_jit": "false", "always_record": "false"}})
	p := addPolicy(g, "p1", "standard-user-access", "allow", "pam:resource:Connect", "*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	e := findEdge(g, p, NodeID(KindResource, "res1"), EdgeStandingUse)
	if e == nil {
		t.Fatal("a non-JIT resource with a Connect grant is standing access (finding C6)")
	}
	if e.Finding != "C6" || !e.Standing {
		t.Errorf("expected standing C6 edge, got finding=%q standing=%v", e.Finding, e.Standing)
	}
}

func TestJITGatedResourceIsNotStandingAccess(t *testing.T) {
	g := mkGraph()
	g.AddNode(Node{ID: NodeID(KindResource, "res1"), Kind: KindResource, Label: "prod-db",
		Attrs: map[string]string{"requires_jit": "true", "always_record": "true"}})
	p := addPolicy(g, "p1", "standard-user-access", "allow", "pam:resource:Connect", "*")
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	if hasEdge(g, p, NodeID(KindResource, "res1"), EdgeStandingUse) {
		t.Error("a JIT-gated resource must not produce a standing-access edge")
	}
}

// ── Graph integrity ───────────────────────────────────────────────────────

func TestDanglingEdgesAreRejected(t *testing.T) {
	g := mkGraph()
	g.AddEdge(Edge{From: "user:ghost", To: CapSuperuser, Kind: EdgeHasRole})
	if len(g.Edges) != 0 {
		t.Error("an edge from a non-existent node must be dropped; phantom paths are the " +
			"worst possible failure mode for this tool")
	}
}

// ── Traversal ─────────────────────────────────────────────────────────────

func TestPathsToFindsCheapestRoute(t *testing.T) {
	g := mkGraph()
	u := NodeID(KindUser, "u1")
	g.AddNode(Node{ID: u, Kind: KindUser, Label: "alice"})
	admin := addRole(g, "r1", "admin")
	root := addRole(g, "r2", "root")
	full := addPolicy(g, "p1", "full-access", "allow", "*", "*")

	g.AddEdge(Edge{From: u, To: admin, Kind: EdgeHasRole, Cost: 0, Standing: true})
	g.AddEdge(Edge{From: admin, To: full, Kind: EdgeRoleGrants, Cost: 0, Standing: true})
	_ = root
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	g.Freeze()

	paths := NewAnalyzer(g).PathsTo(CapSuperuser, 0)
	if len(paths) == 0 {
		t.Fatal("expected alice to reach superuser")
	}
		// The type-admin -> *:* policy -> superuser route is cost 0.
	if paths[0].TotalCost != 0 {
		t.Errorf("expected the cost-0 route to rank first, got cost %d", paths[0].TotalCost)
	}
	if !paths[0].AllStanding {
		t.Error("that route is entirely standing privilege and should be flagged as such")
	}
}

func TestChokepointRanksHighestImpactFirst(t *testing.T) {
	g := mkGraph()
	shared := addPolicy(g, "p1", "full-access", "allow", "*", "*")
	role := addRole(g, "r1", "admin")
	g.AddEdge(Edge{From: role, To: shared, Kind: EdgeRoleGrants, Cost: 0, Standing: true})
	for _, name := range []string{"a", "b", "c"} {
		u := NodeID(KindUser, name)
		g.AddNode(Node{ID: u, Kind: KindUser, Label: name})
		g.AddEdge(Edge{From: u, To: role, Kind: EdgeHasRole, Cost: 0, Standing: true})
	}
	if err := Derive(g); err != nil {
		t.Fatalf("Derive: %v", err)
	}
	g.Freeze()

	cps := NewAnalyzer(g).Chokepoints([]string{CapSuperuser}, 5)
	if len(cps) == 0 {
		t.Fatal("expected chokepoints")
	}
	// The single role->policy edge carries all three users' paths and must
	// outrank any individual user's own membership edge.
	top := cps[0]
	if top.UsersCutOff < 3 {
		t.Errorf("expected the shared edge to rank first (3 users), got %d cut off via %s->%s",
			top.UsersCutOff, top.FromLabel, top.ToLabel)
	}
}
