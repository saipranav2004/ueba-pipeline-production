// pam/internal/services/graph/user_graph.go
//
// Per-member identity graph — one user, live from the identity tables.
//
//	user
//	  ├─ user type            exactly one system role (root | admin | user),
//	  │                       highest rank wins
//	  │     └─ policies via that role
//	  │           └─ concrete resources / credentials those policies match
//	  ├─ additional roles     every other held role (custom, plus leftover
//	  │                       system roles e.g. "user" under an admin)
//	  │     └─ policies attached to that role
//	  │           └─ concrete resources / credentials those policies match
//	  └─ direct policies      PBAC on the user, bypassing roles
//	        └─ concrete resources / credentials those policies match
//
// "Match" means the PDP matcher (opa.MatchesAny): the policy's action and
// resource patterns against this deployment's PAM resources and credentials.
// A deny policy is listed but matches nothing.
//
// Distinct from PathsForUser (escalation to crown jewels, cached snapshot).
// This is a live read — a role assigned a second ago is visible here.
//
//	GET /api/v1/pam/admin/identity/users/:id/graph
package graph

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/opa"
	"gorm.io/gorm"
)

const EdgeUserType EdgeKind = "USER_TYPE"

var ErrUserNotFound = errors.New("user not found")

// ── response types ────────────────────────────────────────────────────────

type MemberGraph struct {
	BuiltAt time.Time `json:"built_at"`

	User MemberUserView `json:"user"`

	// UserType is the highest-ranked system role: root > admin > user.
	// Its Policies each carry the resources that policy actually matches.
	UserType *MemberRoleView `json:"user_type"`

	// SystemRoles is every held root/admin/user role (type + leftovers).
	SystemRoles []MemberRoleView `json:"system_roles"`

	// AdditionalRoles is every held role that is not the user type.
	AdditionalRoles []MemberRoleView `json:"additional_roles"`

	// DirectPolicies are PBAC attachments on the user. Each carries its
	// matched resources — same shape as a role's policies.
	DirectPolicies []MemberPolicyView `json:"direct_policies"`

	Nodes []Node `json:"nodes"`
	Edges []Edge `json:"edges"`
	Stats MemberGraphStats `json:"stats"`
}

type MemberUserView struct {
	ID          string `json:"id"`
	Username    string `json:"username"`
	Email       string `json:"email"`
	FullName    string `json:"full_name,omitempty"`
	Status      string `json:"status"`
	MFAEnabled  bool   `json:"mfa_enabled"`
	IsProtected bool   `json:"is_protected"`
}

type MemberRoleView struct {
	ID          string             `json:"id"`
	Name        string             `json:"name"`
	Description string             `json:"description,omitempty"`
	IsSystem    bool               `json:"is_system"`
	Policies    []MemberPolicyView `json:"policies"`
}

// MemberPolicyView is one policy AND the concrete targets it matches.
// ResourcePatterns is the policy document (what was written).
// MatchedResources / MatchedCredentials are what that document hits here.
type MemberPolicyView struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Description string   `json:"description,omitempty"`
	Effect      string   `json:"effect"`
	Actions     []string `json:"actions"`
	// ResourcePatterns is the policy's own resource list ("*", "pam:resource/…").
	ResourcePatterns []string `json:"resource_patterns"`
	IsSystem         bool     `json:"is_system"`
	// Origin is "user_type" | "additional_role" | "direct".
	Origin         string `json:"origin"`
	OriginRoleID   string `json:"origin_role_id,omitempty"`
	OriginRoleName string `json:"origin_role_name,omitempty"`

	MatchedResources   []MemberResourceView   `json:"matched_resources"`
	MatchedCredentials []MemberCredentialView `json:"matched_credentials"`
}

type MemberResourceView struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	Type         string `json:"type"`
	RequiresJIT  bool   `json:"requires_jit"`
	AlwaysRecord bool   `json:"always_record"`
	Active       bool   `json:"active"`
	// Access is jit_connect | standing_connect | read | list | all.
	Access   string `json:"access"`
	Standing bool   `json:"standing"`
}

type MemberCredentialView struct {
	ID      string `json:"id"`
	Name    string `json:"name"`
	Type    string `json:"type"`
	Account string `json:"account,omitempty"`
	Access  string `json:"access"` // reveal
}

type MemberGraphStats struct {
	Roles              int `json:"roles"`
	AdditionalRoles    int `json:"additional_roles"`
	DirectPolicies     int `json:"direct_policies"`
	Policies           int `json:"policies"`
	MatchedResources   int `json:"matched_resources"`
	MatchedCredentials int `json:"matched_credentials"`
	StandingConnects   int `json:"standing_connects"`
}

type MemberGraphInput struct {
	User           models.User
	Roles          []models.Role
	RolePolicies   map[string][]models.Policy
	DirectPolicies []models.Policy
	Resources      []models.PAMResource
	Credentials    []models.Credential
}

// ── service entry ─────────────────────────────────────────────────────────

func (s *PrivilegePathService) MemberGraph(ctx context.Context, userID string) (*MemberGraph, error) {
	return s.builder.MemberGraph(ctx, userID)
}

func (b *Builder) MemberGraph(ctx context.Context, userID string) (*MemberGraph, error) {
	userID = strings.TrimSpace(userID)
	if userID == "" {
		return nil, ErrUserNotFound
	}

	var user models.User
	if err := b.db.WithContext(ctx).Where("user_id = ?", userID).First(&user).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrUserNotFound
		}
		return nil, fmt.Errorf("graph: load user: %w", err)
	}

	var roles []models.Role
	if err := b.db.WithContext(ctx).
		Joins("JOIN pam_user_roles ON pam_user_roles.role_id = pam_roles.id").
		Where("pam_user_roles.user_id = ?", userID).
		Order("pam_roles.name ASC").
		Find(&roles).Error; err != nil {
		return nil, fmt.Errorf("graph: load user roles: %w", err)
	}

	rolePolicies := make(map[string][]models.Policy, len(roles))
	for _, role := range roles {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		var policies []models.Policy
		if err := b.db.WithContext(ctx).
			Joins("JOIN pam_role_policies ON pam_role_policies.policy_id = pam_policies.id").
			Where("pam_role_policies.role_id = ?", role.ID).
			Order("pam_policies.name ASC").
			Find(&policies).Error; err != nil {
			return nil, fmt.Errorf("graph: load policies for role %s: %w", role.Name, err)
		}
		rolePolicies[role.ID] = policies
	}

	var direct []models.Policy
	if err := b.db.WithContext(ctx).
		Joins("JOIN pam_user_policies ON pam_user_policies.policy_id = pam_policies.id").
		Where("pam_user_policies.user_id = ?", userID).
		Order("pam_policies.name ASC").
		Find(&direct).Error; err != nil {
		return nil, fmt.Errorf("graph: load direct policies: %w", err)
	}

	var resources []models.PAMResource
	if err := b.db.WithContext(ctx).Order("name ASC").Find(&resources).Error; err != nil {
		return nil, fmt.Errorf("graph: load resources: %w", err)
	}

	var creds []models.Credential
	if err := b.db.WithContext(ctx).
		Where("status != ?", "archived").
		Order("name ASC").
		Find(&creds).Error; err != nil {
		return nil, fmt.Errorf("graph: load credentials: %w", err)
	}

	return AssembleMemberGraph(MemberGraphInput{
		User:           user,
		Roles:          roles,
		RolePolicies:   rolePolicies,
		DirectPolicies: direct,
		Resources:      resources,
		Credentials:    creds,
	}), nil
}

// ── assembly ──────────────────────────────────────────────────────────────

func AssembleMemberGraph(in MemberGraphInput) *MemberGraph {
	now := time.Now().UTC()
	g := New()
	g.BuiltAt = now
	seenEdge := map[string]bool{}

	addNode := func(n Node) { g.AddNode(n) }
	addEdge := func(e Edge) {
		key := e.From + "|" + e.To + "|" + string(e.Kind)
		if seenEdge[key] {
			return
		}
		seenEdge[key] = true
		g.AddEdge(e)
	}

	userID := NodeID(KindUser, in.User.UserID)
	addNode(Node{
		ID: userID, Kind: KindUser, Label: in.User.Username,
		Attrs: map[string]string{
			"status":    in.User.Status,
			"mfa":       fmt.Sprintf("%t", in.User.MFAEnabled),
			"protected": fmt.Sprintf("%t", in.User.IsProtected),
			"email":     in.User.Email,
			"full_name": in.User.FullName,
			"user_id":   in.User.UserID,
		},
	})

	typeRole := pickUserType(in.Roles)
	out := &MemberGraph{
		BuiltAt:         now,
		User:            userView(in.User),
		SystemRoles:     []MemberRoleView{},
		AdditionalRoles: []MemberRoleView{},
		DirectPolicies:  []MemberPolicyView{},
	}

	for _, role := range in.Roles {
		origin := originFor(role, typeRole)
		view := roleView(role, in.RolePolicies[role.ID], origin, in.Resources, in.Credentials)
		if isSystemRoleName(role.Name) {
			out.SystemRoles = append(out.SystemRoles, view)
		}

		rid := NodeID(KindRole, role.ID)
		if typeRole != nil && role.ID == typeRole.ID {
			copied := view
			out.UserType = &copied
			addNode(roleNode(role, true))
			addEdge(Edge{
				From: userID, To: rid, Kind: EdgeUserType, Cost: 0, Standing: true,
				Via: "system role — this account's user type",
			})
			attachRolePolicies(addNode, addEdge, role, view.Policies, "user_type")
			attachTypeCapabilities(addNode, addEdge, rid, role.Name)
			expandPolicyViews(addNode, addEdge, view.Policies)
			continue
		}

		out.AdditionalRoles = append(out.AdditionalRoles, view)
		addNode(roleNode(role, false))
		addEdge(Edge{
			From: userID, To: rid, Kind: EdgeHasRole, Cost: 0, Standing: true,
			Via: "pam_user_roles — additional role",
		})
		attachRolePolicies(addNode, addEdge, role, view.Policies, "additional_role")
		expandPolicyViews(addNode, addEdge, view.Policies)
	}

	for _, p := range in.DirectPolicies {
		view := policyView(p, "direct", "", "", in.Resources, in.Credentials)
		out.DirectPolicies = append(out.DirectPolicies, view)
		pid := NodeID(KindPolicy, p.ID)
		addNode(policyNode(p, "direct"))
		addEdge(Edge{
			From: userID, To: pid, Kind: EdgeHasPolicy, Cost: 0, Standing: true,
			Via: "pam_user_policies (PBAC direct attachment — bypasses roles)",
		})
		expandPolicyViews(addNode, addEdge, []MemberPolicyView{view})
	}

	out.Nodes = nodesSlice(g)
	out.Edges = append([]Edge(nil), g.Edges...)
	out.Stats = statsFrom(out)
	return out
}

func attachRolePolicies(
	addNode func(Node),
	addEdge func(Edge),
	role models.Role,
	policies []MemberPolicyView,
	origin string,
) {
	rid := NodeID(KindRole, role.ID)
	for _, p := range policies {
		addNode(policyNodeFromView(p, origin))
		addEdge(Edge{
			From: rid, To: NodeID(KindPolicy, p.ID), Kind: EdgeRoleGrants, Cost: 0, Standing: true,
			Via: "pam_role_policies",
		})
	}
}

func attachTypeCapabilities(addNode func(Node), addEdge func(Edge), roleNodeID, roleName string) {
	switch roleName {
	case "root":
		addNode(Node{ID: CapSuperuser, Kind: KindCapability, Tier: 2,
			Label: "Effective superuser (policy bypass / *:*)"})
		addNode(Node{ID: CapAdminWrite, Kind: KindCapability, Tier: 2,
			Label: "Admin Center write access"})
		addEdge(Edge{From: roleNodeID, To: CapSuperuser, Kind: EdgeRootBypass, Cost: 0, Standing: true,
			Via: "opa.Engine.Evaluate returns root_bypass before consulting any policy"})
		addEdge(Edge{From: roleNodeID, To: CapAdminWrite, Kind: EdgeAdminCenter, Cost: 0, Standing: true,
			Via: "middleware.RequireAdmin accepts root"})
	case "admin":
		addNode(Node{ID: CapAdminWrite, Kind: KindCapability, Tier: 2,
			Label: "Admin Center write access"})
		addEdge(Edge{From: roleNodeID, To: CapAdminWrite, Kind: EdgeAdminCenter, Cost: 0, Standing: true,
			Via: "middleware.RequireAdmin — /admin group has no RequirePermission checks"})
	}
}

// expandPolicyViews draws policy → matched resource / credential edges
// from the same match set already nested on the policy view, so the graph
// and the tree cannot disagree.
func expandPolicyViews(addNode func(Node), addEdge func(Edge), policies []MemberPolicyView) {
	for _, p := range policies {
		pid := NodeID(KindPolicy, p.ID)
		if containsExact(p.Actions, "*") && containsExact(p.ResourcePatterns, "*") {
			addNode(Node{ID: CapSuperuser, Kind: KindCapability, Tier: 2,
				Label: "Effective superuser (policy bypass / *:*)"})
			addEdge(Edge{From: pid, To: CapSuperuser, Kind: EdgeAllowsAction, Cost: 0, Standing: true,
				Via: "policy allows *:*"})
		}
		if opa.MatchesAny(p.Actions, "pam:audit:Read") &&
			(opa.MatchesAny(p.ResourcePatterns, "pam:audit") || opa.MatchesAny(p.ResourcePatterns, "pam:audit/anything")) {
			addNode(Node{ID: CapAuditRead, Kind: KindCapability, Tier: 1, Label: "Org-wide audit read"})
			addEdge(Edge{From: pid, To: CapAuditRead, Kind: EdgeAllowsAction, Cost: 1, Standing: true,
				Finding: "H6", Via: "policy allows pam:audit:Read"})
		}
		if opa.MatchesAny(p.Actions, "pam:vault:Reveal") &&
			opa.MatchesAny(p.ResourcePatterns, "pam:vault/ANY-CREDENTIAL-ID") {
			addNode(Node{ID: CapVaultPlaintext, Kind: KindCapability, Tier: 2,
				Label: "Decrypt any vaulted credential"})
			addEdge(Edge{From: pid, To: CapVaultPlaintext, Kind: EdgeAllowsAction, Cost: 1, Standing: true,
				Finding: "C5", Via: "policy allows pam:vault:Reveal on a wildcard resource"})
		}
		for _, r := range p.MatchedResources {
			rid := NodeID(KindResource, r.ID)
			addNode(Node{
				ID: rid, Kind: KindResource, Label: r.Name,
				Attrs: map[string]string{
					"type": r.Type, "requires_jit": fmt.Sprintf("%t", r.RequiresJIT),
					"always_record": fmt.Sprintf("%t", r.AlwaysRecord),
					"active":        fmt.Sprintf("%t", r.Active),
					"access":        r.Access,
				},
			})
			kind := EdgeAllowsAction
			finding := ""
			if r.Access == "standing_connect" {
				kind = EdgeStandingUse
				finding = "C6"
			}
			addEdge(Edge{From: pid, To: rid, Kind: kind, Cost: 1, Standing: r.Standing,
				Finding: finding, Via: "policy matches pam:resource/" + r.ID + " (" + r.Access + ")"})
		}
		for _, c := range p.MatchedCredentials {
			cid := NodeID(KindCredential, c.ID)
			addNode(Node{
				ID: cid, Kind: KindCredential, Label: c.Name,
				Attrs: map[string]string{"type": c.Type, "account": c.Account, "access": c.Access},
			})
			addEdge(Edge{From: pid, To: cid, Kind: EdgeCanReveal, Cost: 1, Standing: true,
				Via: "policy matches pam:vault/" + c.ID})
		}
	}
}

// ── matching: policy patterns → concrete rows ─────────────────────────────

func matchPolicyTargets(
	p models.Policy,
	resources []models.PAMResource,
	creds []models.Credential,
) (rs []MemberResourceView, cs []MemberCredentialView) {
	rs = []MemberResourceView{}
	cs = []MemberCredentialView{}
	if !strings.EqualFold(p.Effect, string(models.PolicyEffectAllow)) {
		return rs, cs
	}

	starStar := containsExact(p.Actions, "*") && containsExact(p.Resources, "*")

	for _, r := range resources {
		if starStar {
			rs = append(rs, resourceView(r, "all", true))
			continue
		}
		access, standing, ok := resourceAccess(p, r)
		if !ok {
			continue
		}
		rs = append(rs, resourceView(r, access, standing))
	}

	reveal := starStar || opa.MatchesAny(p.Actions, "pam:vault:Reveal")
	if reveal {
		for _, c := range creds {
			if starStar || opa.MatchesAny(p.Resources, "pam:vault/"+c.ID) {
				cs = append(cs, MemberCredentialView{
					ID: c.ID, Name: c.Name, Type: c.CredentialType,
					Account: c.AccountName, Access: "reveal",
				})
			}
		}
	}
	return rs, cs
}

func resourceAccess(p models.Policy, r models.PAMResource) (access string, standing bool, ok bool) {
	arn := "pam:resource/" + r.ID
	if !opa.MatchesAny(p.Resources, arn) {
		return "", false, false
	}
	if opa.MatchesAny(p.Actions, "pam:resource:Connect") {
		if r.RequiresJIT {
			return "jit_connect", false, true
		}
		return "standing_connect", true, true
	}
	if opa.MatchesAny(p.Actions, "pam:resource:Read") {
		return "read", false, true
	}
	if opa.MatchesAny(p.Actions, "pam:resource:List") {
		return "list", false, true
	}
	return "", false, false
}

func resourceView(r models.PAMResource, access string, standing bool) MemberResourceView {
	return MemberResourceView{
		ID: r.ID, Name: r.Name, Type: r.ResourceType,
		RequiresJIT: r.RequiresJIT, AlwaysRecord: r.AlwaysRecord, Active: r.IsActive,
		Access: access, Standing: standing,
	}
}

// ── classification ────────────────────────────────────────────────────────

func isSystemRoleName(name string) bool {
	switch name {
	case "root", "admin", "user":
		return true
	}
	return false
}

func systemRank(name string) int {
	switch name {
	case "root":
		return 3
	case "admin":
		return 2
	case "user":
		return 1
	}
	return 0
}

func pickUserType(roles []models.Role) *models.Role {
	var best *models.Role
	bestRank := 0
	for i := range roles {
		r := &roles[i]
		if rank := systemRank(r.Name); rank > bestRank {
			bestRank = rank
			best = r
		}
	}
	return best
}

func originFor(role models.Role, typeRole *models.Role) string {
	if typeRole != nil && role.ID == typeRole.ID {
		return "user_type"
	}
	return "additional_role"
}

// ── views ─────────────────────────────────────────────────────────────────

func userView(u models.User) MemberUserView {
	return MemberUserView{
		ID: u.UserID, Username: u.Username, Email: u.Email, FullName: u.FullName,
		Status: u.Status, MFAEnabled: u.MFAEnabled, IsProtected: u.IsProtected,
	}
}

func roleView(
	role models.Role,
	policies []models.Policy,
	origin string,
	resources []models.PAMResource,
	creds []models.Credential,
) MemberRoleView {
	v := MemberRoleView{
		ID: role.ID, Name: role.Name, Description: role.Description, IsSystem: role.IsSystem,
		Policies: []MemberPolicyView{},
	}
	for _, p := range policies {
		v.Policies = append(v.Policies, policyView(p, origin, role.ID, role.Name, resources, creds))
	}
	return v
}

func policyView(
	p models.Policy,
	origin, originRoleID, originRoleName string,
	resources []models.PAMResource,
	creds []models.Credential,
) MemberPolicyView {
	rs, cs := matchPolicyTargets(p, resources, creds)
	return MemberPolicyView{
		ID: p.ID, Name: p.Name, Description: p.Description, Effect: p.Effect,
		Actions:          append([]string(nil), p.Actions...),
		ResourcePatterns: append([]string(nil), p.Resources...),
		IsSystem:         p.IsSystem,
		Origin:           origin,
		OriginRoleID:     originRoleID,
		OriginRoleName:   originRoleName,
		MatchedResources:   rs,
		MatchedCredentials: cs,
	}
}

func roleNode(role models.Role, isType bool) Node {
	tier := 0
	if role.Name == "root" || role.Name == "admin" {
		tier = 2
	}
	kind := "additional_role"
	if isType {
		kind = "user_type"
	}
	return Node{
		ID: NodeID(KindRole, role.ID), Kind: KindRole, Label: role.Name, Tier: tier,
		Attrs: map[string]string{"is_system": fmt.Sprintf("%t", role.IsSystem), "role_kind": kind},
	}
}

func policyNode(p models.Policy, origin string) Node {
	return policyNodeFromView(MemberPolicyView{
		ID: p.ID, Name: p.Name, Effect: p.Effect, Actions: p.Actions,
		ResourcePatterns: p.Resources, IsSystem: p.IsSystem,
	}, origin)
}

func policyNodeFromView(p MemberPolicyView, origin string) Node {
	tier := 0
	if strings.EqualFold(p.Effect, "allow") && containsExact(p.Actions, "*") && containsExact(p.ResourcePatterns, "*") {
		tier = 2
	}
	return Node{
		ID: NodeID(KindPolicy, p.ID), Kind: KindPolicy, Label: p.Name, Tier: tier,
		Attrs: map[string]string{
			"effect":     p.Effect,
			"actions":    strings.Join(p.Actions, ","),
			"resources":  strings.Join(p.ResourcePatterns, ","),
			"origin":     origin,
			"is_system":  fmt.Sprintf("%t", p.IsSystem),
		},
	}
}

func nodesSlice(g *Graph) []Node {
	out := make([]Node, 0, len(g.Nodes))
	for _, n := range g.Nodes {
		out = append(out, *n)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Kind != out[j].Kind {
			return out[i].Kind < out[j].Kind
		}
		return out[i].Label < out[j].Label
	})
	return out
}

func statsFrom(out *MemberGraph) MemberGraphStats {
	s := MemberGraphStats{
		AdditionalRoles: len(out.AdditionalRoles),
		DirectPolicies:  len(out.DirectPolicies),
		Roles:           len(out.AdditionalRoles),
	}
	if out.UserType != nil {
		s.Roles++
	}
	seenR, seenC := map[string]bool{}, map[string]bool{}
	countPol := func(ps []MemberPolicyView) {
		s.Policies += len(ps)
		for _, p := range ps {
			for _, r := range p.MatchedResources {
				if !seenR[r.ID] {
					seenR[r.ID] = true
					s.MatchedResources++
				}
				if r.Standing {
					s.StandingConnects++
				}
			}
			for _, c := range p.MatchedCredentials {
				if !seenC[c.ID] {
					seenC[c.ID] = true
					s.MatchedCredentials++
				}
			}
		}
	}
	if out.UserType != nil {
		countPol(out.UserType.Policies)
	}
	for _, r := range out.AdditionalRoles {
		countPol(r.Policies)
	}
	countPol(out.DirectPolicies)
	return s
}

func containsExact(ss []string, v string) bool {
	for _, s := range ss {
		if s == v {
			return true
		}
	}
	return false
}
