//
// Derived edges — the analytical core.
//
// The structural graph (build.go) is just the join tables drawn as arrows.
// It shows the org chart. It cannot show privilege ESCALATION, because
// escalation lives in what the handlers permit, not in what the tables
// record. This file encodes those rules.
//
// Each rule below answers: "given what this principal already holds, what
// ELSE can they cause to become true, and what does it cost them?" Every
// derived edge carries a Finding tag tying it to the code review, so the
// report doubles as a remediation queue rather than an anxiety generator.
//
// MAINTENANCE CONTRACT
//
// These rules mirror enforcement behaviour. If you change an enforcement
// path — add the missing AssertCanAssignRole call, gate the admin group
// with RequirePermission, flip the RequiresJIT default — you MUST update
// the corresponding rule here, or the analyzer will keep reporting a path
// that no longer exists. A stale analyzer is worse than none: it trains
// people to ignore it.
//
// The tests in derive_test.go pin each rule to its enforcement assumption,
// so a behaviour change that isn't reflected here fails CI.
package graph

import (
	"strings"

	"github.com/yourorg/pam/opa"
)

// Derive adds all escalation edges to a structurally-complete graph.
func Derive(g *Graph) error {
	derivePolicyPower(g)
	deriveRoleCapabilities(g)
	deriveAdminMutations(g)
	deriveVaultReach(g)
	deriveStandingResourceAccess(g)
	return nil
}

// ── 1. What does holding a policy actually get you? ───────────────────────
//
// Translates each allow policy's (actions × resources) patterns into edges
// to the capability nodes. Uses the REAL matcher from opa/engine.go via the
// exported shim, so the analyzer's notion of "does this pattern match" can
// never drift from the PDP's. That shared-matcher requirement is the single
// most important correctness property in this package: a reimplemented
// matcher would eventually disagree with production and silently hide paths.
func derivePolicyPower(g *Graph) {
	for _, n := range g.Nodes {
		if n.Kind != KindPolicy {
			continue
		}
		if !strings.EqualFold(n.Attrs["effect"], "allow") {
			// Deny policies subtract reachability. Modelling subtraction
			// properly needs per-(action,resource) evaluation rather than
			// edges; see the note in Analyzer.Run about why we report deny
			// coverage separately instead of pretending edges can express it.
			continue
		}
		actions := splitCSV(n.Attrs["actions"])
		resources := splitCSV(n.Attrs["resources"])

		// Unrestricted allow == superuser.
		if opa.MatchesAny(actions, "*") && opa.MatchesAny(resources, "*") {
			g.AddEdge(Edge{From: n.ID, To: CapSuperuser, Kind: EdgeAllowsAction,
				Cost: 0, Via: "policy allows *:*", Standing: true})
			continue
		}

		// Vault reveal on a wildcard resource == every secret. This is C5:
		// the seeded standard-user-access policy hits exactly this branch.
		if opa.MatchesAny(actions, "pam:vault:Reveal") {
			if opa.MatchesAny(resources, "pam:vault/ANY-CREDENTIAL-ID") {
				g.AddEdge(Edge{From: n.ID, To: CapVaultPlaintext, Kind: EdgeAllowsAction,
					Cost: 1, Finding: "C5", Standing: true,
					Via: "policy allows pam:vault:Reveal on a wildcard resource; " +
						"RevealCredential performs no safe-ownership check"})
			}
		}

		if opa.MatchesAny(actions, "pam:audit:Read") {
			if opa.MatchesAny(resources, "pam:audit") || opa.MatchesAny(resources, "pam:audit/anything") {
				g.AddEdge(Edge{From: n.ID, To: CapAuditRead, Kind: EdgeAllowsAction,
					Cost: 1, Finding: "H6",
					Via: "policy allows pam:audit:Read; AuditHandler.Search/ByUser " +
						"do not scope results to the caller", Standing: true})
			}
		}

		// Per-resource connect reachability.
		for _, rn := range g.Nodes {
			if rn.Kind != KindResource {
				continue
			}
			pattern := "pam:resource/" + strings.TrimPrefix(rn.ID, string(KindResource)+":")
			if opa.MatchesAny(actions, "pam:resource:Connect") && opa.MatchesAny(resources, pattern) {
				g.AddEdge(Edge{From: n.ID, To: rn.ID, Kind: EdgeAllowsAction,
					Cost: 1, Via: "policy allows pam:resource:Connect", Standing: true})
			}
		}
	}
}

// ── 2. What does holding a ROLE get you, independent of policy? ───────────
//
// This is the rule people miss. middleware.RequireAdmin reads the roles
// claim straight off the JWT and the entire /admin group has ZERO
// RequirePermission calls (verified by grep). So "admin" is not a bundle of
// policies here — it is a raw, unmediated capability. No policy edit can
// take it away; only removing the role can.
func deriveRoleCapabilities(g *Graph) {
	for _, n := range g.Nodes {
		if n.Kind != KindRole {
			continue
		}
		// Only the three account TYPES confer Admin Center / root bypass.
		// A created role, even if poorly named, does not.
		if !IsSystemAccountType(n.Label) {
			continue
		}
		switch strings.ToLower(n.Label) {
		case AccountTypeRoot:
			g.AddEdge(Edge{From: n.ID, To: CapSuperuser, Kind: EdgeRootBypass,
				Cost: 0, Standing: true,
				Via: "account type root — opa.Engine.Evaluate returns root_bypass before consulting any policy"})
			g.AddEdge(Edge{From: n.ID, To: CapAdminWrite, Kind: EdgeAdminCenter,
				Cost: 0, Via: "account type root — middleware.RequireAdmin accepts root", Standing: true})
		case AccountTypeAdmin:
			g.AddEdge(Edge{From: n.ID, To: CapAdminWrite, Kind: EdgeAdminCenter,
				Cost: 0, Standing: true,
				Via: "account type admin — RequireAdmin; Admin Center is type-gated, not a created role"})
		}
	}
}

// ── 3. What can someone with Admin Center write access DO to the graph? ───
//
// These are the edges that turn a bounded role into unbounded authority.
// Each corresponds to a missing guard in the review.
func deriveAdminMutations(g *Graph) {
	if _, ok := g.Nodes[CapAdminWrite]; !ok {
		return
	}

	// Created roles only. Account types user/admin/root are not assignable
	// by admin. Only root delegates admin (CAN_DELEGATE).
	for _, n := range g.Nodes {
		if n.Kind != KindRole || IsSystemAccountType(n.Label) {
			continue
		}
		g.AddEdge(Edge{From: CapAdminWrite, To: n.ID, Kind: EdgeCanAssign,
			Cost: 1, Standing: true,
			Via: "POST /api/v1/pam/admin/identity/users/:id/roles — created role \"" +
				n.Label + "\" (system types user/admin/root excluded)"})
	}

	var rootID, adminTypeID string
	for _, n := range g.Nodes {
		if n.Kind != KindRole {
			continue
		}
		switch strings.ToLower(n.Label) {
		case AccountTypeRoot:
			rootID = n.ID
		case AccountTypeAdmin:
			adminTypeID = n.ID
		}
	}
	if rootID != "" && adminTypeID != "" {
		g.AddEdge(Edge{From: rootID, To: adminTypeID, Kind: EdgeCanDelegate,
			Cost: 1, Standing: true,
			Via: "POST /api/v1/pam/admin/identity/users/:id/delegate-admin — root only; admin cannot mint admin or root"})
	}

	// C2 — AttachPolicy likewise. Reaching a *:* policy this way produces no
	// delegation record, so GET /users/:id/delegation still reports "none".
	for _, n := range g.Nodes {
		if n.Kind != KindPolicy || !strings.EqualFold(n.Attrs["effect"], "allow") {
			continue
		}
		finding := ""
		if n.Tier >= 2 {
			finding = "C2"
		}
		g.AddEdge(Edge{From: CapAdminWrite, To: n.ID, Kind: EdgeCanAttach,
			Cost: 1, Finding: finding, Standing: true,
			Via: "POST /api/v1/pam/admin/identity/users/:id/policies — no rank check; " +
				"leaves no delegation record"})
	}

	// Admin Center also exposes org-wide audit read directly.
	g.AddEdge(Edge{From: CapAdminWrite, To: CapAuditRead, Kind: EdgeAllowsAction,
		Cost: 0, Via: "GET /api/v1/pam/admin/audit", Standing: true})
}

// ── 4. From vault plaintext to the resources it unlocks ───────────────────
func deriveVaultReach(g *Graph) {
	if _, ok := g.Nodes[CapVaultPlaintext]; !ok {
		return
	}
	for _, n := range g.Nodes {
		if n.Kind != KindCredential {
			continue
		}
		g.AddEdge(Edge{From: CapVaultPlaintext, To: n.ID, Kind: EdgeCanReveal,
			Cost: 1, Finding: "C5", Standing: true,
			Via: "POST /api/v1/pam/credentials/:id/reveal — credential IDs are " +
				"enumerable via GET /safes and GET /safes/:id/credentials, both unscoped"})
	}
}

// ── 5. Standing (non-JIT) resource access ─────────────────────────────────
//
// C6: RequiresJIT defaults to false, and RequireActiveGrant short-circuits
// with c.Next() when it's false. So for any resource nobody explicitly
// opted in, a Connect permission is permanent standing access — no request,
// no approval, no expiry, and no recording (AlwaysRecord defaults false too).
func deriveStandingResourceAccess(g *Graph) {
	for _, n := range g.Nodes {
		if n.Kind != KindResource || n.Attrs["requires_jit"] == "true" {
			continue
		}
		for _, p := range g.Nodes {
			if p.Kind != KindPolicy || !strings.EqualFold(p.Attrs["effect"], "allow") {
				continue
			}
			actions := splitCSV(p.Attrs["actions"])
			resources := splitCSV(p.Attrs["resources"])
			pattern := "pam:resource/" + strings.TrimPrefix(n.ID, string(KindResource)+":")
			if opa.MatchesAny(actions, "pam:resource:Connect") && opa.MatchesAny(resources, pattern) {
				g.AddEdge(Edge{From: p.ID, To: n.ID, Kind: EdgeStandingUse,
					Cost: 1, Finding: "C6", Standing: true,
					Via: "resource.requires_jit=false — RequireActiveGrant short-circuits; " +
						"access is standing, unapproved, un-time-boxed" +
						recordingNote(n.Attrs["always_record"])})
			}
		}
	}
}

func recordingNote(alwaysRecord string) string {
	if alwaysRecord == "true" {
		return ""
	}
	return ", and unrecorded (always_record=false)"
}

func splitCSV(s string) []string {
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if t := strings.TrimSpace(p); t != "" {
			out = append(out, t)
		}
	}
	return out
}
