// pam/internal/services/sweeper.go
//
// Auto-revocation worker.
//
// Deliberately built on time.Ticker rather than robfig/cron or go-co-op/gocron:
// the schedule is a fixed short interval, not a crontab, so a cron parser adds
// a dependency and a failure mode without adding capability. Multi-replica
// safety comes from FOR UPDATE SKIP LOCKED in the queries, not from the timer.
//
// Guarantees:
//   - a panic in one pass does not kill the worker (each pass is recovered)
//   - passes never overlap (the ticker body runs synchronously)
//   - shutdown is cooperative via context; Stop() waits for the in-flight pass
package services

import (
	"context"
	"sync"
	"time"

	"go.uber.org/zap"
)

// ExpiryReconciler is anything with expired/idle state to clean up on the
// sweeper's cadence. Kept as a narrow interface rather than a concrete type
// so internal/webproxy (which imports this package for ResourceService and
// AuditService) can be swept without this package importing it back — that
// would be an import cycle.
type ExpiryReconciler interface {
	// ReconcileExpired closes whatever has aged out, returning how many.
	ReconcileExpired(ctx context.Context) (int, error)
	// Name identifies the reconciler in sweeper logs.
	Name() string
}

// Sweeper periodically expires grants and requests and activates break-glass.
type Sweeper struct {
	jit         *JITService
	resources   *ResourceService
	reconcilers []ExpiryReconciler
	interval    time.Duration
	logger      *zap.Logger

	stopOnce sync.Once
	done     chan struct{}
	cancel   context.CancelFunc
}

// NewSweeper builds the worker. interval <= 0 falls back to 30s. resources
// may be nil (recording reconciliation is then skipped, see RunOnce) — kept
// nil-able rather than required so a caller that has not wired up the
// recording pipeline yet doesn't have to change every NewSweeper call site
// at once.
func NewSweeper(jit *JITService, resources *ResourceService, interval time.Duration, logger *zap.Logger) *Sweeper {
	if interval <= 0 {
		interval = 30 * time.Second
	}
	return &Sweeper{
		jit:       jit,
		resources: resources,
		interval:  interval,
		logger:    logger,
		done:      make(chan struct{}),
	}
}

// Register adds an ExpiryReconciler to every subsequent sweep pass. Call
// before Start. A nil reconciler is ignored, so a caller can pass an
// optional, feature-flagged subsystem without branching at the call site.
func (s *Sweeper) Register(r ExpiryReconciler) {
	if r == nil {
		return
	}
	s.reconcilers = append(s.reconcilers, r)
}

// Start runs the worker until Stop is called or the parent context is done.
func (s *Sweeper) Start(parent context.Context) {
	ctx, cancel := context.WithCancel(parent)
	s.cancel = cancel

	go func() {
		defer close(s.done)
		ticker := time.NewTicker(s.interval)
		defer ticker.Stop()

		s.logger.Info("sweeper.started", zap.Duration("interval", s.interval))

		// Run one pass immediately so a restart does not leave expired grants
		// live for a whole interval.
		s.RunOnce(ctx)

		for {
			select {
			case <-ctx.Done():
				s.logger.Info("sweeper.stopped")
				return
			case <-ticker.C:
				s.RunOnce(ctx)
			}
		}
	}()
}

// Stop signals the worker and waits for the current pass to finish.
func (s *Sweeper) Stop(timeout time.Duration) {
	s.stopOnce.Do(func() {
		if s.cancel != nil {
			s.cancel()
		}
	})
	select {
	case <-s.done:
	case <-time.After(timeout):
		s.logger.Warn("sweeper.stop.timeout", zap.Duration("timeout", timeout))
	}
}

// RunOnce executes a single sweep pass. Exported so it can be triggered
// manually (tests, admin "force sweep" tooling) without waiting for the tick.
func (s *Sweeper) RunOnce(ctx context.Context) SweepResult {
	var res SweepResult

	defer func() {
		if r := recover(); r != nil {
			s.logger.Error("sweeper.panic", zap.Any("recovered", r))
		}
	}()

	started := time.Now()

	// Order matters: activate first so a break-glass grant that is due now is
	// not created and immediately expired in the same pass by a stale clock.
	activated, errs := s.jit.ActivateDueBreakglass(ctx)
	res.BreakglassActivated = activated
	res.Errors += errs

	expired, killed, errs := s.jit.ExpireDueGrants(ctx)
	res.GrantsExpired = expired
	res.SessionsKilled = killed
	res.Errors += errs

	staleReqs, errs := s.jit.ExpireStaleRequests(ctx)
	res.RequestsExpired = staleReqs
	res.Errors += errs

	// Recording orphan reconciliation piggybacks on this same worker rather
	// than getting its own ticker — it's cheap, idempotent, and there is no
	// reason to run it on a different cadence than grant expiry. resources
	// is nil until the recording pipeline is wired up in main.go, so this
	// degrades to a no-op rather than a crash on any deployment that hasn't
	// done that yet.
	if s.resources != nil {
		orphaned, err := s.resources.ReconcileOrphanedRecordings(ctx)
		if err != nil {
			s.logger.Error("sweeper.reconcile_recordings.fail", zap.Error(err))
			res.Errors++
		} else {
			res.OrphanedRecordingsFailed = orphaned
		}
	}

	// Registered subsystem reconcilers (e.g. brokered web sessions aging out
	// or going idle — see internal/webproxy). Same rationale as recording
	// reconciliation above: cheap, idempotent, and no reason to run on a
	// different cadence than grant expiry.
	for _, rec := range s.reconcilers {
		closed, err := rec.ReconcileExpired(ctx)
		if err != nil {
			s.logger.Error("sweeper.reconcile.fail", zap.String("reconciler", rec.Name()), zap.Error(err))
			res.Errors++
			continue
		}
		if closed > 0 {
			if res.ReconciledByName == nil {
				res.ReconciledByName = map[string]int{}
			}
			res.ReconciledByName[rec.Name()] = closed
		}
	}

	if res.GrantsExpired > 0 || res.RequestsExpired > 0 || res.BreakglassActivated > 0 ||
		res.OrphanedRecordingsFailed > 0 || len(res.ReconciledByName) > 0 || res.Errors > 0 {
		s.logger.Info("sweeper.pass",
			zap.Int("grants_expired", res.GrantsExpired),
			zap.Int("sessions_killed", res.SessionsKilled),
			zap.Int("requests_expired", res.RequestsExpired),
			zap.Int("breakglass_activated", res.BreakglassActivated),
			zap.Int("orphaned_recordings_failed", res.OrphanedRecordingsFailed),
			zap.Any("reconciled", res.ReconciledByName),
			zap.Int("errors", res.Errors),
			zap.Duration("took", time.Since(started)),
		)
	}
	return res
}
