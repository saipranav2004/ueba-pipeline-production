// pam/internal/middleware/admin.go
//
// The Admin Center gate.
//
// This used to authenticate the external IAM console via a shared service
// token (RequireServiceToken) plus a forwarded X-Admin-User-Id header to
// attribute actions to a human. That entire model is gone: the Admin Center
// is now a first-class part of this same PAM backend, reached by a real
// PAM user who logged in and holds the "root" or "admin" role — the same
// PAMAuth-issued JWT every other route uses. Attribution is automatic
// because the acting user's own identity (user_id/username, already set in
// context by PAMAuth) IS the admin's identity — there is no separate
// identity to forward.
package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// RequireAdmin gates the entire /api/v1/pam/admin group, requiring "root" or
// "admin".
//
// ---------------------------------------------------------------------------
// WHY THIS ASKS THE DATABASE
// ---------------------------------------------------------------------------
// It used to read the "roles" claim PAMAuth put in context and nothing else,
// on the reasoning that the JWT already carries the answer and the gate should
// stay fast. That is true of a GRANT — and wrong about a REVOKE.
//
// Roles are baked into the token at login (AuthService.issueTokensForUser) and
// there is no refresh endpoint, so the claim is a snapshot of who the user was
// when they signed in. When root revokes an admin delegation, the role row is
// deleted immediately — but the target's existing token still says "admin",
// and a claim-only gate kept honouring it for the remainder of the token's
// life (PAM_JWT_ACCESS_TTL_MIN, 30 minutes by default). Root would revoke
// access, see the console confirm it, and the revoked administrator would keep
// operating the Admin Center for another half hour. Revocation that takes
// effect "in a while" is not revocation.
//
// So the live role set decides. That is one indexed lookup on a path that
// already performs several, and it is the difference between a privilege
// change being immediate and being eventually-consistent with a 30-minute tail.
//
// The claim is kept as a FALLBACK for one case only: the lookup itself
// failing. Failing closed there would mean a database blip locks every
// administrator out of the console — including whoever would fix the blip —
// so a signed, server-issued claim from at most one token-lifetime ago is the
// safer answer, and it is logged at Error so the degradation is visible.
func RequireAdmin(roles services.RoleResolver, log *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		claimRaw, _ := c.Get("roles")
		claimRoles, _ := claimRaw.([]string)

		effective := claimRoles
		if roles != nil {
			if userIDRaw, ok := c.Get("user_id"); ok {
				if userID, ok := userIDRaw.(string); ok && userID != "" {
					live, err := roles.RoleNamesForUser(userID)
					if err != nil {
						log.Error("admin_gate.resolve_roles.fail",
							zap.String("user_id", userID), zap.Error(err))
					} else {
						effective = live
						// Keep the rest of the request honest too: handlers and
						// the MFA/delegation services read "roles" off the
						// context, and they should see the same live answer
						// this gate just decided on rather than the stale claim.
						c.Set("roles", live)
					}
				}
			}
		}

		if !services.IsAdminOrRoot(effective) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "Admin Center access requires the root or admin role",
				"code":    "admin_access_required",
			})
			return
		}
		c.Next()
	}
}

// AdminIdentityFromContext returns the acting administrator's identity for
// audit attribution. Now simply the authenticated PAM user — kept as a
// named helper (rather than inlining c.Get calls at every call site) so
// admin_handler.go's existing call sites needed no changes at all.
func AdminIdentityFromContext(c *gin.Context) (userID, username string) {
	if v, ok := c.Get("user_id"); ok {
		userID, _ = v.(string)
	}
	if v, ok := c.Get("username"); ok {
		username, _ = v.(string)
	}
	return userID, username
}
