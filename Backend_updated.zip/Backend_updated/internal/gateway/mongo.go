// pam/internal/gateway/mongo.go
//
// MongoDB connector for the in-browser terminal. Deliberately a
// CONSTRAINED command subset, not a full mongosh JS engine (embedding a JS
// runtime just for a terminal is a large, unjustified attack surface for
// what this needs to do) — documented explicitly here and surfaced to the
// user as a clear "unsupported syntax" message rather than silently
// failing, per this project's existing disclosed-limitation convention.
//
// Supported:
//
//	show dbs
//	show collections
//	db.<collection>.find(<jsonFilter>)
//	db.<collection>.findOne(<jsonFilter>)
//	db.<collection>.insertOne(<jsonDoc>)
//	db.<collection>.updateOne(<jsonFilter>, <jsonUpdate>)
//	db.<collection>.deleteOne(<jsonFilter>)
//	db.<collection>.countDocuments(<jsonFilter>)
//	db.<collection>.aggregate(<jsonArrayPipeline>)
//
// Arguments must be valid JSON (not full JS object-literal syntax — no
// unquoted keys, no single quotes). This is the same trade-off the original
// design doc for this feature called out: "not a full mongosh JS engine."
package gateway

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"github.com/yourorg/pam/internal/recorder"
	"github.com/yourorg/pam/internal/services"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.uber.org/zap"
)

var mongoCommandPattern = regexp.MustCompile(`^db\.([A-Za-z0-9_]+)\.([A-Za-z]+)\((.*)\)$`)

func runMongoTerminal(ctx context.Context, conn wsConn, info *services.ConnectionInfo, logCmd commandLogger, logger *zap.Logger) error {
	dbName := info.DatabaseName
	if dbName == "" {
		dbName = "admin"
	}

	uri := fmt.Sprintf("mongodb://%s:%d/?connectTimeoutMS=8000&serverSelectionTimeoutMS=8000", info.Host, info.Port)
	clientOpts := options.Client().ApplyURI(uri)
	if info.AccountName != "" {
		clientOpts.SetAuth(options.Credential{
			Username:   info.AccountName,
			Password:   info.Password,
			AuthSource: dbName,
		})
	}

	connectCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	client, err := mongo.Connect(connectCtx, clientOpts)
	cancel()
	if err != nil {
		logger.Warn("gateway.mongo.connect.fail", zap.String("host", info.Host), zap.Error(err))
		_ = writeLine(conn, "Failed to connect to MongoDB: "+err.Error())
		return err
	}
	defer func() {
		_ = client.Disconnect(context.Background())
	}()

	pingCtx, pingCancel := context.WithTimeout(ctx, 8*time.Second)
	if err := client.Ping(pingCtx, nil); err != nil {
		pingCancel()
		_ = writeLine(conn, "Failed to reach MongoDB: "+err.Error())
		return err
	}
	pingCancel()

	database := client.Database(dbName)

	_ = writeLine(conn, fmt.Sprintf(
		"Connected to MongoDB at %s:%d/%s. Constrained command subset only (show dbs, show collections, "+
			"db.<coll>.find/findOne/insertOne/updateOne/deleteOne/countDocuments/aggregate — JSON arguments only). Type exit to close.",
		info.Host, info.Port, dbName))
	_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"> "))

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		_, msg, err := conn.ReadMessage()
		if err != nil {
			return err
		}
		line := strings.TrimSpace(string(msg))
		if line == "" {
			_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"> "))
			continue
		}
		if strings.EqualFold(line, "exit") || strings.EqualFold(line, "quit") {
			_ = writeLine(conn, "bye")
			return nil
		}

		cmdStart := time.Now()
		output, execErr := executeMongoCommand(ctx, client, database, line)
		elapsedMs := time.Since(cmdStart).Milliseconds()
		if execErr != nil {
			logCmd(line, false, execErr.Error(), elapsedMs)
			_ = writeLine(conn, "Error: "+execErr.Error())
		} else {
			logCmd(line, true, "", elapsedMs)
			_ = writeLine(conn, output)
		}
		_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"> "))
	}
}

func executeMongoCommand(ctx context.Context, client *mongo.Client, database *mongo.Database, line string) (string, error) {
	switch {
	case strings.EqualFold(line, "show dbs"):
		names, err := client.ListDatabaseNames(ctx, bson.D{})
		if err != nil {
			return "", err
		}
		return strings.Join(names, "\r\n"), nil

	case strings.EqualFold(line, "show collections"):
		names, err := database.ListCollectionNames(ctx, bson.D{})
		if err != nil {
			return "", err
		}
		return strings.Join(names, "\r\n"), nil
	}

	m := mongoCommandPattern.FindStringSubmatch(line)
	if m == nil {
		return "", fmt.Errorf("unsupported syntax — only show dbs / show collections / db.<coll>.<method>(<json args>) are supported (see the connect banner for the full method list)")
	}
	collName, method, argsRaw := m[1], m[2], strings.TrimSpace(m[3])
	coll := database.Collection(collName)

	switch strings.ToLower(method) {
	case "find":
		filter, err := parseBSONArg(argsRaw)
		if err != nil {
			return "", err
		}
		cur, err := coll.Find(ctx, filter)
		if err != nil {
			return "", err
		}
		defer cur.Close(ctx)
		var docs []bson.M
		if err := cur.All(ctx, &docs); err != nil {
			return "", err
		}
		return formatMongoDocs(redactSensitiveFields(docs)), nil

	case "findone":
		filter, err := parseBSONArg(argsRaw)
		if err != nil {
			return "", err
		}
		var doc bson.M
		err = coll.FindOne(ctx, filter).Decode(&doc)
		if err == mongo.ErrNoDocuments {
			return "null", nil
		}
		if err != nil {
			return "", err
		}
		return formatMongoDoc(redactSensitiveFieldsOne(doc)), nil

	case "insertone":
		doc, err := parseBSONArg(argsRaw)
		if err != nil {
			return "", err
		}
		res, err := coll.InsertOne(ctx, doc)
		if err != nil {
			return "", err
		}
		return fmt.Sprintf("Inserted _id: %v", res.InsertedID), nil

	case "updateone":
		parts, err := splitTwoJSONArgs(argsRaw)
		if err != nil {
			return "", err
		}
		filter, err := parseBSONArg(parts[0])
		if err != nil {
			return "", err
		}
		update, err := parseBSONArg(parts[1])
		if err != nil {
			return "", err
		}
		res, err := coll.UpdateOne(ctx, filter, update)
		if err != nil {
			return "", err
		}
		return fmt.Sprintf("matched: %d, modified: %d", res.MatchedCount, res.ModifiedCount), nil

	case "deleteone":
		filter, err := parseBSONArg(argsRaw)
		if err != nil {
			return "", err
		}
		res, err := coll.DeleteOne(ctx, filter)
		if err != nil {
			return "", err
		}
		return fmt.Sprintf("deleted: %d", res.DeletedCount), nil

	case "countdocuments":
		filter, err := parseBSONArg(argsRaw)
		if err != nil {
			return "", err
		}
		n, err := coll.CountDocuments(ctx, filter)
		if err != nil {
			return "", err
		}
		return fmt.Sprintf("%d", n), nil

	case "aggregate":
		var pipeline []bson.M
		if strings.TrimSpace(argsRaw) == "" {
			pipeline = []bson.M{}
		} else if err := json.Unmarshal([]byte(argsRaw), &pipeline); err != nil {
			return "", fmt.Errorf("aggregate() argument must be a JSON array pipeline: %w", err)
		}
		cur, err := coll.Aggregate(ctx, pipeline)
		if err != nil {
			return "", err
		}
		defer cur.Close(ctx)
		var docs []bson.M
		if err := cur.All(ctx, &docs); err != nil {
			return "", err
		}
		return formatMongoDocs(redactSensitiveFields(docs)), nil

	default:
		return "", fmt.Errorf("unsupported method %q — supported: find, findOne, insertOne, updateOne, deleteOne, countDocuments, aggregate", method)
	}
}

// parseBSONArg parses one JSON-object argument (or the empty string, which
// means "match everything" / "{}"), returning a bson.M filter/document.
func parseBSONArg(raw string) (bson.M, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return bson.M{}, nil
	}
	var m bson.M
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return nil, fmt.Errorf("argument must be valid JSON, e.g. {\"field\": \"value\"}: %w", err)
	}
	return m, nil
}

// splitTwoJSONArgs splits "arg1, arg2" into its two top-level JSON object
// arguments (used by updateOne). Uses brace-depth tracking rather than a
// naive comma split, since either argument may itself contain commas.
func splitTwoJSONArgs(raw string) ([]string, error) {
	depth := 0
	for i, ch := range raw {
		switch ch {
		case '{':
			depth++
		case '}':
			depth--
		case ',':
			if depth == 0 {
				return []string{strings.TrimSpace(raw[:i]), strings.TrimSpace(raw[i+1:])}, nil
			}
		}
	}
	return nil, fmt.Errorf("updateOne requires two JSON arguments: a filter and an update, e.g. ({\"_id\":1}, {\"$set\":{\"x\":1}})")
}

// redactSensitiveFieldsOne walks a decoded document and replaces the value
// of any field whose NAME looks sensitive (password, secret, token, ...)
// with a fixed marker, recursing into nested documents and arrays of
// documents. This is the Mongo analogue of the Postgres connector's
// per-column redaction: a returned document's field name IS the key
// context recorder.MaskSecrets needs but can't find on its own — a JSON
// value like "S3cr3t!" carries no key alongside it once it's been pulled
// out into `{"password": "S3cr3t!"}` and re-serialized; the key is a
// sibling in the map, not text adjacent to the value. Mutates and returns
// the same map for convenience at the call sites above.
func redactSensitiveFieldsOne(doc bson.M) bson.M {
	for k, v := range doc {
		if recorder.ReferencesSecretKey(k) {
			doc[k] = "***MASKED***"
			continue
		}
		switch nested := v.(type) {
		case bson.M:
			doc[k] = redactSensitiveFieldsOne(nested)
		case []bson.M:
			doc[k] = redactSensitiveFields(nested)
		case map[string]interface{}:
			doc[k] = redactSensitiveFieldsOne(bson.M(nested))
		}
	}
	return doc
}

func redactSensitiveFields(docs []bson.M) []bson.M {
	for i := range docs {
		docs[i] = redactSensitiveFieldsOne(docs[i])
	}
	return docs
}

func formatMongoDoc(doc bson.M) string {
	b, err := json.MarshalIndent(doc, "", "  ")
	if err != nil {
		return fmt.Sprintf("%v", doc)
	}
	return string(b)
}

func formatMongoDocs(docs []bson.M) string {
	if len(docs) == 0 {
		return "(no documents)"
	}
	var parts []string
	for _, d := range docs {
		parts = append(parts, formatMongoDoc(d))
	}
	return strings.Join(parts, "\r\n")
}
