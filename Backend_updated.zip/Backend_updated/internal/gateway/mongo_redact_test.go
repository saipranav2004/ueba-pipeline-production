package gateway

import (
	"testing"

	"go.mongodb.org/mongo-driver/bson"
)

func TestRedactSensitiveFieldsOne(t *testing.T) {
	doc := bson.M{
		"_id":      "u1",
		"username": "alice",
		"password": "S3cr3t!",
		"profile": bson.M{
			"apiKey": "sk-abc123",
			"bio":    "hello",
		},
		"tokens": []bson.M{
			{"token": "tok-1", "label": "a"},
			{"token": "tok-2", "label": "b"},
		},
	}

	got := redactSensitiveFieldsOne(doc)

	if got["username"] != "alice" {
		t.Errorf("username should be untouched, got %v", got["username"])
	}
	if got["password"] != "***MASKED***" {
		t.Errorf("password should be masked, got %v", got["password"])
	}
	nested, ok := got["profile"].(bson.M)
	if !ok {
		t.Fatalf("profile should remain a bson.M, got %T", got["profile"])
	}
	if nested["apiKey"] != "***MASKED***" {
		t.Errorf("nested apiKey should be masked, got %v", nested["apiKey"])
	}
	if nested["bio"] != "hello" {
		t.Errorf("nested bio should be untouched, got %v", nested["bio"])
	}
	arr, ok := got["tokens"].([]bson.M)
	if !ok {
		t.Fatalf("tokens should remain []bson.M, got %T", got["tokens"])
	}
	for i, item := range arr {
		if item["token"] != "***MASKED***" {
			t.Errorf("tokens[%d].token should be masked, got %v", i, item["token"])
		}
		if item["label"] == "***MASKED***" {
			t.Errorf("tokens[%d].label should NOT be masked, got %v", i, item["label"])
		}
	}
}

