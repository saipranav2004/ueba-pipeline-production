// pam/internal/gateway/ssh.go
//
// SSH connector for the in-browser terminal. Deliberately NOT a raw
// interactive PTY: every other connector in this package (redis.go,
// postgres.go, mongo.go) works by reading one full line from the WebSocket
// per user-submitted command and writing one reply back — there is no
// keystroke-by-keystroke byte stream between the browser and this handler.
// A real interactive shell (vim, top, tab-completion) needs raw PTY
// semantics that model doesn't support, so instead each submitted line is
// run as a single non-interactive command over its own SSH session channel
// (the same thing `ssh host <command>` does), multiplexed over one
// long-lived SSH connection for the lifetime of the browser session. That
// covers the overwhelming majority of "run a few commands on a box"
// PAM use cases without taking on a full PTY-relay rewrite of this package.
//
// Auth: the vaulted secret is tried as an SSH private key first (covers
// CredentialTypeSSHKey) and falls back to password auth if it doesn't parse
// as one (covers CredentialTypePassword) — ConnectionInfo has no
// credential-type field to branch on directly, so this mirrors what the
// secret actually looks like instead of what it's labeled as.
//
// Host key verification is deliberately not enforced (see sshClientConfig)
// — there is no known-hosts store anywhere in this codebase yet. Same
// disclosed-limitation posture as mongo.go's constrained command subset:
// called out here rather than silently shipped.
package gateway

import (
	"context"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
	"golang.org/x/crypto/ssh"
)

func runSSHTerminal(ctx context.Context, conn wsConn, info *services.ConnectionInfo, logCmd commandLogger, logger *zap.Logger) error {
	config := &ssh.ClientConfig{
		User:            info.AccountName,
		Auth:            sshAuthMethods(info.Password),
		HostKeyCallback: ssh.InsecureIgnoreHostKey(), //nolint:gosec // no known-hosts store yet — see file doc comment
		Timeout:         8 * time.Second,
	}

	dialCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	client, err := dialSSH(dialCtx, fmt.Sprintf("%s:%d", info.Host, info.Port), config)
	cancel()
	if err != nil {
		logger.Warn("gateway.ssh.connect.fail", zap.String("host", info.Host), zap.Error(err))
		_ = writeLine(conn, "Failed to connect over SSH: "+err.Error())
		return err
	}
	defer client.Close()

	prompt := fmt.Sprintf("%s@%s:~$ ", info.AccountName, info.Host)
	_ = writeLine(conn, fmt.Sprintf(
		"Connected to %s@%s:%d over SSH. Each line runs as one non-interactive command (like `ssh host <command>`) — full-screen programs (vim, top, less) are not supported. Type exit to close.",
		info.AccountName, info.Host, info.Port))
	_ = conn.WriteMessage(websocket.TextMessage, []byte(prompt))

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		_, msg, err := conn.ReadMessage()
		if err != nil {
			return err
		}
		line := strings.TrimSpace(string(msg))
		if line == "" {
			_ = conn.WriteMessage(websocket.TextMessage, []byte(prompt))
			continue
		}
		if line == "exit" || line == "quit" {
			_ = writeLine(conn, "bye")
			return nil
		}

		cmdStart := time.Now()
		execCtx, execCancel := context.WithTimeout(ctx, 30*time.Second)
		output, execErr := runSSHCommand(execCtx, client, line)
		execCancel()
		elapsedMs := time.Since(cmdStart).Milliseconds()

		if execErr != nil {
			logCmd(line, false, execErr.Error(), elapsedMs)
			_ = writeLine(conn, output+"\r\n"+execErr.Error())
		} else {
			logCmd(line, true, "", elapsedMs)
			_ = writeLine(conn, output)
		}
		_ = conn.WriteMessage(websocket.TextMessage, []byte(prompt))
	}
}

// dialSSH is ssh.Dial with an actual context deadline — the stdlib ssh
// package only exposes a fixed Timeout on ClientConfig (applies to the TCP
// dial, not to being cancelled early by the caller's context), so this
// dials via net.Dialer.DialContext first and hands the resulting conn to
// ssh.NewClientConn, the same two-step ssh.Dial itself does internally.
func dialSSH(ctx context.Context, addr string, config *ssh.ClientConfig) (*ssh.Client, error) {
	d := net.Dialer{Timeout: config.Timeout}
	netConn, err := d.DialContext(ctx, "tcp", addr)
	if err != nil {
		return nil, err
	}
	sshConn, chans, reqs, err := ssh.NewClientConn(netConn, addr, config)
	if err != nil {
		return nil, err
	}
	return ssh.NewClient(sshConn, chans, reqs), nil
}

// sshAuthMethods tries the vaulted secret as a private key first, falling
// back to password auth if it doesn't parse as one — see file doc comment.
func sshAuthMethods(secret string) []ssh.AuthMethod {
	if signer, err := ssh.ParsePrivateKey([]byte(secret)); err == nil {
		return []ssh.AuthMethod{ssh.PublicKeys(signer)}
	}
	return []ssh.AuthMethod{ssh.Password(secret)}
}

// runSSHCommand runs one non-interactive command on its own session channel
// (matching how a real, unmasked ssh session's stdout+stderr looks combined
// together) and returns its combined output. Unlike the Redis/Postgres/Mongo
// connectors, there is no result *structure* here to anchor a redaction on
// — a shell command's output is opaque text — so, same trade-off mongo.go's
// doc comment discloses for its constrained command subset, output is
// recorded and logged as-is. That is the intended behavior for a session
// recorder (capturing exactly what happened, including anything sensitive a
// command chose to print, is the point of the audit trail), not an
// oversight.
func runSSHCommand(ctx context.Context, client *ssh.Client, cmd string) (string, error) {
	session, err := client.NewSession()
	if err != nil {
		return "", err
	}
	defer session.Close()

	type result struct {
		out []byte
		err error
	}
	done := make(chan result, 1)
	go func() {
		out, err := session.CombinedOutput(cmd)
		done <- result{out, err}
	}()

	select {
	case <-ctx.Done():
		_ = session.Signal(ssh.SIGKILL)
		_ = session.Close()
		return "", ctx.Err()
	case r := <-done:
		return strings.TrimRight(string(r.out), "\r\n"), r.err
	}
}
