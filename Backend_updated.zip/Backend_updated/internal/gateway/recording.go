// pam/internal/gateway/recording.go
//
// RecordingConn wraps the real *websocket.Conn so that every command a user
// sends and every reply the terminal sends back also lands in a
// recorder.Cast, without any of the three protocol runners (redis.go,
// postgres.go, mongo.go) needing to know recording exists at all — they
// already only ever call ReadMessage/WriteMessage on whatever `conn` they
// were handed, so swapping in a wrapper that satisfies the same minimal
// interface is a transparent, none-of-your-business change from their side.
package gateway

import (
	"sync"

	"github.com/gorilla/websocket"
	"github.com/yourorg/pam/internal/recorder"
)

// wsConn is the minimal surface the protocol runners actually use. Both
// *websocket.Conn and *RecordingConn satisfy it; runXTerminal functions take
// this interface rather than the concrete gorilla type so a recording
// session and a non-recording session run through the exact same code path.
type wsConn interface {
	ReadMessage() (messageType int, p []byte, err error)
	WriteMessage(messageType int, data []byte) error
}

// RecordingConn is a wsConn that mirrors every message into a recorder.Cast.
//
// The mutex here is not just about the cast: gateway.go's kill-notice
// goroutine (the one watching ctx.Done()) writes a "session terminated"
// message and closes the connection concurrently with whatever the main
// protocol loop is doing. gorilla's websocket.Conn explicitly only
// supports one concurrent reader and one concurrent writer — that was
// already a latent race before this file existed. Serializing writes here
// fixes it as a side effect of adding recording, not something recording
// itself needed.
type RecordingConn struct {
	inner wsConn
	cast  *recorder.Cast
	mu    sync.Mutex
}

// NewRecordingConn wraps conn so every message also goes to cast.
func NewRecordingConn(conn *websocket.Conn, cast *recorder.Cast) *RecordingConn {
	return &RecordingConn{inner: conn, cast: cast}
}

func (r *RecordingConn) ReadMessage() (int, []byte, error) {
	mt, p, err := r.inner.ReadMessage()
	if err == nil && mt == websocket.TextMessage {
		r.cast.Input(p)
	}
	return mt, p, err
}

func (r *RecordingConn) WriteMessage(messageType int, data []byte) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if messageType == websocket.TextMessage {
		r.cast.Output(data)
	}
	return r.inner.WriteMessage(messageType, data)
}
