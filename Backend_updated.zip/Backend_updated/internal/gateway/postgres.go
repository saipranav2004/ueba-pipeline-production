// pam/internal/gateway/postgres.go
//
// PostgreSQL connector for the in-browser terminal. Raw SQL over a real
// wire connection (pgx, the same driver family GORM's own postgres driver
// uses elsewhere in this codebase) — whatever the user types is executed
// exactly as psql would run it, with a psql-like aligned table for results.
package gateway

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"github.com/jackc/pgx/v5"
	"github.com/yourorg/pam/internal/recorder"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

func runPostgresTerminal(ctx context.Context, conn wsConn, info *services.ConnectionInfo, logCmd commandLogger, logger *zap.Logger) error {
	dbName := info.DatabaseName
	if dbName == "" {
		dbName = "postgres"
	}
	connString := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=prefer connect_timeout=8",
		info.Host, info.Port, info.AccountName, info.Password, dbName)

	connectCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	pgConn, err := pgx.Connect(connectCtx, connString)
	cancel()
	if err != nil {
		logger.Warn("gateway.postgres.connect.fail", zap.String("host", info.Host), zap.Error(err))
		_ = writeLine(conn, "Failed to connect to PostgreSQL: "+sanitizePgError(err))
		return err
	}
	defer pgConn.Close(context.Background())

	_ = writeLine(conn, fmt.Sprintf("Connected to PostgreSQL at %s:%d/%s. Type SQL statements (end with ; optional); type \\q to close.", info.Host, info.Port, dbName))
	_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"=> "))

	var buffer strings.Builder

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		_, msg, err := conn.ReadMessage()
		if err != nil {
			return err
		}
		line := string(msg)
		trimmed := strings.TrimSpace(line)

		if trimmed == `\q` || strings.EqualFold(trimmed, "quit") || strings.EqualFold(trimmed, "exit") {
			_ = writeLine(conn, "bye")
			return nil
		}
		if trimmed == "" {
			_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"=> "))
			continue
		}

		buffer.WriteString(line)
		buffer.WriteString(" ")

		// Only execute once the accumulated input ends with a semicolon —
		// this lets a statement span multiple WS messages (multi-line
		// paste), matching how psql itself waits for the terminator.
		if !strings.HasSuffix(trimmed, ";") {
			_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"-> "))
			continue
		}

		stmt := strings.TrimSpace(buffer.String())
		buffer.Reset()

		execStart := time.Now()
		execCtx, execCancel := context.WithTimeout(ctx, 30*time.Second)
		output, execErr := executePostgresStatement(execCtx, pgConn, stmt)
		execCancel()
		elapsedMs := time.Since(execStart).Milliseconds()

		if execErr != nil {
			logCmd(stmt, false, execErr.Error(), elapsedMs)
			_ = writeLine(conn, "ERROR: "+sanitizePgError(execErr))
		} else {
			logCmd(stmt, true, "", elapsedMs)
			_ = writeLine(conn, output)
		}
		_ = conn.WriteMessage(websocket.TextMessage, []byte(dbName+"=> "))
	}
}

// executePostgresStatement runs one statement and renders the result as a
// psql-style aligned table (for SELECT/RETURNING-style queries) or a short
// command tag (for INSERT/UPDATE/DELETE/DDL, which have no rows).
func executePostgresStatement(ctx context.Context, pgConn *pgx.Conn, stmt string) (string, error) {
	rows, err := pgConn.Query(ctx, stmt)
	if err != nil {
		return "", err
	}
	defer rows.Close()

	fields := rows.FieldDescriptions()
	if len(fields) == 0 {
		// No result columns — this was an INSERT/UPDATE/DELETE/DDL, not a
		// SELECT. rows.CommandTag() is only valid after rows.Close()/Err(),
		// so read it after the loop below (which will be a no-op here).
		for rows.Next() {
		}
		if err := rows.Err(); err != nil {
			return "", err
		}
		tag := rows.CommandTag()
		return tag.String(), nil
	}

	headers := make([]string, len(fields))
	sensitiveCol := make([]bool, len(fields))
	for i, f := range fields {
		headers[i] = string(f.Name)
		// A column literally named password/secret/token/etc. — redact
		// every value under it. Unlike Redis (a bare key/value store with
		// no shape to anchor a redaction to), a result set's column names
		// ARE the key context recorder.MaskSecrets needs but can't see on
		// its own (a rendered table cell is just "S3cr3t!" with no
		// "password=" prefix next to it — the key is one column over,
		// in the header row, which no per-cell regex would ever look at).
		sensitiveCol[i] = recorder.ReferencesSecretKey(headers[i])
	}

	var records [][]string
	for rows.Next() {
		vals, err := rows.Values()
		if err != nil {
			return "", err
		}
		record := make([]string, len(vals))
		for i, v := range vals {
			switch {
			case sensitiveCol[i] && v != nil:
				record[i] = "***MASKED***"
			case v == nil:
				record[i] = "NULL"
			default:
				record[i] = fmt.Sprintf("%v", v)
			}
		}
		records = append(records, record)
	}
	if err := rows.Err(); err != nil {
		return "", err
	}

	return renderTable(headers, records), nil
}

// renderTable produces a fixed-width, psql-style table:
//
//	 col1 | col2
//	------+------
//	 a    | b
//	(1 row)
func renderTable(headers []string, records [][]string) string {
	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h)
	}
	for _, rec := range records {
		for i, v := range rec {
			if len(v) > widths[i] {
				widths[i] = len(v)
			}
		}
	}

	var b strings.Builder
	for i, h := range headers {
		if i > 0 {
			b.WriteString(" | ")
		}
		b.WriteString(padRight(h, widths[i]))
	}
	b.WriteString("\r\n")
	for i, w := range widths {
		if i > 0 {
			b.WriteString("-+-")
		}
		b.WriteString(strings.Repeat("-", w))
	}
	b.WriteString("\r\n")
	for _, rec := range records {
		for i, v := range rec {
			if i > 0 {
				b.WriteString(" | ")
			}
			b.WriteString(padRight(v, widths[i]))
		}
		b.WriteString("\r\n")
	}
	rowWord := "rows"
	if len(records) == 1 {
		rowWord = "row"
	}
	b.WriteString(fmt.Sprintf("(%d %s)", len(records), rowWord))
	return b.String()
}

func padRight(s string, width int) string {
	if len(s) >= width {
		return s
	}
	return s + strings.Repeat(" ", width-len(s))
}

// sanitizePgError strips the connection string (which embeds the plaintext
// password) out of a pgx connection error before it ever reaches the
// browser or the audit log.
func sanitizePgError(err error) string {
	msg := err.Error()
	if idx := strings.Index(msg, "password="); idx != -1 {
		end := strings.IndexAny(msg[idx:], " )")
		if end == -1 {
			return msg[:idx] + "password=****"
		}
		return msg[:idx] + "password=****" + msg[idx+end:]
	}
	return msg
}
