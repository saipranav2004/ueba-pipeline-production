// pam/opa/matcher_export.go
//
// Exported shim over this package's unexported pattern matcher.
//
// WHY THIS EXISTS AS A SEPARATE FILE
//
// The privilege-path analyzer (internal/services/graph) has to answer
// "given these policy patterns, what would the PDP actually allow?" — and
// it must answer it *identically* to the PDP, forever. The tempting
// alternative is for the analyzer to reimplement the wildcard rules. That
// is a trap: the two copies drift the first time someone adjusts matching
// semantics in engine.go, and the analyzer silently stops reporting real
// escalation paths. A privilege-path tool that under-reports is worse than
// none, because people trust it.
//
// So the analyzer calls straight into the PDP's own matcher. This lives in
// its own file rather than appended to engine.go purely so the export is
// obvious to a reader and survives future edits to engine.go without merge
// noise.
//
// Read-only, stateless, no third-party imports — engine.go's zero-dependency
// property is preserved.
package opa

// MatchesAny reports whether value matches at least one pattern, using
// exactly the semantics Engine.Evaluate applies internally:
//
//	"*"        matches anything
//	"exact"    matches only that exact value
//	"prefix*"  matches any value starting with "prefix"
//
// Intended for offline analysis and tooling. It is NOT part of the
// enforcement path — Engine.Evaluate does not route through this function,
// it calls the unexported matchesAny directly.
func MatchesAny(patterns []string, value string) bool {
	return matchesAny(patterns, value)
}

// MatchOne is the single-pattern form, exposed for the same reason as
// MatchesAny. Useful when tooling needs to explain WHICH pattern matched
// rather than just whether one did.
func MatchOne(pattern, value string) bool {
	return matchOne(pattern, value)
}
