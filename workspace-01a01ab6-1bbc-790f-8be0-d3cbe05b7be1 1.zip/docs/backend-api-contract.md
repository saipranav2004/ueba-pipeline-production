# Identity Risk Graph — Backend API Contract

This contract matches the current frontend types in `src/types/security.ts`. A REST or GraphQL adapter may use different endpoint names, but the service methods must return these response bodies.

## Conventions

- IDs must be stable strings. Prefer namespaced IDs derived from `objectGUID`, such as `ad-user:<guid>` or `ad-computer:<guid>`.
- Never use display names as IDs.
- Timestamps are ISO-8601 UTC strings.
- Confidence is a decimal from `0` to `1`.
- Risk scores are integers from `0` to `100`.
- Node `position` may be `{ "x": 0, "y": 0 }`; the frontend calculates the layout.
- Graph endpoints return visualization summaries. Detailed SID, DN, evidence, and authentication data belong in the identity-details endpoint.
- Search selection defines `compromisedSourceId` in the frontend. Clicking another graph node only inspects it and does not change the compromised source.

## Enumerations

### `identityType`

```text
user | privilegedUser | group | serviceAccount | computer | server | domainController | criticalAsset
```

### `riskLevel`

```text
critical | high | medium | low | normal
```

### Baseline `status`

```text
compromised | potentially-at-risk | reachable | normal
```

For normal identity-graph responses, return the directory object's baseline state. The frontend applies the compromised treatment to the search-selected source. Blast Radius responses may explicitly mark their `focusId` as `compromised`.

### `relationshipType`

```text
MemberOf | AdminOf | HasSession | CanAccess | CanDelegate | CanImpersonate |
Owns | Controls | Trusts | CanRDP | CanResetPassword | SyncedTo
```

## Recommended REST operations

| Frontend operation | Suggested endpoint | Response type |
|---|---|---|
| Search identities | `GET /api/identities/search?q=` | `SecurityGraphNode[]` |
| Identity graph | `GET /api/identities/{id}/graph?depth=2&limit=24` | `GraphResponse` |
| Expand identity | `POST /api/graph/expand` | `GraphResponse` |
| Identity details | `GET /api/identities/{id}` | `IdentityDetails` |
| Relationship details | `GET /api/relationships/{id}` | `RelationshipDetails` |
| Blast Radius overview | `GET /api/identities/{id}/blast-radius?depth=4&limit=34` | `BlastRadiusResponse` |
| Expand Blast branch | `GET /api/identities/{sourceId}/blast-branches/{branchRootId}?limit=5` | `BlastBranchResponse` |
| Attack Paths | `GET /api/attack-paths?sourceId={id}&targetId={id}` | `AttackPathsResponse` |

## Expand identity request

```json
{
  "focusId": "u-john",
  "expandIdentityId": "g-itops",
  "existingNodeIds": ["u-john", "g-itops", "v-jump"],
  "limit": 12
}
```

The response is a complete merged `GraphResponse`, not raw Neo4j records.

## Graph node

```json
{
  "id": "u-john",
  "type": "security",
  "position": { "x": 0, "y": 0 },
  "data": {
    "name": "john.smith",
    "displayName": "John Smith",
    "identityType": "user",
    "riskScore": 87,
    "riskLevel": "critical",
    "status": "normal",
    "privileged": false,
    "criticality": "standard",
    "blastRadius": {
      "potentiallyAffected": 247,
      "privilegedIdentities": 0,
      "criticalAssets": 0,
      "servers": 0
    },
    "riskReasons": ["Suspicious authentication", "Excessive group membership"]
  }
}
```

`blastRadius` on a graph node is a lightweight quick-summary. If your backend cannot classify privileged identities or critical assets, return `0`; `potentiallyAffected` is the field used by the current graph tooltip and reachability flow.

## Graph edge

```json
{
  "id": "e-john-itops",
  "source": "u-john",
  "target": "g-itops",
  "type": "security",
  "data": {
    "relationshipType": "MemberOf",
    "label": "Member Of",
    "direct": true,
    "effectiveAccess": "Inherits IT operations access",
    "riskContribution": 25,
    "confidence": 0.98,
    "firstObserved": "2026-05-14T09:30:00Z",
    "lastObserved": "2026-08-19T07:42:00Z",
    "securityProperties": ["Security enabled: true"]
  }
}
```

For Blast Radius branch edges, include:

```json
{
  "blastDepth": 2,
  "blastFlow": true
}
```

Valid `blastDepth` values are `1`, `2`, `3`, and `4`. The frontend uses these values for progressively fading directional animation.

## `GraphResponse`

```text
focusId: string
nodes: SecurityGraphNode[]
edges: SecurityGraphEdge[]
totalRelated: number
truncated: boolean
hiddenCount: number
```

- `totalRelated` is the total backend result count, not only the rendered count.
- `hiddenCount = totalRelated - displayedRelatedCount`.
- Keep the visible result set ranked and limited.

## `BlastRadiusResponse`

In addition to all `GraphResponse` fields:

```text
directExposureIds: string[]
branchSummaries: BlastBranchSummary[]
metrics:
  totalPotentiallyAtRisk: number
  directExposures: number
  withinTwoHops: number
  extendedReachability: number
  strongControlRelationships: number
  activeSessionExposures: number
assumptions: string[]
```

Each `directExposureId` must exist in `nodes` and must be connected to `focusId` by an edge in `edges`.

A branch summary contains:

```text
directExposureId: string
downstreamCount: number
maxDepth: number
relationshipType: RelationshipType
relationshipLabel: string
confidence: number
```

`downstreamCount` is the number of distinct objects reachable through that branch under the backend's traversal rules. It is not an AD category count.

## `BlastBranchResponse`

```text
sourceId: string
branchRootId: string
nodes: SecurityGraphNode[]
edges: SecurityGraphEdge[]
totalReachable: number
hiddenCount: number
maxDepth: number
```

- Return actual AD objects, not category nodes.
- Return one primary-parent edge per object for the Blast Radius tree.
- Exclude the compromised source and other one-hop branch roots from branch children.
- Rank results before applying `limit`.
- Branch edges should contain `blastDepth` and `blastFlow`.
- The frontend creates the `+N reachable objects` overflow node from `hiddenCount`.

## `IdentityDetails`

Detailed identity properties are loaded separately. Required fields are shown in the sample bundle. Fields such as SID, DN, authentication source, evidence, active sessions, and memberships should not be duplicated into every graph node.

## `AttackPathsResponse`

```text
sourceId: string
targetId: string
strongestPathId: string
overallReachabilityRisk: number
overallRiskLevel: RiskLevel
confidence: number
explanation: string
paths: AttackPath[]
graph: GraphResponse
```

Each path must include:

```text
id, label, sourceId, targetId, riskScore, riskLevel, hops, confidence,
reasons[], nodeIds[], edgeIds[], steps[], mitigatingControls[]
```

Every ID in `nodeIds` and `edgeIds` must exist in the nested `graph`. Path steps must be ordered from source to target.

Do not calculate `overallReachabilityRisk` by averaging paths. Weight it toward the strongest viable path and account for alternatives, confidence, target criticality, relationship strength, and mitigating controls.

## Error response

Use one consistent error envelope:

```json
{
  "error": {
    "code": "IDENTITY_NOT_FOUND",
    "message": "Identity was not found in the security graph.",
    "requestId": "req-8f138a"
  }
}
```

Suggested HTTP status codes:

- `400`: invalid query or unsupported relationship type
- `404`: identity or relationship not found
- `409`: stale graph-expansion cursor
- `422`: valid request but no modeled path exists
- `500`: graph query or transformation failure
