import type { Edge, Node } from '@xyflow/react';

export type RiskLevel = 'critical' | 'high' | 'medium' | 'low' | 'normal';
export type IdentityType =
  | 'user'
  | 'privilegedUser'
  | 'group'
  | 'serviceAccount'
  | 'computer'
  | 'server'
  | 'domainController'
  | 'criticalAsset';
export type SecurityStatus = 'compromised' | 'potentially-at-risk' | 'reachable' | 'normal';
export type RelationshipType =
  | 'MemberOf'
  | 'AdminOf'
  | 'HasSession'
  | 'CanAccess'
  | 'CanDelegate'
  | 'CanImpersonate'
  | 'Owns'
  | 'Controls'
  | 'Trusts'
  | 'CanRDP'
  | 'CanResetPassword'
  | 'SyncedTo';

export interface BlastSummary {
  potentiallyAffected: number;
  privilegedIdentities: number;
  criticalAssets: number;
  servers: number;
}

export interface SecurityNodeData extends Record<string, unknown> {
  name: string;
  displayName: string;
  identityType: IdentityType;
  riskScore: number;
  riskLevel: RiskLevel;
  status: SecurityStatus;
  privileged: boolean;
  criticality?: 'tier-0' | 'tier-1' | 'tier-2' | 'standard';
  blastRadius: BlastSummary;
  riskReasons: string[];
  hiddenConnections?: number;
  expanded?: boolean;
  selected?: boolean;
  faded?: boolean;
  highlighted?: boolean;
  mode?: 'user' | 'soc';
  investigationState?: 'connected' | 'reachable' | 'potentially-at-risk' | 'compromised';
  blastBranch?: {
    downstreamCount: number;
    maxDepth: number;
    relationshipLabel: string;
    confidence: number;
    active?: boolean;
  };
  onExpand?: (id: string) => void;
}

export interface AggregateNodeData extends Record<string, unknown> {
  label: string;
  count: number;
  parentId: string;
  aggregateType: IdentityType | 'mixed';
  kind?: 'overflow' | 'branch-overflow';
  subtitle?: string;
  selected?: boolean;
  faded?: boolean;
}

export interface RelationshipSecurityData extends Record<string, unknown> {
  relationshipType: RelationshipType;
  label: string;
  direct: boolean;
  effectiveAccess: string;
  riskContribution: number;
  confidence: number;
  inheritedFrom?: string;
  firstObserved: string;
  lastObserved: string;
  securityProperties: string[];
  blastDepth?: 1 | 2 | 3 | 4;
  blastFlow?: boolean;
  selected?: boolean;
  highlighted?: boolean;
  faded?: boolean;
  mode?: 'user' | 'soc';
}

export type SecurityGraphNode = Node<SecurityNodeData, 'security'>;
export type AggregateGraphNode = Node<AggregateNodeData, 'aggregate'>;
export type AppGraphNode = SecurityGraphNode | AggregateGraphNode;
export type SecurityGraphEdge = Edge<RelationshipSecurityData, 'security'>;

export interface IdentityDetails {
  id: string;
  displayName: string;
  accountName: string;
  identityType: IdentityType;
  title?: string;
  department?: string;
  riskScore: number;
  riskLevel: RiskLevel;
  status: SecurityStatus;
  privileged: boolean;
  criticality: 'tier-0' | 'tier-1' | 'tier-2' | 'standard';
  riskReasons: Array<{ title: string; description: string; contribution: number }>;
  blastRadius: BlastSummary & { domainControllers: number; highRiskIdentities: number };
  sid?: string;
  distinguishedName?: string;
  lastAuthentication?: string;
  authenticationSource?: string;
  activeSessions: number;
  groupMemberships: string[];
  evidence: Array<{ type: string; summary: string; observedAt: string; confidence: number }>;
}

export interface RelationshipDetails extends RelationshipSecurityData {
  id: string;
  sourceId: string;
  sourceName: string;
  targetId: string;
  targetName: string;
}

export interface GraphResponse {
  focusId: string;
  nodes: SecurityGraphNode[];
  edges: SecurityGraphEdge[];
  totalRelated: number;
  truncated: boolean;
  hiddenCount: number;
}

export interface BlastBranchSummary {
  directExposureId: string;
  downstreamCount: number;
  maxDepth: number;
  relationshipType: RelationshipType;
  relationshipLabel: string;
  confidence: number;
}

export interface BlastBranchResponse {
  sourceId: string;
  branchRootId: string;
  nodes: SecurityGraphNode[];
  edges: SecurityGraphEdge[];
  totalReachable: number;
  hiddenCount: number;
  maxDepth: number;
}

export interface BlastRadiusResponse extends GraphResponse {
  directExposureIds: string[];
  branchSummaries: BlastBranchSummary[];
  metrics: {
    totalPotentiallyAtRisk: number;
    directExposures: number;
    withinTwoHops: number;
    extendedReachability: number;
    strongControlRelationships: number;
    activeSessionExposures: number;
  };
  assumptions: string[];
}

export interface AttackPathStep {
  sourceId: string;
  sourceName: string;
  relationshipId: string;
  relationshipType: RelationshipType;
  relationshipLabel: string;
  targetId: string;
  targetName: string;
  explanation: string;
}

export interface AttackPath {
  id: string;
  label: string;
  sourceId: string;
  targetId: string;
  riskScore: number;
  riskLevel: RiskLevel;
  hops: number;
  confidence: number;
  reasons: string[];
  nodeIds: string[];
  edgeIds: string[];
  steps: AttackPathStep[];
  mitigatingControls: string[];
}

export interface AttackPathsResponse {
  sourceId: string;
  targetId: string;
  strongestPathId: string;
  overallReachabilityRisk: number;
  overallRiskLevel: RiskLevel;
  confidence: number;
  explanation: string;
  paths: AttackPath[];
  graph: GraphResponse;
}

export interface GraphFilters {
  riskLevels: RiskLevel[];
  identityTypes: IdentityType[];
  relationshipTypes: RelationshipType[];
  privilegedOnly: boolean;
  compromisedOnly: boolean;
  riskyOnly: boolean;
}

export type InvestigationView = 'graph' | 'blast' | 'paths';
export type VisualizationMode = 'user' | 'soc';
