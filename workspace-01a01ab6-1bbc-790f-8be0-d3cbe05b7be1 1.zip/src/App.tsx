import { useCallback, useRef, useState } from 'react';
import type { ReactFlowInstance } from '@xyflow/react';
import { AlertTriangle, CheckCircle2, Clock3, FileSearch, X } from 'lucide-react';
import { GraphWorkspace } from './components/graph/GraphWorkspace';
import { InvestigationPanel } from './components/investigation/InvestigationPanel';
import { TopToolbar } from './components/toolbar/TopToolbar';
import { securityApi } from './services/mockSecurityApi';
import type {
  AppGraphNode, AttackPathsResponse, BlastBranchResponse, BlastRadiusResponse, GraphFilters, GraphResponse,
  IdentityDetails, InvestigationView, RelationshipDetails, SecurityGraphEdge, SecurityGraphNode,
  VisualizationMode,
} from './types/security';

const ALL_FILTERS: GraphFilters = {
  riskLevels: ['critical', 'high', 'medium', 'low', 'normal'],
  identityTypes: ['user', 'privilegedUser', 'group', 'serviceAccount', 'computer', 'server', 'domainController', 'criticalAsset'],
  relationshipTypes: ['MemberOf', 'AdminOf', 'HasSession', 'CanAccess', 'CanDelegate', 'CanImpersonate', 'Owns', 'Controls', 'Trusts', 'CanRDP', 'CanResetPassword', 'SyncedTo'],
  privilegedOnly: false,
  compromisedOnly: false,
  riskyOnly: false,
};

type ModalKind = 'timeline' | 'evidence' | null;

function asSelectedCompromisedSource(details: IdentityDetails): IdentityDetails {
  const selectionReason = 'Selected compromised investigation source';
  return {
    ...details,
    status: 'compromised',
    riskScore: Math.max(85, details.riskScore),
    riskLevel: 'critical',
    riskReasons: details.riskReasons.some((reason) => reason.title === selectionReason)
      ? details.riskReasons
      : [{
          title: selectionReason,
          description: 'This identity was selected as the confirmed compromise source for the current investigation.',
          contribution: 40,
        }, ...details.riskReasons],
  };
}

export default function App() {
  const [mode, setMode] = useState<VisualizationMode>('soc');
  const [depth, setDepth] = useState(2);
  const [filters, setFilters] = useState<GraphFilters>(ALL_FILTERS);
  const [view, setView] = useState<InvestigationView>('graph');
  const [graph, setGraph] = useState<GraphResponse | null>(null);
  const [details, setDetails] = useState<IdentityDetails | null>(null);
  const [relationship, setRelationship] = useState<RelationshipDetails | null>(null);
  const [blast, setBlast] = useState<BlastRadiusResponse | null>(null);
  const [blastBranch, setBlastBranch] = useState<BlastBranchResponse | null>(null);
  const [blastBranchLimit, setBlastBranchLimit] = useState(5);
  const [attackPaths, setAttackPaths] = useState<AttackPathsResponse | null>(null);
  const [compromisedSourceId, setCompromisedSourceId] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  const [selectedTargetId, setSelectedTargetId] = useState('g-domain-admins');
  const [selectedPathId, setSelectedPathId] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<SecurityGraphNode[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [graphLoading, setGraphLoading] = useState(false);
  const [panelLoading, setPanelLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [fitNonce, setFitNonce] = useState(0);
  const [recenterNonce, setRecenterNonce] = useState(0);
  const [layoutNonce, setLayoutNonce] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [modal, setModal] = useState<ModalKind>(null);
  const graphInstance = useRef<ReactFlowInstance<AppGraphNode, SecurityGraphEdge> | null>(null);
  const baseGraph = useRef<GraphResponse | null>(null);
  const requestId = useRef(0);
  const detailRequestId = useRef(0);

  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 3200);
  }, []);

  const loadIdentity = useCallback(async (identityId: string, graphDepth = depth) => {
    const currentRequest = ++requestId.current;
    detailRequestId.current += 1;
    setGraphLoading(true);
    setPanelLoading(true);
    setError(null);
    setCompromisedSourceId(identityId);
    setSelectedNodeId(identityId);
    setDetails(null);
    setRelationship(null);
    setSelectedEdgeId(null);
    setSelectedPathId(null);
    setView('graph');
    setPanelOpen(true);
    try {
      const [graphResponse, detailResponse] = await Promise.all([
        securityApi.getIdentityGraph(identityId, graphDepth, graphDepth === 1 ? 16 : graphDepth === 2 ? 24 : graphDepth === 3 ? 32 : 38),
        securityApi.getIdentityDetails(identityId),
      ]);
      if (requestId.current !== currentRequest) return;
      setGraph(graphResponse);
      baseGraph.current = graphResponse;
      setDetails(asSelectedCompromisedSource(detailResponse));
      setSelectedNodeId(identityId);
      const firstAvailableTarget = securityApi.getAttackTargets().find((target) => target.id !== identityId);
      setSelectedTargetId((current) => current === identityId ? (firstAvailableTarget?.id ?? current) : current);
      setBlast(null);
      setBlastBranch(null);
      setBlastBranchLimit(5);
      setAttackPaths(null);
    } catch (cause) {
      if (requestId.current === currentRequest) setError(cause instanceof Error ? cause.message : 'Unable to load the identity graph.');
    } finally {
      if (requestId.current === currentRequest) {
        setGraphLoading(false);
        setPanelLoading(false);
      }
    }
  }, [depth]);

  const handleDepthChange = useCallback((nextDepth: number) => {
    setDepth(nextDepth);
    if (compromisedSourceId) void loadIdentity(compromisedSourceId, nextDepth);
  }, [compromisedSourceId, loadIdentity]);

  const handleSearch = useCallback(async (query: string) => {
    setSearchLoading(true);
    try { setSearchResults(await securityApi.searchIdentities(query)); }
    finally { setSearchLoading(false); }
  }, []);

  const handleSearchSelect = useCallback((node: SecurityGraphNode) => {
    void loadIdentity(node.id, depth);
  }, [depth, loadIdentity]);

  const handleNodeSelect = useCallback(async (id: string) => {
    const currentRequest = ++detailRequestId.current;
    setSelectedNodeId(id);
    setSelectedEdgeId(null);
    setRelationship(null);
    setPanelOpen(true);
    setPanelLoading(true);
    setError(null);
    setSelectedPathId(null);
    setBlastBranch(null);
    if (view !== 'graph') {
      setView('graph');
      if (baseGraph.current) setGraph(baseGraph.current);
    }
    try {
      const nodeDetails = await securityApi.getIdentityDetails(id);
      if (detailRequestId.current !== currentRequest) return;
      setDetails(id === compromisedSourceId ? asSelectedCompromisedSource(nodeDetails) : nodeDetails);
    } catch (cause) {
      if (detailRequestId.current === currentRequest) {
        setError(cause instanceof Error ? cause.message : 'Unable to load identity details.');
      }
    } finally {
      if (detailRequestId.current === currentRequest) setPanelLoading(false);
    }
  }, [compromisedSourceId, view]);

  const handleEdgeSelect = useCallback(async (id: string) => {
    if (id.startsWith('edge-aggregate')) return;
    setSelectedEdgeId(id);
    setRelationship(null);
    setPanelOpen(true);
    setPanelLoading(true);
    try { setRelationship(await securityApi.getRelationshipDetails(id)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to load relationship details.'); }
    finally { setPanelLoading(false); }
  }, []);

  const handleExpandNode = useCallback(async (id: string) => {
    if (!graph || graphLoading) return;
    setGraphLoading(true);
    try {
      const response = await securityApi.expandIdentity(id, graph.nodes.map((node) => node.id), graph.focusId);
      setGraph(response);
      if (view === 'graph') baseGraph.current = response;
      notify(`Expanded ${response.nodes.find((node) => node.id === id)?.data.displayName ?? 'identity'} relationships`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to expand relationships.'); }
    finally { setGraphLoading(false); }
  }, [graph, graphLoading, notify, view]);

  const handleExpandAggregate = useCallback(async () => {
    if (!graph || graphLoading) return;
    setGraphLoading(true);
    try {
      const response = await securityApi.expandAggregate(graph.focusId, graph.nodes.map((node) => node.id));
      setGraph(response);
      if (view === 'graph') baseGraph.current = response;
      notify(`Added ${response.nodes.length - graph.nodes.length} high-priority related identities`);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to expand grouped identities.'); }
    finally { setGraphLoading(false); }
  }, [graph, graphLoading, notify, view]);

  const loadBlastRadius = useCallback(async () => {
    if (!compromisedSourceId) return;
    setView('blast');
    setSelectedNodeId(compromisedSourceId);
    setDetails(null);
    setRelationship(null);
    setBlastBranch(null);
    setBlastBranchLimit(5);
    setPanelOpen(true);
    setGraphLoading(true);
    setPanelLoading(true);
    setError(null);
    if (view === 'graph' && graph) baseGraph.current = graph;
    try {
      const [response, sourceDetails] = await Promise.all([
        securityApi.getBlastRadius(compromisedSourceId),
        securityApi.getIdentityDetails(compromisedSourceId),
      ]);
      setBlast(response);
      setGraph(response);
      setDetails(asSelectedCompromisedSource(sourceDetails));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to calculate blast radius.'); }
    finally { setGraphLoading(false); setPanelLoading(false); }
  }, [compromisedSourceId, graph, view]);

  const fetchBlastBranch = useCallback(async (branchRootId: string, limit: number) => {
    if (!compromisedSourceId || !blast) return;
    setGraphLoading(true);
    setError(null);
    try {
      const response = await securityApi.getBlastBranch(compromisedSourceId, branchRootId, limit);
      setBlastBranch(response);
      setBlastBranchLimit(limit);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Unable to expand this reachability branch.');
    } finally {
      setGraphLoading(false);
    }
  }, [blast, compromisedSourceId]);

  const handleBlastBranchSelect = useCallback((branchRootId: string) => {
    if (blastBranch?.branchRootId === branchRootId) {
      setBlastBranch(null);
      setBlastBranchLimit(5);
      return;
    }
    void fetchBlastBranch(branchRootId, 5);
  }, [blastBranch, fetchBlastBranch]);

  const handleBlastBranchLoadMore = useCallback(() => {
    if (!blastBranch) return;
    void fetchBlastBranch(blastBranch.branchRootId, blastBranchLimit + 5);
  }, [blastBranch, blastBranchLimit, fetchBlastBranch]);

  const loadAttackPaths = useCallback(async (targetId = selectedTargetId) => {
    if (!compromisedSourceId) return;
    const availableTargets = securityApi.getAttackTargets().filter((target) => target.id !== compromisedSourceId);
    const resolvedTargetId = targetId === compromisedSourceId ? (availableTargets[0]?.id ?? targetId) : targetId;
    setView('paths');
    setSelectedNodeId(compromisedSourceId);
    setDetails(null);
    setRelationship(null);
    setBlastBranch(null);
    setPanelOpen(true);
    setGraphLoading(true);
    setPanelLoading(true);
    setError(null);
    setSelectedTargetId(resolvedTargetId);
    if (view === 'graph' && graph) baseGraph.current = graph;
    try {
      const [response, sourceDetails] = await Promise.all([
        securityApi.getAttackPaths(compromisedSourceId, resolvedTargetId),
        securityApi.getIdentityDetails(compromisedSourceId),
      ]);
      setAttackPaths(response);
      setGraph(response.graph);
      setDetails(asSelectedCompromisedSource(sourceDetails));
      setSelectedPathId(response.strongestPathId);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to calculate attack paths.'); }
    finally { setGraphLoading(false); setPanelLoading(false); }
  }, [compromisedSourceId, graph, selectedTargetId, view]);

  const handleViewChange = useCallback((nextView: InvestigationView) => {
    if (nextView === 'blast') void loadBlastRadius();
    else if (nextView === 'paths') void loadAttackPaths();
    else {
      setView('graph');
      setBlastBranch(null);
      if (baseGraph.current) setGraph(baseGraph.current);
      setSelectedPathId(null);
    }
  }, [loadAttackPaths, loadBlastRadius]);

  const handleBackToGraph = useCallback(() => {
    setView('graph');
    setBlastBranch(null);
    setSelectedPathId(null);
    if (baseGraph.current) setGraph(baseGraph.current);
  }, []);

  const handleReset = useCallback(() => {
    requestId.current += 1;
    detailRequestId.current += 1;
    setFilters(ALL_FILTERS);
    setDepth(2);
    setMode('soc');
    setView('graph');
    setGraph(null);
    baseGraph.current = null;
    setDetails(null);
    setRelationship(null);
    setBlast(null);
    setBlastBranch(null);
    setBlastBranchLimit(5);
    setAttackPaths(null);
    setCompromisedSourceId(null);
    setSelectedNodeId(null);
    setSelectedEdgeId(null);
    setSelectedPathId(null);
    setPanelOpen(false);
    setGraphLoading(false);
    setPanelLoading(false);
    setError(null);
    setLayoutNonce((value) => value + 1);
    notify('Investigation cleared — select an identity to begin');
  }, [notify]);

  const handleQuickAction = useCallback((action: string) => {
    if (action === 'privileged') {
      setFilters({ ...ALL_FILTERS, privilegedOnly: true, riskyOnly: true });
      notify('Showing privileged identities and security-relevant access');
    } else if (action === 'sessions') {
      setFilters({ ...ALL_FILTERS, relationshipTypes: ['HasSession'], riskyOnly: true });
      notify('Showing active session relationships');
    } else if (action === 'timeline' || action === 'evidence') setModal(action);
  }, [notify]);

  const selectedPath = attackPaths?.paths.find((path) => path.id === selectedPathId) ?? null;
  const availableAttackTargets = securityApi.getAttackTargets().filter((target) => target.id !== compromisedSourceId);

  return (
    <div className="app-shell">
      <TopToolbar
        mode={mode} onModeChange={setMode} depth={depth} onDepthChange={handleDepthChange}
        filters={filters} onFiltersChange={setFilters} searchResults={searchResults} searchLoading={searchLoading}
        onSearch={handleSearch} onSelectSearch={handleSearchSelect}
        onFit={() => setFitNonce((value) => value + 1)}
        onRecenter={() => setRecenterNonce((value) => value + 1)} onReset={handleReset}
      />
      <div className={`app-main ${panelOpen ? 'panel-visible' : ''}`}>
        <GraphWorkspace
          graph={graph} blast={blast} blastBranch={blastBranch} filters={filters} mode={mode} view={view}
          compromisedSourceId={compromisedSourceId} selectedNodeId={selectedNodeId} selectedEdgeId={selectedEdgeId} selectedPath={selectedPath} loading={graphLoading} error={error}
          fitNonce={fitNonce} recenterNonce={recenterNonce} layoutNonce={layoutNonce}
          onNodeSelect={handleNodeSelect} onEdgeSelect={handleEdgeSelect} onExpandNode={handleExpandNode}
          onExpandAggregate={handleExpandAggregate} onBlastBranchSelect={handleBlastBranchSelect}
          onBlastBranchLoadMore={handleBlastBranchLoadMore} onInit={(instance) => { graphInstance.current = instance; }}
        />
        {panelOpen && (
          <InvestigationPanel
            details={details} relationship={relationship} loading={panelLoading} view={view} blast={blast}
            attackPaths={attackPaths} attackTargets={availableAttackTargets} selectedTargetId={selectedTargetId}
            selectedPathId={selectedPathId} mode={mode} onClose={() => setPanelOpen(false)} onBackToGraph={handleBackToGraph}
            onViewChange={handleViewChange} onTargetChange={(targetId) => void loadAttackPaths(targetId)}
            onPathSelect={setSelectedPathId} onQuickAction={handleQuickAction}
          />
        )}
      </div>
      {!panelOpen && details && <button className="reopen-panel" onClick={() => setPanelOpen(true)}>Open investigation <span>{details.displayName}</span></button>}
      {toast && <div className="toast"><CheckCircle2 size={15} /><span>{toast}</span></div>}
      {modal && details && <EvidenceModal kind={modal} details={details} onClose={() => setModal(null)} />}
    </div>
  );
}

function EvidenceModal({ kind, details, onClose }: { kind: Exclude<ModalKind, null>; details: IdentityDetails; onClose: () => void }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="evidence-modal" onMouseDown={(event) => event.stopPropagation()}>
        <div className="modal-header"><div>{kind === 'evidence' ? <FileSearch size={17} /> : <Clock3 size={17} />}<span><small>{details.accountName}</small><strong>{kind === 'evidence' ? 'Supporting evidence' : 'Security timeline'}</strong></span></div><button className="icon-button" onClick={onClose}><X size={16} /></button></div>
        <div className="modal-body">
          {kind === 'evidence' ? details.evidence.map((item) => <div className="evidence-row" key={item.summary}><span className={item.confidence > .9 ? 'critical-evidence' : ''}><AlertTriangle size={14} /></span><div><strong>{item.summary}</strong><p>{item.type} · {Math.round(item.confidence * 100)}% confidence</p></div><time>{new Date(item.observedAt).toLocaleString()}</time></div>) : details.evidence.map((item, index) => <div className="timeline-row" key={item.summary}><div><i /><span /></div><section><time>{new Date(item.observedAt).toLocaleString()}</time><strong>{item.summary}</strong><p>{index === 0 ? 'Security telemetry correlated this event with the current identity risk.' : 'Directory state contributed to modeled reachability.'}</p></section></div>)}
        </div>
      </div>
    </div>
  );
}
