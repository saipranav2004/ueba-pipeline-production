import type { AppGraphNode, SecurityGraphEdge } from '../types/security';

export type LayoutKind = 'layered' | 'radial' | 'path';

export function layoutGraph(
  inputNodes: AppGraphNode[],
  edges: SecurityGraphEdge[],
  focusId: string,
  kind: LayoutKind = 'layered',
): AppGraphNode[] {
  if (kind === 'path') {
    return inputNodes.map((node, index) => ({
      ...node,
      position: { x: index * 250, y: index % 2 === 0 ? 80 : 130 },
    }));
  }

  const adjacency = new Map<string, Set<string>>();
  inputNodes.forEach((node) => adjacency.set(node.id, new Set()));
  edges.forEach((edge) => {
    if (adjacency.has(edge.source) && adjacency.has(edge.target)) {
      adjacency.get(edge.source)?.add(edge.target);
      adjacency.get(edge.target)?.add(edge.source);
    }
  });

  const levels = new Map<string, number>([[focusId, 0]]);
  const queue = [focusId];
  while (queue.length) {
    const current = queue.shift()!;
    const level = levels.get(current) ?? 0;
    adjacency.get(current)?.forEach((next) => {
      if (!levels.has(next)) {
        levels.set(next, level + 1);
        queue.push(next);
      }
    });
  }

  const groups = new Map<number, AppGraphNode[]>();
  inputNodes.forEach((node) => {
    const level = levels.get(node.id) ?? 4;
    const list = groups.get(level) ?? [];
    list.push(node);
    groups.set(level, list);
  });

  if (kind === 'radial') {
    return inputNodes.map((node) => {
      const level = levels.get(node.id) ?? 4;
      if (level === 0) return { ...node, position: { x: 0, y: 0 } };
      const siblings = groups.get(level) ?? [node];
      const index = siblings.findIndex((item) => item.id === node.id);
      const radius = 190 + (level - 1) * 190;
      const offset = level % 2 ? -Math.PI / 2 : -Math.PI / 2 + Math.PI / Math.max(siblings.length, 2);
      const angle = offset + (Math.PI * 2 * index) / siblings.length;
      return {
        ...node,
        position: { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius },
      };
    });
  }

  const maxRowsPerColumn = 6;
  const levelStarts = new Map<number, number>();
  let xCursor = 0;
  [...groups.keys()].sort((a, b) => a - b).forEach((level) => {
    levelStarts.set(level, xCursor);
    const count = groups.get(level)?.length ?? 1;
    const columns = Math.max(1, Math.ceil(count / maxRowsPerColumn));
    xCursor += columns * 225 + 55;
  });

  return inputNodes.map((node) => {
    const level = levels.get(node.id) ?? 4;
    const siblings = groups.get(level) ?? [node];
    const index = siblings.findIndex((item) => item.id === node.id);
    const column = Math.floor(index / maxRowsPerColumn);
    const row = index % maxRowsPerColumn;
    const rowsInColumn = Math.min(maxRowsPerColumn, siblings.length - column * maxRowsPerColumn);
    return {
      ...node,
      position: {
        x: (levelStarts.get(level) ?? level * 260) + column * 225,
        y: (row - (rowsInColumn - 1) / 2) * 132 + (column % 2 ? 22 : 0),
      },
    };
  });
}
