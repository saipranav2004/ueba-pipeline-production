import type { IdentityType, RiskLevel, RelationshipType } from '../types/security';

export const RISK_META: Record<RiskLevel, { label: string; color: string; bg: string }> = {
  critical: { label: 'Critical', color: '#ff5c68', bg: 'rgba(255, 68, 82, .14)' },
  high: { label: 'High', color: '#ff9b54', bg: 'rgba(255, 139, 61, .14)' },
  medium: { label: 'Medium', color: '#f4c95d', bg: 'rgba(244, 201, 93, .14)' },
  low: { label: 'Low', color: '#5fd38d', bg: 'rgba(95, 211, 141, .12)' },
  normal: { label: 'Normal', color: '#8995a8', bg: 'rgba(137, 149, 168, .1)' },
};

export const IDENTITY_LABELS: Record<IdentityType, string> = {
  user: 'User',
  privilegedUser: 'Privileged User',
  group: 'Security Group',
  serviceAccount: 'Service Account',
  computer: 'Computer',
  server: 'Server',
  domainController: 'Domain Controller',
  criticalAsset: 'Critical Asset',
};

export const RELATIONSHIP_LABELS: Record<RelationshipType, string> = {
  MemberOf: 'Member Of',
  AdminOf: 'Admin Access',
  HasSession: 'Has Session',
  CanAccess: 'Can Access',
  CanDelegate: 'Can Delegate',
  CanImpersonate: 'Can Impersonate',
  Owns: 'Owns',
  Controls: 'Controls',
  Trusts: 'Trusts',
  CanRDP: 'Can RDP',
  CanResetPassword: 'Can Reset Password',
  SyncedTo: 'Synced To',
};

export function scoreToRisk(score: number): RiskLevel {
  if (score >= 80) return 'critical';
  if (score >= 60) return 'high';
  if (score >= 35) return 'medium';
  if (score >= 15) return 'low';
  return 'normal';
}

export function formatConfidence(value: number): string {
  return `${Math.round(value * 100)}%`;
}

export function relativeTime(iso: string): string {
  const days = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 86400000));
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  return `${days} days ago`;
}
