import type { AppGraphNode } from '../types/security';

/**
 * Purpose-built, graph-native blast-radius layout:
 * compromised source -> actual one-hop exposures -> selected branch objects.
 */
export function layoutBlastStages(
  nodes: AppGraphNode[],
  sourceId: string,
  directExposureIds: string[],
  downstreamIds: string[] = [],
): AppGraphNode[] {
  const directOrder = new Map(directExposureIds.map((id, index) => [id, index]));
  const downstreamOrder = new Map(downstreamIds.map((id, index) => [id, index]));
  const fallbackDownstream = nodes.filter(
    (node) => node.id !== sourceId && !directOrder.has(node.id),
  );
  const downstreamCount = Math.max(downstreamIds.length, fallbackDownstream.length);

  return nodes.map((node) => {
    if (node.id === sourceId) {
      return { ...node, position: { x: 0, y: 0 } };
    }

    const directIndex = directOrder.get(node.id);
    if (directIndex !== undefined) {
      return {
        ...node,
        position: {
          x: 315,
          y: (directIndex - (directExposureIds.length - 1) / 2) * 126,
        },
      };
    }

    const downstreamIndex = downstreamOrder.get(node.id) ?? fallbackDownstream.findIndex((item) => item.id === node.id);
    return {
      ...node,
      position: {
        x: 665,
        y: (downstreamIndex - (downstreamCount - 1) / 2) * 116,
      },
    };
  });
}
