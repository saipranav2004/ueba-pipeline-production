import { useEffect, useRef, useState } from 'react';
import {
  ChevronDown, Filter, Focus, Network, RotateCcw, Search, ShieldCheck, SlidersHorizontal, X,
} from 'lucide-react';
import type {
  GraphFilters, IdentityType, RelationshipType, RiskLevel, SecurityGraphNode, VisualizationMode,
} from '../../types/security';
import { IDENTITY_LABELS, RELATIONSHIP_LABELS, RISK_META } from '../../utils/risk';

interface TopToolbarProps {
  mode: VisualizationMode;
  onModeChange: (mode: VisualizationMode) => void;
  depth: number;
  onDepthChange: (depth: number) => void;
  filters: GraphFilters;
  onFiltersChange: (filters: GraphFilters) => void;
  searchResults: SecurityGraphNode[];
  searchLoading: boolean;
  onSearch: (query: string) => void;
  onSelectSearch: (node: SecurityGraphNode) => void;
  onFit: () => void;
  onRecenter: () => void;
  onReset: () => void;
}

const riskLevels: RiskLevel[] = ['critical', 'high', 'medium', 'low', 'normal'];
const identityTypes: IdentityType[] = ['user', 'privilegedUser', 'group', 'serviceAccount', 'computer', 'server', 'domainController', 'criticalAsset'];
const relationshipTypes: RelationshipType[] = ['MemberOf', 'AdminOf', 'HasSession', 'CanAccess', 'CanDelegate', 'CanImpersonate', 'Owns', 'Controls', 'Trusts', 'CanRDP', 'CanResetPassword'];

function toggleValue<T>(values: T[], value: T): T[] {
  return values.includes(value) ? values.filter((item) => item !== value) : [...values, value];
}

export function TopToolbar(props: TopToolbarProps) {
  const [query, setQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const filterRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (query.trim()) props.onSearch(query);
    }, 180);
    return () => window.clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (filterRef.current && !filterRef.current.contains(event.target as Node)) setShowFilters(false);
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) setShowResults(false);
    };
    window.addEventListener('mousedown', close);
    return () => window.removeEventListener('mousedown', close);
  }, []);

  const activeFilterCount =
    (props.filters.riskLevels.length < riskLevels.length ? 1 : 0) +
    (props.filters.identityTypes.length < identityTypes.length ? 1 : 0) +
    (props.filters.relationshipTypes.length < relationshipTypes.length ? 1 : 0) +
    Number(props.filters.privilegedOnly) + Number(props.filters.compromisedOnly) + Number(props.filters.riskyOnly);

  const setRiskPreset = (value: string) => {
    if (value === 'custom') return;
    if (value === 'all') props.onFiltersChange({ ...props.filters, riskLevels });
    else props.onFiltersChange({ ...props.filters, riskLevels: [value as RiskLevel] });
  };

  const currentRiskPreset = props.filters.riskLevels.length === riskLevels.length ? 'all' : props.filters.riskLevels.length === 1 ? props.filters.riskLevels[0] : 'custom';

  return (
    <header className="top-toolbar">
      <div className="brand-block">
        <div className="brand-mark"><Network size={19} /></div>
        <div><strong>Identity Risk Graph</strong><span>Exposure intelligence</span></div>
      </div>

      <div className="toolbar-divider" />

      <div className="identity-search" ref={searchRef}>
        <Search size={15} />
        <input
          id="identity-search-input"
          value={query}
          onChange={(event) => { setQuery(event.target.value); setShowResults(true); }}
          onFocus={() => { setShowResults(true); props.onSearch(query); }}
          placeholder="Select the compromised identity…"
          aria-label="Search identity"
        />
        {query && <button className="icon-button tiny" onClick={() => { setQuery(''); setShowResults(false); }}><X size={13} /></button>}
        {showResults && (
          <div className="search-results">
            <div className="search-results-head">Identities <span>{props.searchLoading ? 'Searching…' : `${props.searchResults.length} found`}</span></div>
            {!props.searchLoading && props.searchResults.map((node) => (
              <button key={node.id} onClick={() => { props.onSelectSearch(node); setQuery(node.data.name); setShowResults(false); }}>
                <span className={`search-risk risk-bg-${node.data.riskLevel}`} />
                <span><strong>{node.data.displayName}</strong><small>{node.data.name} · {IDENTITY_LABELS[node.data.identityType]}</small></span>
                <b>{node.data.riskScore}</b>
              </button>
            ))}
            {!props.searchLoading && props.searchResults.length === 0 && <div className="search-empty">No matching identities</div>}
          </div>
        )}
      </div>

      <div className="toolbar-spacer" />

      <div className="mode-switch" aria-label="Visualization mode">
        <button className={props.mode === 'user' ? 'active' : ''} onClick={() => props.onModeChange('user')}>User</button>
        <button className={props.mode === 'soc' ? 'active' : ''} onClick={() => props.onModeChange('soc')}><ShieldCheck size={12} /> SOC</button>
      </div>

      <label className="select-control compact"><span>Depth</span>
        <select value={props.depth} onChange={(event) => props.onDepthChange(Number(event.target.value))}>
          {[1, 2, 3, 4].map((value) => <option key={value} value={value}>{value} hop{value > 1 ? 's' : ''}</option>)}
        </select><ChevronDown size={12} />
      </label>

      <label className="select-control compact"><span>Risk</span>
        <select value={currentRiskPreset} onChange={(event) => setRiskPreset(event.target.value)}>
          <option value="all">All levels</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
          <option value="normal">Normal</option>
          {currentRiskPreset === 'custom' && <option value="custom">Custom</option>}
        </select><ChevronDown size={12} />
      </label>

      <div className="filter-wrap" ref={filterRef}>
        <button className={`toolbar-button ${activeFilterCount ? 'active' : ''}`} onClick={() => setShowFilters((value) => !value)}>
          <Filter size={14} /> Filters {activeFilterCount > 0 && <b>{activeFilterCount}</b>}
        </button>
        {showFilters && (
          <div className="filter-popover">
            <div className="filter-header"><div><SlidersHorizontal size={15} /><strong>Graph filters</strong></div><button className="text-button" onClick={props.onReset}>Reset all</button></div>
            <div className="quick-filter-row">
              <label><input type="checkbox" checked={props.filters.riskyOnly} onChange={() => props.onFiltersChange({ ...props.filters, riskyOnly: !props.filters.riskyOnly })} /><span>Risky only</span></label>
              <label><input type="checkbox" checked={props.filters.privilegedOnly} onChange={() => props.onFiltersChange({ ...props.filters, privilegedOnly: !props.filters.privilegedOnly })} /><span>Privileged</span></label>
              <label><input type="checkbox" checked={props.filters.compromisedOnly} onChange={() => props.onFiltersChange({ ...props.filters, compromisedOnly: !props.filters.compromisedOnly })} /><span>Compromised</span></label>
            </div>
            <FilterSection title="Risk level">
              <div className="chip-grid risk-chips">
                {riskLevels.map((level) => <button key={level} className={props.filters.riskLevels.includes(level) ? 'selected' : ''} onClick={() => props.onFiltersChange({ ...props.filters, riskLevels: toggleValue(props.filters.riskLevels, level) })}><i style={{ background: RISK_META[level].color }} />{RISK_META[level].label}</button>)}
              </div>
            </FilterSection>
            <FilterSection title="Identity type">
              <div className="check-grid">
                {identityTypes.map((type) => <label key={type}><input type="checkbox" checked={props.filters.identityTypes.includes(type)} onChange={() => props.onFiltersChange({ ...props.filters, identityTypes: toggleValue(props.filters.identityTypes, type) })} /><span>{IDENTITY_LABELS[type]}</span></label>)}
              </div>
            </FilterSection>
            <FilterSection title="Relationship type">
              <div className="check-grid relationship-grid">
                {relationshipTypes.map((type) => <label key={type}><input type="checkbox" checked={props.filters.relationshipTypes.includes(type)} onChange={() => props.onFiltersChange({ ...props.filters, relationshipTypes: toggleValue(props.filters.relationshipTypes, type) })} /><span>{RELATIONSHIP_LABELS[type]}</span></label>)}
              </div>
            </FilterSection>
          </div>
        )}
      </div>

      <div className="toolbar-actions">
        <button className="icon-button" title="Recenter selected identity" onClick={props.onRecenter}><Focus size={15} /></button>
        <button className="icon-button" title="Fit graph to screen" onClick={props.onFit}><Network size={15} /></button>
        <button className="icon-button" title="Reset graph and filters" onClick={props.onReset}><RotateCcw size={15} /></button>
      </div>
    </header>
  );
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="filter-section"><h4>{title}</h4>{children}</section>;
}
