import {
  Activity, ArrowLeft, BadgeCheck, Binary, ChevronDown, ChevronRight, CircleDot,
  Clock3, Crosshair, ExternalLink, FileSearch, GitBranch, KeyRound,
  Network, Radar, Route, ShieldAlert, ShieldCheck, Sparkles, Target, UsersRound, X,
} from 'lucide-react';
import type {
  AttackPath, AttackPathsResponse, BlastRadiusResponse, IdentityDetails, InvestigationView,
  RelationshipDetails, VisualizationMode,
} from '../../types/security';
import { formatConfidence, IDENTITY_LABELS, RELATIONSHIP_LABELS, RISK_META, relativeTime } from '../../utils/risk';
import { LoadingState } from '../common/LoadingState';
import { RiskBadge } from '../common/RiskBadge';

interface InvestigationPanelProps {
  details: IdentityDetails | null;
  relationship: RelationshipDetails | null;
  loading: boolean;
  view: InvestigationView;
  blast: BlastRadiusResponse | null;
  attackPaths: AttackPathsResponse | null;
  attackTargets: Array<{ id: string; label: string; type: string }>;
  selectedTargetId: string;
  selectedPathId: string | null;
  mode: VisualizationMode;
  onClose: () => void;
  onBackToGraph: () => void;
  onViewChange: (view: InvestigationView) => void;
  onTargetChange: (targetId: string) => void;
  onPathSelect: (pathId: string) => void;
  onQuickAction: (action: string) => void;
}

export function InvestigationPanel(props: InvestigationPanelProps) {
  if (props.loading && !props.details && !props.relationship) {
    return <aside className="investigation-panel"><LoadingState label="Loading investigation context…" /></aside>;
  }
  if (props.relationship) return <RelationshipPanel relationship={props.relationship} onClose={props.onClose} />;
  if (!props.details) return null;

  return (
    <aside className="investigation-panel">
      <PanelHeader details={props.details} view={props.view} onClose={props.onClose} onBack={props.onBackToGraph} />
      {props.view === 'graph' && <IdentityOverview details={props.details} mode={props.mode} onViewChange={props.onViewChange} onQuickAction={props.onQuickAction} />}
      {props.view === 'blast' && <BlastRadiusPanel details={props.details} blast={props.blast} loading={props.loading} onViewPaths={() => props.onViewChange('paths')} />}
      {props.view === 'paths' && (
        <AttackPathsPanel
          details={props.details}
          response={props.attackPaths}
          loading={props.loading}
          targets={props.attackTargets}
          targetId={props.selectedTargetId}
          selectedPathId={props.selectedPathId}
          onTargetChange={props.onTargetChange}
          onPathSelect={props.onPathSelect}
        />
      )}
    </aside>
  );
}

function PanelHeader({ details, view, onClose, onBack }: { details: IdentityDetails; view: InvestigationView; onClose: () => void; onBack: () => void }) {
  const risk = RISK_META[details.riskLevel];
  return (
    <div className="panel-header">
      <div className="panel-nav-row">
        {view !== 'graph' ? <button className="panel-back" onClick={onBack}><ArrowLeft size={13} /> Identity overview</button> : <span className="panel-eyebrow"><CircleDot size={11} /> Investigation</span>}
        <button className="icon-button tiny" onClick={onClose} title="Close panel"><X size={15} /></button>
      </div>
      <div className="identity-heading">
        <div className="identity-avatar" style={{ '--avatar-risk': risk.color } as React.CSSProperties}>{details.displayName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</div>
        <div><h2>{details.displayName}</h2><p>{details.accountName}</p></div>
      </div>
      <div className="identity-tags">
        <span>{IDENTITY_LABELS[details.identityType]}</span>
        {details.status === 'compromised' && <span className="compromised-tag"><ShieldAlert size={11} /> Compromised</span>}
        {details.privileged && <span className="privileged-tag"><ShieldCheck size={11} /> Privileged</span>}
      </div>
    </div>
  );
}

function IdentityOverview({ details, mode, onViewChange, onQuickAction }: { details: IdentityDetails; mode: VisualizationMode; onViewChange: (view: InvestigationView) => void; onQuickAction: (action: string) => void }) {
  const risk = RISK_META[details.riskLevel];
  return (
    <div className="panel-scroll">
      <section className="risk-overview-card">
        <div className="score-ring" style={{ '--score': `${details.riskScore * 3.6}deg`, '--score-color': risk.color } as React.CSSProperties}>
          <div><strong>{details.riskScore}</strong><span>/100</span></div>
        </div>
        <div><span className="section-kicker">Current identity risk</span><RiskBadge level={details.riskLevel} /><p>Risk reflects compromise evidence, permissions, sessions, and reachable assets.</p></div>
      </section>

      <section className="panel-section">
        <div className="section-title"><div><Radar size={14} /><h3>Potential blast radius</h3></div><button onClick={() => onViewChange('blast')}>Explore <ChevronRight size={12} /></button></div>
        <div className="metric-grid three">
          <Metric value={details.blastRadius.potentiallyAffected} label="Reachable objects" />
          <Metric value={details.activeSessions} label="Active sessions" />
          <Metric value={details.groupMemberships.length} label="Memberships" />
        </div>
        <p className="precision-note"><CircleDot size={11} /> Potential exposure, not confirmed compromise.</p>
      </section>

      <section className="panel-section">
        <div className="section-title"><div><Sparkles size={14} /><h3>Why is this risky?</h3></div><span>{details.riskReasons.length} findings</span></div>
        <div className="reason-list">
          {details.riskReasons.map((reason, index) => (
            <div className="reason-item" key={reason.title}>
              <span className={`reason-index ${index === 0 ? 'strong' : ''}`}>{index + 1}</span>
              <div><strong>{reason.title}</strong><p>{reason.description}</p></div>
              <b>+{reason.contribution}</b>
            </div>
          ))}
        </div>
      </section>

      <section className="panel-section">
        <div className="section-title"><div><Crosshair size={14} /><h3>Investigate</h3></div></div>
        <div className="action-grid">
          <button onClick={() => onViewChange('blast')}><Radar size={15} /><span>Show Blast Radius</span></button>
          <button onClick={() => onViewChange('paths')}><Route size={15} /><span>Show Attack Paths</span></button>
          <button onClick={() => onQuickAction('privileged')}><KeyRound size={15} /><span>Privileged Access</span></button>
          <button onClick={() => onQuickAction('sessions')}><Activity size={15} /><span>Show Sessions</span></button>
          <button onClick={() => onQuickAction('timeline')}><Clock3 size={15} /><span>Show Timeline</span></button>
          <button onClick={() => onQuickAction('evidence')}><FileSearch size={15} /><span>View Evidence</span></button>
        </div>
      </section>

      {mode === 'soc' && (
        <section className="panel-section">
          <div className="section-title"><div><Binary size={14} /><h3>Directory context</h3></div><span>SOC detail</span></div>
          <dl className="detail-list">
            <div><dt>SID</dt><dd className="mono">{details.sid}</dd></div>
            <div><dt>Distinguished name</dt><dd className="mono wrap">{details.distinguishedName}</dd></div>
            <div><dt>Last authentication</dt><dd>{details.lastAuthentication ? `${relativeTime(details.lastAuthentication)} · ${details.authenticationSource}` : 'Not applicable'}</dd></div>
            <div><dt>Active sessions</dt><dd>{details.activeSessions}</dd></div>
            <div><dt>Criticality</dt><dd>{details.criticality.toUpperCase()}</dd></div>
          </dl>
          {details.groupMemberships.length > 0 && <div className="membership-chips">{details.groupMemberships.map((group) => <span key={group}>{group}</span>)}</div>}
        </section>
      )}
    </div>
  );
}

function BlastRadiusPanel({ details, blast, loading, onViewPaths }: { details: IdentityDetails; blast: BlastRadiusResponse | null; loading: boolean; onViewPaths: () => void }) {
  if (loading || !blast) return <LoadingState label="Calculating potential blast radius…" />;
  const metrics = blast.metrics;
  return (
    <div className="panel-scroll">
      <div className="view-intro blast-intro"><div className="view-icon"><Radar size={19} /></div><div><span>Potential Blast Radius</span><h3>What could be affected?</h3><p>Modeled breadth of impact if <strong>{details.accountName}</strong> is used by an attacker.</p></div></div>
      <section className="impact-total">
        <span>Potentially reachable objects</span><strong>{metrics.totalPotentiallyAtRisk}</strong><small>distinct graph objects within the configured depth</small>
      </section>
      <div className="impact-metrics">
        <ImpactMetric icon={<Network size={15} />} value={metrics.directExposures} label="Direct exposures" tone="blue" />
        <ImpactMetric icon={<GitBranch size={15} />} value={metrics.withinTwoHops} label="Within 2 hops" tone="violet" />
        <ImpactMetric icon={<Route size={15} />} value={metrics.extendedReachability} label="3–4 hop reachability" tone="orange" />
        <ImpactMetric icon={<KeyRound size={15} />} value={metrics.strongControlRelationships} label="Strong control relations" tone="red" />
        <ImpactMetric icon={<Activity size={15} />} value={metrics.activeSessionExposures} label="Session exposures" tone="violet" />
      </div>
      <section className="branch-guidance"><GitBranch size={14} /><div><strong>Explore one branch at a time</strong><p>Select a direct exposure in the graph to reveal its highest-priority downstream AD objects.</p></div></section>
      <section className="panel-section legend-section">
        <div className="section-title"><div><BadgeCheck size={14} /><h3>State definitions</h3></div></div>
        <div className="state-legend">
          <div><i className="state-compromised" /><span><strong>Compromised</strong> Confirmed security evidence</span></div>
          <div><i className="state-risk" /><span><strong>Potentially at risk</strong> Security-relevant reachable object</span></div>
          <div><i className="state-reachable" /><span><strong>Reachable</strong> Connected under modeled assumptions</span></div>
        </div>
      </section>
      <section className="assumption-box"><strong>Analysis assumptions</strong>{blast.assumptions.map((item) => <p key={item}><CircleDot size={9} /> {item}</p>)}</section>
      <button className="primary-panel-action" onClick={onViewPaths}><Route size={15} /> Investigate possible attack paths</button>
    </div>
  );
}

function AttackPathsPanel({ details, response, loading, targets, targetId, selectedPathId, onTargetChange, onPathSelect }: {
  details: IdentityDetails; response: AttackPathsResponse | null; loading: boolean;
  targets: Array<{ id: string; label: string; type: string }>; targetId: string; selectedPathId: string | null;
  onTargetChange: (id: string) => void; onPathSelect: (id: string) => void;
}) {
  const selectedPath = response?.paths.find((path) => path.id === selectedPathId) ?? null;
  return (
    <div className="panel-scroll">
      <div className="view-intro path-intro"><div className="view-icon"><Route size={19} /></div><div><span>Possible Attack Paths</span><h3>How could an attacker move?</h3><p>Modeled routes from <strong>{details.accountName}</strong> to a selected target.</p></div></div>
      <label className="target-picker"><span><Target size={12} /> Target</span><select value={targetId} onChange={(event) => onTargetChange(event.target.value)}>{targets.map((target) => <option key={target.id} value={target.id}>{target.label} — {target.type}</option>)}</select><ChevronDown size={13} /></label>
      {loading || !response ? <LoadingState label="Finding strongest viable routes…" /> : (
        <>
          <section className="reachability-card">
            <div><span>Overall Reachability Risk</span><RiskBadge level={response.overallRiskLevel} score={response.overallReachabilityRisk} /></div>
            <div className="reachability-stats"><span><strong>{response.paths[0].riskScore}</strong> Strongest path</span><span><strong>{response.paths.length - 1}</strong> Alternative paths</span><span><strong>{formatConfidence(response.confidence)}</strong> Confidence</span></div>
            <p>{response.explanation}</p>
          </section>
          <div className="paths-heading"><strong>{response.paths.length} relevant routes</strong><span>ranked by viability and risk</span></div>
          <div className="path-list">
            {response.paths.map((path, index) => <PathCard key={path.id} path={path} index={index} strongest={path.id === response.strongestPathId} selected={path.id === selectedPathId} onSelect={() => onPathSelect(path.id)} />)}
          </div>
          {selectedPath && <PathExplanation path={selectedPath} />}
          <p className="precision-note prominent"><CircleDot size={11} /> A possible route does not mean the target is compromised.</p>
        </>
      )}
    </div>
  );
}

function PathCard({ path, index, strongest, selected, onSelect }: { path: AttackPath; index: number; strongest: boolean; selected: boolean; onSelect: () => void }) {
  return (
    <button className={`path-card ${selected ? 'selected' : ''}`} onClick={onSelect}>
      <div className="path-card-top"><span>Path {index + 1}</span>{strongest && <em>Strongest</em>}<RiskBadge level={path.riskLevel} compact /></div>
      <strong>{path.label}</strong>
      <div className="path-card-stats"><span><b>{path.riskScore}</b>/100</span><span>{path.hops} hops</span><span>{formatConfidence(path.confidence)} confidence</span></div>
      <div className="path-mini-route">{path.steps.map((step, stepIndex) => <span key={step.relationshipId}>{stepIndex === 0 && <b>{step.sourceName}</b>}<i>{step.relationshipLabel}</i><b>{step.targetName}</b></span>)}</div>
    </button>
  );
}

function PathExplanation({ path }: { path: AttackPath }) {
  return (
    <section className="path-explanation">
      <div className="section-title"><div><GitBranch size={14} /><h3>Why this path exists</h3></div><span>{path.id.toUpperCase()}</span></div>
      <div className="path-steps">
        {path.steps.map((step, index) => (
          <div key={step.relationshipId}><span className="step-number">{index + 1}</span><div><strong>{step.sourceName} <i>→ {step.relationshipLabel} →</i> {step.targetName}</strong><p>{step.explanation}</p></div></div>
        ))}
      </div>
      <div className="mitigations"><strong>Mitigating controls</strong>{path.mitigatingControls.map((control) => <span key={control}><ShieldCheck size={10} /> {control}</span>)}</div>
    </section>
  );
}

function RelationshipPanel({ relationship, onClose }: { relationship: RelationshipDetails; onClose: () => void }) {
  return (
    <>
      <div className="panel-header relationship-header">
        <div className="panel-nav-row"><span className="panel-eyebrow"><GitBranch size={11} /> Relationship detail</span><button className="icon-button tiny" onClick={onClose}><X size={15} /></button></div>
        <div className="relationship-route"><strong>{relationship.sourceName}</strong><span><GitBranch size={13} /> {RELATIONSHIP_LABELS[relationship.relationshipType]}</span><strong>{relationship.targetName}</strong></div>
      </div>
      <div className="panel-scroll">
        <section className="relationship-risk"><span>Risk contribution</span><strong>+{relationship.riskContribution}</strong><small>{formatConfidence(relationship.confidence)} confidence</small></section>
        <section className="panel-section"><div className="section-title"><div><KeyRound size={14} /><h3>Effective access</h3></div></div><p className="access-summary">{relationship.effectiveAccess}</p><div className="identity-tags"><span>{relationship.direct ? 'Direct' : `Inherited via ${relationship.inheritedFrom}`}</span><span>{RELATIONSHIP_LABELS[relationship.relationshipType]}</span></div></section>
        <section className="panel-section"><div className="section-title"><div><Clock3 size={14} /><h3>Observation</h3></div></div><dl className="detail-list"><div><dt>First observed</dt><dd>{new Date(relationship.firstObserved).toLocaleDateString()}</dd></div><div><dt>Last observed</dt><dd>{relativeTime(relationship.lastObserved)}</dd></div><div><dt>Confidence</dt><dd>{formatConfidence(relationship.confidence)}</dd></div></dl></section>
        <section className="panel-section"><div className="section-title"><div><FileSearch size={14} /><h3>Security properties</h3></div></div><div className="property-list">{relationship.securityProperties.map((property) => <span key={property}><CircleDot size={9} />{property}</span>)}</div></section>
        <button className="secondary-panel-action"><ExternalLink size={14} /> Open supporting evidence</button>
      </div>
    </>
  );
}

function Metric({ value, label }: { value: number; label: string }) { return <div className="metric"><strong>{value}</strong><span>{label}</span></div>; }
function ImpactMetric({ icon, value, label, tone }: { icon: React.ReactNode; value: number; label: string; tone: string }) { return <div className={`impact-metric tone-${tone}`}><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></div>; }
