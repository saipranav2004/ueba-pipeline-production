import type { RiskLevel } from '../../types/security';
import { RISK_META } from '../../utils/risk';

export function RiskBadge({ level, score, compact = false }: { level: RiskLevel; score?: number; compact?: boolean }) {
  const risk = RISK_META[level];
  return (
    <span className={`risk-badge ${compact ? 'is-compact' : ''}`} style={{ color: risk.color, background: risk.bg }}>
      <i style={{ background: risk.color }} />
      {risk.label}{score !== undefined && !compact ? ` · ${score}` : ''}
    </span>
  );
}
