import { LoaderCircle } from 'lucide-react';

export function LoadingState({ label = 'Loading security graph…' }: { label?: string }) {
  return <div className="loading-state"><LoaderCircle size={19} className="spin" /><span>{label}</span></div>;
}
