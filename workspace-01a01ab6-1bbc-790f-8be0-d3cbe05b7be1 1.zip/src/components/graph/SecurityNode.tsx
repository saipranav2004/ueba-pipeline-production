import { memo, type MouseEvent } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import {
  ChevronRight, Crown, Database, HardDrive, KeyRound, Layers3, Laptop, Network,
  Plus, Server, ShieldAlert, ShieldCheck, UserRound, UsersRound,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { AggregateGraphNode, SecurityGraphNode } from '../../types/security';
import { IDENTITY_LABELS, RISK_META } from '../../utils/risk';

const TYPE_ICONS: Record<string, LucideIcon> = {
  user: UserRound,
  privilegedUser: Crown,
  group: UsersRound,
  serviceAccount: KeyRound,
  computer: Laptop,
  server: Server,
  domainController: Network,
  criticalAsset: Database,
};

const TYPE_COLORS: Record<string, string> = {
  user: '#7396c8',
  privilegedUser: '#b69af4',
  group: '#6ba6ce',
  serviceAccount: '#d3a86c',
  computer: '#8097ae',
  server: '#6d9dc2',
  domainController: '#b58ae2',
  criticalAsset: '#d18d6e',
};

function SecurityNodeComponent({ id, data, selected }: NodeProps<SecurityGraphNode>) {
  const Icon = TYPE_ICONS[data.identityType] ?? HardDrive;
  const risk = RISK_META[data.riskLevel];
  const isCompromised = data.status === 'compromised';
  const isPotential = data.investigationState === 'potentially-at-risk';

  const expand = (event: MouseEvent) => {
    event.stopPropagation();
    data.onExpand?.(id);
  };

  return (
    <div
      className={`security-node risk-${data.riskLevel} state-${data.investigationState ?? 'normal'} ${selected || data.selected ? 'is-selected' : ''} ${data.faded ? 'is-faded' : ''} ${data.highlighted ? 'is-highlighted' : ''} ${isCompromised ? 'is-compromised' : ''}`}
      style={{ '--risk-color': risk.color, '--type-color': TYPE_COLORS[data.identityType] } as React.CSSProperties}
      aria-label={`${data.displayName}, ${IDENTITY_LABELS[data.identityType]}, ${risk.label} risk`}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />
      {isCompromised && (
        <div className="compromised-ribbon"><ShieldAlert size={10} /> Compromised</div>
      )}
      {isPotential && !isCompromised && <div className="potential-ribbon">Potentially at risk</div>}
      <div className="node-main">
        <div className="node-type-icon"><Icon size={18} strokeWidth={1.8} /></div>
        <div className="node-copy">
          <div className="node-title" title={data.displayName}>{data.displayName}</div>
          <div className="node-subtitle">{IDENTITY_LABELS[data.identityType]}</div>
        </div>
        <div className="node-signals">
          {data.privileged && <span className="privilege-mark" title="Privileged identity"><ShieldCheck size={12} /></span>}
          <span className="risk-dot" title={`${risk.label} risk`} />
        </div>
      </div>
      {data.blastBranch && (
        <div
          className={`node-branch-row ${data.blastBranch.active ? 'is-active' : ''}`}
          title={`${data.blastBranch.downstreamCount} downstream reachable objects via ${data.blastBranch.relationshipLabel}`}
        >
          <span className="branch-count"><Layers3 size={10} /><strong>{data.blastBranch.downstreamCount}</strong><small>downstream</small></span>
          <span className="branch-action">{data.blastBranch.active ? 'Collapse' : 'Explore'}<ChevronRight size={9} /></span>
        </div>
      )}
      {data.mode === 'soc' && !data.blastBranch && (
        <div className="node-soc-row">
          <span>Risk <strong>{data.riskScore}</strong></span>
          {data.criticality && data.criticality !== 'standard' && <span className="tier-label">{data.criticality.toUpperCase()}</span>}
        </div>
      )}
      {data.onExpand && <button className="node-expand nodrag" onClick={expand} title="Expand connected identities" aria-label={`Expand ${data.displayName}`}>
        <Plus size={11} />
      </button>}
      <Handle type="source" position={Position.Right} className="node-handle" />

      <div className="node-tooltip" role="tooltip">
        <div className="tooltip-kicker">{IDENTITY_LABELS[data.identityType]}</div>
        <div className="tooltip-name">{data.displayName}</div>
        <div className="tooltip-grid">
          <span>State</span><strong>{data.investigationState === 'potentially-at-risk' ? 'Potentially at risk' : data.investigationState === 'reachable' ? 'Reachable' : isCompromised ? 'Compromised' : 'Connected'}</strong>
          <span>Risk</span><strong style={{ color: risk.color }}>{risk.label} · {data.riskScore}/100</strong>
          <span>Potential reach</span><strong>{data.blastRadius.potentiallyAffected} identities</strong>
          <span>Critical assets</span><strong>{data.blastRadius.criticalAssets}</strong>
        </div>
        <div className="tooltip-foot">{data.blastBranch ? `Click to expand this ${data.blastBranch.relationshipLabel} branch` : 'Click to investigate · + to expand'}</div>
      </div>
    </div>
  );
}

export const SecurityNode = memo(SecurityNodeComponent);

export function AggregateNode({ data, selected }: NodeProps<AggregateGraphNode>) {
  const isBranchOverflow = data.kind === 'branch-overflow';
  return (
    <div className={`aggregate-node ${isBranchOverflow ? 'branch-overflow-node' : ''} ${selected ? 'is-selected' : ''} ${data.faded ? 'is-faded' : ''}`}>
      <Handle type="target" position={Position.Left} className="node-handle" />
      <span className="aggregate-icon"><Layers3 size={16} /></span>
      {isBranchOverflow ? (
        <div><strong>+{data.count} reachable objects</strong><span>Load the next results</span></div>
      ) : (
        <div><strong>+{data.count} identities</strong><span>{data.label || 'Grouped relationships'}</span></div>
      )}
      <Plus size={14} className="aggregate-plus" />
    </div>
  );
}
