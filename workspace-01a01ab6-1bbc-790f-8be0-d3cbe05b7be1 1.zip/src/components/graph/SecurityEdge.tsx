import { memo } from 'react';
import {
  BaseEdge, EdgeLabelRenderer, getBezierPath, type EdgeProps,
} from '@xyflow/react';
import type { SecurityGraphEdge } from '../../types/security';

const REL_COLORS: Record<string, string> = {
  MemberOf: '#6985a8',
  AdminOf: '#c28a58',
  HasSession: '#9a75b8',
  CanAccess: '#5d8998',
  CanDelegate: '#b77c98',
  CanImpersonate: '#a67491',
  Owns: '#66798b',
  Controls: '#ad755e',
  Trusts: '#6f7fa3',
  CanRDP: '#728cb5',
  CanResetPassword: '#a78563',
  SyncedTo: '#687f8a',
};

const BLAST_DEPTH_STYLE = {
  1: { color: '#59d8e7', width: 2.8, opacity: 0.98, dash: '10 7' },
  2: { color: '#50aeba', width: 2.2, opacity: 0.72, dash: '8 8' },
  3: { color: '#497c8b', width: 1.7, opacity: 0.46, dash: '6 9' },
  4: { color: '#3d5868', width: 1.3, opacity: 0.28, dash: '4 10' },
} as const;

function SecurityEdgeComponent(props: EdgeProps<SecurityGraphEdge>) {
  const { sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, markerEnd, data, selected } = props;
  const [path, labelX, labelY] = getBezierPath({ sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, curvature: 0.32 });
  const relationship = data?.relationshipType ?? 'CanAccess';
  const baseColor = REL_COLORS[relationship] ?? '#63758b';
  const elevated = (data?.riskContribution ?? 0) >= 28;
  const highlighted = data?.highlighted;
  const faded = data?.faded;
  const blastDepth = data?.blastFlow ? data.blastDepth : undefined;
  const blastStyle = blastDepth ? BLAST_DEPTH_STYLE[blastDepth] : null;
  const showLabel = data?.mode === 'soc' || highlighted || selected;
  const edgeClass = highlighted
    ? 'path-edge-flow'
    : blastStyle
      ? `blast-edge-flow blast-depth-${blastDepth}`
      : '';

  return (
    <>
      {highlighted && <BaseEdge path={path} style={{ stroke: '#49d6e8', strokeWidth: 8, opacity: 0.16, filter: 'blur(2px)' }} />}
      {blastDepth === 1 && !faded && !highlighted && (
        <BaseEdge path={path} style={{ stroke: blastStyle?.color, strokeWidth: 7, opacity: 0.1, filter: 'blur(2px)' }} />
      )}
      <BaseEdge
        path={path}
        markerEnd={markerEnd}
        className={edgeClass}
        style={{
          stroke: highlighted ? '#68dce9' : selected ? '#aab8c9' : blastStyle?.color ?? baseColor,
          strokeWidth: highlighted ? 2.8 : selected ? 2.4 : blastStyle?.width ?? (elevated ? 1.8 : 1.25),
          opacity: faded ? 0.07 : highlighted ? 1 : blastStyle?.opacity ?? (elevated ? 0.78 : 0.48),
          strokeDasharray: highlighted ? '7 6' : blastStyle?.dash,
        }}
      />
      {showLabel && !faded && (
        <EdgeLabelRenderer>
          <div
            className={`edge-label nodrag nopan ${highlighted ? 'is-highlighted' : ''}`}
            style={{ transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)` }}
          >
            {data?.label}
            {data?.direct === false && <span> inherited</span>}
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
}

export const SecurityEdge = memo(SecurityEdgeComponent);
