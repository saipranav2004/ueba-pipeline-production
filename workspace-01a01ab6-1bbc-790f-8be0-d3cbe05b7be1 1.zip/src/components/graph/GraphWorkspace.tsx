import { useEffect, useMemo, useRef } from 'react';
import {
  Background, BackgroundVariant, Controls, MarkerType, MiniMap, ReactFlow,
  useEdgesState, useNodesState, type ReactFlowInstance,
} from '@xyflow/react';
import { CircleDot, Info, Layers3, Maximize2, MousePointer2, Search } from 'lucide-react';
import type {
  AppGraphNode, AttackPath, BlastBranchResponse, BlastRadiusResponse, GraphFilters, GraphResponse, InvestigationView,
  SecurityGraphEdge, VisualizationMode,
} from '../../types/security';
import { layoutBlastStages } from '../../utils/blastLayout';
import { layoutGraph } from '../../utils/layout';
import { RISK_META } from '../../utils/risk';
import { AggregateNode, SecurityNode } from './SecurityNode';
import { SecurityEdge } from './SecurityEdge';

const nodeTypes = { security: SecurityNode, aggregate: AggregateNode };
const edgeTypes = { security: SecurityEdge };

interface GraphWorkspaceProps {
  graph: GraphResponse | null;
  blast: BlastRadiusResponse | null;
  blastBranch: BlastBranchResponse | null;
  filters: GraphFilters;
  mode: VisualizationMode;
  view: InvestigationView;
  compromisedSourceId: string | null;
  selectedNodeId: string | null;
  selectedEdgeId: string | null;
  selectedPath: AttackPath | null;
  loading: boolean;
  error: string | null;
  fitNonce: number;
  recenterNonce: number;
  layoutNonce: number;
  onNodeSelect: (id: string) => void;
  onEdgeSelect: (id: string) => void;
  onExpandNode: (id: string) => void;
  onExpandAggregate: () => void;
  onBlastBranchSelect: (id: string) => void;
  onBlastBranchLoadMore: () => void;
  onInit: (instance: ReactFlowInstance<AppGraphNode, SecurityGraphEdge>) => void;
}

export function GraphWorkspace(props: GraphWorkspaceProps) {
  const instanceRef = useRef<ReactFlowInstance<AppGraphNode, SecurityGraphEdge> | null>(null);

  const displayed = useMemo(() => {
    if (!props.graph) return { nodes: [] as AppGraphNode[], edges: [] as SecurityGraphEdge[] };
    const pathNodeIds = new Set(props.selectedPath?.nodeIds ?? []);
    const pathEdgeIds = new Set(props.selectedPath?.edgeIds ?? []);
    const branchNodeIds = props.blastBranch?.nodes.map((node) => node.id) ?? [];
    const blastStageIds = props.view === 'blast' && props.blast
      ? new Set([props.blast.focusId, ...props.blast.directExposureIds, ...branchNodeIds])
      : null;
    const availableGraphNodes = [...new Map(
      [...props.graph.nodes, ...(props.blastBranch?.nodes ?? [])].map((node) => [node.id, node]),
    ).values()];
    const graphCandidates = blastStageIds
      ? availableGraphNodes.filter((node) => blastStageIds.has(node.id))
      : availableGraphNodes;

    const securityNodes = graphCandidates.filter((node) => {
      const isCompromisedSource = node.id === props.compromisedSourceId;
      const effectiveRiskLevel = isCompromisedSource ? 'critical' : node.data.riskLevel;
      const effectiveRiskScore = isCompromisedSource ? Math.max(85, node.data.riskScore) : node.data.riskScore;
      if (!props.filters.riskLevels.includes(effectiveRiskLevel)) return false;
      if (!props.filters.identityTypes.includes(node.data.identityType)) return false;
      if (props.filters.privilegedOnly && !node.data.privileged) return false;
      if (props.filters.compromisedOnly && !isCompromisedSource) return false;
      if (props.filters.riskyOnly && effectiveRiskScore < 35 && !node.data.privileged && !isCompromisedSource) return false;
      return true;
    });

    const visibleIds = new Set(securityNodes.map((node) => node.id));
    let edges: SecurityGraphEdge[];

    if (props.view === 'blast' && props.blast) {
      edges = props.blast.directExposureIds
        .filter((id) => visibleIds.has(id) && visibleIds.has(props.blast!.focusId))
        .map((id) => {
          const relationship = props.graph!.edges.find((edge) =>
            (edge.source === props.blast!.focusId && edge.target === id) ||
            (edge.target === props.blast!.focusId && edge.source === id),
          );
          return {
            id: `blast-direct-${relationship?.id ?? id}`,
            source: props.blast!.focusId,
            target: id,
            type: 'security' as const,
            data: relationship?.data
              ? { ...relationship.data, label: 'Direct exposure', blastDepth: 1 as const, blastFlow: true }
              : {
                  relationshipType: 'CanAccess' as const,
                  label: 'Direct exposure', direct: true, blastDepth: 1 as const, blastFlow: true,
                  effectiveAccess: 'Direct modeled exposure', riskContribution: 12, confidence: 0.8,
                  firstObserved: '2026-08-19T00:00:00Z', lastObserved: '2026-08-19T00:00:00Z',
                  securityProperties: ['Simplified for blast-radius overview'],
                },
          };
        });
    } else {
      edges = props.graph.edges.filter((edge) =>
        visibleIds.has(edge.source) && visibleIds.has(edge.target) &&
        !!edge.data && props.filters.relationshipTypes.includes(edge.data.relationshipType),
      );
    }

    const branchSummaryById = new Map(
      (props.blast?.branchSummaries ?? []).map((summary) => [summary.directExposureId, summary]),
    );
    let nodes: AppGraphNode[] = securityNodes.map((node) => {
      const isCompromisedSource = node.id === props.compromisedSourceId;
      const isInspectedNode = node.id === props.selectedNodeId;
      const branchSummary = branchSummaryById.get(node.id);
      const isActiveBranchRoot = props.blastBranch?.branchRootId === node.id;
      const isInactiveDirectExposure = !!props.blastBranch && !!props.blast?.directExposureIds.includes(node.id) && !isActiveBranchRoot;
      const baselineStatus = node.data.status === 'compromised' ? 'normal' : node.data.status;
      const baselineInvestigationState = node.data.investigationState === 'compromised'
        ? 'connected'
        : node.data.investigationState;
      const baselineRiskReasons = node.data.riskReasons.filter(
        (reason) => reason !== 'Selected compromised investigation source',
      );

      return {
        ...node,
        data: {
          ...node.data,
          status: isCompromisedSource ? 'compromised' : baselineStatus,
          riskScore: isCompromisedSource ? Math.max(85, node.data.riskScore) : node.data.riskScore,
          riskLevel: isCompromisedSource ? 'critical' : node.data.riskLevel,
          investigationState: isCompromisedSource ? 'compromised' : baselineInvestigationState,
          riskReasons: isCompromisedSource
            ? ['Selected compromised investigation source', ...baselineRiskReasons]
            : baselineRiskReasons,
          mode: props.mode,
          blastBranch: branchSummary ? {
            downstreamCount: branchSummary.downstreamCount,
            maxDepth: branchSummary.maxDepth,
            relationshipLabel: branchSummary.relationshipLabel,
            confidence: branchSummary.confidence,
            active: isActiveBranchRoot,
          } : undefined,
          selected: isInspectedNode,
          highlighted: pathNodeIds.has(node.id) || isActiveBranchRoot,
          faded: (!!props.selectedPath && !pathNodeIds.has(node.id)) || isInactiveDirectExposure,
          onExpand: props.view === 'blast' ? undefined : props.onExpandNode,
        },
      };
    });

    if (props.view === 'blast' && props.blastBranch) {
      edges.push(...props.blastBranch.edges.filter((edge) =>
        visibleIds.has(edge.source) && visibleIds.has(edge.target),
      ));

      if (props.blastBranch.hiddenCount > 0) {
        const overflowNodeId = `blast-branch-overflow-${props.blastBranch.branchRootId}`;
        nodes.push({
          id: overflowNodeId,
          type: 'aggregate',
          position: { x: 0, y: 0 },
          data: {
            label: 'Additional reachable objects',
            count: props.blastBranch.hiddenCount,
            parentId: props.blastBranch.branchRootId,
            aggregateType: 'mixed',
            kind: 'branch-overflow',
            subtitle: 'Expand the next highest-priority results',
          },
        });
        edges.push({
          id: `blast-branch-overflow-edge-${props.blastBranch.branchRootId}`,
          source: props.blastBranch.branchRootId,
          target: overflowNodeId,
          type: 'security',
          data: {
            relationshipType: 'CanAccess',
            label: 'Additional reach',
            direct: false,
            effectiveAccess: 'Additional reachable graph objects',
            riskContribution: 0,
            confidence: 0.75,
            blastDepth: 4,
            blastFlow: true,
            firstObserved: '2026-08-19T00:00:00Z',
            lastObserved: '2026-08-19T00:00:00Z',
            securityProperties: ['Truncated for graph readability'],
          },
        });
      }
    }

    edges = edges.map((edge) => {
      const blastDepth = edge.data?.blastDepth;
      const inactiveBlastEdge = !!props.blastBranch && edge.id.startsWith('blast-direct-') && edge.target !== props.blastBranch.branchRootId;
      const markerColor = inactiveBlastEdge ? '#2b3d49'
        : blastDepth === 1 ? '#59d8e7'
        : blastDepth === 2 ? '#50aeba'
          : blastDepth === 3 ? '#497c8b'
            : blastDepth === 4 ? '#3d5868'
              : '#657991';
      return {
        ...edge,
        markerEnd: { type: MarkerType.ArrowClosed, width: 12, height: 12, color: markerColor },
        data: {
          ...edge.data!,
          mode: props.view === 'blast' ? 'user' as const : props.mode,
          selected: edge.id === props.selectedEdgeId,
          highlighted: pathEdgeIds.has(edge.id),
          faded: (!!props.selectedPath && !pathEdgeIds.has(edge.id)) || inactiveBlastEdge,
        },
      };
    });

    if (props.graph.truncated && props.graph.hiddenCount > 0 && nodes.length > 0 && props.view === 'graph') {
      const aggregateId = `aggregate-${props.graph.focusId}`;
      nodes.push({
        id: aggregateId,
        type: 'aggregate',
        position: { x: 0, y: 0 },
        data: {
          label: `${props.graph.hiddenCount} additional related identities`,
          count: props.graph.hiddenCount,
          parentId: props.graph.focusId,
          aggregateType: 'mixed',
          kind: 'overflow',
          selected: props.selectedNodeId === aggregateId,
        },
      });
      if (visibleIds.has(props.graph.focusId)) {
        edges.push({
          id: `edge-${aggregateId}`,
          source: props.graph.focusId,
          target: aggregateId,
          type: 'security',
          data: {
            relationshipType: 'CanAccess', label: 'Additional related', direct: false,
            effectiveAccess: 'Aggregated related identities', riskContribution: 0, confidence: 0.7,
            firstObserved: '2026-08-19T00:00:00Z', lastObserved: '2026-08-19T00:00:00Z',
            securityProperties: ['Aggregated for graph readability'], mode: props.mode,
          },
        });
      }
    }

    if (props.view === 'blast' && props.blast) {
      const downstreamIds = [
        ...(props.blastBranch?.nodes.map((node) => node.id).filter((id) => visibleIds.has(id)) ?? []),
        ...(props.blastBranch?.hiddenCount
          ? [`blast-branch-overflow-${props.blastBranch.branchRootId}`]
          : []),
      ];
      nodes = layoutBlastStages(
        nodes,
        props.blast.focusId,
        props.blast.directExposureIds.filter((id) => visibleIds.has(id)),
        downstreamIds,
      );
    } else {
      nodes = layoutGraph(nodes, edges, props.graph.focusId, 'layered');
    }
    return { nodes, edges };
  }, [props.graph, props.blast, props.blastBranch, props.filters, props.mode, props.compromisedSourceId, props.selectedNodeId, props.selectedEdgeId, props.selectedPath, props.view, props.layoutNonce, props.onExpandNode]);

  const [nodes, setNodes, onNodesChange] = useNodesState<AppGraphNode>(displayed.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState<SecurityGraphEdge>(displayed.edges);

  useEffect(() => {
    setNodes(displayed.nodes);
    setEdges(displayed.edges);
  }, [displayed, setNodes, setEdges]);

  useEffect(() => {
    const timer = window.setTimeout(() => instanceRef.current?.fitView({ padding: 0.2, duration: 500, maxZoom: 1.15 }), 70);
    return () => window.clearTimeout(timer);
  }, [props.graph, props.blastBranch, props.view, props.layoutNonce]);

  useEffect(() => {
    if (props.fitNonce > 0) instanceRef.current?.fitView({ padding: 0.2, duration: 450, maxZoom: 1.2 });
  }, [props.fitNonce]);

  useEffect(() => {
    if (props.recenterNonce > 0 && props.selectedNodeId) {
      const node = instanceRef.current?.getNode(props.selectedNodeId);
      if (node) instanceRef.current?.setCenter(node.position.x + (node.measured?.width ?? 180) / 2, node.position.y + (node.measured?.height ?? 70) / 2, { zoom: 1.15, duration: 450 });
    }
  }, [props.recenterNonce, props.selectedNodeId]);

  useEffect(() => {
    if (!props.selectedPath || !instanceRef.current) return;
    const pathNodes = instanceRef.current.getNodes().filter((node) => props.selectedPath?.nodeIds.includes(node.id));
    const timer = window.setTimeout(() => instanceRef.current?.fitView({ nodes: pathNodes, padding: 0.3, duration: 550, maxZoom: 1.2 }), 80);
    return () => window.clearTimeout(timer);
  }, [props.selectedPath]);

  const handleInit = (instance: ReactFlowInstance<AppGraphNode, SecurityGraphEdge>) => {
    instanceRef.current = instance;
    props.onInit(instance);
  };

  const visibleSecurityCount = nodes.filter((node) => node.type === 'security').length;

  return (
    <main className="graph-workspace">
      <div className="graph-context-bar">
        <div className="context-crumb">
          <span className={`view-indicator view-${props.view}`}>{!props.graph ? <Search size={12} /> : props.view === 'graph' ? <MousePointer2 size={12} /> : props.view === 'blast' ? <Layers3 size={12} /> : <Maximize2 size={12} />}</span>
          <strong>{!props.graph ? 'Identity discovery' : props.view === 'graph' ? 'Identity context' : props.view === 'blast' ? 'Potential blast radius' : 'Possible attack paths'}</strong>
          {props.graph ? <span>Compromised source: {props.graph.nodes.find((node) => node.id === props.compromisedSourceId)?.data.displayName ?? props.graph.nodes.find((node) => node.id === props.graph?.focusId)?.data.displayName}</span> : <span>No compromised source selected</span>}
        </div>
        {props.graph && <div className="graph-count"><CircleDot size={10} />{props.view === 'blast' && props.blast
          ? props.blastBranch
            ? <span><strong>{props.blast.directExposureIds.length}</strong> direct exposures · showing <strong>{props.blastBranch.nodes.length}</strong> of <strong>{props.blastBranch.totalReachable}</strong> branch objects</span>
            : <span><strong>{props.blast.directExposureIds.length}</strong> of <strong>{props.blast.metrics.directExposures}</strong> direct exposures · select a branch to expand</span>
          : <span>Showing <strong>{visibleSecurityCount}</strong> of <strong>{props.graph.totalRelated}</strong> related identities</span>}
        </div>}
      </div>

      {props.view === 'blast' && props.blast && (
        <div className="blast-stage-headings" aria-hidden="true">
          <span><b>01</b> Compromised source</span>
          <span><b>02</b> Direct exposure</span>
          <span><b>03</b> Downstream reachability</span>
        </div>
      )}

      <ReactFlow<AppGraphNode, SecurityGraphEdge>
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onInit={handleInit}
        onNodeClick={(_, node) => {
          if (node.type === 'aggregate') {
            if (node.data.kind === 'overflow') props.onExpandAggregate();
            if (node.data.kind === 'branch-overflow') props.onBlastBranchLoadMore();
            return;
          }
          if (props.view === 'blast' && props.blast?.directExposureIds.includes(node.id)) {
            props.onBlastBranchSelect(node.id);
            return;
          }
          props.onNodeSelect(node.id);
          instanceRef.current?.setCenter(node.position.x + 90, node.position.y + 38, { zoom: 1.12, duration: 420 });
        }}
        onNodeDoubleClick={(_, node) => { if (node.type === 'security' && props.view !== 'blast') props.onExpandNode(node.id); }}
        onEdgeClick={(_, edge) => { if (!edge.id.startsWith('blast-')) props.onEdgeSelect(edge.id); }}
        onPaneClick={() => undefined}
        minZoom={0.22}
        maxZoom={2.1}
        fitView
        fitViewOptions={{ padding: 0.2, maxZoom: 1.15 }}
        proOptions={{ hideAttribution: true }}
        defaultEdgeOptions={{ type: 'security' }}
        selectionOnDrag={false}
        nodesConnectable={false}
        deleteKeyCode={null}
      >
        <Background variant={BackgroundVariant.Dots} gap={22} size={1} color="#233043" />
        {props.graph && <Controls position="bottom-left" showInteractive={false} />}
        {props.graph && <MiniMap
          position="bottom-right"
          pannable
          zoomable
          nodeStrokeWidth={2}
          nodeColor={(node) => {
            if (node.type === 'aggregate') return '#394557';
            const riskLevel = (node.data as { riskLevel?: keyof typeof RISK_META }).riskLevel;
            return riskLevel ? RISK_META[riskLevel].color : '#59677a';
          }}
          maskColor="rgba(5, 9, 15, .72)"
        />}
      </ReactFlow>

      {!props.loading && !props.graph && (
        <div className="graph-empty initial-state">
          <div><Search size={22} /></div>
          <span className="empty-eyebrow">Start an investigation</span>
          <h3>Select the compromised identity</h3>
          <p>Search the directory to identify the compromise source. The selected node will drive its risk context, potential blast radius, and possible attack-path analysis.</p>
          <button onClick={() => document.getElementById('identity-search-input')?.focus()}><Search size={13} /> Search identities</button>
        </div>
      )}
      {!props.loading && !!props.graph && nodes.length === 0 && (
        <div className="graph-empty"><div><Info size={22} /></div><h3>No relationships match these filters</h3><p>Broaden the risk, identity, or relationship filters to restore graph context.</p></div>
      )}
      {props.error && <div className="graph-error"><Info size={15} /><span>{props.error}</span></div>}
      {props.loading && <div className="graph-loading"><span className="loader-orbit" /><div><strong>Analyzing identity relationships</strong><small>Applying risk and reachability model…</small></div></div>}

      {props.graph && <div className="graph-legend">
        {(['critical', 'high', 'medium', 'low', 'normal'] as const).map((level) => <span key={level}><i style={{ background: RISK_META[level].color }} />{RISK_META[level].label}</span>)}
      </div>}

      {props.graph?.truncated && props.graph.hiddenCount > 0 && props.view === 'graph' && (
        <button className="truncation-banner" onClick={props.onExpandAggregate}>
          <Layers3 size={14} /><span><strong>Graph reduced for readability</strong> · {props.graph.hiddenCount} related identities are grouped</span><b>Expand next 10</b>
        </button>
      )}
    </main>
  );
}
