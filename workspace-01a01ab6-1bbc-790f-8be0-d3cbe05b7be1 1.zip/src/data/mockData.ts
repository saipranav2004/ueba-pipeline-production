import type {
  IdentityDetails,
  IdentityType,
  RelationshipSecurityData,
  RiskLevel,
  SecurityGraphEdge,
  SecurityGraphNode,
  SecurityStatus,
} from '../types/security';
import { scoreToRisk } from '../utils/risk';

type EntitySeed = {
  id: string;
  name: string;
  displayName: string;
  type: IdentityType;
  score: number;
  status?: SecurityStatus;
  privileged?: boolean;
  criticality?: 'tier-0' | 'tier-1' | 'tier-2' | 'standard';
  title?: string;
  department?: string;
  reasons?: string[];
  affected?: number;
  criticalAssets?: number;
  servers?: number;
  groups?: string[];
};

const E = (
  id: string,
  name: string,
  displayName: string,
  type: IdentityType,
  score: number,
  options: Omit<EntitySeed, 'id' | 'name' | 'displayName' | 'type' | 'score'> = {},
): EntitySeed => ({ id, name, displayName, type, score, ...options });

export const entitySeeds: EntitySeed[] = [
  E('u-john', 'john.smith', 'John Smith', 'user', 87, {
    department: 'Finance', title: 'Senior Financial Analyst', affected: 247,
    criticalAssets: 4, servers: 12, groups: ['Helpdesk Admins', 'IT Operations', 'Finance Users'],
    reasons: ['Credential exposure indicators', 'Suspicious authentication', 'Excessive group membership', 'Can administer critical server'],
  }),
  E('u-jane', 'jane.doe', 'Jane Doe', 'user', 18, { department: 'Finance', title: 'Controller', groups: ['Finance Users'], reasons: ['Password age exceeds policy'] }),
  E('u-michael', 'michael.chen', 'Michael Chen', 'user', 28, { department: 'Engineering', title: 'Software Engineer', groups: ['IT Operations'], reasons: ['Stale interactive session'] }),
  E('u-priya', 'priya.reddy', 'Priya Reddy', 'user', 8, { department: 'People', title: 'HR Business Partner', groups: ['Standard Users'] }),
  E('u-david', 'david.wilson', 'David Wilson', 'user', 42, { department: 'IT', title: 'Support Engineer', groups: ['Helpdesk Admins'], reasons: ['Local admin on 16 endpoints', 'Legacy authentication observed'] }),
  E('u-sarah', 'sarah.kim', 'Sarah Kim', 'user', 12, { department: 'Legal', title: 'Legal Counsel', groups: ['Standard Users'] }),
  E('u-robert', 'robert.brown', 'Robert Brown', 'user', 32, { department: 'Finance', title: 'Payroll Specialist', groups: ['Finance Users'], reasons: ['Access to sensitive payroll records'] }),
  E('u-emily', 'emily.nguyen', 'Emily Nguyen', 'user', 5, { department: 'Marketing', title: 'Campaign Manager', groups: ['Standard Users'] }),

  E('p-alice', 'alice.admin', 'Alice Morgan', 'privilegedUser', 72, { privileged: true, criticality: 'tier-0', department: 'IT', title: 'Directory Services Admin', affected: 312, criticalAssets: 6, servers: 18, groups: ['Domain Admins'], reasons: ['Member of Domain Admins', 'Active privileged session', 'Session exposed on member server'] }),
  E('p-bob', 'bob.admin', 'Bob Martinez', 'privilegedUser', 64, { privileged: true, criticality: 'tier-0', department: 'Infrastructure', title: 'Platform Administrator', affected: 288, criticalAssets: 5, servers: 22, groups: ['Domain Admins', 'Server Operators'], reasons: ['Member of Domain Admins', 'Privileged session on jump server'] }),
  E('p-carol', 'carol.ea', 'Carol Evans', 'privilegedUser', 55, { privileged: true, criticality: 'tier-0', department: 'IT', title: 'Enterprise Administrator', affected: 346, criticalAssets: 7, servers: 24, groups: ['Enterprise Admins'], reasons: ['Enterprise-wide administrative rights', 'Standing privilege'] }),
  E('p-breakglass', 'adm.breakglass', 'Emergency Admin', 'privilegedUser', 24, { privileged: true, criticality: 'tier-0', department: 'Security', title: 'Emergency Access Account', affected: 350, criticalAssets: 7, servers: 25, groups: ['Domain Admins'], reasons: ['Permanent Tier-0 membership', 'Interactive sign-in enabled'] }),

  E('g-domain-admins', 'DOMAIN\\Domain Admins', 'Domain Admins', 'group', 93, { privileged: true, criticality: 'tier-0', affected: 380, criticalAssets: 8, servers: 27, reasons: ['Tier-0 privileged group', 'Controls domain controllers', 'Broad effective permissions'] }),
  E('g-enterprise-admins', 'DOMAIN\\Enterprise Admins', 'Enterprise Admins', 'group', 96, { privileged: true, criticality: 'tier-0', affected: 412, criticalAssets: 9, servers: 30, reasons: ['Forest-wide privilege', 'Controls every domain'] }),
  E('g-helpdesk', 'DOMAIN\\Helpdesk Admins', 'Helpdesk Admins', 'group', 61, { privileged: true, criticality: 'tier-2', affected: 82, criticalAssets: 1, servers: 3, reasons: ['Admin access to shared servers', 'Can reset user passwords'] }),
  E('g-itops', 'DOMAIN\\IT Operations', 'IT Operations', 'group', 58, { privileged: true, criticality: 'tier-1', affected: 134, criticalAssets: 2, servers: 9, reasons: ['Administrative access to jump hosts', 'Broad server access'] }),
  E('g-backup', 'DOMAIN\\Backup Operators', 'Backup Operators', 'group', 77, { privileged: true, criticality: 'tier-0', affected: 301, criticalAssets: 6, servers: 20, reasons: ['Can read protected system data', 'Indirect Tier-0 reachability'] }),
  E('g-serverops', 'DOMAIN\\Server Operators', 'Server Operators', 'group', 52, { privileged: true, criticality: 'tier-1', affected: 112, criticalAssets: 2, servers: 15, reasons: ['Administrative access to production servers'] }),
  E('g-finance', 'DOMAIN\\Finance Users', 'Finance Users', 'group', 21, { department: 'Finance', affected: 48, criticalAssets: 1, servers: 2, reasons: ['Access to finance file shares'] }),

  E('s-backup', 'svc_backup', 'Backup Service', 'serviceAccount', 82, { privileged: true, criticality: 'tier-0', department: 'Infrastructure', affected: 305, criticalAssets: 6, servers: 19, groups: ['Domain Admins'], reasons: ['Service account in Domain Admins', 'Password not rotated in 426 days', 'Interactive logon enabled'] }),
  E('s-sql', 'svc_sqlprod', 'SQL Production Service', 'serviceAccount', 68, { privileged: true, criticality: 'tier-1', department: 'Data Platform', affected: 96, criticalAssets: 2, servers: 5, groups: ['Server Operators'], reasons: ['Kerberoastable SPN', 'Controls payroll database service'] }),
  E('s-deploy', 'svc_deploy', 'Deployment Service', 'serviceAccount', 47, { privileged: true, criticality: 'tier-1', department: 'Engineering', affected: 74, criticalAssets: 2, servers: 12, groups: ['Server Operators'], reasons: ['Broad deployment rights', 'Credential stored on build agent'] }),
  E('s-adfs', 'svc_adfs', 'Federation Service', 'serviceAccount', 57, { privileged: true, criticality: 'tier-0', department: 'Identity', affected: 330, criticalAssets: 4, servers: 4, reasons: ['Token-signing service identity', 'Delegation enabled'] }),

  E('c-john', 'WS-FIN-042', 'John’s Workstation', 'computer', 74, { status: 'potentially-at-risk', department: 'Finance', affected: 7, reasons: ['High-risk interactive session observed', 'EDR credential-theft alert'] }),
  E('c-jane', 'WS-FIN-018', 'Jane’s Workstation', 'computer', 12, { department: 'Finance' }),
  E('c-priya', 'LT-HR-011', 'Priya’s Laptop', 'computer', 8, { department: 'People' }),
  E('c-shared', 'WS-OPS-007', 'Operations Shared PC', 'computer', 49, { department: 'IT', affected: 16, reasons: ['Multiple privileged users signed in', 'Shared interactive workstation'] }),

  E('v-file', 'SRV-FILE01', 'Finance File Server', 'server', 63, { criticality: 'tier-1', affected: 43, criticalAssets: 1, servers: 1, reasons: ['Helpdesk has local administrator rights', 'Privileged session observed'] }),
  E('v-jump', 'SRV-JUMP01', 'Administration Jump Host', 'server', 71, { criticality: 'tier-0', affected: 198, criticalAssets: 4, servers: 8, reasons: ['Domain Admin session exposed', 'Reachable from IT Operations'] }),
  E('v-backup', 'SRV-BACKUP01', 'Enterprise Backup Server', 'server', 84, { criticality: 'tier-0', affected: 304, criticalAssets: 6, servers: 21, reasons: ['Stores reusable Tier-0 credential', 'Reachable through a weak management boundary'] }),
  E('v-sql', 'SRV-SQL01', 'Production SQL Server', 'server', 69, { criticality: 'tier-1', affected: 88, criticalAssets: 2, servers: 2, reasons: ['Hosts sensitive payroll data', 'Service account is Kerberoastable'] }),
  E('v-app', 'SRV-APP01', 'Finance Application Server', 'server', 54, { criticality: 'tier-1', affected: 62, criticalAssets: 1, servers: 3, reasons: ['Weak local admin boundary', 'Helpdesk administrative access'] }),
  E('v-adfs', 'SRV-ADFS01', 'Federation Server', 'server', 59, { criticality: 'tier-0', affected: 329, criticalAssets: 4, servers: 3, reasons: ['Delegation configured', 'Tier-0 federation role'] }),
  E('v-exchange', 'SRV-EXCH01', 'Exchange Server', 'server', 46, { criticality: 'tier-1', affected: 244, criticalAssets: 2, servers: 2, reasons: ['Privileged mailbox access path'] }),

  E('dc-01', 'DC-CORP-01', 'Primary Domain Controller', 'domainController', 88, { criticality: 'tier-0', affected: 420, criticalAssets: 9, servers: 31, reasons: ['Domain control plane', 'Reachable through modeled privileged path'] }),
  E('dc-02', 'DC-CORP-02', 'Secondary Domain Controller', 'domainController', 78, { criticality: 'tier-0', affected: 420, criticalAssets: 9, servers: 31, reasons: ['Domain control plane', 'Privileged sessions observed'] }),

  E('a-payroll', 'PAYROLL-PROD', 'Payroll Database', 'criticalAsset', 76, { criticality: 'tier-1', department: 'Finance', affected: 42, criticalAssets: 1, servers: 1, reasons: ['Regulated payroll data', 'Reachable through SQL service identity'] }),
  E('a-vault', 'IDENTITY-VAULT', 'Identity Credential Vault', 'criticalAsset', 91, { criticality: 'tier-0', department: 'Security', affected: 354, criticalAssets: 7, servers: 23, reasons: ['Stores privileged credentials', 'Controlled by Domain Admins'] }),
  E('a-erp', 'ERP-PROD', 'Enterprise ERP', 'criticalAsset', 67, { criticality: 'tier-1', department: 'Finance', affected: 206, criticalAssets: 2, servers: 4, reasons: ['Business-critical finance system', 'Broad delegated access'] }),
];

const relationshipDefaults = {
  direct: true,
  effectiveAccess: 'Relationship grants effective access',
  confidence: 0.9,
  firstObserved: '2026-05-14T09:30:00Z',
  lastObserved: '2026-08-19T07:42:00Z',
  securityProperties: [] as string[],
};

function edge(
  id: string,
  source: string,
  target: string,
  relationshipType: RelationshipSecurityData['relationshipType'],
  label: string,
  riskContribution: number,
  options: Partial<RelationshipSecurityData> = {},
): SecurityGraphEdge {
  return {
    id,
    source,
    target,
    type: 'security',
    data: {
      ...relationshipDefaults,
      relationshipType,
      label,
      riskContribution,
      securityProperties: ['Observed in directory security graph'],
      ...options,
    },
  };
}

export const mockEdges: SecurityGraphEdge[] = [
  edge('e-john-helpdesk', 'u-john', 'g-helpdesk', 'MemberOf', 'Member Of', 22, { effectiveAccess: 'Inherits helpdesk administrative rights', securityProperties: ['Nested membership: false', 'Security enabled: true'] }),
  edge('e-john-itops', 'u-john', 'g-itops', 'MemberOf', 'Member Of', 25, { effectiveAccess: 'Inherits IT operations access', securityProperties: ['Membership added outside standard role profile'] }),
  edge('e-john-finance', 'u-john', 'g-finance', 'MemberOf', 'Member Of', 4),
  edge('e-john-workstation', 'u-john', 'c-john', 'Owns', 'Primary Device', 16, { effectiveAccess: 'Interactive session and local profile', securityProperties: ['Active session', 'EDR alert: credential access'] }),
  edge('e-john-file', 'u-john', 'v-file', 'CanAccess', 'Can Access', 17, { effectiveAccess: 'Read/write finance shares' }),
  edge('e-john-jump', 'u-john', 'v-jump', 'CanRDP', 'Can RDP', 29, { effectiveAccess: 'Remote interactive logon', confidence: 0.94, securityProperties: ['RDP logon right', 'MFA not enforced'] }),
  edge('e-john-app', 'u-john', 'v-app', 'CanAccess', 'Can Access', 14, { effectiveAccess: 'Application operator access' }),
  edge('e-john-backup', 'u-john', 'v-backup', 'CanAccess', 'Can Access', 31, { effectiveAccess: 'Authenticated management endpoint access', confidence: 0.86, securityProperties: ['TCP management endpoint exposed', 'Credential relay feasible'] }),

  edge('e-helpdesk-file', 'g-helpdesk', 'v-file', 'AdminOf', 'Admin Access', 28, { effectiveAccess: 'Local administrator', securityProperties: ['Direct local group membership'] }),
  edge('e-helpdesk-app', 'g-helpdesk', 'v-app', 'AdminOf', 'Admin Access', 24, { effectiveAccess: 'Local administrator' }),
  edge('e-helpdesk-reset-jane', 'g-helpdesk', 'u-jane', 'CanResetPassword', 'Reset Password', 18, { effectiveAccess: 'Can reset password without current credential' }),
  edge('e-helpdesk-reset-robert', 'g-helpdesk', 'u-robert', 'CanResetPassword', 'Reset Password', 19),
  edge('e-itops-jump', 'g-itops', 'v-jump', 'AdminOf', 'Admin Access', 30, { effectiveAccess: 'Local administrator on Tier-0 jump host', confidence: 0.95 }),
  edge('e-itops-exchange', 'g-itops', 'v-exchange', 'AdminOf', 'Admin Access', 21),
  edge('e-itops-shared', 'g-itops', 'c-shared', 'AdminOf', 'Admin Access', 15),
  edge('e-file-alice', 'v-file', 'p-alice', 'HasSession', 'Has Session', 27, { effectiveAccess: 'Reusable privileged interactive session', confidence: 0.91, firstObserved: '2026-08-18T16:12:00Z', securityProperties: ['Logon type: RemoteInteractive', 'Credential material potentially present'] }),
  edge('e-app-alice', 'v-app', 'p-alice', 'HasSession', 'Has Session', 23, { effectiveAccess: 'Privileged service session', confidence: 0.82 }),
  edge('e-jump-bob', 'v-jump', 'p-bob', 'HasSession', 'Has Session', 33, { effectiveAccess: 'Reusable Domain Admin session', confidence: 0.96, firstObserved: '2026-08-19T06:10:00Z' }),
  edge('e-backup-svc', 'v-backup', 's-backup', 'HasSession', 'Has Session', 32, { effectiveAccess: 'Service credential material on host', confidence: 0.92 }),
  edge('e-alice-da', 'p-alice', 'g-domain-admins', 'MemberOf', 'Member Of', 35, { effectiveAccess: 'Full domain administration', confidence: 1 }),
  edge('e-bob-da', 'p-bob', 'g-domain-admins', 'MemberOf', 'Member Of', 35, { effectiveAccess: 'Full domain administration', confidence: 1 }),
  edge('e-breakglass-da', 'p-breakglass', 'g-domain-admins', 'MemberOf', 'Member Of', 31, { effectiveAccess: 'Full domain administration', confidence: 1 }),
  edge('e-carol-ea', 'p-carol', 'g-enterprise-admins', 'MemberOf', 'Member Of', 38, { effectiveAccess: 'Forest-wide administration', confidence: 1 }),
  edge('e-ea-da', 'g-enterprise-admins', 'g-domain-admins', 'Controls', 'Controls', 38, { effectiveAccess: 'Can modify Domain Admin membership', confidence: 0.98 }),
  edge('e-svcbackup-da', 's-backup', 'g-domain-admins', 'MemberOf', 'Member Of', 39, { effectiveAccess: 'Full domain administration', confidence: 1, securityProperties: ['Direct membership', 'Non-expiring password'] }),
  edge('e-svcbackup-backup', 's-backup', 'g-backup', 'MemberOf', 'Member Of', 27),
  edge('e-serverops-bob', 'p-bob', 'g-serverops', 'MemberOf', 'Member Of', 16),
  edge('e-sql-serverops', 's-sql', 'g-serverops', 'MemberOf', 'Member Of', 25),
  edge('e-deploy-serverops', 's-deploy', 'g-serverops', 'MemberOf', 'Member Of', 18),
  edge('e-serverops-sql', 'g-serverops', 'v-sql', 'AdminOf', 'Admin Access', 24),
  edge('e-serverops-app', 'g-serverops', 'v-app', 'AdminOf', 'Admin Access', 20),
  edge('e-sqlhost-svc', 'v-sql', 's-sql', 'HasSession', 'Has Session', 27),
  edge('e-sql-payroll', 's-sql', 'a-payroll', 'Controls', 'Controls', 30, { effectiveAccess: 'Database owner through SQL service' }),
  edge('e-app-erp', 'v-app', 'a-erp', 'CanAccess', 'Can Access', 22),
  edge('e-adfs-svc', 'v-adfs', 's-adfs', 'HasSession', 'Has Session', 28),
  edge('e-adfs-delegate', 's-adfs', 'dc-01', 'CanDelegate', 'Can Delegate', 34, { effectiveAccess: 'Constrained delegation to directory service', securityProperties: ['msDS-AllowedToDelegateTo: ldap/DC-CORP-01'] }),

  edge('e-da-dc1', 'g-domain-admins', 'dc-01', 'AdminOf', 'Admin Access', 40, { effectiveAccess: 'Full control of domain controller', confidence: 1 }),
  edge('e-da-dc2', 'g-domain-admins', 'dc-02', 'AdminOf', 'Admin Access', 40, { effectiveAccess: 'Full control of domain controller', confidence: 1 }),
  edge('e-da-vault', 'g-domain-admins', 'a-vault', 'Controls', 'Controls', 37, { effectiveAccess: 'Administrative control over vault infrastructure' }),
  edge('e-da-erp', 'g-domain-admins', 'a-erp', 'Controls', 'Controls', 31),
  edge('e-dc1-dc2', 'dc-01', 'dc-02', 'Trusts', 'Replication Trust', 18, { effectiveAccess: 'Bidirectional directory replication', confidence: 1 }),
  edge('e-dc1-vault', 'dc-01', 'a-vault', 'CanAccess', 'Can Access', 24),
  edge('e-dc2-adfs', 'dc-02', 'v-adfs', 'Trusts', 'Trusts', 25),

  edge('e-jane-finance', 'u-jane', 'g-finance', 'MemberOf', 'Member Of', 3),
  edge('e-robert-finance', 'u-robert', 'g-finance', 'MemberOf', 'Member Of', 4),
  edge('e-priya-workstation', 'u-priya', 'c-priya', 'Owns', 'Primary Device', 2),
  edge('e-jane-workstation', 'u-jane', 'c-jane', 'Owns', 'Primary Device', 2),
  edge('e-david-helpdesk', 'u-david', 'g-helpdesk', 'MemberOf', 'Member Of', 18),
  edge('e-michael-itops', 'u-michael', 'g-itops', 'MemberOf', 'Member Of', 13),
  edge('e-shared-alice', 'c-shared', 'p-alice', 'HasSession', 'Has Session', 24),
  edge('e-shared-bob', 'c-shared', 'p-bob', 'HasSession', 'Has Session', 25),
  edge('e-finance-payroll', 'g-finance', 'a-payroll', 'CanAccess', 'Can Access', 12, { effectiveAccess: 'Application-level payroll access' }),
  edge('e-finance-erp', 'g-finance', 'a-erp', 'CanAccess', 'Can Access', 11),
  edge('e-backup-vault', 'g-backup', 'a-vault', 'CanAccess', 'Can Access', 29, { effectiveAccess: 'Backup and restore vault data' }),
  edge('e-deploy-app', 's-deploy', 'v-app', 'AdminOf', 'Admin Access', 20),
  edge('e-deploy-exchange', 's-deploy', 'v-exchange', 'CanAccess', 'Can Access', 15),
  edge('e-exchange-carol', 'v-exchange', 'p-carol', 'CanImpersonate', 'Can Impersonate', 28, { effectiveAccess: 'Mailbox application impersonation' }),
  edge('e-erp-sql', 'a-erp', 'v-sql', 'SyncedTo', 'Data Sync', 14),
  edge('e-sarah-shared', 'u-sarah', 'c-shared', 'CanAccess', 'Can Access', 3),
  edge('e-emily-shared', 'u-emily', 'c-shared', 'CanAccess', 'Can Access', 2),
];

const identityTypeDn: Record<IdentityType, string> = {
  user: 'OU=Users', privilegedUser: 'OU=Privileged Accounts', group: 'OU=Security Groups',
  serviceAccount: 'OU=Service Accounts', computer: 'OU=Workstations', server: 'OU=Servers',
  domainController: 'OU=Domain Controllers', criticalAsset: 'OU=Critical Assets',
};

export const entityDetails: Record<string, IdentityDetails> = Object.fromEntries(
  entitySeeds.map((seed, index) => {
    const riskLevel: RiskLevel = scoreToRisk(seed.score);
    const reasons = seed.reasons ?? (seed.score < 15 ? ['No material security findings'] : ['Elevated relationship exposure']);
    const detail: IdentityDetails = {
      id: seed.id,
      displayName: seed.displayName,
      accountName: seed.name,
      identityType: seed.type,
      title: seed.title,
      department: seed.department,
      riskScore: seed.score,
      riskLevel,
      status: seed.status ?? 'normal',
      privileged: seed.privileged ?? false,
      criticality: seed.criticality ?? 'standard',
      riskReasons: reasons.map((title, reasonIndex) => ({
        title,
        description: reasonIndex === 0
          ? 'This finding materially increases modeled identity reachability.'
          : 'Observed directory or authentication evidence contributes to this risk.',
        contribution: Math.max(4, Math.round(seed.score / (reasons.length + 1)) - reasonIndex * 2),
      })),
      blastRadius: {
        potentiallyAffected: seed.affected ?? Math.max(2, Math.round(seed.score * 0.8)),
        privilegedIdentities: seed.privileged ? Math.max(1, Math.round(seed.score / 22)) : Math.round(seed.score / 30),
        criticalAssets: seed.criticalAssets ?? Math.round(seed.score / 30),
        servers: seed.servers ?? Math.round(seed.score / 13),
        domainControllers: seed.criticality === 'tier-0' ? 2 : seed.score > 75 ? 1 : 0,
        highRiskIdentities: Math.round(seed.score / 8),
      },
      sid: `S-1-5-21-2874519382-1149284751-3765019284-${1100 + index}`,
      distinguishedName: `CN=${seed.displayName},${identityTypeDn[seed.type]},DC=corp,DC=example,DC=com`,
      lastAuthentication: seed.type === 'group' || seed.type === 'criticalAsset' ? undefined : `2026-08-${String(19 - (index % 5)).padStart(2, '0')}T${String(7 + (index % 9)).padStart(2, '0')}:24:00Z`,
      authenticationSource: seed.type === 'serviceAccount' ? 'Kerberos service ticket' : 'Windows interactive / SSO',
      activeSessions: seed.type === 'user' || seed.type === 'privilegedUser' ? index % 4 : seed.type === 'serviceAccount' ? 3 : 0,
      groupMemberships: seed.groups ?? [],
      evidence: reasons.slice(0, 3).map((reason, evidenceIndex) => ({
        type: evidenceIndex === 0 && seed.status === 'compromised' ? 'Detection' : evidenceIndex % 2 ? 'Directory configuration' : 'Authentication telemetry',
        summary: reason,
        observedAt: `2026-08-${String(19 - evidenceIndex).padStart(2, '0')}T0${8 + evidenceIndex}:42:00Z`,
        confidence: Math.max(0.7, 0.96 - evidenceIndex * 0.08),
      })),
    };
    return [seed.id, detail];
  }),
);

export function toGraphNode(seed: EntitySeed): SecurityGraphNode {
  const details = entityDetails[seed.id];
  return {
    id: seed.id,
    type: 'security',
    position: { x: 0, y: 0 },
    data: {
      name: seed.name,
      displayName: seed.displayName,
      identityType: seed.type,
      riskScore: seed.score,
      riskLevel: details.riskLevel,
      status: details.status,
      privileged: details.privileged,
      criticality: details.criticality,
      blastRadius: {
        potentiallyAffected: details.blastRadius.potentiallyAffected,
        privilegedIdentities: details.blastRadius.privilegedIdentities,
        criticalAssets: details.blastRadius.criticalAssets,
        servers: details.blastRadius.servers,
      },
      riskReasons: details.riskReasons.map((reason) => reason.title),
    },
  };
}

export const mockNodes = entitySeeds.map(toGraphNode);
