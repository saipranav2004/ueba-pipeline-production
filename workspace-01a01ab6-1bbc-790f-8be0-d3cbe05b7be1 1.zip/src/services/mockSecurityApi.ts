import { entityDetails, entitySeeds, mockEdges, mockNodes } from '../data/mockData';
import type {
  AttackPath,
  AttackPathsResponse,
  BlastBranchResponse,
  BlastBranchSummary,
  BlastRadiusResponse,
  GraphResponse,
  IdentityDetails,
  RelationshipDetails,
  SecurityGraphEdge,
  SecurityGraphNode,
} from '../types/security';
import { scoreToRisk } from '../utils/risk';

const nodeById = new Map(mockNodes.map((node) => [node.id, node]));
const seedById = new Map(entitySeeds.map((seed) => [seed.id, seed]));
const edgeById = new Map(mockEdges.map((edge) => [edge.id, edge]));

const adjacency = new Map<string, Array<{ nodeId: string; edge: SecurityGraphEdge }>>();
mockNodes.forEach((node) => adjacency.set(node.id, []));
mockEdges.forEach((edge) => {
  adjacency.get(edge.source)?.push({ nodeId: edge.target, edge });
  adjacency.get(edge.target)?.push({ nodeId: edge.source, edge });
});

function wait<T>(value: T, delay = 180): Promise<T> {
  return new Promise((resolve) => window.setTimeout(() => resolve(structuredClone(value)), delay));
}

function graphForIds(focusId: string, ids: Set<string>, totalRelated?: number): GraphResponse {
  const nodes = [...ids].map((id) => nodeById.get(id)).filter(Boolean) as SecurityGraphNode[];
  const edges = mockEdges.filter((edge) => ids.has(edge.source) && ids.has(edge.target));
  const related = totalRelated ?? Math.max(nodes.length - 1, entityDetails[focusId]?.blastRadius.potentiallyAffected ?? 0);
  return {
    focusId,
    nodes,
    edges,
    totalRelated: related,
    truncated: related > nodes.length - 1,
    hiddenCount: Math.max(0, related - (nodes.length - 1)),
  };
}

function traverse(focusId: string, depth: number, limit: number): Set<string> {
  const visited = new Set<string>([focusId]);
  const queue: Array<{ id: string; depth: number }> = [{ id: focusId, depth: 0 }];

  while (queue.length && visited.size < limit) {
    const current = queue.shift()!;
    if (current.depth >= depth) continue;
    const neighbors = [...(adjacency.get(current.id) ?? [])].sort((a, b) => {
      const aNode = nodeById.get(a.nodeId)!;
      const bNode = nodeById.get(b.nodeId)!;
      const aPriority = (aNode.data.status === 'compromised' ? 100 : 0) + (aNode.data.privileged ? 25 : 0) + aNode.data.riskScore + (a.edge.data?.riskContribution ?? 0);
      const bPriority = (bNode.data.status === 'compromised' ? 100 : 0) + (bNode.data.privileged ? 25 : 0) + bNode.data.riskScore + (b.edge.data?.riskContribution ?? 0);
      return bPriority - aPriority;
    });
    for (const next of neighbors) {
      if (!visited.has(next.nodeId) && visited.size < limit) {
        visited.add(next.nodeId);
        queue.push({ id: next.nodeId, depth: current.depth + 1 });
      }
    }
  }
  return visited;
}

function pathStep(edgeId: string, explanation: string) {
  const relationship = edgeById.get(edgeId)!;
  return {
    sourceId: relationship.source,
    sourceName: seedById.get(relationship.source)?.displayName ?? relationship.source,
    relationshipId: relationship.id,
    relationshipType: relationship.data!.relationshipType,
    relationshipLabel: relationship.data!.label,
    targetId: relationship.target,
    targetName: seedById.get(relationship.target)?.displayName ?? relationship.target,
    explanation,
  };
}

const attackPaths: AttackPath[] = [
  {
    id: 'path-1', label: 'Helpdesk session exposure', sourceId: 'u-john', targetId: 'g-domain-admins',
    riskScore: 91, riskLevel: 'critical', hops: 4, confidence: 0.91,
    reasons: ['Compromised source inherits helpdesk admin rights', 'Local admin access enables credential extraction', 'Exposed Domain Admin session provides a high-confidence escalation route'],
    nodeIds: ['u-john', 'g-helpdesk', 'v-file', 'p-alice', 'g-domain-admins'],
    edgeIds: ['e-john-helpdesk', 'e-helpdesk-file', 'e-file-alice', 'e-alice-da'],
    steps: [
      pathStep('e-john-helpdesk', 'John inherits administrative rights through direct security-group membership.'),
      pathStep('e-helpdesk-file', 'Helpdesk Admins are local administrators on the Finance File Server.'),
      pathStep('e-file-alice', 'A reusable privileged session for Alice is observed on this server.'),
      pathStep('e-alice-da', 'Alice is a direct member of Domain Admins.'),
    ],
    mitigatingControls: ['EDR isolation can interrupt the first movement step', 'Removing the privileged session would break this route'],
  },
  {
    id: 'path-2', label: 'IT Operations jump-host route', sourceId: 'u-john', targetId: 'g-domain-admins',
    riskScore: 78, riskLevel: 'high', hops: 4, confidence: 0.84,
    reasons: ['Excessive IT Operations membership', 'Administrative access to a Tier-0 jump host', 'Active Domain Admin session is present'],
    nodeIds: ['u-john', 'g-itops', 'v-jump', 'p-bob', 'g-domain-admins'],
    edgeIds: ['e-john-itops', 'e-itops-jump', 'e-jump-bob', 'e-bob-da'],
    steps: [
      pathStep('e-john-itops', 'John has direct membership in IT Operations outside his standard role profile.'),
      pathStep('e-itops-jump', 'IT Operations has local administrator access on the administration jump host.'),
      pathStep('e-jump-bob', 'Bob’s Domain Admin session is active on the jump host.'),
      pathStep('e-bob-da', 'Bob is a direct member of Domain Admins.'),
    ],
    mitigatingControls: ['Jump-host network controls reduce exploitability', 'Privileged access management approval may be required'],
  },
  {
    id: 'path-3', label: 'Backup service-account route', sourceId: 'u-john', targetId: 'g-domain-admins',
    riskScore: 54, riskLevel: 'medium', hops: 3, confidence: 0.72,
    reasons: ['Management endpoint is reachable', 'Backup credential material may be recoverable', 'Backup service account has direct privileged membership'],
    nodeIds: ['u-john', 'v-backup', 's-backup', 'g-domain-admins'],
    edgeIds: ['e-john-backup', 'e-backup-svc', 'e-svcbackup-da'],
    steps: [
      pathStep('e-john-backup', 'John can authenticate to an exposed backup management endpoint.'),
      pathStep('e-backup-svc', 'Backup service credential material is modeled as present on the server.'),
      pathStep('e-svcbackup-da', 'The backup service account is a direct member of Domain Admins.'),
    ],
    mitigatingControls: ['Endpoint access is segmented', 'Credential retrieval requires a second exploitation condition'],
  },
];

function orientedPathStep(edgeId: string, sourceId: string, targetId: string, explanation: string) {
  const relationship = edgeById.get(edgeId)!;
  return {
    sourceId,
    sourceName: seedById.get(sourceId)?.displayName ?? sourceId,
    relationshipId: relationship.id,
    relationshipType: relationship.data!.relationshipType,
    relationshipLabel: relationship.data!.label,
    targetId,
    targetName: seedById.get(targetId)?.displayName ?? targetId,
    explanation,
  };
}

function curatedPathsToTarget(targetId: string): AttackPath[] {
  if (targetId === 'g-domain-admins') return attackPaths;

  if (targetId === 'p-alice') {
    return [
      {
        ...attackPaths[0], id: 'path-alice-1', label: 'Helpdesk credential-exposure route', targetId,
        riskScore: 88, riskLevel: 'critical', hops: 3,
        nodeIds: ['u-john', 'g-helpdesk', 'v-file', 'p-alice'],
        edgeIds: ['e-john-helpdesk', 'e-helpdesk-file', 'e-file-alice'],
        steps: attackPaths[0].steps.slice(0, 3),
        reasons: ['Compromised source inherits helpdesk rights', 'Local administration enables credential access', 'Alice has an exposed privileged session'],
      },
      {
        ...attackPaths[1], id: 'path-alice-2', label: 'Finance application session route', targetId,
        riskScore: 68, riskLevel: 'high', hops: 2, confidence: 0.8,
        nodeIds: ['u-john', 'v-app', 'p-alice'], edgeIds: ['e-john-app', 'e-app-alice'],
        steps: [
          orientedPathStep('e-john-app', 'u-john', 'v-app', 'John has application-operator access to the Finance Application Server.'),
          orientedPathStep('e-app-alice', 'v-app', 'p-alice', 'A privileged service session for Alice is observed on this server.'),
        ],
        reasons: ['Application server is reachable', 'Privileged session is modeled as reusable'],
      },
      {
        ...attackPaths[2], id: 'path-alice-3', label: 'Shared operations workstation route', targetId,
        riskScore: 57, riskLevel: 'medium', hops: 3, confidence: 0.73,
        nodeIds: ['u-john', 'g-itops', 'c-shared', 'p-alice'], edgeIds: ['e-john-itops', 'e-itops-shared', 'e-shared-alice'],
        steps: [
          orientedPathStep('e-john-itops', 'u-john', 'g-itops', 'John has direct IT Operations membership.'),
          orientedPathStep('e-itops-shared', 'g-itops', 'c-shared', 'IT Operations administers the shared operations workstation.'),
          orientedPathStep('e-shared-alice', 'c-shared', 'p-alice', 'Alice has a privileged session on the shared workstation.'),
        ],
        reasons: ['Excessive group membership', 'Shared workstation contains a privileged session'],
      },
    ];
  }

  const extension = targetId === 'dc-01'
    ? { edgeId: 'e-da-dc1', label: 'Domain controller control', reason: 'Domain Admins has full administrative control of the primary domain controller', score: 3 }
    : { edgeId: 'e-da-vault', label: 'Credential vault control', reason: 'Domain Admins controls the identity credential vault', score: 1 };

  return attackPaths.map((path) => ({
    ...path,
    id: `${path.id}-${targetId}`,
    label: `${path.label} → ${extension.label}`,
    targetId,
    riskScore: Math.min(96, path.riskScore + extension.score),
    riskLevel: scoreToRisk(Math.min(96, path.riskScore + extension.score)),
    hops: path.hops + 1,
    nodeIds: [...path.nodeIds, targetId],
    edgeIds: [...path.edgeIds, extension.edgeId],
    steps: [...path.steps, pathStep(extension.edgeId, extension.reason)],
    reasons: [...path.reasons, extension.reason],
  }));
}

function discoverModeledPaths(sourceId: string, targetId: string): AttackPath[] {
  const found: Array<{ nodeIds: string[]; edges: SecurityGraphEdge[] }> = [];
  const walk = (currentId: string, nodeIds: string[], edges: SecurityGraphEdge[]) => {
    if (found.length >= 60 || edges.length >= 6) return;
    for (const next of adjacency.get(currentId) ?? []) {
      if (nodeIds.includes(next.nodeId)) continue;
      const nextNodes = [...nodeIds, next.nodeId];
      const nextEdges = [...edges, next.edge];
      if (next.nodeId === targetId) found.push({ nodeIds: nextNodes, edges: nextEdges });
      else walk(next.nodeId, nextNodes, nextEdges);
    }
  };
  walk(sourceId, [sourceId], []);

  return found
    .map((candidate, index) => {
      const relationshipStrength = candidate.edges.reduce((sum, item) => sum + (item.data?.riskContribution ?? 0), 0) / candidate.edges.length;
      const targetCriticality = nodeById.get(targetId)?.data.riskScore ?? 50;
      const score = Math.max(32, Math.min(89, Math.round(relationshipStrength * 1.7 + targetCriticality * 0.28 - candidate.edges.length * 2)));
      const confidence = Math.max(0.62, candidate.edges.reduce((sum, item) => sum + (item.data?.confidence ?? 0.7), 0) / candidate.edges.length - candidate.edges.length * 0.012);
      return {
        id: `modeled-path-${index + 1}`,
        label: `${candidate.edges[0].data?.label ?? 'Relationship'} route via ${seedById.get(candidate.nodeIds[1])?.displayName ?? 'directory access'}`,
        sourceId, targetId, riskScore: score, riskLevel: scoreToRisk(score), hops: candidate.edges.length, confidence,
        reasons: ['Modeled from current effective directory relationships', 'Path viability depends on the observed permissions and sessions shown below'],
        nodeIds: candidate.nodeIds,
        edgeIds: candidate.edges.map((item) => item.id),
        steps: candidate.edges.map((item, stepIndex) => orientedPathStep(
          item.id,
          candidate.nodeIds[stepIndex],
          candidate.nodeIds[stepIndex + 1],
          `This ${item.data?.label.toLowerCase()} relationship provides the next modeled movement condition.`,
        )),
        mitigatingControls: ['Validate the underlying access before remediation', 'Conditional access or segmentation may reduce viability'],
      } satisfies AttackPath;
    })
    .sort((a, b) => b.riskScore * b.confidence - a.riskScore * a.confidence)
    .slice(0, 3)
    .map((path, index) => ({ ...path, id: `modeled-path-${index + 1}` }));
}

export const securityApi = {
  async searchIdentities(query: string): Promise<SecurityGraphNode[]> {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return wait(mockNodes.slice(0, 8), 80);
    const results = mockNodes
      .filter((node) => node.data.name.toLowerCase().includes(normalized) || node.data.displayName.toLowerCase().includes(normalized))
      .sort((a, b) => b.data.riskScore - a.data.riskScore)
      .slice(0, 8);
    return wait(results, 90);
  },

  async getIdentityGraph(identityId: string, depth = 2, limit = 24): Promise<GraphResponse> {
    if (!nodeById.has(identityId)) throw new Error('Identity was not found in the security graph.');
    const ids = traverse(identityId, depth, limit);
    const related = entityDetails[identityId]?.blastRadius.potentiallyAffected ?? ids.size - 1;
    return wait(graphForIds(identityId, ids, related));
  },

  async expandIdentity(identityId: string, existingIds: string[], focusId = identityId, limit = 12): Promise<GraphResponse> {
    if (!nodeById.has(identityId) || !nodeById.has(focusId)) throw new Error('Unable to expand the selected identity.');
    const ids = new Set(existingIds);
    const candidates = [...(adjacency.get(identityId) ?? [])]
      .map((item) => item.nodeId)
      .filter((id) => !ids.has(id))
      .sort((a, b) => nodeById.get(b)!.data.riskScore - nodeById.get(a)!.data.riskScore)
      .slice(0, limit);
    candidates.forEach((id) => ids.add(id));
    const response = graphForIds(focusId, ids, entityDetails[focusId]?.blastRadius.potentiallyAffected);
    return wait(response, 140);
  },

  async expandAggregate(focusId: string, existingIds: string[]): Promise<GraphResponse> {
    const ids = new Set(existingIds);
    const candidates = mockNodes
      .filter((node) => !ids.has(node.id))
      .sort((a, b) => b.data.riskScore - a.data.riskScore)
      .slice(0, 10);
    candidates.forEach((node) => ids.add(node.id));
    return wait(graphForIds(focusId, ids, entityDetails[focusId]?.blastRadius.potentiallyAffected), 220);
  },

  async getIdentityDetails(identityId: string): Promise<IdentityDetails> {
    const details = entityDetails[identityId];
    if (!details) throw new Error('Identity details are unavailable.');
    return wait(details, 120);
  },

  async getRelationshipDetails(edgeId: string): Promise<RelationshipDetails> {
    const relationship = edgeById.get(edgeId);
    if (!relationship?.data) throw new Error('Relationship details are unavailable.');
    return wait({
      id: relationship.id,
      sourceId: relationship.source,
      sourceName: seedById.get(relationship.source)?.displayName ?? relationship.source,
      targetId: relationship.target,
      targetName: seedById.get(relationship.target)?.displayName ?? relationship.target,
      ...relationship.data,
    }, 120);
  },

  async getBlastRadius(identityId: string, limit = 34): Promise<BlastRadiusResponse> {
    const details = entityDetails[identityId];
    if (!details) throw new Error('Unable to model blast radius for the selected identity.');
    const ids = traverse(identityId, 4, limit);
    const base = graphForIds(identityId, ids, details.blastRadius.potentiallyAffected);
    const nodes = base.nodes.map((node) => ({
      ...node,
      data: {
        ...node.data,
        status: node.id === identityId ? 'compromised' as const : node.data.status,
        riskScore: node.id === identityId ? Math.max(85, node.data.riskScore) : node.data.riskScore,
        riskLevel: node.id === identityId ? 'critical' as const : node.data.riskLevel,
        riskReasons: node.id === identityId
          ? ['Selected compromised investigation source', ...node.data.riskReasons.filter((reason) => reason !== 'Selected compromised investigation source')]
          : node.data.riskReasons,
        investigationState: node.id === identityId
          ? 'compromised' as const
          : node.data.riskScore >= 35 || node.data.privileged
            ? 'potentially-at-risk' as const
            : 'reachable' as const,
      },
    }));

    const rankedDirectExposures = [...new Map(
      (adjacency.get(identityId) ?? [])
        .filter((item) => ids.has(item.nodeId))
        .sort((a, b) => {
          const aNode = nodeById.get(a.nodeId)!;
          const bNode = nodeById.get(b.nodeId)!;
          const aPriority = aNode.data.riskScore + (aNode.data.privileged ? 22 : 0) + (a.edge.data?.riskContribution ?? 0);
          const bPriority = bNode.data.riskScore + (bNode.data.privileged ? 22 : 0) + (b.edge.data?.riskContribution ?? 0);
          return bPriority - aPriority;
        })
        .map((item) => [item.nodeId, item] as const),
    ).values()];
    const directExposureIds = rankedDirectExposures.slice(0, 6).map((item) => item.nodeId);

    const branchSummaries: BlastBranchSummary[] = rankedDirectExposures.slice(0, 6).map((item) => ({
      directExposureId: item.nodeId,
      downstreamCount: Math.min(
        details.blastRadius.potentiallyAffected,
        Math.max(1, entityDetails[item.nodeId]?.blastRadius.potentiallyAffected ?? 1),
      ),
      maxDepth: 4,
      relationshipType: item.edge.data!.relationshipType,
      relationshipLabel: item.edge.data!.label,
      confidence: item.edge.data!.confidence,
    }));

    const distances = new Map<string, number>([[identityId, 0]]);
    const distanceQueue = [identityId];
    while (distanceQueue.length) {
      const currentId = distanceQueue.shift()!;
      const currentDistance = distances.get(currentId) ?? 0;
      if (currentDistance >= 4) continue;
      for (const next of adjacency.get(currentId) ?? []) {
        if (!ids.has(next.nodeId) || distances.has(next.nodeId)) continue;
        distances.set(next.nodeId, currentDistance + 1);
        distanceQueue.push(next.nodeId);
      }
    }
    const withinTwoHops = [...distances.values()].filter((distance) => distance > 0 && distance <= 2).length;
    const strongTypes = new Set(['AdminOf', 'Controls', 'CanDelegate', 'CanImpersonate', 'CanResetPassword']);
    const metrics = {
      totalPotentiallyAtRisk: details.blastRadius.potentiallyAffected,
      directExposures: rankedDirectExposures.length,
      withinTwoHops,
      extendedReachability: Math.max(0, details.blastRadius.potentiallyAffected - withinTwoHops),
      strongControlRelationships: base.edges.filter((edge) => strongTypes.has(edge.data?.relationshipType ?? '')).length,
      activeSessionExposures: base.edges.filter((edge) => edge.data?.relationshipType === 'HasSession').length,
    };

    return wait({
      ...base,
      nodes,
      directExposureIds,
      branchSummaries,
      metrics,
      assumptions: [
        'Reachability uses observed graph relationships and current session evidence.',
        'Downstream counts are distinct reachable objects, not asset categories.',
        'Potential exposure does not indicate confirmed compromise.',
      ],
    }, 260);
  },

  async getBlastBranch(sourceId: string, branchRootId: string, limit = 5): Promise<BlastBranchResponse> {
    if (!nodeById.has(sourceId) || !nodeById.has(branchRootId)) {
      throw new Error('Unable to expand the selected blast-radius branch.');
    }
    const isDirectExposure = (adjacency.get(sourceId) ?? []).some((item) => item.nodeId === branchRootId);
    if (!isDirectExposure) throw new Error('The selected object is not a direct exposure of the compromised source.');

    const otherDirectExposureIds = (adjacency.get(sourceId) ?? [])
      .map((item) => item.nodeId)
      .filter((id) => id !== branchRootId);
    const visited = new Set<string>([sourceId, branchRootId, ...otherDirectExposureIds]);
    const queue: Array<{ id: string; depth: number }> = [{ id: branchRootId, depth: 0 }];
    const discovered: Array<{ id: string; parentId: string; edge: SecurityGraphEdge; depth: number }> = [];

    while (queue.length) {
      const current = queue.shift()!;
      if (current.depth >= 3) continue;
      const neighbors = [...(adjacency.get(current.id) ?? [])].sort((a, b) => {
        const aNode = nodeById.get(a.nodeId)!;
        const bNode = nodeById.get(b.nodeId)!;
        const aPriority = aNode.data.riskScore + (aNode.data.privileged ? 20 : 0) + (a.edge.data?.riskContribution ?? 0);
        const bPriority = bNode.data.riskScore + (bNode.data.privileged ? 20 : 0) + (b.edge.data?.riskContribution ?? 0);
        return bPriority - aPriority;
      });
      for (const next of neighbors) {
        if (visited.has(next.nodeId)) continue;
        visited.add(next.nodeId);
        discovered.push({ id: next.nodeId, parentId: current.id, edge: next.edge, depth: current.depth + 1 });
        queue.push({ id: next.nodeId, depth: current.depth + 1 });
      }
    }

    const visible = discovered.slice(0, limit);
    const visibleIds = new Set(visible.map((item) => item.id));
    const nodes = visible.map((item) => {
      const node = nodeById.get(item.id)!;
      return {
        ...node,
        data: {
          ...node.data,
          status: node.data.status === 'compromised' ? 'normal' as const : node.data.status,
          investigationState: node.data.riskScore >= 35 || node.data.privileged
            ? 'potentially-at-risk' as const
            : 'reachable' as const,
        },
      };
    });
    const edges = visible
      .filter((item) => item.parentId === branchRootId || visibleIds.has(item.parentId))
      .map((item) => ({
        ...item.edge,
        id: `blast-branch-${item.edge.id}-${item.id}`,
        source: item.parentId,
        target: item.id,
        data: {
          ...item.edge.data!,
          blastDepth: Math.min(4, item.depth + 1) as 1 | 2 | 3 | 4,
          blastFlow: true,
        },
      }));
    const modeledReach = Math.max(discovered.length, entityDetails[branchRootId]?.blastRadius.potentiallyAffected ?? discovered.length);
    const totalReachable = Math.min(entityDetails[sourceId]?.blastRadius.potentiallyAffected ?? modeledReach, modeledReach);

    return wait({
      sourceId,
      branchRootId,
      nodes,
      edges,
      totalReachable,
      hiddenCount: Math.max(0, totalReachable - visible.length),
      maxDepth: 4,
    }, 180);
  },

  async getAttackPaths(sourceId: string, targetId: string): Promise<AttackPathsResponse> {
    const paths = sourceId === 'u-john'
      ? curatedPathsToTarget(targetId)
      : discoverModeledPaths(sourceId, targetId);
    if (paths.length === 0) throw new Error('No viable modeled route was found between the selected source and target.');

    const nodeIds = new Set(paths.flatMap((path) => path.nodeIds));
    const graph = graphForIds(sourceId, nodeIds, nodeIds.size - 1);
    const strongest = paths[0];
    const alternativeAdjustment = Math.min(3, Math.max(0, paths.length - 1));
    const overallReachabilityRisk = sourceId === 'u-john' && targetId === 'g-domain-admins'
      ? 93
      : Math.min(97, strongest.riskScore + alternativeAdjustment);
    const confidence = Math.min(0.97, strongest.confidence * 0.92 + (paths.length > 1 ? 0.05 : 0));

    return wait({
      sourceId,
      targetId,
      strongestPathId: strongest.id,
      overallReachabilityRisk,
      overallRiskLevel: scoreToRisk(overallReachabilityRisk),
      confidence,
      explanation: 'Overall reachability is weighted toward the strongest viable route, then adjusted for alternative routes, confidence, target criticality, relationship strength, and mitigating controls. It is not an average and does not indicate target compromise.',
      paths,
      graph,
    }, 280);
  },

  getAttackTargets(): Array<{ id: string; label: string; type: string }> {
    return [
      { id: 'g-domain-admins', label: 'Domain Admins', type: 'Privileged group' },
      { id: 'dc-01', label: 'Primary Domain Controller', type: 'Domain controller' },
      { id: 'a-vault', label: 'Identity Credential Vault', type: 'Critical asset' },
      { id: 'p-alice', label: 'Alice Morgan', type: 'Privileged identity' },
    ];
  },
};
