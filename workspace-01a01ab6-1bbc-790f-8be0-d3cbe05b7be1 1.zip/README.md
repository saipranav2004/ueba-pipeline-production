# Identity Risk Graph

A production-style React Flow prototype for investigating Active Directory identity risk, compromise context, attack paths, and potential blast radius.

## Run locally

```bash
npm install
npm run dev
```

Production verification:

```bash
npm run typecheck
npm run build
```

## Demonstrated workflow

1. The application starts without a fixed compromised identity. Use search to select the identity or asset confirmed as compromised in the current investigation.
2. Only an identity selected from search becomes the compromised source for the context graph, blast-radius model, and attack-path analysis. No directory object—including `john.smith`—is permanently marked compromised in baseline data.
3. Clicking a graph node selects it for inspection and opens its details without changing the compromised source. Use `+` or double-click to progressively expand relationships.
4. Switch between User and SOC modes. SOC mode exposes relationship labels, risk scores, Tier context, evidence, and directory metadata.
5. Use risk, identity, relationship, privileged, compromised, and Risky Only filters.
6. Open **Show Blast Radius** to visualize potential impact without equating reachability with compromise.
7. Open **Show Attack Paths**, choose a target, compare independently scored routes, and select one to fade unrelated graph elements and highlight its typed relationships.
8. Click any graph edge to inspect direct/inherited status, effective access, confidence, evidence properties, and observation dates.

## Architecture

```text
React components / React Flow renderer
                ↓
Typed security service contract (mockSecurityApi.ts)
                ↓
Mock graph summaries + separately loaded identity details
                ↓ future
Risk/security API → Neo4j query and graph transformation layer
```

The mock service mirrors future backend operations:

- `searchIdentities(query)`
- `getIdentityGraph(identityId, depth, limit)`
- `expandIdentity(identityId, existingIds, limit)`
- `getIdentityDetails(identityId)`
- `getRelationshipDetails(edgeId)`
- `getBlastRadius(identityId, limit)`
- `getBlastBranch(sourceId, directExposureId, limit)`
- `getAttackPaths(sourceId, targetId)`

React Flow nodes contain visualization summaries only. SID, distinguished name, authentication context, evidence, sessions, and other detailed data are returned separately. Replacing the mock service with REST or GraphQL calls should not require changing the graph components.

## Important semantics

- **Compromised** means supported by explicit security evidence.
- **Potentially at risk** means security-relevant exposure under modeled assumptions.
- **Reachable** means connected through modeled relationships; it is not proof of exploitation.
- **Possible attack path** is an explainable sequence of typed relationships; it does not mean the target is compromised.
- **Overall reachability risk** is weighted toward the strongest viable path and adjusted for alternatives, confidence, target criticality, relationship strength, and controls. It is not an average of path scores.
