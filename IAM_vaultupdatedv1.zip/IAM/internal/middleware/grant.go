// pam/internal/middleware/grant.go
//
// RequireActiveGrant is the SECOND policy enforcement layer.
//
//	Layer 1 (authz.go)  — IAM/OPA: "is this principal allowed this action at all?"
//	Layer 2 (this file) — PAM JIT: "does this principal hold a live, unexpired,
//	                       time-boxed grant for this specific resource right now?"
//
// Both must pass. Layer 1 alone is standing access; layer 2 is what makes the
// access just-in-time. Grants are read from the database on every request —
// never cached — so a revocation takes effect on the very next call.
//
// Backwards compatibility: resources with requires_jit = false (the default,
// and therefore every pre-existing row) pass straight through, so adding this
// middleware to a route changes nothing until a resource is explicitly gated.
package middleware

import (
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// Context keys set by this middleware.
const (
	CtxGrantID           = "grant_id"
	CtxJITRequestID      = "jit_request_id"
	CtxGrantIsBreakglass = "grant_is_breakglass"
	CtxRecordingRequired = "recording_required"
	CtxGrantRequired     = "grant_required"
	CtxGrantExpiresAt    = "grant_expires_at"
)

// RequireActiveGrant enforces JIT entitlement for JIT-gated resources.
func RequireActiveGrant(
	jit *services.JITService,
	res *services.ResourceService,
	resourceIDFn func(*gin.Context) string,
	log *zap.Logger,
) gin.HandlerFunc {
	return func(c *gin.Context) {
		userIDRaw, ok := c.Get("user_id")
		if !ok {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Authentication required before grant check",
			})
			return
		}
		userID, _ := userIDRaw.(string)

		resourceID := resourceIDFn(c)
		if resourceID == "" {
			c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
				"success": false,
				"error":   "resource id is required",
			})
			return
		}

		resource, err := res.GetResource(resourceID)
		if err != nil {
			status := http.StatusInternalServerError
			msg := "Failed to resolve resource"
			if errors.Is(err, services.ErrResourceNotFound) {
				status = http.StatusNotFound
				msg = "Resource not found"
			}
			c.AbortWithStatusJSON(status, gin.H{"success": false, "error": msg})
			return
		}

		if !resource.RequiresJIT {
			// Not JIT-gated: allowed by layer 1 alone, but still record the
			// recording obligation the resource itself may impose.
			c.Set(CtxGrantRequired, false)
			c.Set(CtxRecordingRequired, resource.AlwaysRecord)
			c.Set(CtxGrantIsBreakglass, false)
			c.Next()
			return
		}

		grant, err := jit.ActiveGrantFor(userID, resourceID)
		if err != nil {
			if errors.Is(err, services.ErrGrantNotFound) {
				log.Warn("jit.grant.missing",
					zap.String("user_id", userID),
					zap.String("resource_id", resourceID),
				)
				c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
					"success": false,
					"error":   "No active just-in-time access grant for this resource",
					"code":    "jit_grant_required",
					"hint":    "POST /api/v1/pam/jit/requests to request time-boxed access",
				})
				return
			}
			log.Error("jit.grant.lookup.fail", zap.Error(err))
			// Fail closed — an unreadable entitlement store is a deny.
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "Unable to verify just-in-time access grant",
				"code":    "jit_grant_unverifiable",
			})
			return
		}

		c.Set(CtxGrantRequired, true)
		c.Set(CtxGrantID, grant.ID)
		c.Set(CtxJITRequestID, grant.RequestID)
		c.Set(CtxGrantIsBreakglass, grant.IsBreakglass)
		c.Set(CtxRecordingRequired, grant.RecordingRequired || resource.AlwaysRecord)
		c.Set(CtxGrantExpiresAt, grant.ExpiresAt)

		log.Info("jit.grant.enforced",
			zap.String("user_id", userID),
			zap.String("resource_id", resourceID),
			zap.String("grant_id", grant.ID),
			zap.Bool("breakglass", grant.IsBreakglass),
			zap.Time("expires_at", grant.ExpiresAt),
		)
		c.Next()
	}
}

// GrantContext is a convenience accessor for handlers.
type GrantContext struct {
	Required          bool
	GrantID           string
	JITRequestID      string
	IsBreakglass      bool
	RecordingRequired bool
}

// GrantFromContext extracts whatever RequireActiveGrant put in the context.
// Safe to call even when the middleware did not run (returns zero values).
func GrantFromContext(c *gin.Context) GrantContext {
	var g GrantContext
	if v, ok := c.Get(CtxGrantRequired); ok {
		g.Required, _ = v.(bool)
	}
	if v, ok := c.Get(CtxGrantID); ok {
		g.GrantID, _ = v.(string)
	}
	if v, ok := c.Get(CtxJITRequestID); ok {
		g.JITRequestID, _ = v.(string)
	}
	if v, ok := c.Get(CtxGrantIsBreakglass); ok {
		g.IsBreakglass, _ = v.(bool)
	}
	if v, ok := c.Get(CtxRecordingRequired); ok {
		g.RecordingRequired, _ = v.(bool)
	}
	return g
}
