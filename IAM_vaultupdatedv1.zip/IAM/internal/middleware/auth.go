// pam/internal/middleware/auth.go
package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	"go.uber.org/zap"
)

// PAMAuth verifies a PAM-issued HS256 JWT (not IAM's RS256 token).
// PAM owns its own authentication entirely.
func PAMAuth(issuer *pamjwt.Issuer, log *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if !strings.HasPrefix(authHeader, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Missing or malformed Authorization header. Expected: Bearer <token>",
			})
			return
		}
		tokenString := strings.TrimPrefix(authHeader, "Bearer ")

		claims, sessionID, err := issuer.Verify(tokenString)
		if err != nil {
			log.Debug("pam.jwt.verify.fail", zap.Error(err))
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Invalid or expired PAM token",
			})
			return
		}

		c.Set("user_id", claims.Subject)
		c.Set("username", claims.Username)
		c.Set("email", claims.Email)
		c.Set("account_id", claims.AccountID)
		c.Set("mfa_verified", claims.MFAVerified)
		c.Set("roles", claims.Roles)
		c.Set("session_id", sessionID)
		c.Set("jti", claims.ID)
		c.Next()
	}
}

// RequireMFA blocks requests if the PAM JWT doesn't have mfa_verified=true.
func RequireMFA() gin.HandlerFunc {
	return func(c *gin.Context) {
		mfa, exists := c.Get("mfa_verified")
		if !exists || !mfa.(bool) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "MFA verification required for this action",
			})
			return
		}
		c.Next()
	}
}
