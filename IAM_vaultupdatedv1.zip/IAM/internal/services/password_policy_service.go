// pam/internal/services/password_policy_service.go
package services

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"strings"
	"unicode"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrPasswordTooShort  = errors.New("password does not meet minimum length requirement")
	ErrPasswordTooLong   = errors.New("password exceeds maximum length limit")
	ErrMissingUppercase  = errors.New("password missing required uppercase character")
	ErrMissingLowercase  = errors.New("password missing required lowercase character")
	ErrMissingDigits     = errors.New("password missing required numeric digit")
	ErrMissingSpecial    = errors.New("password missing required special character")
	ErrPasswordInHistory = errors.New("password has been used recently (history violation)")
)

const (
	upperChars  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	lowerChars  = "abcdefghijklmnopqrstuvwxyz"
	digitChars  = "0123456789"
	defaultSpec = "!@#$%^&*()-_=+[]{}|;:,.<>?"
)

type PasswordPolicyService struct {
	db  *gorm.DB
	log *zap.Logger
}

func NewPasswordPolicyService(db *gorm.DB, log *zap.Logger) *PasswordPolicyService {
	return &PasswordPolicyService{db: db, log: log}
}

// GenerateCompliantPassword produces a cryptographically secure random password
// guaranteed to satisfy the provided PasswordPolicy complexity rules.
func (s *PasswordPolicyService) GenerateCompliantPassword(policy models.PasswordPolicy) (string, error) {
	minLen := policy.MinLength
	if minLen <= 0 {
		minLen = 16
	}
	spec := policy.SpecialChars
	if spec == "" {
		spec = defaultSpec
	}

	var chars []rune
	var pool string

	if policy.RequireUppercase {
		r, err := randomChar(upperChars)
		if err != nil {
			return "", err
		}
		chars = append(chars, r)
		pool += upperChars
	}
	if policy.RequireLowercase {
		r, err := randomChar(lowerChars)
		if err != nil {
			return "", err
		}
		chars = append(chars, r)
		pool += lowerChars
	}
	if policy.RequireDigits {
		r, err := randomChar(digitChars)
		if err != nil {
			return "", err
		}
		chars = append(chars, r)
		pool += digitChars
	}
	if policy.RequireSpecial {
		r, err := randomChar(spec)
		if err != nil {
			return "", err
		}
		chars = append(chars, r)
		pool += spec
	}

	if pool == "" {
		pool = upperChars + lowerChars + digitChars
	}

	for len(chars) < minLen {
		r, err := randomChar(pool)
		if err != nil {
			return "", err
		}
		chars = append(chars, r)
	}

	// Shuffle slice using crypto/rand
	for i := len(chars) - 1; i > 0; i-- {
		jBig, err := rand.Int(rand.Reader, big.NewInt(int64(i+1)))
		if err != nil {
			return "", fmt.Errorf("crypto rand error during shuffle: %w", err)
		}
		j := int(jBig.Int64())
		chars[i], chars[j] = chars[j], chars[i]
	}

	generated := string(chars)
	s.log.Debug("password.policy.generated",
		zap.String("policy", policy.Name),
		zap.Int("length", len(generated)),
	)
	return generated, nil
}

func randomChar(alphabet string) (rune, error) {
	if len(alphabet) == 0 {
		return 'A', nil
	}
	idx, err := rand.Int(rand.Reader, big.NewInt(int64(len(alphabet))))
	if err != nil {
		return 0, fmt.Errorf("crypto rand failed: %w", err)
	}
	return rune(alphabet[idx.Int64()]), nil
}

func (s *PasswordPolicyService) ValidatePassword(password string, policy models.PasswordPolicy, history []string) error {
	if len(password) < policy.MinLength {
		return ErrPasswordTooShort
	}
	if policy.MaxLength > 0 && len(password) > policy.MaxLength {
		return ErrPasswordTooLong
	}

	var hasUp, hasLow, hasDig, hasSpec bool
	specChars := policy.SpecialChars
	if specChars == "" {
		specChars = defaultSpec
	}

	for _, r := range password {
		switch {
		case unicode.IsUpper(r):
			hasUp = true
		case unicode.IsLower(r):
			hasLow = true
		case unicode.IsDigit(r):
			hasDig = true
		case strings.ContainsRune(specChars, r):
			hasSpec = true
		}
	}

	if policy.RequireUppercase && !hasUp {
		return ErrMissingUppercase
	}
	if policy.RequireLowercase && !hasLow {
		return ErrMissingLowercase
	}
	if policy.RequireDigits && !hasDig {
		return ErrMissingDigits
	}
	if policy.RequireSpecial && !hasSpec {
		return ErrMissingSpecial
	}

	candidateHash := sha256Hex(password)
	for _, oldHash := range history {
		if strings.EqualFold(candidateHash, oldHash) {
			return ErrPasswordInHistory
		}
	}
	return nil
}

func (s *PasswordPolicyService) GetPolicyForPlatform(platformType string) (models.PasswordPolicy, error) {
	var policy models.PasswordPolicy
	err := s.db.Where("platform_type = ? OR platform_type = 'any'", platformType).
		Order("is_default ASC").First(&policy).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return models.DefaultPasswordPolicy(), nil
		}
		return models.DefaultPasswordPolicy(), err
	}
	return policy, nil
}

func sha256Hex(s string) string {
	sum := sha256.Sum256([]byte(s))
	return hex.EncodeToString(sum[:])
}
