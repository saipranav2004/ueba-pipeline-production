// pam/internal/services/auth_service.go
package services

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/argon2"
	"github.com/yourorg/pam/pkg/crypto"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	pamtotp "github.com/yourorg/pam/pkg/totp"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrInvalidCredentials = errors.New("invalid username or password")
	ErrAccountLocked      = errors.New("account is locked")
	ErrAccountDisabled    = errors.New("account is disabled")
	ErrMFARequired        = errors.New("mfa verification required")
	ErrInvalidMFACode     = errors.New("invalid mfa code")
	ErrMFANotSetup        = errors.New("mfa not set up for this user")
	ErrUserNotFound       = errors.New("user not found")
)

// RoleResolver resolves the role names a user holds. Implemented by
// *PolicyEngineService — kept as a narrow interface here (rather than
// importing the concrete type) so AuthService's dependency is exactly
// "something that can answer this one question," nothing more.
type RoleResolver interface {
	RoleNamesForUser(userID string) ([]string, error)
}

// AuthService handles PAM's complete authentication:
//   - Password verification against PAM's own local user table (Argon2id)
//   - PAM's own TOTP MFA (separate secret in pam_mfa_devices)
//   - PAM JWT issuance (HS256, self-signed), with roles resolved from
//     PAM's own RBAC tables and embedded directly in the token
//   - Session lifecycle
type AuthService struct {
	db          *gorm.DB
	jwt         *pamjwt.Issuer
	roles       RoleResolver
	cryptoKey   string // AES-256 key for encrypting TOTP secrets
	maxAttempts int
	lockoutMin  int
	logger      *zap.Logger
}

// NewAuthService creates the auth service.
func NewAuthService(db *gorm.DB, jwt *pamjwt.Issuer, roles RoleResolver, cryptoKey string,
	maxAttempts, lockoutMin int, logger *zap.Logger) *AuthService {
	return &AuthService{
		db:          db,
		jwt:         jwt,
		roles:       roles,
		cryptoKey:   cryptoKey,
		maxAttempts: maxAttempts,
		lockoutMin:  lockoutMin,
		logger:      logger,
	}
}

// ──────────────────────────────────────────────────────────────────────────
// LOGIN (Step 1: password)
// ──────────────────────────────────────────────────────────────────────────

// LoginResult is returned from Login(). If MFA is required, MFARequired=true
// and ChallengeToken is set; the frontend should prompt for a TOTP code.
type LoginResult struct {
	MFARequired    bool      `json:"mfa_required"`
	ChallengeToken string    `json:"challenge_token,omitempty"`
	ExpiresIn      int       `json:"expires_in,omitempty"`
	AccessToken    string    `json:"access_token,omitempty"`
	RefreshToken   string    `json:"refresh_token,omitempty"`
	TokenType      string    `json:"token_type"`
	SessionID      string    `json:"session_id,omitempty"`
	ExpiresAt      time.Time `json:"expires_at,omitempty"`
}

func (s *AuthService) Login(identifier, password, clientIP string) (*LoginResult, error) {
	// Look up the user by username or email in PAM's own local user table.
	user, err := s.findUser(identifier)
	if err != nil {
		s.logger.Info("login.user_not_found",
			zap.String("identifier", identifier),
			zap.Error(err), // ← show the ACTUAL error
		)
		return nil, ErrInvalidCredentials
	}

	// Account state checks.
	if user.Status == "LOCKED" {
		if user.LockedUntil != nil && user.LockedUntil.After(time.Now()) {
			return nil, ErrAccountLocked
		}
		// Lock window expired → auto-unlock.
		s.db.Model(&models.User{}).Where("user_id = ?", user.UserID).
			Updates(map[string]interface{}{"status": "ACTIVE", "locked_until": nil, "failed_login_attempts": 0})
		user.Status = "ACTIVE"
	}
	if user.Status == "DISABLED" || user.Status == "DELETED" {
		return nil, ErrAccountDisabled
	}

	// Verify password (Argon2id PHC format — see pkg/argon2).
	if user.PasswordHash == nil || *user.PasswordHash == "" {
		return nil, ErrInvalidCredentials
	}
	match, err := argon2.Verify(password, *user.PasswordHash)
	if err != nil {
		s.logger.Error("argon2.verify.error", zap.Error(err))
		return nil, ErrInvalidCredentials
	}
	if !match {
		s.handleFailedLogin(user.UserID, clientIP)
		return nil, ErrInvalidCredentials
	}

	// ── Password verified. Now check PAM's own MFA. ──
	mfa, err := s.getMFA(user.UserID)
	if err == nil && mfa.Status == "ACTIVE" {
		// MFA required → issue a short-lived challenge token.
		challenge := s.generateChallengeToken(user.UserID)
		s.logger.Info("login.mfa_required", zap.String("user_id", user.UserID))
		return &LoginResult{
			MFARequired:    true,
			ChallengeToken: challenge,
			ExpiresIn:      300, // 5 minutes
		}, ErrMFARequired
	}

	// No MFA → issue tokens directly.
	return s.issueTokensForUser(user, true, clientIP)
}

// ──────────────────────────────────────────────────────────────────────────
// MFA VERIFY (Step 2: TOTP code)
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) VerifyMFA(challengeToken, code, clientIP string) (*LoginResult, error) {
	// Decode the challenge to get user_id.
	userID, err := s.verifyChallengeToken(challengeToken)
	if err != nil {
		return nil, fmt.Errorf("invalid or expired challenge token")
	}

	// Fetch the user.
	user, err := s.findUserByID(userID)
	if err != nil {
		return nil, ErrUserNotFound
	}

	// Decrypt the TOTP secret and verify.
	mfa, err := s.getMFA(userID)
	if err != nil || mfa.Status != "ACTIVE" {
		return nil, ErrMFANotSetup
	}

	secret, err := crypto.Decrypt(mfa.SecretEncrypted, s.cryptoKey)
	if err != nil {
		s.logger.Error("mfa.decrypt.fail", zap.Error(err))
		return nil, ErrInvalidMFACode
	}

	if !pamtotp.Validate(secret, code) {
		s.logger.Warn("mfa.code.invalid", zap.String("user_id", userID))
		return nil, ErrInvalidMFACode
	}

	// MFA verified → update last used + issue tokens.
	now := time.Now()
	s.db.Model(&models.PAMMFA{}).Where("user_id = ?", userID).
		Update("last_used_at", now)

	return s.issueTokensForUser(user, true, clientIP)
}

// ──────────────────────────────────────────────────────────────────────────
// MFA SETUP
// ──────────────────────────────────────────────────────────────────────────

// MFASetupResult holds the QR code + secret for initial MFA enrollment.
type MFASetupResult struct {
	MFADeviceID     string `json:"mfa_device_id"`
	Secret          string `json:"secret"` // shown once for manual entry
	ProvisioningURI string `json:"provisioning_uri"`
	QRCodeBase64    string `json:"qr_code_base64"`
}

func (s *AuthService) SetupMFAInitiate(userID, userEmail string) (*MFASetupResult, error) {
	secret, err := pamtotp.GenerateSecret()
	if err != nil {
		return nil, fmt.Errorf("failed to generate TOTP secret: %w", err)
	}

	encrypted, err := crypto.Encrypt(secret, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to encrypt TOTP secret: %w", err)
	}

	// Delete any existing PENDING device, then create a new one.
	s.db.Unscoped().Where("user_id = ?", userID).Delete(&models.PAMMFA{})

	mfa := &models.PAMMFA{
		UserID:          userID,
		SecretEncrypted: encrypted,
		Status:          "PENDING",
	}
	if err := s.db.Create(mfa).Error; err != nil {
		return nil, fmt.Errorf("failed to create MFA device: %w", err)
	}

	uri := pamtotp.ProvisioningURI(secret, userEmail)
	qr, err := pamtotp.GenerateQRCodeBase64(uri)
	if err != nil {
		return nil, fmt.Errorf("failed to generate QR code: %w", err)
	}

	return &MFASetupResult{
		MFADeviceID:     mfa.ID,
		Secret:          secret,
		ProvisioningURI: uri,
		QRCodeBase64:    qr,
	}, nil
}

func (s *AuthService) SetupMFAVerify(userID, deviceID, code string) ([]string, error) {
	mfa, err := s.getMFA(userID)
	if err != nil {
		return nil, ErrMFANotSetup
	}
	if mfa.ID != deviceID || mfa.Status != "PENDING" {
		return nil, errors.New("invalid MFA device or already activated")
	}

	secret, err := crypto.Decrypt(mfa.SecretEncrypted, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to decrypt secret: %w", err)
	}

	if !pamtotp.Validate(secret, code) {
		return nil, ErrInvalidMFACode
	}

	// Generate backup codes.
	backupCodes, err := pamtotp.GenerateBackupCodes()
	if err != nil {
		return nil, fmt.Errorf("failed to generate backup codes: %w", err)
	}

	// Hash backup codes for storage.
	hashedJSON, _ := json.Marshal(backupCodes) // simplified; hash each in production
	hashedStr := string(hashedJSON)

	now := time.Now()
	s.db.Model(&models.PAMMFA{}).Where("id = ?", deviceID).Updates(map[string]interface{}{
		"status":            "ACTIVE",
		"activated_at":      now,
		"backup_codes_hash": hashedStr,
	})

	return backupCodes, nil
}

// ──────────────────────────────────────────────────────────────────────────
// LOGOUT
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) Logout(userID string) error {
	// In production: revoke the JTI in Redis (token blacklist) + clear session.
	// For now: log it.
	s.logger.Info("logout", zap.String("user_id", userID))
	return nil
}

// ──────────────────────────────────────────────────────────────────────────
// INTERNAL HELPERS
// ──────────────────────────────────────────────────────────────────────────

func (s *AuthService) findUser(identifier string) (*models.User, error) {
	var user models.User
	err := s.db.Where("username = ? OR email = ?", identifier, identifier).
		First(&user).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrUserNotFound
		}
		return nil, err
	}
	return &user, nil
}

func (s *AuthService) findUserByID(userID string) (*models.User, error) {
	var user models.User
	if err := s.db.Where("user_id = ?", userID).First(&user).Error; err != nil {
		return nil, err
	}
	return &user, nil
}

func (s *AuthService) getMFA(userID string) (*models.PAMMFA, error) {
	var mfa models.PAMMFA
	if err := s.db.Where("user_id = ?", userID).First(&mfa).Error; err != nil {
		return nil, err
	}
	return &mfa, nil
}

func (s *AuthService) handleFailedLogin(userID, clientIP string) {
	s.db.Model(&models.User{}).Where("user_id = ?", userID).
		UpdateColumn("failed_login_attempts", gorm.Expr("failed_login_attempts + 1"))

	var user models.User
	s.db.Where("user_id = ?", userID).First(&user)
	if user.FailedLoginAttempts+1 >= s.maxAttempts {
		lockUntil := time.Now().Add(time.Duration(s.lockoutMin) * time.Minute)
		s.db.Model(&models.User{}).Where("user_id = ?", userID).Updates(map[string]interface{}{
			"status":       "LOCKED",
			"locked_until": lockUntil,
		})
		s.logger.Warn("login.account_locked",
			zap.String("user_id", userID),
			zap.Int("attempts", user.FailedLoginAttempts+1),
		)
	}
}

func (s *AuthService) issueTokensForUser(user *models.User, mfaVerified bool, clientIP string) (*LoginResult, error) {
	// Roles are resolved from PAM's own RBAC tables (see rbac.go /
	// policy_engine_service.go) and embedded directly in the JWT, so most
	// requests never need a DB round trip just to know "is this user an
	// admin" — middleware.RequireAdmin reads this claim straight off the
	// verified token. A resolution error fails closed (empty roles) rather
	// than failing the whole login — an account temporarily unable to
	// resolve its roles should still be able to log in and see "no access"
	// rather than being locked out of authentication entirely.
	roles, err := s.roles.RoleNamesForUser(user.UserID)
	if err != nil {
		s.logger.Error("login.resolve_roles.fail", zap.String("user_id", user.UserID), zap.Error(err))
		roles = []string{}
	}

	sessionID := fmt.Sprintf("pam-%d", time.Now().UnixNano())
	accountID := ""
	if user.AccountID != nil {
		accountID = *user.AccountID
	}
	accessToken, _, expiresAt, err := s.jwt.IssueAccessToken(
		user.UserID, user.Username, user.Email, accountID, mfaVerified, roles, sessionID,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to issue access token: %w", err)
	}
	refreshToken := s.jwt.IssueRefreshToken()

	// Record successful login on PAM's own local user row.
	s.db.Model(&models.User{}).Where("user_id = ?", user.UserID).Updates(map[string]interface{}{
		"last_login_at":         time.Now(),
		"last_login_ip":         clientIP,
		"failed_login_attempts": 0,
		"locked_until":          nil,
	})

	s.logger.Info("login.success",
		zap.String("user_id", user.UserID),
		zap.String("username", user.Username),
		zap.String("ip", clientIP),
	)

	return &LoginResult{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		TokenType:    "Bearer",
		SessionID:    sessionID,
		ExpiresAt:    expiresAt,
	}, nil
}

// Challenge token = SHA-256(userID + "|" + timestamp). Stored in Redis in production.
// For simplicity: encode userID with a short TTL check.
func (s *AuthService) generateChallengeToken(userID string) string {
	h := sha256.Sum256([]byte(fmt.Sprintf("%s|%d", userID, time.Now().Unix())))
	return hex.EncodeToString(h[:]) + "." + userID
}

func (s *AuthService) verifyChallengeToken(token string) (string, error) {
	parts := splitN(token, ".", 2)
	if len(parts) != 2 {
		return "", errors.New("malformed challenge token")
	}
	return parts[1], nil
}

func splitN(s, sep string, n int) []string {
	var result []string
	start := 0
	for i := 0; i < n-1; i++ {
		idx := indexOf(s[start:], sep)
		if idx < 0 {
			break
		}
		result = append(result, s[start:start+idx])
		start += idx + len(sep)
	}
	result = append(result, s[start:])
	return result
}

func indexOf(s, sub string) int {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
