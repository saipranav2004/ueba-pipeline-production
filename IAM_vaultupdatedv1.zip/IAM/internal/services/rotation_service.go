// pam/internal/services/rotation_service.go
package services

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrRotationInProgress = errors.New("a rotation job is already in progress for this credential")
	ErrRotationFailed     = errors.New("credential rotation failed on target resource")
	ErrDependencyFailed   = errors.New("dependency update failed; credential rotation rolled back")
	ErrRollbackFailed     = errors.New("dependency update failed AND rollback failed on target resource")
)

type RotationService struct {
	db        *gorm.DB
	kms       crypto.KMSProvider
	vaultSvc  *VaultService
	policySvc *PasswordPolicyService
	registry  *ConnectorRegistry
	log       *zap.Logger
}

func NewRotationService(db *gorm.DB, vaultSvc *VaultService, log *zap.Logger) *RotationService {
	policySvc := NewPasswordPolicyService(db, log)
	registry := NewConnectorRegistry(log)
	return &RotationService{
		db:        db,
		kms:       vaultSvc.KMS(),
		vaultSvc:  vaultSvc,
		policySvc: policySvc,
		registry:  registry,
		log:       log,
	}
}

func (s *RotationService) RequestRotation(ctx context.Context, credID, operator string) (*models.RotationJob, error) {
	return s.RotateCredential(ctx, credID, models.RotationTriggerManual, operator)
}

func (s *RotationService) RotateCredential(ctx context.Context, credID string, trigger models.RotationTriggerType, operator string) (*models.RotationJob, error) {
	var pending int64
	s.db.Model(&models.RotationJob{}).Where("(credential_id = ? OR vault_entry_id = ?) AND status = 'in_progress'", credID, credID).Count(&pending)
	if pending > 0 {
		return nil, ErrRotationInProgress
	}

	now := time.Now()
	job := &models.RotationJob{
		CredentialID: credID,
		VaultEntryID: credID,
		Status:       "in_progress",
		TriggerType:  string(trigger),
		AttemptCount: 1,
		StartedAt:    &now,
	}
	if err := s.db.Create(job).Error; err != nil {
		return nil, fmt.Errorf("failed to create rotation job: %w", err)
	}

	var entry models.Credential
	if err := s.db.First(&entry, "id = ?", credID).Error; err != nil {
		s.failJob(job, entry.Version, operator, fmt.Sprintf("credential not found: %v", err))
		return job, err
	}

	var resource models.PAMResource
	if entry.ResourceID != "" {
		_ = s.db.First(&resource, "id = ?", entry.ResourceID).Error
	}
	if resource.ResourceType == "" {
		resource.ResourceType = "ssh"
	}

	aad := map[string]string{
		"account": entry.AccountName,
	}
	if entry.SafeID != "" {
		aad["safe_id"] = entry.SafeID
	}
	if entry.ResourceID != "" {
		aad["resource_id"] = entry.ResourceID
	}

	oldSecret, err := crypto.EnvelopeDecryptor(ctx, s.kms, entry.CredentialEnc, aad)
	if err != nil {
		s.failJob(job, entry.Version, operator, fmt.Sprintf("failed to decrypt current secret: %v", err))
		return job, err
	}

	policy, err := s.policySvc.GetPolicyForPlatform(resource.ResourceType)
	if err != nil {
		s.log.Warn("rotation.policy.fallback", zap.Error(err))
		policy = models.DefaultPasswordPolicy()
	}
	newSecret, err := s.policySvc.GenerateCompliantPassword(policy)
	if err != nil {
		s.failJob(job, entry.Version, operator, fmt.Sprintf("password generation failed: %v", err))
		return job, err
	}

	connector, err := s.registry.Get(resource.ResourceType)
	if err != nil {
		s.failJob(job, entry.Version, operator, err.Error())
		return job, err
	}

	s.log.Info("rotation.target.start",
		zap.String("job_id", job.ID),
		zap.String("resource", resource.Name),
		zap.String("account", entry.AccountName),
	)
	if err := connector.RotateCredential(ctx, resource, entry.AccountName, oldSecret, newSecret); err != nil {
		s.failJob(job, entry.Version, operator, fmt.Sprintf("target rotation failed: %v", err))
		return job, fmt.Errorf("%w: %v", ErrRotationFailed, err)
	}

	// ── Dependency-Aware Rotation with Automatic Rollback (Feature 16) ──
	var deps []models.RotationDependency
	if err := s.db.Where("(credential_id = ? OR vault_entry_id = ?) AND status = 'active'", credID, credID).Find(&deps).Error; err == nil && len(deps) > 0 {
		s.log.Info("rotation.dependencies.start", zap.Int("count", len(deps)), zap.String("cred_id", credID))
		for _, dep := range deps {
			if err := s.updateDependency(ctx, dep, newSecret); err != nil {
				s.log.Error("rotation.dependency.failed.rolling_back",
					zap.String("dep_id", dep.ID),
					zap.String("service", dep.ServiceName),
					zap.Error(err),
				)

				rollbackErr := connector.RotateCredential(ctx, resource, entry.AccountName, newSecret, oldSecret)
				if rollbackErr != nil {
					s.failJob(job, entry.Version, operator, fmt.Sprintf("CRITICAL: dependency '%s' failed (%v) AND ROLLBACK FAILED: %v", dep.ServiceName, err, rollbackErr))
					return job, ErrRollbackFailed
				}

				s.rollbackJob(job, entry.Version, operator, fmt.Sprintf("dependency '%s' update failed (%v) — primary target successfully rolled back", dep.ServiceName, err))
				return job, ErrDependencyFailed
			}
		}
	}

	newEnc, err := crypto.EnvelopeEncryptor(ctx, s.kms, newSecret, aad)
	if err != nil {
		s.failJob(job, entry.Version, operator, fmt.Sprintf("failed to envelope-encrypt new secret: %v", err))
		return job, err
	}

	oldVersion := entry.Version
	newVersion := oldVersion + 1
	completed := time.Now()
	nextRotation := completed.AddDate(0, 0, entry.RotationIntervalDays)
	var nextPtr *time.Time
	if entry.RotationIntervalDays > 0 {
		nextPtr = &nextRotation
	}

	err = s.db.Transaction(func(tx *gorm.DB) error {
		entry.CredentialEnc = newEnc
		entry.Version = newVersion
		entry.LastRotatedAt = &completed
		entry.NextRotationAt = nextPtr
		entry.Status = "active"
		if err := tx.Save(&entry).Error; err != nil {
			return err
		}

		job.Status = "success"
		job.CompletedAt = &completed
		if err := tx.Save(job).Error; err != nil {
			return err
		}

		versionRow := models.CredentialVersion{
			CredentialID:  entry.ID,
			Version:       newVersion,
			CredentialEnc: newEnc,
			Reason:        fmt.Sprintf("Automated rotation (%s)", trigger),
			CreatedBy:     operator,
			CreatedAt:     completed,
		}
		if err := tx.Create(&versionRow).Error; err != nil {
			return err
		}

		history := models.RotationHistory{
			CredentialID: entry.ID,
			VaultEntryID: entry.ID,
			JobID:        job.ID,
			OldVersion:   oldVersion,
			NewVersion:   newVersion,
			RotatedBy:    operator,
			Status:       "success",
			RotatedAt:    completed,
		}
		return tx.Create(&history).Error
	})

	if err != nil {
		s.failJob(job, oldVersion, operator, fmt.Sprintf("database transaction failed: %v", err))
		return job, err
	}

	s.log.Info("rotation.success",
		zap.String("credential_id", entry.ID),
		zap.Int("new_version", newVersion),
		zap.String("operator", operator),
	)
	return job, nil
}

func (s *RotationService) updateDependency(ctx context.Context, dep models.RotationDependency, newSecret string) error {
	now := time.Now()
	dep.LastUpdated = &now
	return s.db.Save(&dep).Error
}

func (s *RotationService) failJob(job *models.RotationJob, version int, operator, errMsg string) {
	now := time.Now()
	job.Status = "failed"
	job.LastErrorMessage = errMsg
	job.CompletedAt = &now
	_ = s.db.Save(job)

	history := models.RotationHistory{
		CredentialID: job.CredentialID,
		VaultEntryID: job.VaultEntryID,
		JobID:        job.ID,
		OldVersion:   version,
		NewVersion:   version,
		RotatedBy:    operator,
		Status:       "failed",
		ErrorMessage: errMsg,
		RotatedAt:    now,
	}
	_ = s.db.Create(&history)
}

func (s *RotationService) rollbackJob(job *models.RotationJob, version int, operator, errMsg string) {
	now := time.Now()
	job.Status = "rolled_back"
	job.LastErrorMessage = errMsg
	job.CompletedAt = &now
	_ = s.db.Save(job)

	history := models.RotationHistory{
		CredentialID: job.CredentialID,
		VaultEntryID: job.VaultEntryID,
		JobID:        job.ID,
		OldVersion:   version,
		NewVersion:   version,
		RotatedBy:    operator,
		Status:       "rolled_back",
		ErrorMessage: errMsg,
		RotatedAt:    now,
	}
	_ = s.db.Create(&history)
}

// StartCronScheduler launches an hourly background goroutine using standard library time.Ticker
// without requiring any external cron library.
func (s *RotationService) StartCronScheduler(ctx context.Context) error {
	ticker := time.NewTicker(1 * time.Hour)
	go func() {
		for {
			select {
			case <-ctx.Done():
				ticker.Stop()
				return
			case <-ticker.C:
				s.runScheduledRotations(ctx)
			}
		}
	}()
	s.log.Info("rotation.scheduler.started", zap.String("interval", "1h"))
	return nil
}

func (s *RotationService) runScheduledRotations(ctx context.Context) {
	now := time.Now()
	var entries []models.Credential
	if err := s.db.Where("status = 'active' AND next_rotation_at IS NOT NULL AND next_rotation_at <= ?", now).Find(&entries).Error; err != nil {
		s.log.Error("rotation.cron.scan.error", zap.Error(err))
		return
	}

	for _, entry := range entries {
		s.log.Info("rotation.cron.triggering", zap.String("cred_id", entry.ID), zap.String("account", entry.AccountName))
		_, err := s.RotateCredential(ctx, entry.ID, models.RotationTriggerScheduled, "cron-rotator")
		if err != nil {
			s.log.Error("rotation.cron.failed", zap.String("cred_id", entry.ID), zap.Error(err))
		}
	}
}
