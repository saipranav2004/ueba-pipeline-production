// pam/internal/services/resource_service.go
package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrResourceNotFound  = errors.New("resource not found")
	ErrVaultNotFound     = errors.New("vault entry not found")
	ErrAlreadyCheckedOut = errors.New("credential is already checked out")
)

// ResourceService manages the resource registry, vault, and connection sessions.
type ResourceService struct {
	db        *gorm.DB
	cryptoKey string
	logger    *zap.Logger
}

func NewResourceService(db *gorm.DB, cryptoKey string, logger *zap.Logger) *ResourceService {
	return &ResourceService{db: db, cryptoKey: cryptoKey, logger: logger}
}

// DB exposes the underlying *gorm.DB for handlers that need raw queries.
func (s *ResourceService) DB() *gorm.DB {
	return s.db
}

// ──────────────────────────────────────────────────────────────────────────
// RESOURCE CRUD
// ──────────────────────────────────────────────────────────────────────────

// CreateResource registers a new target system (database, service, app).
func (s *ResourceService) CreateResource(r *models.PAMResource) error {
	return s.db.Create(r).Error
}

// GetResource fetches a single resource by ID.
func (s *ResourceService) GetResource(id string) (*models.PAMResource, error) {
	var r models.PAMResource
	if err := s.db.Where("id = ?", id).First(&r).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrResourceNotFound
		}
		return nil, err
	}
	return &r, nil
}

// ListResources returns all active resources, optionally filtered by type.
func (s *ResourceService) ListResources(resourceType string) ([]models.PAMResource, error) {
	var resources []models.PAMResource
	query := s.db.Where("is_active = ?", true).Order("resource_type ASC, name ASC")
	if resourceType != "" {
		query = query.Where("resource_type = ?", resourceType)
	}
	err := query.Find(&resources).Error
	return resources, err
}

// ListResourceGroups returns resources grouped by type (for UI display).
func (s *ResourceService) ListResourceGroups() ([]models.ResourceGroup, error) {
	resources, err := s.ListResources("")
	if err != nil {
		return nil, err
	}

	groupMap := make(map[string][]models.PAMResource)
	for _, r := range resources {
		groupMap[r.ResourceType] = append(groupMap[r.ResourceType], r)
	}

	typeInfo := map[string]struct{ Name, Icon string }{
		"postgresql": {"PostgreSQL Databases", "🐘"},
		"mongodb":    {"MongoDB Databases", "🍃"},
		"redis":      {"Redis Instances", "🔴"},
		"clickhouse": {"ClickHouse Databases", "⚡"},
		"minio":      {"MinIO Storage", "📦"},
		"qdrant":     {"Qdrant Vector DB", "🔍"},
		"metabase":   {"Metabase BI", "📊"},
		"langfuse":   {"Langfuse Observability", "🔬"},
		"web":        {"Web Applications", "🌐"},
	}

	var groups []models.ResourceGroup
	for rtype, items := range groupMap {
		info, ok := typeInfo[rtype]
		if !ok {
			info = struct{ Name, Icon string }{rtype, "🔗"}
		}
		groups = append(groups, models.ResourceGroup{
			Name:      info.Name,
			Icon:      info.Icon,
			Resources: items,
		})
	}
	return groups, nil
}

// UpdateResource updates a resource's mutable fields.
func (s *ResourceService) UpdateResource(id string, updates map[string]interface{}) error {
	result := s.db.Model(&models.PAMResource{}).Where("id = ?", id).Updates(updates)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return ErrResourceNotFound
	}
	return nil
}

// DeleteResource soft-deletes a resource.
func (s *ResourceService) DeleteResource(id string) error {
	return s.db.Where("id = ?", id).Delete(&models.PAMResource{}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// VAULT (encrypted credential management)
// ──────────────────────────────────────────────────────────────────────────

// StoreCredential creates a vault entry with an AES-256-GCM encrypted credential.
func (s *ResourceService) StoreCredential(resourceID, accountName, credentialType, plaintext string) (*models.VaultEntry, error) {
	encrypted, err := crypto.Encrypt(plaintext, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to encrypt credential: %w", err)
	}

	entry := &models.VaultEntry{
		ResourceID:     resourceID,
		AccountName:    accountName,
		CredentialType: credentialType,
		CredentialEnc:  encrypted,
	}

	if err := s.db.Create(entry).Error; err != nil {
		return nil, fmt.Errorf("failed to store vault entry: %w", err)
	}

	// Link the vault entry to the resource.
	s.db.Model(&models.PAMResource{}).Where("id = ?", resourceID).
		Update("vault_entry_id", entry.ID)

	s.logger.Info("vault.credential.stored",
		zap.String("resource_id", resourceID),
		zap.String("account", accountName),
	)
	return entry, nil
}

// GetDecryptedCredential retrieves and decrypts a credential.
// This is called ONLY at connection time — the plaintext is never stored or logged.
func (s *ResourceService) GetDecryptedCredential(resourceID string) (accountName, plaintext string, err error) {
	var entry models.VaultEntry
	if err := s.db.Where("resource_id = ?", resourceID).First(&entry).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return "", "", ErrVaultNotFound
		}
		return "", "", err
	}

	decrypted, err := crypto.Decrypt(entry.CredentialEnc, s.cryptoKey)
	if err != nil {
		return "", "", fmt.Errorf("failed to decrypt credential: %w", err)
	}

	return entry.AccountName, decrypted, nil
}

// RotateCredential replaces the stored credential with a new one.
func (s *ResourceService) RotateCredential(resourceID, newPlaintext string) error {
	encrypted, err := crypto.Encrypt(newPlaintext, s.cryptoKey)
	if err != nil {
		return err
	}
	now := time.Now()
	return s.db.Model(&models.VaultEntry{}).
		Where("resource_id = ?", resourceID).
		Updates(map[string]interface{}{
			"credential_enc":  encrypted,
			"last_rotated_at": now,
		}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// CONNECTION SESSIONS
// ──────────────────────────────────────────────────────────────────────────

// StartSession creates a connection session record when a user connects to a resource.
func (s *ResourceService) StartSession(userID, username, resourceID, sourceIP,
	authzDecisionID string) (*models.ConnectionSession, error) {

	resource, err := s.GetResource(resourceID)
	if err != nil {
		return nil, err
	}

	allowed := true
	session := &models.ConnectionSession{
		UserID:          userID,
		Username:        username,
		ResourceID:      resourceID,
		ResourceName:    resource.Name,
		ResourceType:    resource.ResourceType,
		SourceIP:        sourceIP,
		Protocol:        resource.ResourceType,
		Status:          "ACTIVE",
		AuthzDecisionID: &authzDecisionID,
		AuthzAllowed:    &allowed,
	}

	if err := s.db.Create(session).Error; err != nil {
		return nil, fmt.Errorf("failed to create session: %w", err)
	}

	s.logger.Info("session.started",
		zap.String("session_id", session.ID),
		zap.String("user", username),
		zap.String("resource", resource.Name),
		zap.String("type", resource.ResourceType),
	)
	return session, nil
}

// EndSession marks a session as completed.
//
// BUGFIX: duration_seconds was previously computed as
//
//	int(now.Sub(time.Time{}).Seconds())
//
// which measures from the Go zero time (year 1) and stores ~6.4e10 seconds
// on every row. It is now derived in SQL from started_at, which is also
// race-free (no read-modify-write round trip).
func (s *ResourceService) EndSession(sessionID string) error {
	now := time.Now().UTC()
	return s.db.Model(&models.ConnectionSession{}).
		Where("id = ? AND status = 'ACTIVE'", sessionID).
		Updates(map[string]interface{}{
			"status":           "COMPLETED",
			"ended_at":         now,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error
}

// ListActiveSessions returns all currently-active sessions (for admin monitoring).
func (s *ResourceService) ListActiveSessions() ([]models.ConnectionSession, error) {
	var sessions []models.ConnectionSession
	err := s.db.Where("status = 'ACTIVE'").Order("started_at DESC").Find(&sessions).Error
	return sessions, err
}

// KillSession terminates a session (admin action).
//
// IMPORTANT — read before relying on this for containment:
// PAM does not currently broker the transport (there is no SSH/RDP/DB
// proxy in this repository), so this marks the session record as KILLED and
// removes the authorisation to (re)connect. It cannot tear down a TCP
// connection the client already established directly against the target.
// Wire the future gateway to watch pam_connection_sessions.status (or a
// Redis pub/sub channel) to make termination physical as well as logical.
func (s *ResourceService) KillSession(sessionID, killedBy, reason string) error {
	now := time.Now().UTC()
	return s.db.Model(&models.ConnectionSession{}).
		Where("id = ? AND status = 'ACTIVE'", sessionID).
		Updates(map[string]interface{}{
			"status":           "KILLED",
			"ended_at":         now,
			"kill_reason":      reason,
			"killed_by":        killedBy,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// CONNECTION BROKER — builds the connection details for a resource
// ──────────────────────────────────────────────────────────────────────────

// ConnectionInfo holds everything needed to connect to a resource.
// This is returned to the WebSocket handler which uses it to open the connection.
type ConnectionInfo struct {
	ResourceID   string                 `json:"resource_id"`
	ResourceName string                 `json:"resource_name"`
	ResourceType string                 `json:"resource_type"`
	Host         string                 `json:"host"`
	Port         int                    `json:"port"`
	DatabaseName string                 `json:"database_name,omitempty"`
	AccountName  string                 `json:"account"`
	Password     string                 `json:"-"` // NEVER serialized to JSON
	ExtraConfig  map[string]interface{} `json:"extra_config,omitempty"`
	ConsoleURL   string                 `json:"console_url,omitempty"`
	ConnectMode  string                 `json:"connect_mode"`
}

// ResolveConnection retrieves all info needed to connect to a resource,
// including the decrypted credential. Called by the WebSocket handler.
// The plaintext password is in-memory only — never logged or returned to the client.
func (s *ResourceService) ResolveConnection(resourceID string) (*ConnectionInfo, error) {
	resource, err := s.GetResource(resourceID)
	if err != nil {
		return nil, err
	}

	accountName, password, err := s.GetDecryptedCredential(resourceID)
	if err != nil {
		return nil, fmt.Errorf("no credential configured for resource '%s': %w", resource.Name, err)
	}

	var extraConfig map[string]interface{}
	if resource.ExtraConfig != "" {
		json.Unmarshal([]byte(resource.ExtraConfig), &extraConfig)
	}

	return &ConnectionInfo{
		ResourceID:   resource.ID,
		ResourceName: resource.Name,
		ResourceType: resource.ResourceType,
		Host:         resource.Host,
		Port:         resource.Port,
		DatabaseName: resource.DatabaseName,
		AccountName:  accountName,
		Password:     password,
		ExtraConfig:  extraConfig,
		ConsoleURL:   resource.ConsoleURL,
		ConnectMode:  resource.ConnectMode,
	}, nil
}
