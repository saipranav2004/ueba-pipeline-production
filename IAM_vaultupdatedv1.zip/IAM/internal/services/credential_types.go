// pam/internal/services/credential_types.go
package services

import (
	"fmt"
	"strings"
)

// Credential type catalog (converted from Python pam/credential_types.py + constants).

const (
	TypeGenericUsernamePassword = "GENERIC_USERNAME_PASSWORD"
	TypeGenericSecret           = "GENERIC_SECRET"
	TypeAPIKey                  = "API_KEY"
	TypeOracleDatabase          = "ORACLE_DATABASE"
	TypePostgresDatabase        = "POSTGRES_DATABASE"
	TypeMySQLDatabase           = "MYSQL_DATABASE"
	TypeSSHAccount              = "SSH_ACCOUNT"
	TypeWindowsLocal            = "WINDOWS_LOCAL_ACCOUNT"
	TypeActiveDirectory         = "ACTIVE_DIRECTORY_ACCOUNT"
	TypeM365Application         = "M365_APPLICATION"
	TypeAWSAccessKey            = "AWS_ACCESS_KEY"
	TypeTLSCertificate          = "TLS_CERTIFICATE"
	TypeGitHubApp               = "GITHUB_APP"
)

// TypeDefinition describes safe metadata + encrypted secret field contracts.
type TypeDefinition struct {
	CredentialType       string   `json:"credential_type"`
	DisplayName          string   `json:"display_name"`
	Category             string   `json:"category"`
	RequiredMetadata     []string `json:"required_metadata"`
	OptionalMetadata     []string `json:"optional_metadata"`
	RequiredSecretFields []string `json:"required_secret_fields"`
	OptionalSecretFields []string `json:"optional_secret_fields"`
	PasswordBased        bool     `json:"password_based"`
	RotationSupported    bool     `json:"rotation_supported"`
}

var typeCatalog = []TypeDefinition{
	{
		CredentialType: TypeGenericUsernamePassword, DisplayName: "Generic Username and Password", Category: "generic",
		OptionalMetadata:     []string{"environment", "target_label", "connector_type", "sensitivity"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeGenericSecret, DisplayName: "Generic Secret", Category: "generic",
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"secret"},
	},
	{
		CredentialType: TypeAPIKey, DisplayName: "API Key / Token", Category: "token",
		OptionalMetadata:     []string{"provider", "key_name", "environment", "target_label"},
		RequiredSecretFields: []string{"api_key"}, RotationSupported: true,
	},
	{
		CredentialType: TypePostgresDatabase, DisplayName: "PostgreSQL Database Account", Category: "database",
		RequiredMetadata:     []string{"host", "port", "database_name"},
		OptionalMetadata:     []string{"sslmode", "environment", "target_label"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeOracleDatabase, DisplayName: "Oracle Database Account", Category: "database",
		RequiredMetadata:     []string{"host", "port", "service_name"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeMySQLDatabase, DisplayName: "MySQL Database Account", Category: "database",
		RequiredMetadata:     []string{"host", "port", "database_name"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeSSHAccount, DisplayName: "SSH Account", Category: "server",
		RequiredMetadata:     []string{"host"},
		OptionalMetadata:     []string{"port", "environment", "target_label"},
		RequiredSecretFields: []string{"username"},
		OptionalSecretFields: []string{"password", "private_key", "private_key_passphrase"},
		PasswordBased:        true, RotationSupported: true,
	},
	{
		CredentialType: TypeWindowsLocal, DisplayName: "Windows Local Account", Category: "server",
		RequiredMetadata:     []string{"host"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeActiveDirectory, DisplayName: "Active Directory Account", Category: "server",
		RequiredMetadata:     []string{"domain"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"username", "password"}, PasswordBased: true, RotationSupported: true,
	},
	{
		CredentialType: TypeM365Application, DisplayName: "Microsoft 365 Application", Category: "cloud",
		RequiredMetadata:     []string{"tenant_id", "client_id"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"client_secret"}, RotationSupported: true,
	},
	{
		CredentialType: TypeAWSAccessKey, DisplayName: "AWS Access Key", Category: "cloud",
		RequiredMetadata:     []string{"account_alias"},
		OptionalMetadata:     []string{"region", "environment", "target_label"},
		RequiredSecretFields: []string{"access_key_id", "secret_access_key"},
		OptionalSecretFields: []string{"session_token"}, RotationSupported: true,
	},
	{
		CredentialType: TypeTLSCertificate, DisplayName: "TLS Certificate", Category: "certificate",
		RequiredMetadata:     []string{"common_name"},
		OptionalMetadata:     []string{"environment", "target_label"},
		RequiredSecretFields: []string{"certificate_pem", "private_key_pem"},
		OptionalSecretFields: []string{"private_key_passphrase", "certificate_chain_pem"},
	},
	{
		CredentialType: TypeGitHubApp, DisplayName: "GitHub App", Category: "cloud",
		OptionalMetadata:     []string{"owner", "repo", "environment", "target_label"},
		RequiredSecretFields: []string{"api_key"}, RotationSupported: true,
	},
}

func ListCredentialTypes() []TypeDefinition {
	out := make([]TypeDefinition, len(typeCatalog))
	copy(out, typeCatalog)
	return out
}

func GetTypeDefinition(credentialType string) (TypeDefinition, error) {
	ct := strings.ToUpper(strings.TrimSpace(credentialType))
	for _, d := range typeCatalog {
		if d.CredentialType == ct {
			return d, nil
		}
	}
	return TypeDefinition{}, fmt.Errorf("unsupported credential type: %s", credentialType)
}

func IsPasswordBased(credentialType string) bool {
	d, err := GetTypeDefinition(credentialType)
	return err == nil && d.PasswordBased
}

// ValidateCredentialData checks metadata + secret field contracts.
func ValidateCredentialData(credentialType string, metadata map[string]any, secret map[string]any) error {
	def, err := GetTypeDefinition(credentialType)
	if err != nil {
		return err
	}
	if metadata == nil {
		metadata = map[string]any{}
	}
	if secret == nil {
		return fmt.Errorf("secret_payload must be an object")
	}
	// Reject secret-like keys in metadata
	for k := range metadata {
		lk := strings.ToLower(k)
		for _, bad := range []string{"password", "secret", "token", "private_key", "ciphertext", "encrypted_dek", "nonce"} {
			if strings.Contains(lk, bad) {
				return fmt.Errorf("sensitive field %q is not allowed in target_metadata", k)
			}
		}
	}
	for _, f := range def.RequiredMetadata {
		if !hasNonEmpty(metadata, f) {
			return fmt.Errorf("required target_metadata field missing: %s", f)
		}
	}
	for _, f := range def.RequiredSecretFields {
		if !hasNonEmpty(secret, f) {
			return fmt.Errorf("required secret field missing: %s", f)
		}
	}
	// SSH special: password OR private_key
	if def.CredentialType == TypeSSHAccount {
		if !hasNonEmpty(secret, "password") && !hasNonEmpty(secret, "private_key") {
			return fmt.Errorf("SSH credential requires password or private_key")
		}
	}
	if def.CredentialType == TypeTLSCertificate {
		cert, _ := secret["certificate_pem"].(string)
		key, _ := secret["private_key_pem"].(string)
		if !strings.Contains(cert, "BEGIN CERTIFICATE") {
			return fmt.Errorf("TLS certificate PEM is invalid")
		}
		if !strings.Contains(key, "PRIVATE KEY") {
			return fmt.Errorf("TLS private key PEM is invalid")
		}
	}
	return nil
}

func hasNonEmpty(m map[string]any, key string) bool {
	v, ok := m[key]
	if !ok || v == nil {
		return false
	}
	switch t := v.(type) {
	case string:
		return strings.TrimSpace(t) != ""
	default:
		return true
	}
}
