// pam/internal/models/user.go
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// User is PAM's own local identity record.
//
// This used to be a read-only mirror of an external IAM service's
// `public.iam_users` table — PAM verified passwords against it but never
// created or modified rows. That external dependency has been removed
// entirely: PAM now owns user lifecycle end to end (see
// internal/services/identity_service.go for the CRUD/lifecycle API, exposed
// through the Admin Center's Identity Management screens). Authorization
// for what a user can DO is a separate concern, resolved via their Role/
// Policy attachments — see rbac.go and opa/engine.go.
type User struct {
	UserID       string  `gorm:"primaryKey;column:user_id;type:varchar(36)" json:"user_id"`
	Username     string  `gorm:"column:username;type:varchar(150);uniqueIndex;not null" json:"username"`
	Email        string  `gorm:"column:email;type:varchar(255);uniqueIndex;not null" json:"email"`
	FullName     string  `gorm:"column:full_name;type:varchar(255)" json:"full_name,omitempty"`
	PasswordHash *string `gorm:"column:password_hash;type:varchar(512)" json:"-"`

	// Status: ACTIVE | DISABLED | LOCKED | DELETED (soft delete via
	// DeletedAt also exists below for permanent removal — Status=DELETED
	// is a distinct, reversible "deactivated" lifecycle state an admin
	// chooses, whereas DeletedAt is the irreversible GORM soft-delete).
	Status              string     `gorm:"column:status;type:varchar(30);default:'ACTIVE';index" json:"status"`
	MFAEnabled          bool       `gorm:"column:mfa_enabled" json:"mfa_enabled"`
	FailedLoginAttempts int        `gorm:"column:failed_login_attempts;default:0" json:"failed_login_attempts"`
	LockedUntil         *time.Time `gorm:"column:locked_until" json:"locked_until,omitempty"`
	LastLoginAt         *time.Time `gorm:"column:last_login_at" json:"last_login_at,omitempty"`
	LastLoginIP         *string    `gorm:"column:last_login_ip;type:varchar(45)" json:"last_login_ip,omitempty"`

	// AccountID is an optional tenant/account scope, kept for the hardened
	// vault's multi-tenancy hooks. Not used by RBAC/PBAC itself.
	AccountID *string `gorm:"column:account_id;type:varchar(64)" json:"account_id,omitempty"`

	// IsProtected marks the seeded bootstrap superuser account (see
	// opa.DefaultSeedBundle / seed_service.go). Protected accounts cannot be
	// deleted or disabled via the Identity Management API — every
	// deployment must always retain at least one way in.
	IsProtected bool `gorm:"column:is_protected;default:false" json:"is_protected"`

	CreatedBy string         `gorm:"column:created_by;type:varchar(36)" json:"created_by,omitempty"`
	CreatedAt time.Time      `gorm:"column:created_at;autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"column:updated_at;autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"column:deleted_at;index" json:"-"`
}

// TableName is PAM's own users table now — no more cross-schema read.
func (User) TableName() string { return "pam_users" }

func (u *User) BeforeCreate(tx *gorm.DB) error {
	if u.UserID == "" {
		u.UserID = uuid.NewString()
	}
	return nil
}
