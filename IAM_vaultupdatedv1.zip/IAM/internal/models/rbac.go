// pam/internal/models/rbac.go
//
// PAM's own Identity/RBAC/PBAC schema — replaces the external IAM service
// for both authentication (see the rewritten user.go) and authorization
// (see opa/engine.go + internal/services/policy_engine_service.go).
//
// The model is the standard hybrid most production IAM systems use:
//   - Policy: a fine-grained statement (effect + actions + resources).
//   - Role:   a named bundle of policies (RBAC) — assign a role to a user
//     and they inherit every policy attached to it.
//   - A policy MAY also be attached directly to a user (PBAC / "inline
//     policy"), bypassing roles entirely, for one-off grants that don't
//     warrant a whole new role.
//
// Effective permissions for a user = union of (policies via every role
// they hold) + (policies attached directly to them). See
// PolicyEngineService.ResolveInput for where that union is computed.
package models

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// ── ROLES ──────────────────────────────────────────────────────────────────

type Role struct {
	ID          string `gorm:"primaryKey;type:varchar(36)" json:"id"`
	Name        string `gorm:"type:varchar(100);uniqueIndex;not null" json:"name"`
	Description string `gorm:"type:text" json:"description,omitempty"`
	// IsSystem marks a seeded role (root/admin/user) that ships with every
	// install. System roles cannot be deleted via the API — deleting
	// "admin" out from under a running deployment would be a very easy way
	// to accidentally lock every administrator out at once.
	IsSystem  bool           `gorm:"default:false" json:"is_system"`
	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Role) TableName() string { return "pam_roles" }

func (r *Role) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}

// ── POLICIES ────────────────────────────────────────────────────────────────

type PolicyEffect string

const (
	PolicyEffectAllow PolicyEffect = "allow"
	PolicyEffectDeny  PolicyEffect = "deny"
)

// Policy is stored with its Actions/Resources arrays serialized to text
// columns (portable across the sqlite-in-tests / postgres-in-prod split
// this codebase already uses elsewhere, e.g. Credential.MetadataJSON) —
// Actions/Resources below are transient (gorm:"-"), populated by
// LoadArrays()/serialized by SaveArrays() in the service layer immediately
// around every read/write, so callers everywhere else just see plain
// []string fields, never the underlying JSON text.
type Policy struct {
	ID          string `gorm:"primaryKey;type:varchar(36)" json:"id"`
	Name        string `gorm:"type:varchar(150);uniqueIndex;not null" json:"name"`
	Description string `gorm:"type:text" json:"description,omitempty"`
	Effect      string `gorm:"type:varchar(10);not null;default:'allow'" json:"effect"`

	ActionsJSON   string `gorm:"column:actions_json;type:text" json:"-"`
	ResourcesJSON string `gorm:"column:resources_json;type:text" json:"-"`

	Actions   []string `gorm:"-" json:"actions"`
	Resources []string `gorm:"-" json:"resources"`

	// IsSystem marks a seeded policy (e.g. "full-access", "standard-user-access").
	// System policies can be edited (to retune default access) but not deleted,
	// for the same reason system roles can't be.
	IsSystem  bool           `gorm:"default:false" json:"is_system"`
	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Policy) TableName() string { return "pam_policies" }

func (p *Policy) BeforeCreate(tx *gorm.DB) error {
	if p.ID == "" {
		p.ID = uuid.NewString()
	}
	return p.encodeArrays()
}

func (p *Policy) BeforeUpdate(tx *gorm.DB) error {
	return p.encodeArrays()
}

func (p *Policy) AfterFind(tx *gorm.DB) error {
	return p.decodeArrays()
}

func (p *Policy) encodeArrays() error {
	actions, err := json.Marshal(p.Actions)
	if err != nil {
		return err
	}
	resources, err := json.Marshal(p.Resources)
	if err != nil {
		return err
	}
	p.ActionsJSON = string(actions)
	p.ResourcesJSON = string(resources)
	return nil
}

func (p *Policy) decodeArrays() error {
	if p.ActionsJSON != "" {
		if err := json.Unmarshal([]byte(p.ActionsJSON), &p.Actions); err != nil {
			return err
		}
	}
	if p.ResourcesJSON != "" {
		if err := json.Unmarshal([]byte(p.ResourcesJSON), &p.Resources); err != nil {
			return err
		}
	}
	return nil
}

// ── ASSIGNMENTS ──────────────────────────────────────────────────────────────

// UserRole is an RBAC assignment: this user holds this role, and therefore
// inherits every policy attached to it.
type UserRole struct {
	UserID     string    `gorm:"primaryKey;type:varchar(36)" json:"user_id"`
	RoleID     string    `gorm:"primaryKey;type:varchar(36)" json:"role_id"`
	AssignedBy string    `gorm:"type:varchar(36)" json:"assigned_by,omitempty"`
	CreatedAt  time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (UserRole) TableName() string { return "pam_user_roles" }

// RolePolicy attaches a policy to a role (RBAC bundle membership).
type RolePolicy struct {
	RoleID    string    `gorm:"primaryKey;type:varchar(36)" json:"role_id"`
	PolicyID  string    `gorm:"primaryKey;type:varchar(36)" json:"policy_id"`
	CreatedAt time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (RolePolicy) TableName() string { return "pam_role_policies" }

// UserPolicy attaches a policy directly to a user (PBAC / inline policy),
// independent of any role.
type UserPolicy struct {
	UserID     string    `gorm:"primaryKey;type:varchar(36)" json:"user_id"`
	PolicyID   string    `gorm:"primaryKey;type:varchar(36)" json:"policy_id"`
	AttachedBy string    `gorm:"type:varchar(36)" json:"attached_by,omitempty"`
	CreatedAt  time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (UserPolicy) TableName() string { return "pam_user_policies" }
