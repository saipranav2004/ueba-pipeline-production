package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// PAMMFA stores PAM's own TOTP secrets — completely separate from IAM's MFA.
// Each PAM user gets their own TOTP secret for PAM-specific MFA verification.
type PAMMFA struct {
	ID              string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	UserID          string         `gorm:"type:varchar(36);not null;uniqueIndex" json:"user_id"`
	SecretEncrypted string         `gorm:"type:text;not null" json:"-"`                      // AES-256 encrypted TOTP secret
	BackupCodesHash *string        `gorm:"type:text" json:"-"`                               // Argon2-hashed backup codes (JSON array)
	Status          string         `gorm:"type:varchar(20);default:'PENDING'" json:"status"` // PENDING | ACTIVE | DISABLED
	CreatedAt       time.Time      `gorm:"autoCreateTime" json:"created_at"`
	ActivatedAt     *time.Time     `json:"activated_at,omitempty"`
	LastUsedAt      *time.Time     `json:"last_used_at,omitempty"`
	UpdatedAt       time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt       gorm.DeletedAt `gorm:"index" json:"-"`
}

func (PAMMFA) TableName() string { return "pam_mfa_devices" }

func (m *PAMMFA) BeforeCreate(tx *gorm.DB) error {
	if m.ID == "" {
		m.ID = uuid.NewString()
	}
	return nil
}
