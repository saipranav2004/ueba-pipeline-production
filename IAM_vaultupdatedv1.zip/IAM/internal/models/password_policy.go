// pam/internal/models/password_policy.go
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// PasswordPolicy defines complexity rules, length bounds, and history retention
// for generating compliant credentials during rotation.
type PasswordPolicy struct {
	ID               string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	Name             string         `gorm:"type:varchar(255);not null;uniqueIndex" json:"name"`
	MinLength        int            `gorm:"default:16" json:"min_length"`
	MaxLength        int            `gorm:"default:64" json:"max_length"`
	RequireUppercase bool           `gorm:"default:true" json:"require_uppercase"`
	RequireLowercase bool           `gorm:"default:true" json:"require_lowercase"`
	RequireDigits    bool           `gorm:"default:true" json:"require_digits"`
	RequireSpecial   bool           `gorm:"default:true" json:"require_special"`
	SpecialChars     string         `gorm:"type:varchar(255)" json:"special_chars"`
	HistoryCount     int            `gorm:"default:5" json:"history_count"`
	MinEntropyBits   int            `gorm:"default:64" json:"min_entropy_bits"`
	PlatformType     string         `gorm:"type:varchar(50);default:'any'" json:"platform_type"`
	IsDefault        bool           `gorm:"default:false" json:"is_default"`
	CreatedAt        time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt        time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt        gorm.DeletedAt `gorm:"index" json:"-"`
}

func (PasswordPolicy) TableName() string { return "pam_password_policies" }

func (p *PasswordPolicy) BeforeCreate(tx *gorm.DB) error {
	if p.ID == "" {
		p.ID = uuid.NewString()
	}
	if p.MinLength == 0 {
		p.MinLength = 16
	}
	if p.MaxLength == 0 {
		p.MaxLength = 64
	}
	if p.SpecialChars == "" {
		p.SpecialChars = "!@#$%^&*()-_=+[]{}|;:,.<>?"
	}
	return nil
}

func DefaultPasswordPolicy() PasswordPolicy {
	return PasswordPolicy{
		Name:             "Enterprise Default",
		MinLength:        16,
		MaxLength:        64,
		RequireUppercase: true,
		RequireLowercase: true,
		RequireDigits:    true,
		RequireSpecial:   true,
		SpecialChars:     "!@#$%^&*()-_=+[]{}|;:,.<>?",
		HistoryCount:     5,
		MinEntropyBits:   64,
		PlatformType:     "any",
		IsDefault:        true,
	}
}
