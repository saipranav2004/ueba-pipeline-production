// pam/internal/api/handlers/resource_handler.go
package handlers

import (
	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

type ResourceHandler struct {
	svc    *services.ResourceService
	logger *zap.Logger
}

func NewResourceHandler(svc *services.ResourceService, logger *zap.Logger) *ResourceHandler {
	return &ResourceHandler{svc: svc, logger: logger}
}

// ── LIST (grouped by type for the UI dashboard) ────────────────────────────

func (h *ResourceHandler) ListGroups(c *gin.Context) {
	groups, err := h.svc.ListResourceGroups()
	if err != nil {
		h.logger.Error("resource.list_groups.fail", zap.Error(err))
		response.Error(c, 500, "Failed to fetch resources")
		return
	}
	response.Success(c, gin.H{"groups": groups}, "Resources fetched")
}

// ── LIST (flat, optional filter by type) ───────────────────────────────────

func (h *ResourceHandler) List(c *gin.Context) {
	rtype := c.Query("type")
	resources, err := h.svc.ListResources(rtype)
	if err != nil {
		response.Error(c, 500, "Failed to fetch resources")
		return
	}
	response.Success(c, gin.H{"resources": resources, "count": len(resources)}, "Resources fetched")
}

// ── GET single resource ────────────────────────────────────────────────────

func (h *ResourceHandler) Get(c *gin.Context) {
	r, err := h.svc.GetResource(c.Param("id"))
	if err != nil {
		response.Error(c, 404, "Resource not found")
		return
	}
	response.Success(c, gin.H{"resource": r}, "Resource fetched")
}

// ── CREATE resource (admin) ────────────────────────────────────────────────

type createResourceRequest struct {
	Name         string `json:"name" binding:"required"`
	Description  string `json:"description"`
	ResourceType string `json:"resource_type" binding:"required"`
	Host         string `json:"host" binding:"required"`
	Port         int    `json:"port" binding:"required"`
	DatabaseName string `json:"database_name"`
	ConnectMode  string `json:"connect_mode"` // web_terminal, embed_redirect
	ConsoleURL   string `json:"console_url"`
	ExtraConfig  string `json:"extra_config"` // JSON string
	// RequiresJIT/AlwaysRecord were previously not bindable here at all —
	// a resource could only ever be created with both defaulted to false,
	// with no way to mark it JIT-gated through the API. Fixed as part of
	// wiring resource management into the Admin Center: an admin creating a
	// resource can now actually decide, at creation time, whether it
	// requires a time-boxed grant to connect.
	RequiresJIT  bool `json:"requires_jit"`
	AlwaysRecord bool `json:"always_record"`
}

func (h *ResourceHandler) Create(c *gin.Context) {
	var req createResourceRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "Invalid request: "+err.Error())
		return
	}

	userID, _ := c.Get("user_id")
	r := &models.PAMResource{
		Name:         req.Name,
		Description:  req.Description,
		ResourceType: req.ResourceType,
		Host:         req.Host,
		Port:         req.Port,
		DatabaseName: req.DatabaseName,
		ConnectMode:  req.ConnectMode,
		ConsoleURL:   req.ConsoleURL,
		ExtraConfig:  req.ExtraConfig,
		RequiresJIT:  req.RequiresJIT,
		AlwaysRecord: req.AlwaysRecord,
		IsActive:     true,
		CreatedBy:    userID.(string),
	}
	if r.ConnectMode == "" {
		r.ConnectMode = "web_terminal"
	}

	if err := h.svc.CreateResource(r); err != nil {
		h.logger.Error("resource.create.fail", zap.Error(err))
		response.Error(c, 500, "Failed to create resource")
		return
	}

	h.logger.Info("resource.created",
		zap.String("id", r.ID),
		zap.String("name", r.Name),
		zap.String("type", r.ResourceType),
	)
	response.Created(c, gin.H{"resource": r}, "Resource created")
}

// ── STORE CREDENTIAL (admin — encrypts and stores in vault) ───────────────

type storeCredentialRequest struct {
	AccountName    string `json:"account_name" binding:"required"` // username
	CredentialType string `json:"credential_type"`                 // password, api_key, connection_string
	Credential     string `json:"credential" binding:"required"`   // plaintext (encrypted before storage)
}

func (h *ResourceHandler) StoreCredential(c *gin.Context) {
	var req storeCredentialRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "Invalid request: "+err.Error())
		return
	}
	if req.CredentialType == "" {
		req.CredentialType = "password"
	}

	entry, err := h.svc.StoreCredential(
		c.Param("id"), req.AccountName, req.CredentialType, req.Credential,
	)
	if err != nil {
		h.logger.Error("vault.store.fail", zap.Error(err))
		response.Error(c, 500, "Failed to store credential")
		return
	}
	response.Created(c, gin.H{"vault_entry_id": entry.ID}, "Credential stored securely")
}

// ── ROTATE CREDENTIAL (admin) ──────────────────────────────────────────────

type rotateCredentialRequest struct {
	NewCredential string `json:"new_credential" binding:"required"`
}

func (h *ResourceHandler) RotateCredential(c *gin.Context) {
	var req rotateCredentialRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "new_credential is required")
		return
	}
	if err := h.svc.RotateCredential(c.Param("id"), req.NewCredential); err != nil {
		response.Error(c, 500, "Failed to rotate credential")
		return
	}
	response.Success(c, nil, "Credential rotated successfully")
}

// ── CONNECT INFO (returns safe connection details — no password) ──────────
// The frontend uses this to display the resource info before connecting.
// The actual credential is resolved server-side during the WebSocket handshake.

func (h *ResourceHandler) ConnectInfo(c *gin.Context) {
	resourceID := c.Param("id")

	r, err := h.svc.GetResource(resourceID)
	if err != nil {
		response.Error(c, 404, "Resource not found")
		return
	}

	// Return safe info — NO password, NO decrypted credential.
	response.Success(c, gin.H{
		"resource_id":    r.ID,
		"name":           r.Name,
		"type":           r.ResourceType,
		"host":           r.Host,
		"port":           r.Port,
		"database_name":  r.DatabaseName,
		"connect_mode":   r.ConnectMode,
		"console_url":    r.ConsoleURL,
		"has_credential": r.VaultEntryID != nil && *r.VaultEntryID != "",
	}, "Connection info retrieved")
}

// ── LIST SESSIONS (admin — see who's connected to what) ───────────────────

func (h *ResourceHandler) ListSessions(c *gin.Context) {
	activeOnly := c.Query("active") == "true"

	var sessions []models.ConnectionSession
	var err error
	if activeOnly {
		sessions, err = h.svc.ListActiveSessions()
	} else {
		err = h.db().Where("1=1").Order("started_at DESC").Limit(100).Find(&sessions).Error
	}

	if err != nil {
		response.Error(c, 500, "Failed to fetch sessions")
		return
	}
	response.Success(c, gin.H{"sessions": sessions, "count": len(sessions)}, "Sessions fetched")
}

// ── KILL SESSION (admin — terminate a user's connection) ──────────────────

type killSessionRequest struct {
	Reason string `json:"reason"`
}

func (h *ResourceHandler) KillSession(c *gin.Context) {
	sessionID := c.Param("id")
	var req killSessionRequest
	c.ShouldBindJSON(&req)
	if req.Reason == "" {
		req.Reason = "killed by admin"
	}

	killedBy, _ := c.Get("user_id")
	if err := h.svc.KillSession(sessionID, killedBy.(string), req.Reason); err != nil {
		response.Error(c, 500, "Failed to kill session")
		return
	}
	response.Success(c, gin.H{"session_id": sessionID}, "Session terminated")
}

// ── DELETE resource (soft delete) ──────────────────────────────────────────

func (h *ResourceHandler) Delete(c *gin.Context) {
	if err := h.svc.DeleteResource(c.Param("id")); err != nil {
		response.Error(c, 500, "Failed to delete resource")
		return
	}
	response.Success(c, nil, "Resource deleted")
}

// ── Helper: get DB from service ────────────────────────────────────────────

func (h *ResourceHandler) db() *gorm.DB {
	return h.svc.DB()
}
