package handlers

import (
	"errors"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type AuthHandler struct {
	auth *services.AuthService
	log  *zap.Logger
}

func NewAuthHandler(auth *services.AuthService, log *zap.Logger) *AuthHandler {
	return &AuthHandler{auth: auth, log: log}
}

// ─── LOGIN (step 1: password) ──────────────────────────────────────────────

type loginRequest struct {
	Identifier string `json:"identifier" binding:"required"`
	Password   string `json:"password" binding:"required"`
}

func (h *AuthHandler) Login(c *gin.Context) {
	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "identifier and password are required")
		return
	}

	result, err := h.auth.Login(req.Identifier, req.Password, c.ClientIP())
	if err != nil {
		switch {
		case errors.Is(err, services.ErrMFARequired):
			response.Success(c, result, "MFA verification required")
			return
		case errors.Is(err, services.ErrInvalidCredentials):
			response.Error(c, 401, "Invalid username or password")
			return
		case errors.Is(err, services.ErrAccountLocked):
			response.Error(c, 423, "Account is temporarily locked")
			return
		case errors.Is(err, services.ErrAccountDisabled):
			response.Error(c, 403, "Account is disabled")
			return
		default:
			h.log.Error("login.internal_error", zap.Error(err))
			response.Error(c, 500, "Login failed")
			return
		}
	}

	response.Success(c, result, "Login successful")
}

// ─── MFA VERIFY (step 2: TOTP code) ────────────────────────────────────────

type mfaVerifyRequest struct {
	ChallengeToken string `json:"challenge_token" binding:"required"`
	Code           string `json:"code" binding:"required"`
}

func (h *AuthHandler) MFAVerify(c *gin.Context) {
	var req mfaVerifyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "challenge_token and code are required")
		return
	}

	result, err := h.auth.VerifyMFA(req.ChallengeToken, req.Code, c.ClientIP())
	if err != nil {
		if errors.Is(err, services.ErrInvalidMFACode) {
			response.Error(c, 401, "Invalid or expired MFA code")
			return
		}
		response.Error(c, 401, err.Error())
		return
	}

	response.Success(c, result, "MFA verified, login successful")
}

// ─── MFA SETUP (initiate) ──────────────────────────────────────────────────

func (h *AuthHandler) MFASetupInitiate(c *gin.Context) {
	userID, _ := c.Get("user_id")
	email, _ := c.Get("email")

	result, err := h.auth.SetupMFAInitiate(userID.(string), email.(string))
	if err != nil {
		h.log.Error("mfa.setup.initiate.fail", zap.Error(err))
		response.Error(c, 500, "Failed to initiate MFA setup")
		return
	}

	response.Success(c, result, "Scan the QR code with your authenticator app")
}

// ─── MFA SETUP (verify + activate) ─────────────────────────────────────────

type mfaSetupVerifyRequest struct {
	MFADeviceID string `json:"mfa_device_id" binding:"required"`
	Code        string `json:"code" binding:"required"`
}

func (h *AuthHandler) MFASetupVerify(c *gin.Context) {
	var req mfaSetupVerifyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, 400, "mfa_device_id and code are required")
		return
	}

	userID, _ := c.Get("user_id")
	backupCodes, err := h.auth.SetupMFAVerify(userID.(string), req.MFADeviceID, req.Code)
	if err != nil {
		if errors.Is(err, services.ErrInvalidMFACode) {
			response.Error(c, 401, "Invalid MFA code")
			return
		}
		response.Error(c, 400, err.Error())
		return
	}

	response.Success(c, gin.H{
		"backup_codes": backupCodes,
		"message":      "Save these backup codes — they will NOT be shown again",
	}, "MFA enabled successfully")
}

// ─── ME (current user) ─────────────────────────────────────────────────────

func (h *AuthHandler) Me(c *gin.Context) {
	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	email, _ := c.Get("email")
	mfa, _ := c.Get("mfa_verified")
	roles, _ := c.Get("roles")

	response.Success(c, gin.H{
		"user_id":      userID,
		"username":     username,
		"email":        email,
		"mfa_verified": mfa,
		"roles":        roles,
	}, "Identity retrieved")
}

// ─── LOGOUT ────────────────────────────────────────────────────────────────

func (h *AuthHandler) Logout(c *gin.Context) {
	userID, _ := c.Get("user_id")
	h.auth.Logout(userID.(string))
	response.Success(c, nil, "Logged out")
}

// ─── HEALTH ────────────────────────────────────────────────────────────────

func (h *AuthHandler) Health(c *gin.Context) {
	userID, _ := c.Get("user_id")
	response.Success(c, gin.H{"status": "ok", "user_id": userID}, "PAM auth is healthy")
}
