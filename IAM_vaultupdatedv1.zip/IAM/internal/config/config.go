// pam/internal/config/config.go
//
// Merged configuration: base server/db/redis/s3/iam/jwt/vault/security config
// (Vault & Rotation branch) + JIT/break-glass config (JIT branch) + audit
// chain config (Audit/Compliance branch). All three teams touched this file
// independently; this is the reconciled superset.
package config

import (
	"fmt"
	"strings"

	"github.com/spf13/viper"
)

// Config holds all configuration for the PAM application.
type Config struct {
	Server   ServerConfig   `mapstructure:"server"`
	Database DatabaseConfig `mapstructure:"database"`
	Redis    RedisConfig    `mapstructure:"redis"`
	S3       S3Config       `mapstructure:"s3"`
	IAM      IAMConfig      `mapstructure:"iam"`
	JWT      JWTConfig      `mapstructure:"jwt"`
	Vault    VaultConfig    `mapstructure:"vault"`
	Security SecurityConfig `mapstructure:"security"`
	JIT      JITConfig      `mapstructure:"jit"`
	Audit    AuditConfig    `mapstructure:"audit"`
}

type ServerConfig struct {
	Port            string `mapstructure:"port"`
	Env             string `mapstructure:"env"` // "development" | "production"
	AllowedOrigins  string `mapstructure:"allowed_origins"`
	ShutdownTimeout int    `mapstructure:"shutdown_timeout"` // seconds

	// PublicURL is this PAM server's externally-reachable base URL — used to
	// build the pam-agent://launch?...&server=<this> handoff URL (see
	// agent_handler.go's CreateLaunch) and the "pam-agent pair --server ..."
	// hint returned from pair/init. MUST be set to the real public URL in
	// any deployment reached by more than one machine — the default below
	// only works when the browser and the paired agent are on the same box
	// as the server itself (local dev).
	PublicURL string `mapstructure:"public_url"`
}

type DatabaseConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Name     string `mapstructure:"name"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	SSLMode  string `mapstructure:"sslmode"`
	Schema   string `mapstructure:"schema"` // "pam"
}

func (d DatabaseConfig) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%d user=%s password=%s dbname=%s sslmode=%s search_path=%s",
		d.Host, d.Port, d.User, d.Password, d.Name, d.SSLMode, d.Schema,
	)
}

type RedisConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
}

type S3Config struct {
	Endpoint  string `mapstructure:"endpoint"`
	Bucket    string `mapstructure:"bucket"`
	AccessKey string `mapstructure:"access_key"`
	SecretKey string `mapstructure:"secret_key"`
	Region    string `mapstructure:"region"`
	UseSSL    bool   `mapstructure:"use_ssl"`
}

// IAMConfig — connection details for the IAM control center (PDP).
type IAMConfig struct {
	BaseURL       string `mapstructure:"base_url"`        // e.g. http://iam-host:5000
	ServiceToken  string `mapstructure:"service_token"`   // X-IAM-Service-Token for /authz/check
	AuthzCheckURL string `mapstructure:"authz_check_url"` // /api/v1/authz/check
	JWKsURL       string `mapstructure:"jwks_url"`        // /.well-known/jwks.json
	TimeoutSec    int    `mapstructure:"timeout_sec"`

	// ── PEP resilience ──
	// MaxRetries applies to the authz/check call only (it is a read-only,
	// side-effect-free decision request, so retrying is safe).
	MaxRetries     int `mapstructure:"max_retries"`
	RetryBackoffMs int `mapstructure:"retry_backoff_ms"`

	// AuthzCacheTTLSec caches ALLOW decisions for this many seconds.
	// DEFAULT 0 = disabled. Any value > 0 trades revocation latency for
	// throughput: a revoked entitlement can still be honoured for up to
	// TTL seconds by the cache. PAM-side JIT grant checks are NOT cached,
	// so time-boxed access remains exact regardless of this setting.
	AuthzCacheTTLSec int `mapstructure:"authz_cache_ttl_sec"`

	// ── Optional IAM projection endpoints (empty = feature skipped) ──
	// GrantURL receives the temporary policy attachment on approval.
	GrantURL string `mapstructure:"grant_url"`
	// RevokeURL receives the detachment. "{grant_id}" is substituted.
	RevokeURL string `mapstructure:"revoke_url"`
	// AlertURL receives CRITICAL break-glass alerts.
	AlertURL string `mapstructure:"alert_url"`
}

// JWTConfig — PAM's own HS256 JWT (separate from IAM's RS256).
type JWTConfig struct {
	SecretKey      string `mapstructure:"secret_key"`       // PAM-only signing secret
	AccessTTLMin   int    `mapstructure:"access_ttl_min"`   // access token lifetime (default 30)
	RefreshTTLDays int    `mapstructure:"refresh_ttl_days"` // refresh token lifetime (default 7)
}

// VaultConfig — AES-256-GCM master key management plus the machine data
// plane's own key material and policy defaults.
type VaultConfig struct {
	EncryptionKey string `mapstructure:"encryption_key"` // base64-encoded 32-byte key

	// ServiceTokenPepper is the server-side HMAC key that pam_service_tokens
	// rows are hashed under. It is deliberately NOT the same value as
	// EncryptionKey: the encryption key decrypts secrets, the pepper
	// authenticates callers, and a compromise of one should not hand over the
	// other. Losing it invalidates every issued service token (they must be
	// re-minted); leaking it lets anyone with a copy of the tokens table
	// brute-force nothing — the secrets are 256-bit random — but it does let
	// them forge a hash for a token id they choose, which is why it is
	// mandatory in production.
	ServiceTokenPepper string `mapstructure:"service_token_pepper"`

	// DefaultSecretTTLSec is how long a service client may cache a secret
	// when neither its grant nor an imminent rotation says otherwise. It is
	// an upper bound on how long a revoked grant can still be effective on a
	// client that already holds the plaintext, so shorter is safer and
	// chattier. 0 uses the built-in default (see
	// services.DefaultSecretTTLSeconds).
	DefaultSecretTTLSec int `mapstructure:"default_secret_ttl_sec"`
}

// SecurityConfig — login security policies.
type SecurityConfig struct {
	MaxLoginAttempts int `mapstructure:"max_login_attempts"` // default 5
	LockoutMinutes   int `mapstructure:"lockout_minutes"`    // default 30
}

// JITConfig — Just-In-Time access workflow, time-boxing and break-glass.
type JITConfig struct {
	// DefaultDurationMin is used when a request omits duration_minutes.
	DefaultDurationMin int `mapstructure:"default_duration_min"`
	// MaxDurationMin caps how long a standard grant may last.
	MaxDurationMin int `mapstructure:"max_duration_min"`
	// RequestTTLMin is how long a PENDING request waits for a decision
	// before it auto-expires.
	RequestTTLMin int `mapstructure:"request_ttl_min"`
	// MinReasonLength enforces a real justification (compliance evidence).
	MinReasonLength int `mapstructure:"min_reason_length"`
	// RequireSeparationOfDuty blocks self-approval.
	RequireSeparationOfDuty bool `mapstructure:"require_separation_of_duty"`

	// BreakglassWaitMin is the mandatory cooling-off period before an
	// emergency grant activates. 15 minutes is the documented default and
	// exists so a human can intervene before privileged access is live.
	BreakglassWaitMin int `mapstructure:"breakglass_wait_min"`
	// BreakglassMaxDurationMin caps emergency grant length.
	BreakglassMaxDurationMin int `mapstructure:"breakglass_max_duration_min"`
	// BreakglassActivationWindowMin is how long after AvailableAt the
	// waiting request stays activatable before it expires unused.
	BreakglassActivationWindowMin int `mapstructure:"breakglass_activation_window_min"`

	// SweepIntervalSec drives the auto-revoke background worker.
	SweepIntervalSec int `mapstructure:"sweep_interval_sec"`
	// SweepBatchSize bounds rows processed per pass per job.
	SweepBatchSize int `mapstructure:"sweep_batch_size"`
	// SweeperEnabled allows disabling the worker (e.g. on read replicas).
	SweeperEnabled bool `mapstructure:"sweeper_enabled"`
}

// AuditConfig — hash-chained audit trail (HMAC secret, default org, periodic
// integrity verification interval).
type AuditConfig struct {
	HMACSecret            string `mapstructure:"hmac_secret"`
	DefaultOrg            string `mapstructure:"default_org"`
	VerifyIntervalMinutes int    `mapstructure:"verify_interval_minutes"`
}

// Load reads configuration from environment variables (viper auto-bind).
func Load() (*Config, error) {
	v := viper.New()

	// ── Defaults (MUST register every key so AutomaticEnv can find its env var) ──
	// Viper's AutomaticEnv only binds env vars for keys that have a SetDefault.
	// Without this, keys like database.host are invisible even if the env var exists.
	v.SetDefault("server.port", "8080")
	v.SetDefault("server.env", "development")
	v.SetDefault("server.allowed_origins", "*")
	v.SetDefault("server.shutdown_timeout", 30)
	v.SetDefault("server.public_url", "http://localhost:8080")

	v.SetDefault("database.host", "")
	v.SetDefault("database.port", 5432)
	v.SetDefault("database.name", "")
	v.SetDefault("database.user", "")
	v.SetDefault("database.password", "")
	v.SetDefault("database.sslmode", "prefer")
	v.SetDefault("database.schema", "pam")

	v.SetDefault("redis.host", "localhost")
	v.SetDefault("redis.port", 6379)
	v.SetDefault("redis.password", "")
	v.SetDefault("redis.db", 1)

	v.SetDefault("s3.endpoint", "localhost:9000")
	v.SetDefault("s3.bucket", "pam-recordings")
	v.SetDefault("s3.access_key", "")
	v.SetDefault("s3.secret_key", "")
	v.SetDefault("s3.region", "us-east-1")
	v.SetDefault("s3.use_ssl", false)

	v.SetDefault("iam.base_url", "")
	v.SetDefault("iam.service_token", "")
	v.SetDefault("iam.authz_check_url", "/api/v1/authz/check")
	v.SetDefault("iam.timeout_sec", 5)
	v.SetDefault("iam.max_retries", 2)
	v.SetDefault("iam.retry_backoff_ms", 150)
	v.SetDefault("iam.authz_cache_ttl_sec", 0)
	v.SetDefault("iam.grant_url", "")
	v.SetDefault("iam.revoke_url", "")
	v.SetDefault("iam.alert_url", "")

	v.SetDefault("jwt.secret_key", "")
	v.SetDefault("jwt.access_ttl_min", 30)
	v.SetDefault("jwt.refresh_ttl_days", 7)

	v.SetDefault("vault.encryption_key", "")
	v.SetDefault("vault.service_token_pepper", "")
	v.SetDefault("vault.default_secret_ttl_sec", 300)

	v.SetDefault("security.max_login_attempts", 5)
	v.SetDefault("security.lockout_minutes", 30)

	v.SetDefault("jit.default_duration_min", 60)
	v.SetDefault("jit.max_duration_min", 480)
	v.SetDefault("jit.request_ttl_min", 1440)
	v.SetDefault("jit.min_reason_length", 10)
	v.SetDefault("jit.require_separation_of_duty", true)
	v.SetDefault("jit.breakglass_wait_min", 15)
	v.SetDefault("jit.breakglass_max_duration_min", 60)
	v.SetDefault("jit.breakglass_activation_window_min", 60)
	v.SetDefault("jit.sweep_interval_sec", 30)
	v.SetDefault("jit.sweep_batch_size", 200)
	v.SetDefault("jit.sweeper_enabled", true)

	v.SetDefault("audit.hmac_secret", "")
	v.SetDefault("audit.default_org", "default")
	v.SetDefault("audit.verify_interval_minutes", 1440)

	// ── Environment variable binding (PAM_SERVER_PORT, PAM_DB_HOST, etc.) ──
	v.SetEnvPrefix("PAM")
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	v.AutomaticEnv()

	// ── Optional config file ──
	v.SetConfigName("config")
	v.SetConfigType("yaml")
	v.AddConfigPath(".")
	v.AddConfigPath("./configs")
	v.AddConfigPath("/etc/pam")
	if err := v.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("config file error: %w", err)
		}
		// No config file is fine — we use env vars.
	}

	var cfg Config
	if err := v.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}

	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) validate() error {
	if c.Database.Host == "" {
		return fmt.Errorf("database.host (PAM_DATABASE_HOST) is required")
	}
	if c.Database.Name == "" {
		return fmt.Errorf("database.name (PAM_DATABASE_NAME) is required")
	}
	// NOTE: IAM config (base_url/service_token) is intentionally NOT
	// required. PAM no longer depends on an external IAM service for
	// anything — authentication and authorization are both fully local
	// (see internal/services/auth_service.go, policy_engine_service.go,
	// and opa/engine.go). The IAMConfig struct is kept only so a
	// deployment that still has PAM_IAM_* env vars set from before this
	// change doesn't fail to start; every field is now unused dead
	// configuration.
	if c.JWT.SecretKey == "" {
		return fmt.Errorf("jwt.secret_key (PAM_JWT_SECRET_KEY) is required")
	}
	if c.Vault.EncryptionKey == "" {
		return fmt.Errorf("vault.encryption_key (PAM_VAULT_ENCRYPTION_KEY) is required")
	}
	// Same rule and same reasoning as the audit HMAC secret below: optional in
	// development (main.go derives a clearly-labelled dev value and warns),
	// mandatory and full-length in production.
	if c.IsProduction() && len(c.Vault.ServiceTokenPepper) < 32 {
		return fmt.Errorf("vault.service_token_pepper (PAM_VAULT_SERVICE_TOKEN_PEPPER) is required and must be >= 32 bytes in production")
	}
	// The audit HMAC secret is allowed to be empty so engineers can run
	// without configuring it in development; main.go substitutes a
	// clearly-labelled dev-only fallback in that case. In production it is
	// mandatory and must be long enough to resist brute force.
	if c.IsProduction() && len(c.Audit.HMACSecret) < 32 {
		return fmt.Errorf("audit.hmac_secret (PAM_AUDIT_HMAC_SECRET) is required and must be >= 32 bytes in production")
	}
	return c.normaliseJIT()
}

// normaliseJIT clamps JIT settings to safe values. Misconfiguration here
// would silently weaken the control (e.g. a 0-minute break-glass wait), so
// every field is floored rather than trusted.
func (c *Config) normaliseJIT() error {
	if c.JIT.DefaultDurationMin <= 0 {
		c.JIT.DefaultDurationMin = 60
	}
	if c.JIT.MaxDurationMin <= 0 {
		c.JIT.MaxDurationMin = 480
	}
	if c.JIT.DefaultDurationMin > c.JIT.MaxDurationMin {
		c.JIT.DefaultDurationMin = c.JIT.MaxDurationMin
	}
	if c.JIT.RequestTTLMin <= 0 {
		c.JIT.RequestTTLMin = 1440
	}
	if c.JIT.MinReasonLength < 0 {
		c.JIT.MinReasonLength = 0
	}
	if c.JIT.BreakglassWaitMin < 0 {
		return fmt.Errorf("jit.breakglass_wait_min (PAM_JIT_BREAKGLASS_WAIT_MIN) cannot be negative")
	}
	if c.JIT.BreakglassMaxDurationMin <= 0 {
		c.JIT.BreakglassMaxDurationMin = 60
	}
	if c.JIT.BreakglassActivationWindowMin <= 0 {
		c.JIT.BreakglassActivationWindowMin = 60
	}
	if c.JIT.SweepIntervalSec <= 0 {
		c.JIT.SweepIntervalSec = 30
	}
	if c.JIT.SweepBatchSize <= 0 {
		c.JIT.SweepBatchSize = 200
	}
	if c.IAM.MaxRetries < 0 {
		c.IAM.MaxRetries = 0
	}
	if c.IAM.RetryBackoffMs <= 0 {
		c.IAM.RetryBackoffMs = 150
	}
	if c.IAM.TimeoutSec <= 0 {
		c.IAM.TimeoutSec = 5
	}
	if c.Audit.DefaultOrg == "" {
		c.Audit.DefaultOrg = "default"
	}
	if c.Audit.VerifyIntervalMinutes <= 0 {
		c.Audit.VerifyIntervalMinutes = 1440
	}
	if c.Vault.DefaultSecretTTLSec < 0 {
		c.Vault.DefaultSecretTTLSec = 0
	}
	return nil
}

func (c *Config) IsProduction() bool {
	return c.Server.Env == "production"
}
