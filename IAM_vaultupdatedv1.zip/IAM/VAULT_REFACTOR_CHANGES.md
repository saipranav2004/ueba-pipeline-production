# Vault Credential Management — Refactor Change Log

**Branch:** `pam_backend_dev/vault_management`
**Date:** 2026-08-24
**Scope:** Vault secret storage → machine-facing retrieval → runtime reuse → rotation handling

**Goal:** Store secrets in Vault → securely retrieve them when required → efficiently reuse
them → automatically handle token/credential expiration or rotation → minimise unnecessary
Vault calls → maintain a clean, secure, production-ready Go implementation.

---

## 0. Verification status

Everything below was compiled and tested. There was no Go toolchain on this machine, so
verification was run inside `golang:1.24-alpine` via Docker against the real module.

| Check | Command | Result |
|---|---|---|
| Build | `go build ./...` | clean, no output |
| Vet | `go vet ./...` | clean, no output |
| Format | `gofmt -l .` | clean, no output |
| Tests | `go test -race -count=1 ./...` | 4 packages `ok`, 0 failures |
| Route tree | temporary gin registration test | no panic (scaffold then deleted) |

Test packages passing: `opa`, `pkg/argon2`, `pkg/auditchain`, `pkg/vaultclient`.

> **Note on the route-tree check.** Gin panics at *registration* time on a conflicting
> wildcard, which would have crashed the process at startup rather than failing the build.
> I registered the exact route shapes from `main.go` in a throwaway test to prove startup
> is safe, confirmed no panic, then removed the scaffold. It is not part of the delivered code.

---

## 1. Executive summary

### 1.1 The branch did not compile before these changes

Four compile errors across three files existed on the branch as handed over:

1. **`models.ServiceToken` was declared twice** — in `internal/models/service_token.go`
   and again in `internal/models/service_identity.go`, with two different schemas pointing
   at two different tables (`service_tokens` vs `pam_service_tokens`). Duplicate type
   declaration in package `models`.
2. **`buildResponse` type mismatch** in `secret_access_service.go:287` — a
   `credentialRow` value passed where `*credentialRow` was required.
3. **`main.go` — `NewSecretAccessService` called with 4 args**, constructor takes 5
   (now 6 after this work).
4. **`main.go` — `middleware.ServiceAuth(db)` called with a `*gorm.DB`**, signature is
   `ServiceAuth(*services.ServiceIdentityService, *zap.Logger)`.

### 1.2 Beyond the compile errors

| # | Problem | Impact |
|---|---|---|
| 1 | Hardcoded AES-256 master key literal committed as a fallback in `vault_service.go` | A deployment that forgot `PAM_VAULT_ENCRYPTION_KEY` started happily and encrypted **every** credential under a key published in the source tree. Silent total compromise; nothing in the logs would flag it. |
| 2 | Envelope AAD hand-built in 4 places, from `req.*` on encrypt and `entry.*` on decrypt | Any credential stored with an empty `SafeID` became **permanently undecryptable** (see §4.2). |
| 3 | `ServiceAuth` mounted on the human route group | Would have made every human route demand a JWT **and** a service token simultaneously — 401 on all human traffic. |
| 4 | `POST /secrets/:name` routed to a handler reading `c.Param("path")` | Route never resolved; the parameter was always empty. |
| 5 | No `ServiceIdentityService` constructed at all | The entire authn/authz layer for machine callers was dead code. |
| 6 | `ServiceIdentity` / `ServiceToken` / `ServiceGrant` missing from `AutoMigrate` | Tables never created; every machine read would fail at the DB layer. |
| 7 | `pkg/vaultclient` — wrong endpoints, map write under `RLock`, useless refresh loop, no request dedup, misaligned cache keys | See §6 for the full list. |
| 8 | `models.ServiceCredential` — dead type, superseded by `ServiceGrant` | Dead code. |
| 9 | Three unused `VaultService` wrapper methods | Dead code. |

---

## 2. Final architecture

```
┌─ CONTROL PLANE ── human operators ── JWT + MFA + RBAC/PBAC ────────────────┐
│                                                                            │
│  /api/v1/pam/safes, /credentials, ...   VaultHandler                       │
│      store · reveal · version · rotate · backup                            │
│                                                                            │
│  /api/v1/pam/admin/services...          ServiceIdentityHandler             │
│      create identity · mint token · grant scope · revoke  (MFA-gated)      │
└────────────────────────────────────────────────────────────────────────────┘
                                     │  provisions
                                     ▼
┌─ DATA PLANE ── applications ── X-Service-Token ────────────────────────────┐
│                                                                            │
│  GET /api/v1/pam/svc/secrets/*path?purpose=...                             │
│  GET /api/v1/pam/svc/resources/:resource_id/secrets?purpose=...            │
│                                                                            │
│  middleware.ServiceAuth  →  authenticate (30s principal cache)             │
│                          →  per-identity token-bucket rate limit           │
│                          →  async coalesced last_used_at write             │
│  SecretAccessService     →  resolve path → authorize grant → decrypt        │
│                          →  compute authoritative TTL → audit              │
└────────────────────────────────────────────────────────────────────────────┘
                                     │  HTTP
                                     ▼
┌─ CONSUMER SDK ── pkg/vaultclient ──────────────────────────────────────────┐
│  Get() → cache hit  |  singleflight fetch  |  async refresh at 75% TTL     │
│         stale-serve on outage · hard-evict on 401/403/404                  │
│         token reload from TokenFile on 401 (rotation without restart)      │
└────────────────────────────────────────────────────────────────────────────┘
```

**The core principle: the server is authoritative on lifetime.** Every response carries
`cache_ttl_seconds`, already clamped server-side to:

```
min( grant.MaxTTLSeconds,
     deployment default,
     time-until-rotation − 2min skew,
     remaining service-token life )        floored at 30s
```

The client **never invents a TTL of its own; it only ever shortens.** That single rule is
what makes rotation safe: a client is structurally unable to hold a credential past the
point the vault knows it will change.

---

## 3. Complete file inventory

### 3.1 Deleted

| File | Reason |
|---|---|
| `internal/models/service_token.go` | Redeclared `ServiceToken`, already defined in `service_identity.go`. **Build breaker.** The surviving definition is the correct one: HMAC hash only, `TokenID` primary key, revocation and expiry columns, table `pam_service_tokens`. The deleted one stored the token **in plaintext** in a `Token` column. |
| `internal/models/service_credential.go` | Dead `ServiceCredential` type (row-per-credential ACL). Superseded by `models.ServiceGrant`, which is path-scoped. Referenced nowhere. |

### 3.2 Rewritten

| File | Reason |
|---|---|
| `pkg/vaultclient/client.go` | Complete rewrite. See §6. |

### 3.3 Created

| File | Reason |
|---|---|
| `pkg/vaultclient/client_test.go` | Behavioural tests for the caching/concurrency contract. See §6.5. |
| `VAULT_REFACTOR_CHANGES.md` | This document. |

### 3.4 Modified

| File | Summary |
|---|---|
| `cmd/pam-api/main.go` | Service wiring, migrations, route groups. §5 |
| `internal/config/config.go` | Two new settings + production validation. §7 |
| `internal/models/vault.go` | `EncryptionAAD()` + `SafeID` normalisation. §4 |
| `internal/services/vault_service.go` | Key from config, AAD helper, dead code removal. §4 |
| `internal/services/secret_access_service.go` | Compile fix, AAD helper, configurable TTL. §8 |
| `internal/api/handlers/service_identity_handler.go` | Two route doc-comments corrected. §5.4 |

### 3.5 Deliberately NOT modified

| File | Why |
|---|---|
| `internal/middleware/service_auth.go` | Already correct and well-designed. Kept as-is. |
| `internal/api/handlers/secret_access_handler.go` | Already correct: `GET`, mandatory `purpose`, `no-store` headers, error mapping that does not leak KMS internals. Kept as-is. |
| `internal/api/handlers/vault_handler.go` | Human control plane. Working, out of scope. |
| `internal/services/service_identity_service.go` | Already well-designed. Only its **caller** was broken. |

---

## 4. Encryption binding (AAD) — the correctness fix

### 4.1 What changed

**`internal/models/vault.go`** — new single source of truth:

```go
func (v *Credential) EncryptionAAD() map[string]string {
	aad := map[string]string{"account": v.AccountName}
	if v.SafeID != "" {
		aad["safe_id"] = v.SafeID
	}
	if v.ResourceID != "" {
		aad["resource_id"] = v.ResourceID
	}
	return aad
}
```

All **four** hand-rolled copies were replaced by calls to this method:

| Location | Before | After |
|---|---|---|
| `vault_service.StoreCredential` | built from `req.SafeID` / `req.AccountName` / `req.ResourceID` | `entry.EncryptionAAD()` |
| `vault_service.RevealCredential` | built from `entry.*` | `entry.EncryptionAAD()` |
| `vault_service.CreateVersion` | built from `entry.*` | `entry.EncryptionAAD()` |
| `secret_access_service.decrypt` | built from `cred.*` | `cred.EncryptionAAD()` |

`StoreCredential` was also restructured: the `Credential` struct is now populated **first**,
then encrypted with `entry.EncryptionAAD()`. Previously it encrypted from the raw request
before the entry existed, which is exactly how the two sides drifted.

### 4.2 The latent bug this fixed

`Credential.SafeID` carries `gorm:"default:'default'"`. A GORM column default applies
**only once the row reaches the database** — GORM omits the zero value from the INSERT and
lets Postgres fill it in.

So for any credential stored with an empty `SafeID`:

```
STORE:  AAD = {account: "app_user"}                        ← SafeID was "" in Go
        ↓ INSERT — Postgres fills safe_id = 'default'
READ:   AAD = {account: "app_user", safe_id: "default"}    ← SafeID is "default" from DB
        ↓
        AES-GCM tag mismatch → decryption fails, permanently
```

The credential was written successfully, appeared healthy in every listing, and then
**failed to decrypt forever**. Nothing surfaced this until someone tried to read it.

**Fix — normalise in Go, before the AAD is computed, in two places:**

1. `Credential.BeforeCreate` — covers every creation path in the codebase.
2. `VaultService.StoreCredential` — needed additionally because the AAD is computed
   *before* the GORM hook ever runs.

```go
if v.SafeID == "" {
	v.SafeID = "default"
}
```

> **Migration note:** any credential already stored with an empty `safe_id` was already
> undecryptable before this change, so there is no regression. Those rows cannot be
> recovered — the AAD they were sealed under is not reconstructible. They must be re-stored.
> Check with:
> `SELECT id, name, account_name FROM pam_credentials WHERE safe_id = 'default';`
> then attempt a reveal on each; any that fail predate the fix.

---

## 5. `cmd/pam-api/main.go` — wiring and routing

### 5.1 Import added

```go
"crypto/sha256"   // for the development pepper derivation
```

### 5.2 AutoMigrate — three tables added

```go
// ── Machine data plane (service identities, tokens, path grants) ──
&models.ServiceIdentity{},
&models.ServiceToken{},
&models.ServiceGrant{},
```

Without these, `pam_service_identities`, `pam_service_tokens` and `pam_service_grants`
were never created and every machine read failed at the database layer.

### 5.3 Service construction

**Before:**
```go
vaultService, err := services.NewVaultService(db, logger)

secretAccessSvc := services.NewSecretAccessService(
	db,
	vaultService.KMS(),
	auditService,      // ← 4 args, constructor takes 5
	logger,
)
```

**After:**
```go
vaultService, err := services.NewVaultService(db, cfg.Vault.EncryptionKey, logger)
if err != nil {
	logger.Fatal("vault.init.fail", zap.Error(err))
}

tokenPepper := []byte(cfg.Vault.ServiceTokenPepper)
if len(tokenPepper) < 32 {
	sum := sha256.Sum256([]byte("pam.service-token-pepper.dev|" + cfg.Vault.EncryptionKey))
	tokenPepper = sum[:]
	logger.Warn("service_token.pepper.using_dev_derivation",
		zap.String("action", "set PAM_VAULT_SERVICE_TOKEN_PEPPER (>= 32 bytes) before production"))
}

serviceIdentitySvc, err := services.NewServiceIdentityService(db, tokenPepper, auditService, logger)
if err != nil {
	logger.Fatal("service_identity.init.fail", zap.Error(err))
}

secretAccessSvc := services.NewSecretAccessService(
	db,
	vaultService.KMS(),
	serviceIdentitySvc,               // ← was entirely missing
	auditService,
	cfg.Vault.DefaultSecretTTLSec,    // ← new, config-driven
	logger,
)
```

**On the development pepper:** it is *derived*, not defaulted to a literal. This gives
determinism (tokens minted in one dev run still verify in the next) without a usable secret
being committed to the repository. In production `config.validate()` rejects startup unless
a real pepper ≥ 32 bytes is set, so the derivation branch is unreachable there.

### 5.4 Handlers registered

```go
secretAccessHandler := handlers.NewSecretAccessHandler(secretAccessSvc, logger)
serviceIdentityHandler := handlers.NewServiceIdentityHandler(serviceIdentitySvc, logger)
```

`serviceIdentityHandler` had **no** construction at all before — the entire control plane
for machine identities was unreachable.

### 5.5 Human route group — `ServiceAuth` removed

**Removed:**
```go
res.Use(middleware.ServiceAuth(db))   // wrong signature AND wrong plane
```

Two independent defects in one line. The signature is `ServiceAuth(*ServiceIdentityService, *zap.Logger)`,
so it did not compile. And had it compiled, mounting it on the human group would have made
every human route require a JWT **and** a service token at the same time — a 401 on all
human traffic. They are two alternative authentication schemes for two different planes,
not two layers of one.

**Also removed** (misrouted, plus a block of dead commented-out routes):
```go
res.POST("/secrets/:name", secretAccessHandler.GetSecret)
res.GET("/secrets/resource/:resource_id", secretAccessHandler.GetResourceSecrets)
// res.POST("/services", adminHandler.CreateServiceToken)
// res.GET("/services", adminHandler.ListServices)
// res.DELETE("/services/:id", adminHandler.RevokeServiceToken)
// res.POST("/services/:id/credentials/:credential_id", adminHandler.GrantCredentialAccess)
```

`POST /secrets/:name` bound the parameter as `name`, but `SecretAccessHandler.GetSecret`
reads `c.Param("path")` — always empty. The handler is also written for `GET`.

### 5.6 New machine data-plane group

```go
svc := r.Group("/api/v1/pam/svc")
svc.Use(middleware.ServiceAuth(serviceIdentitySvc, logger))
{
	svc.GET("/secrets/*path", secretAccessHandler.GetSecret)
	svc.GET("/resources/:resource_id/secrets", secretAccessHandler.GetResourceSecrets)
}
```

- **Its own group** — carries only `ServiceAuth`, never `PAMAuth`.
- **`*path` wildcard, not `:name`** — a secret is addressed by its canonical multi-segment
  path (`prod-db/postgres/pg-app`), and every read is audited under that resolved path.
- **`GET`, not `POST`** — a secret read is a read. The `purpose` travels as a query
  parameter or the `X-Secret-Purpose` header, because a GET with a body is the kind of
  thing proxies quietly drop.
- **Read-only by construction** — minting tokens and widening grants live under `/admin`,
  so a leaked service token can never escalate itself.

### 5.7 New admin control-plane routes

```go
admin.POST   ("/services",                    serviceIdentityHandler.CreateIdentity)
admin.GET    ("/services",                    serviceIdentityHandler.ListIdentities)
admin.POST   ("/services/:service/tokens",    middleware.RequireMFA(), serviceIdentityHandler.IssueToken)
admin.GET    ("/services/:service/tokens",    serviceIdentityHandler.ListTokens)
admin.POST   ("/services/:service/grants",    middleware.RequireMFA(), serviceIdentityHandler.GrantScope)
admin.GET    ("/services/:service/grants",    serviceIdentityHandler.ListGrants)
admin.POST   ("/services/:service/disable",   serviceIdentityHandler.DisableIdentity)
admin.DELETE ("/service-tokens/:token_id",    serviceIdentityHandler.RevokeToken)
admin.DELETE ("/service-grants/:grant_id",    serviceIdentityHandler.RevokeGrant)
```

**MFA gating:** applied to exactly the two operations that widen access — minting a token
and granting a scope. Listing and revoking do not need it; revocation should never have
friction during an incident.

**Path layout:** revocation is addressed as `/service-tokens/:token_id`, not
`/services/tokens/:token_id`. The latter would sit a static `tokens` segment as a sibling
of the `:service` parameter. Gin 1.10 does support that, but the flat form is unambiguous
regardless of router version and needs no reasoning to verify.

Two doc-comments in `service_identity_handler.go` were corrected to match:
- `// DELETE /admin/services/tokens/:token_id` → `// DELETE /admin/service-tokens/:token_id`
- `// DELETE /admin/services/grants/:grant_id` → `// DELETE /admin/service-grants/:grant_id`

### 5.8 Comment placement corrected

The `MACHINE DATA PLANE` banner is placed above the `svc` group and the pre-existing
`ADMIN CENTER` banner above the `admin` group. (My first pass inserted the new group
between the admin banner and its group; corrected.)

---

## 6. `pkg/vaultclient/client.go` — complete rewrite

This is the piece that answers *"retrieve and use those stored credentials securely and
efficiently at runtime."*

### 6.1 Defects in the previous implementation

| # | Defect | Consequence |
|---|---|---|
| 1 | Endpoints `POST /api/v1/vault/secrets/{name}` and `GET /api/v1/vault/secrets/resource/{id}` | Neither route existed on the server. **Nothing worked.** |
| 2 | `cache.get()` called `delete(sc.secrets, key)` while holding **`RLock`** | Concurrent map write under a read lock → `fatal error: concurrent map writes`. Not recoverable. |
| 3 | `refreshLoop()` re-fetched every cached secret every 5 minutes and **discarded the result** (`_, _ = c.fetchSecret(...)`) | Produced load without producing freshness, forever, including for secrets the app had stopped using hours earlier. |
| 4 | `refreshLoop` goroutine had no stop channel and no `Close()` | Permanent goroutine leak, one per client. |
| 5 | `GetSecret` cached by **secret name**; `GetResourceSecrets` cached by **`CredentialID`** | The two key spaces never intersected. The batch path's caching was pure memory growth. |
| 6 | No request coalescing | N concurrent goroutines on a cold cache → N HTTP requests. Thundering herd on every cold start and every expiry boundary. |
| 7 | No retries, no backoff | A single dropped packet surfaced as a hard failure to the application. |
| 8 | No status-code handling — any non-200 became `fmt.Errorf("vault error: %s", body)` | Callers could not distinguish "grant revoked" from "vault is down", so neither could be handled correctly. Also echoed the raw response body into the error string. |
| 9 | No `purpose` sent | Server requires it — every request would have been rejected with 400. |
| 10 | `MustGetSecret` panicked | Unacceptable in a library. |
| 11 | Secret name logged at `Info` on **every cache hit** | Log spam proportional to request rate. |
| 12 | No redaction on the response type | `fmt.Printf("%+v", secret)` anywhere in the calling application printed the plaintext credential. |
| 13 | No token rotation handling | A rotated service token meant a hard outage until restart. |
| 14 | No TLS enforcement, no redirect policy, default transport | Service token could be sent over cleartext HTTP or forwarded to another host on a redirect. |

### 6.2 The new caching model

Each cache entry carries two deadlines:

```
fetched ─────────── refreshAt ─────────── expiresAt ─────────── expiresAt+grace
        │  fresh   │   stale-but-valid   │   stale-in-grace   │
        │  serve   │  serve + refresh    │  serve only if     │  evict
        │  from    │  in background      │  vault is down     │
        │  cache   │                     │                    │
        └──────────┴─────────────────────┴────────────────────┘
                    ▲                     ▲
     refreshAt = fetched + TTL×0.75      expiresAt = fetched + TTL
                 (jittered ±10%)          (or RotatesAt, whichever is sooner)
```

| Read lands in | Behaviour | Vault requests |
|---|---|---|
| **fresh** | return cached value | 0 |
| **stale-but-valid** | return cached value **immediately**, refresh in background | 0 on the critical path |
| **expired** | blocking fetch, coalesced across callers | 1 total, regardless of concurrency |
| **expired + vault down** | serve stale within grace window, log a warning | 1 failed attempt |
| **expired + 401/403/404** | evict and return a typed error | 1 |

**Why refresh at 75% and not on expiry:** after the first fetch, a steadily-used secret is
never again fetched on the critical path. A rotation propagates without any request ever
paying the latency.

**Why jitter:** a hundred pods started together share a TTL and would otherwise refresh in
the same instant, forever — the vault sees a flat line with periodic vertical spikes.
Spreading `refreshAt` across ±10% breaks that lockstep permanently.

**Why no background prefetch loop:** refresh is read-driven, so a secret the application
has stopped using costs exactly zero requests. This is the direct answer to *"minimise
unnecessary Vault API calls."* The janitor goroutine only evicts; it never fetches.

### 6.3 Public API

```go
func New(cfg Config) (*Client, error)

func (c *Client) Get(ctx, path string) (Secret, error)
func (c *Client) GetValue(ctx, path string) (string, error)
func (c *Client) GetResourceSecrets(ctx, resourceID string) (map[string]Secret, error)
func (c *Client) Invalidate(path string)
func (c *Client) Close() error
```

**Typed errors** — callers can branch on the actual condition:

| Error | HTTP | Retryable | Cache action |
|---|---|---|---|
| `ErrUnauthenticated` | 401 | after `TokenFile` reload | evict |
| `ErrForbidden` | 403 | no | evict |
| `ErrNotFound` | 404 | no | evict |
| `ErrAmbiguous` | 409 | no | — |
| `ErrRateLimited` | 429 | yes | serve stale |
| *(transport / 5xx)* | 5xx | yes | serve stale |
| `ErrClosed` | — | no | — |

The **evict vs. serve-stale split is the security-critical distinction.** An explicit 401 /
403 / 404 means *the answer changed* — the grant was withdrawn, the token died, the secret
is gone — so the cached copy must go immediately. A 5xx or a dropped connection means *the
answer is unavailable*, which is a reason to keep serving, not to take the application down.

`Config` fields:

| Field | Default | Purpose |
|---|---|---|
| `Address` | *(required)* | PAM base URL; plain `http` rejected unless `AllowInsecureTransport` |
| `Purpose` | *(required)* | recorded on every audit row |
| `Token` | — | literal token |
| `TokenFile` | — | **preferred**; re-read on 401 |
| `AllowInsecureTransport` | `false` | dev only |
| `TLSConfig` | `nil` | e.g. internal CA pinning |
| `HTTPClient` | built-in tuned client | full override |
| `Timeout` | `10s` | per request |
| `MaxRetries` | `3` | additional attempts |
| `RefreshLead` | `0.75` | fraction of TTL at which background refresh starts |
| `StaleGrace` | `5m` | outage tolerance; negative disables |
| `Logger` | `nil` | never receives secrets or tokens |

### 6.4 Security properties, mechanism by mechanism

**Never log secrets, tokens, or credentials.**
`Secret` implements `String()`, `GoString()` and `MarshalJSON()`, all redacting. `String()`
is on the **value receiver** so it applies to both `Secret` and `*Secret`. This closes the
single most likely leak path: a `fmt.Printf("%+v", …)` or a structured-log field somewhere
in the calling application. Verified by `TestSecretNeverRendersItsValue`, which asserts
across `%v`, `%+v`, `%s`, `%#v`, `%v` on a pointer, and `json.Marshal`.

**Avoid unnecessarily storing sensitive values in memory.**
- Cache bounded at `maxEntries = 512`, evicting nearest-to-expiry first.
- Janitor evicts past `expiresAt + StaleGrace` every minute.
- `Close()` drops the whole map.
- TTL ≤ 0 from the server means *do not cache*: the value is returned but nothing is retained.

> **Honest limitation, stated in the code:** Go strings are immutable and may have been
> copied by the runtime, so there is no way to promise a plaintext has been scrubbed from
> process memory. What is guaranteed is that no further reference is held, so the values
> become collectable and a later heap dump is far less likely to contain them.

**Handle Vault tokens securely.**
- Token never logged, not even its public half.
- Shape validated at `New()` so a misconfiguration fails at startup, not as an opaque 401
  on the first read.
- Held under its own `tokenMu`, separate from the cache lock, so a reload never blocks reads.
- Sources in order: `Config.Token` → `Config.TokenFile` → `$PAM_SERVICE_TOKEN`.

**Handle authentication failures and expired credentials.**
On 401 the client re-reads `TokenFile`. If the contents differ from the token just
rejected, it retries once with the new token — so **rotating a service token is "write the
new value to the file"**, with no restart and no dropped requests (Kubernetes projected
volume, systemd credential, config-management run). If the file is absent, unreadable, or
unchanged, `reloadToken()` returns `false` and the request fails immediately rather than
burning the full retry budget on a permanently dead token.

**Transport hardening.**
- Plain `http://` rejected unless explicitly opted into — a service token in a cleartext
  header is a credential on the wire.
- `CheckRedirect` returns `http.ErrUseLastResponse` — a redirect must never carry the
  service token to another host.
- Dedicated `http.Transport` (8 idle conns/host, 90s idle timeout, HTTP/2) rather than
  `http.DefaultTransport`: this client talks to exactly one host, and handshaking per read
  would dominate the latency of an operation that is otherwise one indexed lookup.
- Response bodies drained (capped at 64 KiB) before close so connections return to the
  pool instead of being torn down.
- Response reads capped at 1 MiB.
- Error strings never echo the response body — on the read path it can carry the resolved
  secret path and other detail that does not belong in a caller's logs.

**Retries.**
Exponential backoff with **full jitter**, base 100 ms, capped at 3 s. Full jitter rather
than a fixed multiplier because the whole fleet retries at once during an outage, and a
deterministic backoff reconverges them into the same synchronised wave that caused the
problem. A cancelled caller context is never retried — that is the caller's decision, not
a vault fault.

**Concurrency.**
- `sync.RWMutex` on the cache; the previous map-write-under-`RLock` bug is gone.
- Per-key in-flight map collapses concurrent misses onto one request.
- `refreshing` flag under the lock keeps a burst of stale reads to one background refresh.
- Background refresh uses `context.Background()` with its own 30 s timeout, **not** the
  triggering request's context — that request may well finish first, and cancelling the
  refresh with it would leave the entry stale and re-trigger on the next read.
- Per-client `*rand.Rand` under its own mutex rather than the global `math/rand` source,
  whose shared mutex a hot cache path has no business contending on.
- `Close()` is idempotent, stops the janitor, waits for in-flight refreshes, and empties
  the cache.

**Least privilege.**
The SDK only ever issues `GET` against the two read endpoints. It structurally cannot mint
a token, widen a grant, or write a secret.

### 6.5 Tests — `pkg/vaultclient/client_test.go`

All pass under `-race`. These assert the caching claims rather than stating them.

| Test | Asserts |
|---|---|
| `TestGetServesFromCache` | 20 reads inside the TTL produce **exactly 1** vault request |
| `TestConcurrentMissesAreCollapsed` | 100 concurrent cold-start reads produce **exactly 1** vault request |
| `TestStaleReadTriggersBackgroundRefresh` | stale read returns the cached version **without blocking**; the rotated version lands in the background |
| `TestServesStaleWhenVaultUnavailable` | 503 past expiry → cached value still served, no error |
| `TestForbiddenEvictsCachedSecret` | 403 past expiry → `ErrForbidden` **and** the entry is gone (never served stale) |
| `TestStatusCodeMapping` | 401/403/404/409 map to the correct typed errors |
| `TestSecretNeverRendersItsValue` | no format verb and no JSON encoder emits the plaintext |
| `TestNewRejectsUnsafeConfig` | plaintext http, missing purpose, missing address, malformed token all rejected at construction |
| `TestCloseDropsCachedPlaintext` | cache emptied, `ErrClosed` afterwards, `Close()` idempotent |

### 6.6 Usage

```go
vc, err := vaultclient.New(vaultclient.Config{
	Address:   "https://pam.internal:8443",
	Purpose:   "billing-api settlement job",
	TokenFile: "/var/run/secrets/pam/service-token",
	Logger:    appLogger,
})
if err != nil {
	return err
}
defer vc.Close()

// Call this on every use. It is a map lookup on the hot path, and it means
// the application never holds a stale copy of its own.
s, err := vc.Get(ctx, "prod-db/postgres/pg-app-writer")
if err != nil {
	return err
}
dsn := fmt.Sprintf("postgres://%s:%s@db.internal/app", s.AccountName, s.Value)

// If the target rejects the credential — the one signal the client cannot get
// from the vault — drop it and re-read.
if errors.Is(dbErr, pgx.ErrInvalidPassword) {
	vc.Invalidate("prod-db/postgres/pg-app-writer")
}
```

---

## 7. `internal/config/config.go`

### 7.1 New settings on `VaultConfig`

```go
ServiceTokenPepper  string `mapstructure:"service_token_pepper"`
DefaultSecretTTLSec int    `mapstructure:"default_secret_ttl_sec"`
```

| Setting | Env var | Default | Notes |
|---|---|---|---|
| `vault.service_token_pepper` | `PAM_VAULT_SERVICE_TOKEN_PEPPER` | `""` | **Required ≥ 32 bytes in production.** |
| `vault.default_secret_ttl_sec` | `PAM_VAULT_DEFAULT_SECRET_TTL_SEC` | `300` | Deployment-wide cache ceiling before per-grant and rotation clamps. |

> Viper's `AutomaticEnv` only binds keys that have a registered `SetDefault`, so both were
> added to the defaults block — without that the env vars would be silently invisible.

### 7.2 Production validation added

```go
if c.IsProduction() && len(c.Vault.ServiceTokenPepper) < 32 {
	return fmt.Errorf("vault.service_token_pepper (PAM_VAULT_SERVICE_TOKEN_PEPPER) is required and must be >= 32 bytes in production")
}
```

Mirrors the existing rule for `audit.hmac_secret`: optional in development (with a warning
and a derived value), mandatory and full-length in production.

### 7.3 Normalisation added

```go
if c.Vault.DefaultSecretTTLSec < 0 {
	c.Vault.DefaultSecretTTLSec = 0   // 0 → services.DefaultSecretTTLSeconds
}
```

### 7.4 Why the pepper is separate from the encryption key

The encryption key **decrypts secrets**; the pepper **authenticates callers**. Compromise
of one should not hand over the other. Losing the pepper invalidates every issued service
token (they must be re-minted, and existing ones simply stop verifying); leaking it does not
enable brute force — the secrets are 256-bit CSPRNG output — but it does let an attacker
with the tokens table forge a hash for a token id of their choosing. Hence mandatory in
production.

---

## 8. `internal/services/secret_access_service.go`

### 8.1 Compile error fixed

```go
// Before — value passed to a *credentialRow parameter. Build failure.
resp := s.buildResponse(j.row, j.path, plaintext, principal, j.grant)

// After
// &j.row is safe: j is this goroutine's own parameter, not the shared loop variable.
resp := s.buildResponse(&j.row, j.path, plaintext, principal, j.grant)
```

Taking the address rather than changing the signature to a value receiver avoids copying
the embedded `models.Credential` on every batch element.

### 8.2 Configurable default TTL

New `defaultTTL` field, new `defaultTTLSeconds` constructor parameter (position 5 of 6),
clamped on construction:

```go
if defaultTTLSeconds <= 0    { defaultTTLSeconds = DefaultSecretTTLSeconds }  // 300
if defaultTTLSeconds < minTTLSeconds { defaultTTLSeconds = minTTLSeconds }    // 30
```

`effectiveTTL` now starts from `s.defaultTTL` instead of the package constant. The clamping
chain below it is unchanged: grant cap → rotation minus skew → token lifetime → 30 s floor.

### 8.3 AAD helper

`decrypt()` now calls `cred.EncryptionAAD()`. The AAD is still passed **explicitly** —
`EnvelopeDecryptor` falls back to the AAD stored inside the envelope when handed `nil`,
which would let anyone with a DB write rewrite the binding they are supposedly bound by.

---

## 9. `internal/services/vault_service.go`

### 9.1 Hardcoded master key removed

**Before:**
```go
func NewVaultService(db *gorm.DB, log *zap.Logger) (*VaultService, error) {
	keyB64 := os.Getenv("PAM_VAULT_ENCRYPTION_KEY")
	if keyB64 == "" {
		keyB64 = "TGdISHdR0jyKFvwAeuzgvaWPSLTw40gKeHghDF93S9U="   // ← committed AES-256 key
	}
	...
```

**After:**
```go
func NewVaultService(db *gorm.DB, masterKeyB64 string, log *zap.Logger) (*VaultService, error) {
	if masterKeyB64 == "" {
		return nil, errors.New("vault master key (PAM_VAULT_ENCRYPTION_KEY) is required")
	}
	...
```

Two reasons for the parameter rather than a second `os.Getenv`:

1. The fallback meant a deployment that forgot the env var **came up happily** and encrypted
   every credential under a key published in the source tree. Nothing in the logs would flag it.
2. `config.Load()` already validates the key as required. Reading the environment a second
   time here could only ever disagree with the configuration the rest of the process is using.

> **Action required if that fallback key was ever live:** every credential encrypted under
> it must be re-encrypted under a real key. Treat those credentials as disclosed and rotate
> them at the target systems.

### 9.2 Import removed

`"os"` is no longer needed.

### 9.3 Dead methods removed

| Method | Why |
|---|---|
| `CheckoutCredential` | One-line passthrough to `RevealCredential`. Zero callers. |
| `ListVaultEntries` | One-line passthrough to `ListCredentials`. Zero callers. |
| `GetDecryptedCredential` | Duplicated the decrypt path with its own hand-built AAD. Zero callers. (`ResourceService.GetDecryptedCredential` is a different method on a different type and is still in use.) |

Verified by grep across the whole module before deletion.

**Kept:** `PasswordChange` and `RevealCredential` — both called by `vault_handler.go`.
`DB()` and `KMS()` — called by `vault_handler.go` and `rotation_service.go`.

---

## 10. Configuration checklist

### 10.1 Required before production

```bash
# 32+ bytes. Changing it invalidates every issued service token.
PAM_VAULT_SERVICE_TOKEN_PEPPER="$(openssl rand -base64 48)"
```

Without it, `config.Load()` fails at startup in production. In development the process
starts and logs:

```
WARN  service_token.pepper.using_dev_derivation
      action=set PAM_VAULT_SERVICE_TOKEN_PEPPER (>= 32 bytes) before production
```

### 10.2 Optional

```bash
PAM_VAULT_DEFAULT_SECRET_TTL_SEC=300   # default 300; lower = safer + chattier
```

### 10.3 Already required, now enforced with no fallback

```bash
PAM_VAULT_ENCRYPTION_KEY="<base64 32-byte key>"
```

---

## 11. End-to-end operational flow

```bash
BASE=https://pam.internal:8443
ADMIN="Authorization: Bearer $ADMIN_JWT"

# 1. Register the machine identity (admin, JWT)
curl -X POST $BASE/api/v1/pam/admin/services -H "$ADMIN" -d '{
  "name": "billing-api-prod",
  "environment": "production",
  "max_secrets_per_minute": 600
}'

# 2. Grant a path scope (admin, JWT + MFA)
curl -X POST $BASE/api/v1/pam/admin/services/billing-api-prod/grants -H "$ADMIN" -d '{
  "scope": "prod-db/postgres/*",
  "reason": "billing settlement job needs the app writer credential",
  "max_ttl_seconds": 300,
  "expires_in_days": 90
}'

# 3. Mint a token (admin, JWT + MFA) — returned ONCE, never recoverable
curl -X POST $BASE/api/v1/pam/admin/services/billing-api-prod/tokens -H "$ADMIN" -d '{
  "description": "k8s billing-api deployment",
  "ttl_days": 90
}'
# → {"data":{"token":"pamsvc.<id>.<secret>", ...}}

# 4. Application reads a secret (service token)
curl $BASE/api/v1/pam/svc/secrets/prod-db/postgres/pg-app-writer?purpose=billing+settlement \
     -H "X-Service-Token: pamsvc.<id>.<secret>"
```

**Zero-downtime token rotation:** mint the new token (step 3 — the old one keeps working),
write it to `TokenFile`, roll the fleet or let the clients pick it up on their next 401,
then `DELETE /api/v1/pam/admin/service-tokens/<old_token_id>`. An identity may hold many
live tokens simultaneously, which is what makes the overlap possible.

**Incident response:** `POST /api/v1/pam/admin/services/<name>/disable` revokes every token
of that identity in a single statement and flushes the principal cache. Worst-case
propagation to other instances is the 30 s principal-cache TTL.

---

## 12. Requirements traceability

| Requirement | Where it is satisfied |
|---|---|
| Vault authentication | `ServiceIdentityService.Authenticate` — PK lookup + constant-time HMAC compare, 30 s principal cache, 5 s negative cache. Client side: `X-Service-Token`, shape-validated at construction. |
| Secure credential retrieval | `GET /api/v1/pam/svc/secrets/*path`, path-scoped grant check, envelope decrypt with explicit AAD, `Cache-Control: no-store`, `Referrer-Policy: no-referrer`. |
| Credential caching | Two-deadline model, §6.2. Server-authoritative TTL; client only shortens. |
| Credential reuse | `Get()` is a map lookup on the hot path. Designed to be called on every use. |
| Token/session lifecycle | Many live tokens per identity; finite default TTL (90 d); `TokenFile` reload on 401; `DisableIdentity` mass revoke; `last_used_at` coalesced to ≤ 1 write/token/minute. |
| Error handling & retries | Typed errors; exponential backoff with full jitter; only network/429/5xx retried; caller cancellation never retried. |
| Secret rotation/refresh | Server clamps TTL to `rotation − 2min`; `RotatesAt` returned to the client; background refresh at 75 % of TTL; `Version` field lets callers detect a rotation without diffing plaintexts. |
| Concurrency safety | `RWMutex` cache, per-key singleflight, `refreshing` flag, per-client RNG, detached refresh context. All verified under `-race`. |
| Avoid unnecessary Vault calls | Read-driven refresh only (no timer loop); request coalescing; 30 s principal cache; 30 s grant cache; coalesced `last_used_at` writes; single JOIN query resolves credential + safe + folder in one round trip. |
| Never log secrets/tokens | `String`/`GoString`/`MarshalJSON` redaction; no token in any log line; error strings never echo response bodies; per-cache-hit `Info` logging removed. |
| Avoid storing sensitive values in memory | Bounded cache (512), janitor eviction, `Close()` drop, no-cache on TTL ≤ 0. Limitation documented honestly. |
| Least privilege | SDK is GET-only against two read endpoints; path-scoped grants with per-grant TTL caps; most-specific-grant-wins so a broad grant cannot relax a narrow one. |
| Handle Vault tokens securely | HMAC-only storage with a separate pepper; token never persisted or logged; own mutex; three-source resolution. |
| Auth failures & expired credentials | Indistinguishable 401 for unknown/expired/revoked/bad-secret (no enumeration oracle); `TokenFile` reload; evict-on-403; fail-closed 503 on infrastructure error, distinguishable in monitoring. |
| No hardcoded credentials/config | Master key literal deleted; pepper from config (derived, not literal, in dev); default TTL from config. |
| Idiomatic, maintainable Go | Passes `go vet` and `gofmt`; no new dependencies; typed sentinel errors; single AAD accessor; behavioural tests. |
| Remove unnecessary code | 2 model files, 3 service methods, 1 dead route block, 4 duplicated AAD constructions, 1 useless refresh loop. |

---

## 13. Known gaps

### 13.1 Postman collection is stale — not updated

`PAM_Vault_Secret_Access.postman_collection.json` targets `/api/v1/vault/secrets/...`,
which **never existed** on this server, plus several admin endpoints that were never
implemented (`/reports/service-usage`, `/credentials/:id/access-history`).

It needs restructuring, not URL substitution:

| Collection request | Reality |
|---|---|
| `POST /api/v1/vault/secrets/{name}` | `GET /api/v1/pam/svc/secrets/*path?purpose=…` |
| `GET /api/v1/vault/secrets/resource/{id}` | `GET /api/v1/pam/svc/resources/{id}/secrets?purpose=…` |
| `POST /admin/services` *(creates a token)* | now **two** calls: create identity, then mint token |
| `POST /admin/services/{id}/credentials/{cid}` | `POST /admin/services/{service}/grants` with a `scope` body |
| `DELETE /admin/services/{service_id}` | `DELETE /admin/service-tokens/{token_id}` |
| `/admin/reports/service-usage`, `/admin/credentials/{id}/access-history` | do not exist |

I left it untouched rather than guessing at endpoints that were never built. It can be
regenerated against the real routes on request.

### 13.2 Pre-existing, out of scope

- `internal/api/handlers/vault_handler.go` has four unused passthrough handlers
  (`Checkout`, `StoreEntry`, `ListEntries`, `Rotate`) with no routes. Harmless; left alone.
- `config.IAMConfig` is entirely dead configuration, retained deliberately so deployments
  with old `PAM_IAM_*` env vars still start (documented in that file).

---

## 14. Change statistics

```
 cmd/pam-api/main.go                          |  90 ++++++++--   (wiring, migrations, routes)
 internal/config/config.go                    |  33 ++++-        (2 settings + validation)
 internal/models/vault.go                     |  34 ++++         (EncryptionAAD + SafeID fix)
 internal/services/vault_service.go           | 105 +++------     (key, AAD, dead code)
 internal/services/secret_access_service.go   |  ~40 +/-         (compile fix, TTL, AAD)
 internal/api/handlers/service_identity_handler.go |  2 +/-      (doc comments)
 pkg/vaultclient/client.go                    | full rewrite     (942 lines)
 pkg/vaultclient/client_test.go               | new              (344 lines)
 internal/models/service_token.go             | DELETED
 internal/models/service_credential.go        | DELETED
```

| Category | Count |
|---|---|
| Compile errors fixed | 4 |
| Latent correctness bugs fixed | 2 (AAD/`SafeID`, map write under `RLock`) |
| Security issues fixed | 4 (hardcoded key, plaintext token model, no redaction, `ServiceAuth` misplacement) |
| Files deleted | 2 |
| Files rewritten | 1 |
| Files created | 2 |
| Files modified | 6 |
| New third-party dependencies | **0** |
