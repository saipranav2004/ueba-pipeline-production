# MFA recovery — backup codes that work, and an admin reset

Closes the two gaps I flagged before you switch any rule to `enforce`.
**Apply this on top of the role-gated MFA enforcement zip** — it edits three
files from that change (`auth_service.go`, `auth_handler.go`,
`mfa_policy_handler.go`, `main.go`).

```
backend/internal/services/auth_service.go         EDIT  backup codes: hashed, verified, single-use
backend/internal/services/mfa_admin.go            NEW   administrative MFA reset
backend/internal/services/mfa_recovery_test.go    NEW   18 cases over both
backend/internal/api/handlers/auth_handler.go     EDIT  regenerate endpoint, remaining count
backend/internal/api/handlers/mfa_policy_handler.go EDIT reset handler
backend/cmd/pam-api/main.go                       EDIT  2 routes

frontend/src/api/auth.js                          EDIT  regenerateBackupCodes()
frontend/src/api/identity.js                      EDIT  resetUserMfa()
frontend/src/pages/auth/MfaVerifyPage.jsx         EDIT  warn when a code is spent
frontend/src/components/auth/MfaEnrollment.jsx    EDIT  "New backup codes"
frontend/src/pages/admin/IdentityDetailPage.jsx   EDIT  Security → Reset MFA
```

---

## Gap 1 — backup codes

**What was wrong.** Ten codes were generated at enrolment, shown once, and
written to `pam_mfa_devices.backup_codes_hash` as a **plain JSON array** —
unhashed, despite the column name and the model's own comment saying
"Argon2-hashed". The code even said so: `// simplified; hash each in
production`. And nothing ever read them back — `VerifyMFA` only validated
TOTP. They were decoration with a plaintext-secret footprint.

The console has offered a "Use a recovery code" field on the MFA screen this
whole time. It was sending codes the server silently ignored.

**Now:**

- **Hashed at rest** with the same Argon2id used for passwords.
- **Actually verified** at sign-in.
- **Single use** — a code is removed from the stored set the moment it works,
  inside a `SELECT … FOR UPDATE` transaction so two simultaneous logins cannot
  both spend the same one.
- **Counted** — `/auth/me` reports `backup_codes_remaining`, and the login
  toast says how many are left ("Signed in with a backup code — 4 left").
- **Regenerable** — `POST /auth/mfa/backup-codes/regenerate`, behind
  `RequireMFA` so only a session that actually presented a second factor can
  mint new recovery material. Exposed as **New backup codes** in Settings.
  Single-use codes are exhaustible, so this is not optional.

Two decisions worth knowing:

**Shape-based routing.** A 6-digit input is tried as TOTP only; a 10-hex-char
input as a backup code only. Trying both would mean up to ten Argon2
comparisons on every mistyped TOTP — a free CPU-exhaustion lever.

**Legacy plaintext is still accepted**, in constant time, and the whole set is
rewritten as hashes the first time a code is spent. Rejecting it would have
silently voided the recovery codes of every user who enrolled before this
change.

**Also fixed while in there:** a wrong TOTP now counts toward the same account
lockout a wrong password does. Without it the second-factor step was an
unlimited online guessing oracle against a six-digit space.

## Gap 2 — administrative MFA reset

`POST /api/v1/pam/admin/identity/users/:id/reset-mfa` (reason required).

Removes every authenticator on the account and nothing else. It does **not**
enrol a new factor and hands the operator nothing they could sign in with —
the target is password-only afterwards, and if a policy rule gates their role
they land straight in the enrolment interrupt at the next sign-in. That
restraint is what keeps this from being an account-takeover primitive.

**Authorisation** (pure function `CanResetMFA`, fully tested):

| Target | Who may reset |
|---|---|
| holds `root` | root only |
| holds `admin` | root only |
| protected account | root only |
| anyone else | admin or root |

The asymmetry is the point: resetting an administrator's second factor is a
privileged downgrade, so it sits at the same level as granting admin in the
first place. It is not a full takeover on its own — the password is still
required — but "attacker with a stolen admin password" is exactly what the
second factor is for.

Fails **closed** if the target's roles can't be resolved. Logged at `Warn` with
actor, target, device count and reason.

**In the console:** Identity → account → **Security → Multi-factor
authentication → Reset MFA**, with a required reason. Disabled with an
explanation for a non-root admin looking at a privileged account.

---

## Verification

- `go build ./...`, `go vet ./...` clean; `go test ./...` passes with **18 new
  cases** — code shape routing, normalisation (dashes/spaces/caps), *no
  plaintext in the stored blob*, hashed match, legacy-plaintext match,
  unreadable input, and the full 13-row reset authorisation table
- `npm run lint` clean (same 4 pre-existing), `npm run build` passes

## One thing I did not do

**Session revocation on reset.** Entra kills active sessions when an admin
resets MFA. `AuthService.Logout` is currently a log line with a `// In
production: revoke the JTI in Redis` note, so there is no revocation machinery
to call — a reset does not end sessions the target already holds. Worth doing
when token revocation lands; I did not want to fake it here.
