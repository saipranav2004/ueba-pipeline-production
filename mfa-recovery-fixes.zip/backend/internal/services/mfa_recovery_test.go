package services

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/yourorg/pam/pkg/argon2"
	pamtotp "github.com/yourorg/pam/pkg/totp"
)

// ---------------------------------------------------------------------------
// Backup codes
// ---------------------------------------------------------------------------

func TestLooksLikeBackupCode(t *testing.T) {
	// Real generated codes must always route to the backup-code path.
	codes, err := pamtotp.GenerateBackupCodes()
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	for _, c := range codes {
		if !looksLikeBackupCode(c) {
			t.Fatalf("generated code %q must be recognised as a backup code", c)
		}
	}

	// TOTP codes must NOT — otherwise a mistyped 6-digit code would cost ten
	// Argon2 comparisons per attempt.
	for _, c := range []string{"000000", "123456", "12345", "1234567"} {
		if looksLikeBackupCode(c) {
			t.Fatalf("%q is a TOTP-shaped input and must not route to backup codes", c)
		}
	}

	// Cosmetics people actually type.
	for _, c := range []string{"AABBCCDDEE", "aabb-ccdd-ee", " aabbccddee ", "aabb ccdd ee"} {
		if !looksLikeBackupCode(c) {
			t.Fatalf("%q should normalise to a valid backup code", c)
		}
	}

	// Not hex, right length.
	for _, c := range []string{"zzzzzzzzzz", "aabbccddeg", "", "----------"} {
		if looksLikeBackupCode(c) {
			t.Fatalf("%q must be rejected", c)
		}
	}
}

func TestNormalizeBackupCode(t *testing.T) {
	want := "aabbccddee"
	for _, in := range []string{"AABBCCDDEE", "aabb-ccdd-ee", "  aabbccddee  ", "AA BB CC DD EE", "aabb\tccddee"} {
		if got := normalizeBackupCode(in); got != want {
			t.Fatalf("normalize(%q) = %q, want %q", in, got, want)
		}
	}
}

// The column is called backup_codes_hash. It must actually contain hashes —
// it previously contained the plaintext codes.
func TestHashBackupCodes_StoresNoPlaintext(t *testing.T) {
	codes := []string{"aabbccddee", "0011223344"}
	blob, err := hashBackupCodes(codes)
	if err != nil {
		t.Fatalf("hash: %v", err)
	}
	for _, c := range codes {
		if strings.Contains(blob, c) {
			t.Fatalf("plaintext code %q must not appear in the stored blob", c)
		}
	}

	var entries []string
	if err := json.Unmarshal([]byte(blob), &entries); err != nil {
		t.Fatalf("stored blob must be a JSON array: %v", err)
	}
	if len(entries) != len(codes) {
		t.Fatalf("expected %d entries, got %d", len(codes), len(entries))
	}
	for _, e := range entries {
		if !strings.HasPrefix(e, "$argon2") {
			t.Fatalf("entry %q is not an Argon2 PHC string", e)
		}
	}
}

func TestMatchesBackupEntry_Hashed(t *testing.T) {
	hash, err := argon2.Hash("aabbccddee")
	if err != nil {
		t.Fatalf("hash: %v", err)
	}
	if !matchesBackupEntry(hash, "aabbccddee") {
		t.Fatal("the correct code must match its hash")
	}
	if matchesBackupEntry(hash, "aabbccddef") {
		t.Fatal("a different code must not match")
	}
	if matchesBackupEntry(hash, "") {
		t.Fatal("an empty code must not match")
	}
}

// Installs that enrolled before this change hold PLAINTEXT codes. Refusing
// them would silently void every existing user's recovery codes.
func TestMatchesBackupEntry_LegacyPlaintext(t *testing.T) {
	if !matchesBackupEntry("aabbccddee", "aabbccddee") {
		t.Fatal("a legacy plaintext entry must still be accepted")
	}
	if !matchesBackupEntry("AABBCCDDEE", normalizeBackupCode("aabb-ccdd-ee")) {
		t.Fatal("legacy comparison must normalise both sides")
	}
	if matchesBackupEntry("aabbccddee", "0011223344") {
		t.Fatal("a wrong code must not match a legacy entry")
	}
}

func TestDecodeBackupCodes(t *testing.T) {
	blob := `["$argon2id$v=19$a","$argon2id$v=19$b"]`
	if got := decodeBackupCodes(&blob); len(got) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(got))
	}
	empty := ""
	garbage := "not json"
	for _, in := range []*string{nil, &empty, &garbage} {
		if got := decodeBackupCodes(in); got != nil && len(got) != 0 {
			t.Fatalf("unreadable input must yield no codes, got %v", got)
		}
	}
}

// ---------------------------------------------------------------------------
// Administrative MFA reset — the authorisation table
// ---------------------------------------------------------------------------

func TestCanResetMFA(t *testing.T) {
	root := []string{"root"}
	admin := []string{"admin"}
	user := []string{"user"}
	none := []string{}

	cases := []struct {
		name      string
		actor     []string
		target    []string
		protected bool
		want      bool
	}{
		{"root resets ordinary user", root, user, false, true},
		{"admin resets ordinary user", admin, user, false, true},
		{"root resets an admin", root, admin, false, true},
		{"admin CANNOT reset an admin", admin, admin, false, false},
		{"root resets root", root, root, false, true},
		{"admin CANNOT reset root", admin, root, false, false},
		{"root resets a protected account", root, user, true, true},
		{"admin CANNOT reset a protected account", admin, user, true, false},
		{"ordinary user can reset nobody", user, user, false, false},
		{"no roles can reset nobody", none, user, false, false},
		{"target with no roles is ordinary", admin, none, false, true},
		{"casing is irrelevant", []string{"ROOT"}, []string{"Admin"}, false, true},
		{"admin blocked on mixed-case admin target", admin, []string{"ADMIN"}, false, false},
	}

	for _, tc := range cases {
		if got := CanResetMFA(tc.actor, tc.target, tc.protected); got != tc.want {
			t.Errorf("%s: CanResetMFA(%v, %v, %v) = %v, want %v",
				tc.name, tc.actor, tc.target, tc.protected, got, tc.want)
		}
	}
}

// A user holding both admin and a custom role is still an admin target.
func TestCanResetMFA_MultiRoleTarget(t *testing.T) {
	if CanResetMFA([]string{"admin"}, []string{"auditor", "admin"}, false) {
		t.Fatal("a second, ordinary role must not launder an admin target")
	}
	if !CanResetMFA([]string{"root"}, []string{"auditor", "admin"}, false) {
		t.Fatal("root must still be able to reset it")
	}
}
