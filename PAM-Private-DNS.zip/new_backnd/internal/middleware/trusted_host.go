// pam/internal/middleware/trusted_host.go
//
// Host validation — "this console answers to its own name and nothing else",
// enforced in the request path before any handler runs.
//
// ── What replaced what, and why they are not the same control ─────────────
//
// This used to be a source-IP allowlist: a list of approved corporate CIDRs,
// checked against the client address on every request. That is the right
// control when the service is published and anyone can route to it, and the
// wrong one when the deployment is private, because it duplicates the
// network's own decision in the application and then drifts from it. An office
// moves, a VPN pool is resized, someone adds a branch, and the list in the
// environment is wrong until an outage teaches you.
//
// A private-DNS deployment puts the boundary somewhere better: the API has no
// public address at all, its name resolves only on the customer's internal
// resolvers, and the network refuses everything that is not inside. The
// firewall, the security group and the private endpoint make the decision,
// once, in the layer that can also protect the database and the object store.
//
// WHAT THAT LEAVES FOR THE APPLICATION is the half a network cannot do:
// making sure a request that DID arrive is addressed to us by name.
//
//	pam.corp.internal          the name the private zone publishes  ALLOW
//	10.4.2.17                  someone who found the private IP     DENY
//	pam.attacker.example       DNS rebinding, resolving to our IP   DENY
//	evil.com (Host header)     poisoning any URL we build           DENY
//
// The last two are the ones that matter and the ones a network control cannot
// see. Rebinding is the classic way a browser on an internal machine is turned
// into a proxy into the private network: the page is served from an attacker's
// domain, its DNS record flips to an internal address, and the browser happily
// sends requests to us with the attacker's Host. And this process builds
// absolute URLs (server.public_url, the brokered proxy's launch links), so a
// Host it trusts blindly is a Host it will paste into a link and mail to
// somebody.
//
// ── Fail-closed, precisely ────────────────────────────────────────────────
//
//	no hosts configured, AllowAnyHost false  -> refuses to build (boot fails)
//	AllowAnyHost true                        -> disabled, logged loudly
//	Host missing or unparseable              -> DENY
//	Host matches nothing                     -> DENY
//	exempt path                              -> ALLOW, before any of the above
//
// The empty-list case is a boot failure rather than a deny-everything for the
// same reason it was before: a control that locks out the person who has to
// fix it should surface at deploy time, where it is cheap.
package middleware

import (
	"net"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// TrustedHostConfig is the host policy for one process.
type TrustedHostConfig struct {
	// Hosts are the names this console answers to, lowercased and without a
	// port. A leading dot is a subdomain wildcard: ".corp.internal" matches
	// "pam.corp.internal" and "vault.corp.internal" but NOT "corp.internal"
	// itself, which has to be listed separately if it is meant to work. That
	// asymmetry is deliberate: a wildcard that silently includes the apex is
	// how a parked marketing domain ends up serving a PAM console.
	Hosts []string

	// AllowAnyHost switches the check off. It exists for local development and
	// for the first boot of an install whose DNS name is not decided yet, and
	// config validation refuses it in production.
	AllowAnyHost bool

	// ExemptPaths bypass the check, matched exactly. The health endpoint
	// belongs here and almost nothing else: a load balancer probes by IP, not
	// by name, so an unexempted health check fails, the instance leaves the
	// pool, and the control causes the outage it was meant to prevent.
	ExemptPaths []string
}

// OnHostRejected is called for each refused request, for the audit trail.
type OnHostRejected func(host, sourceIP, path, userAgent string)

// TrustedHost builds the middleware. It returns an error rather than a
// disabled middleware when the configuration is unusable, so a bad deploy
// fails at boot instead of quietly serving to anybody.
func TrustedHost(cfg TrustedHostConfig, onRejected OnHostRejected, log *zap.Logger) (gin.HandlerFunc, error) {
	if cfg.AllowAnyHost {
		log.Warn("network.trusted_hosts.disabled",
			zap.String("effect", "this console answers to any name, including a raw IP address"),
			zap.String("enable_with", "PAM_NETWORK_TRUSTED_HOSTS=pam.your-domain.internal"))
		return func(c *gin.Context) { c.Next() }, nil
	}

	exact := make(map[string]struct{}, len(cfg.Hosts))
	var suffixes []string
	for _, raw := range cfg.Hosts {
		h := strings.ToLower(strings.TrimSpace(raw))
		if h == "" {
			continue
		}
		// A configured value may arrive with a port ("pam.corp.internal:8443")
		// because that is how people write a URL. The port is not part of the
		// identity, so it is dropped on both sides of the comparison.
		h = stripPort(h)
		if strings.HasPrefix(h, ".") {
			if len(h) > 1 {
				suffixes = append(suffixes, h)
			}
			continue
		}
		exact[h] = struct{}{}
	}

	if len(exact) == 0 && len(suffixes) == 0 {
		return nil, errNoTrustedHosts
	}

	exemptPaths := make(map[string]struct{}, len(cfg.ExemptPaths))
	for _, p := range cfg.ExemptPaths {
		if p = strings.TrimSpace(p); p != "" {
			exemptPaths[p] = struct{}{}
		}
	}

	log.Info("network.trusted_hosts.enabled",
		zap.Int("exact", len(exact)),
		zap.Int("wildcards", len(suffixes)),
		zap.String("meaning", "requests addressed to any other name are refused"))

	return func(c *gin.Context) {
		if _, ok := exemptPaths[c.Request.URL.Path]; ok {
			c.Next()
			return
		}

		host := stripPort(strings.ToLower(strings.TrimSpace(c.Request.Host)))
		if host != "" && hostAllowed(host, exact, suffixes) {
			c.Next()
			return
		}

		if onRejected != nil {
			onRejected(c.Request.Host, c.ClientIP(), c.Request.URL.Path, c.Request.UserAgent())
		}

		// 421 is the honest status: the request reached a server that is not
		// authoritative for the name it asked for. It also tells a browser not
		// to reuse this connection for that name, which is exactly right for a
		// rebinding attempt. The body names nothing about the deployment.
		c.AbortWithStatusJSON(http.StatusMisdirectedRequest, gin.H{
			"success": false,
			"message": "This server does not serve the requested host.",
			"error":   gin.H{"code": "host_not_recognised"},
		})
	}, nil
}

func hostAllowed(host string, exact map[string]struct{}, suffixes []string) bool {
	if _, ok := exact[host]; ok {
		return true
	}
	for _, s := range suffixes {
		// ".corp.internal" matches "pam.corp.internal" and deliberately not
		// "corp.internal" or "notcorp.internal".
		if strings.HasSuffix(host, s) && len(host) > len(s) {
			return true
		}
	}
	return false
}

// stripPort removes a trailing :port from a host, leaving IPv6 literals
// intact. net.SplitHostPort fails on a bare host, which is the common case, so
// the error is the signal to keep what we were given.
func stripPort(host string) string {
	if host == "" {
		return ""
	}
	if h, _, err := net.SplitHostPort(host); err == nil {
		return strings.Trim(h, "[]")
	}
	return strings.Trim(host, "[]")
}

type trustedHostError string

func (e trustedHostError) Error() string { return string(e) }

const errNoTrustedHosts = trustedHostError(
	"network.trusted_hosts is empty and network.allow_any_host is false: " +
		"name the host this console answers to (PAM_NETWORK_TRUSTED_HOSTS), " +
		"or set PAM_NETWORK_ALLOW_ANY_HOST=true outside production")
