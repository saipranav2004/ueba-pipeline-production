package config

import (
	"strings"
	"testing"
)

// A complete production config, so each test below changes exactly one thing.
func prodBase() *Config {
	c := &Config{}
	c.Server.Env = "production"
	c.Server.AllowedOrigins = "https://pam.corp.internal"
	c.Server.PublicURL = "https://pam.corp.internal"
	c.Database.Host = "db.internal"
	c.Database.Name = "pam"
	c.JWT.SecretKey = "a-jwt-secret-that-is-long-enough-for-tests"
	c.Vault.EncryptionKey = "MRj5waDrH+pH1/lruVNZYtXp+wzzb7YNbMnB6NLN2N8="
	c.Audit.HMACSecret = strings.Repeat("x", 32)
	c.Network.TrustedProxies = "10.0.0.0/8"
	c.Network.TrustedHosts = "pam.corp.internal"
	return c
}

// Session recordings are keystroke logs of privileged sessions. Sending them
// to an object store in plaintext is the loudest contradiction of a "nobody
// outside can reach this" requirement, so production refuses to start.
func TestPlaintextObjectStoreIsRefusedInProduction(t *testing.T) {
	c := prodBase()
	c.Recording.Backend = "minio"
	c.S3.Endpoint = "13.206.221.6:9000"
	c.S3.Bucket, c.S3.AccessKey, c.S3.SecretKey = "recordings", "k", "s"
	c.S3.UseSSL = false

	err := c.validate()
	if err == nil {
		t.Fatal("plaintext object store must be refused in production")
	}
	if !strings.Contains(err.Error(), "PAM_S3_USE_SSL") {
		t.Fatalf("the error must name the setting, got %q", err)
	}

	c.S3.UseSSL = true
	if err := c.validate(); err != nil {
		t.Fatalf("TLS on the object store must boot: %v", err)
	}
}

// A sidecar on the loopback interface has no wire to be on. Requiring a
// certificate for it would push people into disabling the check globally,
// which is worse than the thing it protects against.
func TestLoopbackObjectStoreIsExempt(t *testing.T) {
	for _, endpoint := range []string{"127.0.0.1:9000", "localhost:9000", "[::1]:9000", "http://127.0.0.1:9000"} {
		c := prodBase()
		c.Recording.Backend = "minio"
		c.S3.Endpoint = endpoint
		c.S3.Bucket, c.S3.AccessKey, c.S3.SecretKey = "recordings", "k", "s"
		c.S3.UseSSL = false
		if err := c.validate(); err != nil {
			t.Errorf("%s must be exempt: %v", endpoint, err)
		}
	}
}

// And the exemption must not be a hole: a public address is not loopback
// however much it looks like one at a glance.
func TestNonLoopbackLooksLikeItButIsNot(t *testing.T) {
	for _, endpoint := range []string{"127.0.0.1.evil.com:9000", "10.0.0.1:9000", "notlocalhost:9000"} {
		if isLoopbackEndpoint(endpoint) {
			t.Errorf("%s must not count as loopback", endpoint)
		}
	}
}

func TestWildcardOriginIsRefusedInProduction(t *testing.T) {
	c := prodBase()
	c.Server.AllowedOrigins = "*"
	err := c.validate()
	if err == nil {
		t.Fatal("a wildcard origin must be refused in production")
	}
	if !strings.Contains(err.Error(), "PAM_SERVER_ALLOWED_ORIGINS") {
		t.Fatalf("the error must name the setting, got %q", err)
	}
}

// The default is not a harmless placeholder: agent enrolment links are built
// from it, so it produces URLs pointing at the operator's own laptop.
func TestLocalhostPublicURLIsRefusedInProduction(t *testing.T) {
	for _, bad := range []string{"", "http://localhost:8080", "http://127.0.0.1:8080"} {
		c := prodBase()
		c.Server.PublicURL = bad
		if err := c.validate(); err == nil {
			t.Errorf("public_url %q must be refused in production", bad)
		}
	}
}

// None of this applies to a laptop.
func TestDevelopmentIsUnaffected(t *testing.T) {
	c := prodBase()
	c.Server.Env = "development"
	c.Server.AllowedOrigins = "*"
	c.Server.PublicURL = "http://localhost:8080"
	c.Recording.Backend = "minio"
	c.S3.Endpoint = "13.206.221.6:9000"
	c.S3.Bucket, c.S3.AccessKey, c.S3.SecretKey = "recordings", "k", "s"
	c.S3.UseSSL = false
	if err := c.validate(); err != nil {
		t.Fatalf("development must not be gated: %v", err)
	}
}
