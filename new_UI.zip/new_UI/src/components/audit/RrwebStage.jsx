import { useEffect, useRef, useState } from 'react'
import 'rrweb/dist/style.css'

// ---------------------------------------------------------------------------
// Visual session replay stage
// ---------------------------------------------------------------------------
// The screen half of a brokered web session: rrweb events replayed into a
// sandboxed iframe, so the auditor watches the actual console the operator
// saw — the DOM, the CSS, the cursor, the dialogs — rather than reading a list
// of the requests it made.
//
// WHY THIS OWNS THE CLOCK, and the viewer's own clock does not.
// SessionRecordingViewer drives its terminal replay from a 10Hz interval that
// advances `t` by elapsed time × speed. Pointing that at rrweb would mean
// seeking the Replayer ten times a second, which is both expensive and visibly
// janky (each seek rebuilds DOM state). rrweb already has a correct internal
// clock, so while a visual recording is playing the Replayer runs it and this
// component reports progress UP to the viewer, which keeps the shared scrubber
// and the command log in sync. The direction of control inverts for exactly
// one format, and only while playing.
//
// SEEKING is therefore explicit rather than inferred from `t`: a `seekToken`
// that changes identity is the signal to jump, because `t` itself is changing
// constantly as a RESULT of playback and cannot distinguish "the clock moved"
// from "the operator dragged the scrubber".
//
// FIDELITY CAVEATS, stated because an auditor should know what they are and
// are not looking at. Stylesheets are inlined at capture time so layout and
// colour are faithful. Images referenced by URL are NOT: the proxy subdomain
// they were served from is gone by replay time, so they render as broken.
// Canvas and WebGL content is not captured (recordCanvas is off, for size).
// Nothing here is re-rendered from a screenshot — it is the real DOM, which is
// why it is faithful in the ways that matter and blank in the ways it isn't.

// rrweb ships its recorder and its Replayer in one bundle. Loaded lazily so
// the ~260KB never lands on a route that is not replaying a visual session.
let replayerModule = null
async function loadReplayer() {
  if (!replayerModule) {
    replayerModule = await import('rrweb')
  }
  return replayerModule
}

export function RrwebStage({
  events,
  playing,
  speed,
  seekToken,
  seekTo,
  onProgress,
  onDuration,
  onError,
}) {
  const hostRef = useRef(null)
  const replayerRef = useRef(null)
  const [ready, setReady] = useState(false)
  const [failure, setFailure] = useState(null)

  // Build the Replayer once per event stream.
  useEffect(() => {
    if (!hostRef.current || !Array.isArray(events) || events.length < 2) return undefined

    let disposed = false
    let instance = null

    ;(async () => {
      try {
        const rrweb = await loadReplayer()
        if (disposed || !hostRef.current) return

        hostRef.current.innerHTML = ''
        instance = new rrweb.Replayer(events, {
          root: hostRef.current,
          // The viewer supplies play/pause/seek/speed, so rrweb's own UI would
          // be a second, conflicting set of controls in the same dialog.
          speed,
          skipInactive: false,
          showWarning: false,
          showDebug: false,
          // An auditor is watching, not interacting: a replay that responds to
          // clicks would let them mutate what they are meant to be reviewing.
          mouseTail: { strokeStyle: '#38bdf8', lineWidth: 2 },
          blockClass: 'pam-block',
        })

        replayerRef.current = instance
        setReady(true)

        const meta = instance.getMetaData?.()
        if (meta && Number.isFinite(meta.totalTime) && meta.totalTime > 0) {
          onDuration?.(meta.totalTime / 1000)
        }
      } catch (err) {
        if (disposed) return
        const message =
          err?.message || 'The visual replay engine could not be loaded (is the rrweb package installed?)'
        setFailure(message)
        onError?.(message)
      }
    })()

    return () => {
      disposed = true
      try {
        instance?.pause()
        instance?.destroy?.()
      } catch {
        /* teardown of a half-built replayer is not worth reporting */
      }
      replayerRef.current = null
      setReady(false)
    }
    // onDuration/onError are intentionally excluded: they are reported once per
    // stream, and including them would rebuild the Replayer on every render of
    // a parent that passes inline callbacks.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [events])

  // Speed is a live setting, not a reason to rebuild.
  useEffect(() => {
    const r = replayerRef.current
    if (!r || !ready) return
    try {
      r.setConfig({ speed })
    } catch {
      /* ignore */
    }
  }, [speed, ready])

  // Play / pause. rrweb's play(offset) resumes from an absolute offset, so the
  // viewer's current position is passed through rather than assumed to be
  // wherever the Replayer happened to stop.
  useEffect(() => {
    const r = replayerRef.current
    if (!r || !ready) return
    try {
      if (playing) r.play(Math.max(0, (seekTo || 0) * 1000))
      else r.pause()
    } catch {
      /* ignore */
    }
    // seekTo is deliberately NOT a dependency: it changes continuously during
    // playback and would restart the replay on every tick. Jumps arrive via
    // seekToken below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, ready])

  // An explicit seek. pause-then-play keeps rrweb's state machine honest when
  // the operator scrubs while playing.
  useEffect(() => {
    const r = replayerRef.current
    if (!r || !ready || seekToken == null) return
    const ms = Math.max(0, (seekTo || 0) * 1000)
    try {
      if (playing) r.play(ms)
      else r.pause(ms)
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seekToken, ready])

  // Report progress up so the shared scrubber and the command log track the
  // replay. 10Hz to match the viewer's own cadence for terminal recordings, so
  // both formats feel identical to use.
  useEffect(() => {
    if (!ready || !playing) return undefined
    const id = setInterval(() => {
      const r = replayerRef.current
      if (!r) return
      try {
        const ms = r.getCurrentTime?.()
        if (Number.isFinite(ms)) onProgress?.(ms / 1000)
      } catch {
        /* ignore */
      }
    }, 100)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, playing])

  if (failure) {
    return (
      <div className="flex h-full items-center justify-center px-6">
        <div className="max-w-md text-center">
          <p className="text-sm font-semibold text-red-300">Visual replay unavailable</p>
          <p className="mt-1.5 text-xs leading-relaxed text-ink-500">{failure}</p>
          <p className="mt-3 text-xs leading-relaxed text-ink-500">
            The request transcript for this session is still available on the Requests tab.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-full w-full overflow-auto bg-[#0b0e13]">
      {/* rrweb sizes its iframe to the recorded viewport, which is usually
          wider than this pane. Scaling the whole stage down keeps the full
          screen visible instead of cropping it, and origin-top-left stops it
          drifting away from the corner as it shrinks. */}
      <div ref={hostRef} className="pam-rrweb-stage origin-top-left" />
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-xs text-ink-500">Preparing visual replay…</p>
        </div>
      )}
    </div>
  )
}
