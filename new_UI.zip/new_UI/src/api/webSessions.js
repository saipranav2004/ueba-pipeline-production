import { http } from '../lib/http'

// ---------------------------------------------------------------------------
// Brokered web sessions (/api/v1/pam/resources/:id/web-session, /web-sessions/*)
// ---------------------------------------------------------------------------
// The third connect method, alongside the tracked session and the native
// agent. PAM logs into the target's own web console SERVER-SIDE and then
// reverse-proxies it, so the operator lands in the application already
// authenticated and the credential never reaches their browser at all.
//
// That is the whole point, and it is what makes this different from the plain
// "Open console" link: that link opens the app's own login page and leaves the
// operator to authenticate themselves — no PAM session binding, no activity
// trail, no kill switch, and a credential they now know.

// Starts the session. The response carries TWO urls and they are not
// interchangeable:
//
//   launch_url  single-use, short-lived (handoff_expires_at, ~30s). Visiting
//               it exchanges the handoff token for an HttpOnly cookie scoped
//               to the app's own subdomain and redirects to app_url. This is
//               the one to navigate to, and it must be used immediately.
//   app_url     the session's home once that cookie exists. Navigating here
//               without the cookie just shows "not signed in".
//
// So a caller must not, for example, stash launch_url to reopen later: it is
// spent on first use and expired seconds after issue.
export async function startWebSession(resourceId) {
  const { data } = await http.post(`/api/v1/pam/resources/${resourceId}/web-session`)
  return data.data // { web_proxy_session_id, session_id, launch_url, app_url, auth_strategy, expires_at, handoff_expires_at }
}

// The caller's own live brokered sessions, each with an app_url to re-enter it.
export async function listMyWebSessions(signal) {
  const { data } = await http.get('/api/v1/pam/web-sessions/mine', { signal })
  return data.data.sessions || []
}

// Ends one of the caller's own sessions. Ownership-checked server-side; ending
// someone else's comes back as 404 rather than 403, by design.
export async function endWebSession(webProxySessionId) {
  const { data } = await http.post(`/api/v1/pam/web-sessions/${webProxySessionId}/end`)
  return data.data
}
