// pam/internal/services/root_authority_test.go
//
// Root's classification has two halves, and only one of them lives in the
// scorer. These pin the other half, the parts that only fail against a
// database:
//
//  1. The seed attaches full-access to root on an install that ALREADY
//     exists. This is the half that decides whether a running deployment
//     picks the fix up on restart or stays broken forever. The bundle edit
//     is worth nothing if the seeder only wires attachments for rows it
//     created itself, and reading the seeder is not proof that it does not.
//
//  2. An override on root is refused before anything is written. The scorer
//     does not consult overrides for root, so an override that were accepted
//     would be stored, audited, answered with 200, and then ignored.
package services

import (
	"context"
	"errors"
	"testing"

	"github.com/glebarez/sqlite"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

func rootAuthorityDB(t *testing.T) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open in-memory sqlite: %v", err)
	}
	if err := db.AutoMigrate(
		&models.Role{}, &models.Policy{}, &models.RolePolicy{},
		&models.UserRole{}, &models.UserPolicy{}, &models.PAMResource{},
		&models.RoleCriticalityOverride{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func attachedPolicyNames(t *testing.T, db *gorm.DB, roleName string) []string {
	t.Helper()
	var role models.Role
	if err := db.Where("name = ?", roleName).First(&role).Error; err != nil {
		t.Fatalf("role %q not seeded: %v", roleName, err)
	}
	var links []models.RolePolicy
	if err := db.Where("role_id = ?", role.ID).Find(&links).Error; err != nil {
		t.Fatalf("read role policies: %v", err)
	}
	out := make([]string, 0, len(links))
	for _, l := range links {
		var p models.Policy
		if err := db.Where("id = ?", l.PolicyID).First(&p).Error; err == nil {
			out = append(out, p.Name)
		}
	}
	return out
}

func hasName(list []string, want string) bool {
	for _, v := range list {
		if v == want {
			return true
		}
	}
	return false
}

// The scenario that produced the screenshot: an install seeded by an EARLIER
// build, where root exists, full-access exists, and the row joining them was
// never written because the old bundle attached full-access to admin only.
// Restarting on the new bundle has to repair that, without a migration and
// without touching anything the administrator has edited since.
func TestSeedAttachesFullAccessToRootOnAnAlreadySeededInstall(t *testing.T) {
	db := rootAuthorityDB(t)
	logger := zap.NewNop()

	// Stand up the old shape by hand: every seeded role and policy already
	// present, and root deliberately holding nothing.
	root := models.Role{Name: "root", Description: "Full system bypass.", IsSystem: true}
	admin := models.Role{Name: "admin", IsSystem: true}
	user := models.Role{Name: "user", IsSystem: true}
	for _, r := range []*models.Role{&root, &admin, &user} {
		if err := db.Create(r).Error; err != nil {
			t.Fatalf("pre-create role %q: %v", r.Name, err)
		}
	}
	full := models.Policy{
		Name: "full-access", Effect: "allow",
		Actions: []string{"*"}, Resources: []string{"*"}, IsSystem: true,
	}
	if err := db.Create(&full).Error; err != nil {
		t.Fatalf("pre-create full-access: %v", err)
	}
	if err := db.Create(&models.RolePolicy{RoleID: admin.ID, PolicyID: full.ID}).Error; err != nil {
		t.Fatalf("pre-attach full-access to admin: %v", err)
	}

	if got := attachedPolicyNames(t, db, "root"); len(got) != 0 {
		t.Fatalf("precondition: root should start with nothing attached, got %v", got)
	}

	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("seed: %v", err)
	}

	got := attachedPolicyNames(t, db, "root")
	if !hasName(got, "full-access") {
		t.Fatalf("root should hold full-access after a restart on the new bundle, got %v", got)
	}

	// Admin must not gain a duplicate row from the same pass.
	adminPolicies := attachedPolicyNames(t, db, "admin")
	n := 0
	for _, name := range adminPolicies {
		if name == "full-access" {
			n++
		}
	}
	if n != 1 {
		t.Fatalf("admin should hold full-access exactly once, got %d of %v", n, adminPolicies)
	}

	// And a second restart must stay idempotent.
	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("second seed: %v", err)
	}
	again := attachedPolicyNames(t, db, "root")
	if len(again) != len(got) {
		t.Fatalf("a second restart changed root's attachments: %v then %v", got, again)
	}
}

func TestOverridingRootIsRefusedAndWritesNothing(t *testing.T) {
	db := rootAuthorityDB(t)
	svc := NewRoleCriticalityService(db, nil, zap.NewNop())
	if err := svc.Migrate(); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	root := models.Role{Name: "root", IsSystem: true}
	if err := db.Create(&root).Error; err != nil {
		t.Fatalf("create root: %v", err)
	}

	_, err := svc.SetOverride(context.Background(), SetOverrideInput{
		RoleID: root.ID, Band: "LOW",
		Reason:    "trying to talk the classifier down from the one role that bypasses it",
		ActorID:   "u-1",
		ActorName: "das_admin",
	})
	if !errors.Is(err, ErrRootNotOverridable) {
		t.Fatalf("expected ErrRootNotOverridable, got %v", err)
	}

	var n int64
	if err := db.Model(&models.RoleCriticalityOverride{}).Where("role_id = ?", root.ID).Count(&n).Error; err != nil {
		t.Fatalf("count overrides: %v", err)
	}
	if n != 0 {
		t.Fatalf("a refused override must not leave a row behind, found %d", n)
	}

	// And the band the console reads is untouched.
	got, err := svc.Get(root.ID)
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if got.Band != models.BandCritical || got.IsOverridden {
		t.Fatalf("root should still be CRITICAL and un-overridden, got band=%s overridden=%v", got.Band, got.IsOverridden)
	}
}

// A custom role is unaffected: the refusal is scoped to root, not to overrides.
func TestOverridingAnOrdinaryRoleStillWorks(t *testing.T) {
	db := rootAuthorityDB(t)
	svc := NewRoleCriticalityService(db, nil, zap.NewNop())
	if err := svc.Migrate(); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	r := models.Role{Name: "reporting-readonly"}
	if err := db.Create(&r).Error; err != nil {
		t.Fatalf("create role: %v", err)
	}
	got, err := svc.SetOverride(context.Background(), SetOverrideInput{
		RoleID: r.ID, Band: "HIGH",
		Reason: "reaches the finance warehouse through a pattern the scorer cannot see",
	})
	if err != nil {
		t.Fatalf("override an ordinary role: %v", err)
	}
	if got.Band != models.CriticalityBand("HIGH") || !got.IsOverridden {
		t.Fatalf("expected an applied HIGH override, got band=%s overridden=%v", got.Band, got.IsOverridden)
	}
}
