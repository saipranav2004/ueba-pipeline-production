package middleware

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

// ---------------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------------
//
// The case that matters most here is TestPreflightAllowsAHeaderNotOnTheBaseline.
// This middleware previously carried a fixed allow-list, the console sends
// Idempotency-Key on POST /jit/requests, it was not on the list, and every
// cross-origin attempt to raise a JIT request failed with nothing in the
// browser naming the setting responsible. These tests exist so that cannot
// happen again for the next header either.

func corsRouter(allowed string, isProxy func(string) bool) *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(CORS(allowed, isProxy))
	r.POST("/api/v1/pam/jit/requests", func(c *gin.Context) { c.String(http.StatusOK, "ok") })
	r.GET("/anything", func(c *gin.Context) { c.String(http.StatusOK, "ok") })
	return r
}

func preflight(r *gin.Engine, path, origin, reqHeaders string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(http.MethodOptions, path, nil)
	req.Header.Set("Origin", origin)
	req.Header.Set("Access-Control-Request-Method", http.MethodPost)
	if reqHeaders != "" {
		req.Header.Set("Access-Control-Request-Headers", reqHeaders)
	}
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	return w
}

// THE REGRESSION.
func TestPreflightAllowsAHeaderNotOnTheBaseline(t *testing.T) {
	r := corsRouter("http://localhost:5173", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "http://localhost:5173",
		"content-type,idempotency-key")

	if w.Code != http.StatusNoContent {
		t.Fatalf("preflight status = %d, want 204", w.Code)
	}
	allow := strings.ToLower(w.Header().Get("Access-Control-Allow-Headers"))
	if !strings.Contains(allow, "idempotency-key") {
		t.Fatalf("Idempotency-Key is not allowed; the browser will refuse the request.\n"+
			"Allow-Headers = %q", allow)
	}
}

// A header nobody has thought of yet must also pass, or the fixed-list bug
// simply recurs under a different name.
func TestPreflightEchoesAnyRequestedHeader(t *testing.T) {
	r := corsRouter("http://localhost:5173", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "http://localhost:5173",
		"x-some-header-invented-tomorrow")

	allow := strings.ToLower(w.Header().Get("Access-Control-Allow-Headers"))
	if !strings.Contains(allow, "x-some-header-invented-tomorrow") {
		t.Fatalf("a requested header was not echoed: %q", allow)
	}
}

// Authorization must be present even when the preflight does not name it,
// because "*" would not have covered it and every authenticated call needs it.
func TestAuthorizationIsAlwaysAllowed(t *testing.T) {
	r := corsRouter("http://localhost:5173", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "http://localhost:5173", "")

	allow := strings.ToLower(w.Header().Get("Access-Control-Allow-Headers"))
	if !strings.Contains(allow, "authorization") {
		t.Fatalf("Authorization missing from Allow-Headers: %q", allow)
	}
}

// A brokered web-application host is a third-party app's response surface.
// Stamping PAM's CORS headers on it would corrupt that app's own contract and
// expose an authenticated session to every other origin.
func TestProxyHostsGetNoCORSHeadersAtAll(t *testing.T) {
	r := corsRouter("http://localhost:5173", func(string) bool { return true })

	req := httptest.NewRequest(http.MethodGet, "/anything", nil)
	req.Header.Set("Origin", "http://evil.example")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	for _, h := range []string{
		"Access-Control-Allow-Origin",
		"Access-Control-Allow-Headers",
		"Access-Control-Allow-Methods",
	} {
		if got := w.Header().Get(h); got != "" {
			t.Fatalf("%s was set on a proxied host (%q) — it must be left alone", h, got)
		}
	}
}

// Vary: Origin keeps a shared cache from serving one origin's allow header to
// another. Only meaningful when the allow-list is not "*".
func TestVaryOriginIsSetForANarrowedAllowList(t *testing.T) {
	narrow := corsRouter("https://console.example", nil)
	w := preflight(narrow, "/api/v1/pam/jit/requests", "https://console.example", "content-type")
	if !strings.Contains(w.Header().Get("Vary"), "Origin") {
		t.Fatal("Vary: Origin must be set when the allow-list names a specific origin")
	}

	wild := corsRouter("*", nil)
	w2 := preflight(wild, "/api/v1/pam/jit/requests", "https://anything.example", "content-type")
	if strings.Contains(w2.Header().Get("Vary"), "Origin") {
		t.Fatal("with \"*\" the response does not vary by origin")
	}
}

// The preflight must not reach the handler.
func TestPreflightShortCircuits(t *testing.T) {
	r := corsRouter("*", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "http://localhost:5173", "content-type")
	if w.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", w.Code)
	}
	if strings.Contains(w.Body.String(), "ok") {
		t.Fatal("the preflight was passed through to the handler")
	}
}

// An unset allow-list must behave as "*", so a deployment that forgets the
// variable gets a working console instead of a browser-side failure that
// looks like an outage.
func TestEmptyAllowListMeansWildcard(t *testing.T) {
	r := corsRouter("", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "https://anywhere.example", "content-type")
	if got := w.Header().Get("Access-Control-Allow-Origin"); got != "*" {
		t.Fatalf("Allow-Origin = %q, want *", got)
	}
}

// The mirror image of the Idempotency-Key bug, on the response side. The audit
// report download reads Content-Disposition for the server's filename; without
// this the export succeeds but silently loses its name, which nobody reports
// as a CORS problem because nothing visibly fails.
func TestContentDispositionIsReadableCrossOrigin(t *testing.T) {
	r := corsRouter("*", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "https://console.example", "content-type")

	expose := strings.ToLower(w.Header().Get("Access-Control-Expose-Headers"))
	if !strings.Contains(expose, "content-disposition") {
		t.Fatalf("Content-Disposition is not exposed, so the audit export cannot read "+
			"its filename cross-origin. Expose-Headers = %q", expose)
	}
}

// Allow-Credentials alongside "*" is rejected by every browser, and it is the
// one change that would make a wildcard origin genuinely dangerous — it is
// what lets a foreign page ride a cookie session. PAM uses Bearer tokens, so
// this must never appear.
func TestCredentialsAreNeverAllowed(t *testing.T) {
	for _, allow := range []string{"*", "https://console.example"} {
		r := corsRouter(allow, nil)
		w := preflight(r, "/api/v1/pam/jit/requests", "https://console.example", "content-type")
		if got := w.Header().Get("Access-Control-Allow-Credentials"); got != "" {
			t.Fatalf("Allow-Credentials = %q with origin %q — it must never be set", got, allow)
		}
	}
}

// Every verb PAM routes must survive a preflight.
func TestAllRoutedMethodsArePreflightable(t *testing.T) {
	r := corsRouter("*", nil)
	w := preflight(r, "/api/v1/pam/jit/requests", "https://console.example", "content-type")
	methods := strings.ToUpper(w.Header().Get("Access-Control-Allow-Methods"))
	for _, m := range []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"} {
		if !strings.Contains(methods, m) {
			t.Fatalf("%s missing from Allow-Methods: %q", m, methods)
		}
	}
}
