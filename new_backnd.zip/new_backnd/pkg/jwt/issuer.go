// pam/pkg/jwt/issuer.go
package jwt

import (
	"errors"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
)

var (
	ErrInvalidToken = errors.New("invalid token")
	ErrExpiredToken = errors.New("token expired")
)

// PAMClaims is the JWT claims structure for PAM-issued tokens.
type PAMClaims struct {
	jwt.RegisteredClaims
	Username    string   `json:"username"`
	Email       string   `json:"email"`
	AccountID   string   `json:"account_id,omitempty"`
	MFAVerified bool     `json:"mfa_verified"`
	Roles       []string `json:"roles"`

	// MFAEnrolmentRequired marks a session that exists ONLY so its owner can
	// enrol a second factor. Role-gated MFA policy said this account must hold
	// one and it does not, and the grace window (if any) has closed.
	//
	// It lives on the TOKEN rather than being re-derived per request for two
	// reasons: re-deriving costs a policy query on every call, and a claim is
	// the only version of this fact that curl cannot ignore. Middleware
	// refuses everything except the enrolment endpoints while it is set.
	MFAEnrolmentRequired bool `json:"mfa_enrolment_required,omitempty"`
}

// Issuer creates and verifies PAM JWTs.
type Issuer struct {
	secretKey      []byte
	issuer         string
	accessTTLMin   int
	refreshTTLDays int
}

// New creates a JWT issuer.
func New(secretKey, issuer string, accessTTLMin, refreshTTLDays int) *Issuer {
	return &Issuer{
		secretKey:      []byte(secretKey),
		issuer:         issuer,
		accessTTLMin:   accessTTLMin,
		refreshTTLDays: refreshTTLDays,
	}
}

// IssueAccessToken creates an HS256 access JWT for a PAM user.
// accountID is the tenant/account scope used by the hardened vault.
// IssueAccessToken mints an access token.
//
// enrolmentOnly restricts the session to MFA enrolment — see
// PAMClaims.MFAEnrolmentRequired. Callers that have nothing to do with the
// policy gate pass false.
func (i *Issuer) IssueAccessToken(userID, username, email, accountID string,
	mfaVerified bool, roles []string, sessionID string, enrolmentOnly bool) (string, string, time.Time, error) {
	now := time.Now()
	expiresAt := now.Add(time.Duration(i.accessTTLMin) * time.Minute)
	jti := uuid.NewString()

	claims := PAMClaims{
		RegisteredClaims: jwt.RegisteredClaims{
			Subject:   userID,
			ID:        jti,
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(expiresAt),
			NotBefore: jwt.NewNumericDate(now.Add(-30 * time.Second)),
			Issuer:    i.issuer,
			Audience:  []string{"pam"},
		},
		MFAEnrolmentRequired: enrolmentOnly,
		Username:             username,
		Email:                email,
		AccountID:            accountID,
		MFAVerified:          mfaVerified,
		Roles:                roles,
	}

	// Add session_id as a private claim via MapClaims override.
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	token.Header["sid"] = sessionID

	signed, err := token.SignedString(i.secretKey)
	if err != nil {
		return "", "", time.Time{}, fmt.Errorf("failed to sign JWT: %w", err)
	}
	return signed, jti, expiresAt, nil
}

// IssueRefreshToken creates an opaque refresh token (not a JWT).
func (i *Issuer) IssueRefreshToken() string {
	return uuid.NewString() + uuid.NewString()
}

// RefreshExpiry returns the expiry time for a refresh token.
func (i *Issuer) RefreshExpiry() time.Time {
	return time.Now().Add(time.Duration(i.refreshTTLDays) * 24 * time.Hour)
}

// Verify parses and verifies a PAM JWT. Returns the claims if valid.
func (i *Issuer) Verify(tokenString string) (*PAMClaims, string, error) {
	claims := &PAMClaims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return i.secretKey, nil
	},
		jwt.WithIssuer(i.issuer),
		jwt.WithAudience("pam"),
		jwt.WithValidMethods([]string{"HS256"}),
	)
	if err != nil {
		if errors.Is(err, jwt.ErrTokenExpired) {
			return nil, "", ErrExpiredToken
		}
		return nil, "", fmt.Errorf("%w: %v", ErrInvalidToken, err)
	}
	if !token.Valid {
		return nil, "", ErrInvalidToken
	}

	sessionID, _ := token.Header["sid"].(string)
	return claims, sessionID, nil
}
