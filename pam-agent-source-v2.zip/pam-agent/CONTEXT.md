# PAM Agent — Architecture & Feature Reference

**Repo:** `pam-agent` · **Module:** `github.com/yourorg/pam-agent` · **Binary:** `pam-agent`
**Stack:** Go, **zero third-party dependencies** (hard invariant)
**Size:** ~5,700 lines across 34 Go files, 7 packages
**Targets:** `windows/amd64` · `darwin/arm64` · `darwin/amd64` · `linux/amd64` · `linux/arm64`

The native agent. It opens a **real local tool** — `psql`, `mongosh`,
`redis-cli`, pgAdmin4, MinIO's console — already authenticated, on the
operator's own machine.

Companion documents: `CONTEXT.md` in the **pam-branch1** (backend) and
**pam-console** (frontend) repos.

---

## 1. The invariant that shapes everything

**Zero third-party Go dependencies.** One static binary, auditable end to end,
shippable anywhere. This is not stylistic — it dictates real implementation
choices throughout:

| Where a library would normally be used | What this repo does instead |
|---|---|
| ConPTY wrapper / `golang.org/x/sys/windows` | raw `syscall.NewLazyDLL` against `kernel32.dll` (`conpty_windows.go`) |
| `creack/pty` | hand-rolled `/dev/ptmx` + ioctls (`pty_linux.go`, `pty_darwin.go`) |
| Windows registry package | shells out to `reg.exe`, present on every Windows install |
| an asciicast library | a small, deliberate reimplementation of the format (`recorder/cast.go`) |

Every constant needed for both Unix ptys already exists in stdlib `syscall`,
which is what made the pty relay possible without breaking the invariant.

---

## 2. Where the agent sits, and what that means

```
   PAM  ──── issues a credential ────▶  pam-agent  ────▶  TARGET
    │                                       │             (direct TCP)
    └── never sees a byte of this session ──┘
```

The agent receives the **plaintext credential** and connects **directly** to
the target. PAM is *not* in the data path.

This is stated plainly in `guard.go` because it must not be oversold: the agent
runs as the operator, on the operator's machine, holding a credential PAM
already gave them. They can close it and run `psql` themselves. So every
agent-side control is **friction plus attribution** — it stops casual copying
and bulk extraction and records every attempt. It is **not prevention**.

The only things that make it prevention are (a) putting PAM back in the data
path — the in-browser terminal or the brokered web proxy — or (b) closing the
`agent` connect method for that resource entirely. The backend exposes exactly
that: `allowed_connect_methods`, and `EgressControlled()` which returns true
only when the agent path is closed.

---

## 3. Subcommands

**Operator-facing:**

```
pam-agent install                            register this OS's pam-agent:// URL handler
pam-agent pair --code XXXX --server <url>    pair this machine (once per PAM server)
pam-agent devices                            list paired servers
pam-agent uninstall                          remove the URL handler
pam-agent launch <pam-agent://...>           redeem a launch token and open the tool
                                             (invoked by the OS, not typed)
```

**Internal — arranged by `launch`, never typed:**

```
pam-agent relay --session … --server … [--policy JSON] [--record] -- <tool> [args…]
                                             macOS/Linux: hold a pty with the tool
                                             inside, record it, enforce policy,
                                             report the session end
pam-agent report-end --session … --server … --exit N
                                             fallback lifecycle report, used only
                                             when the relay could not be started
```

---

## 4. Trust model

`internal/keystore/keystore.go` · `internal/apiclient/client.go`

1. **Pairing, once per machine per server.** The user obtains a short,
   human-typed, 5-minute code from an authenticated PAM session. The agent
   generates an **Ed25519 keypair locally** and sends only the **public** half
   plus the code. PAM never sees the private key.
2. **Every subsequent request is Ed25519-signed.** Nothing stored locally is a
   bearer secret an attacker could copy and replay from another machine — a
   signature is only useful with the private key that made it.
3. **Launch tokens are single-use** and short-lived.

One keypair per server, since an operator may reasonably pair against more than
one PAM deployment. The keystore is keyed by server URL — **which is why
changing the backend's public hostname requires re-pairing.**

> **Stated honestly in the code:** the private key file is `0600`, which stops
> other OS accounts on a shared machine but does **not** encrypt it against a
> process running as the same user or someone with raw disk access. Wrapping it
> in DPAPI / Keychain / Secret Service is the natural next hardening step;
> full-disk encryption covers much of the same risk meanwhile.

---

## 5. End-to-end launch flow

```
 Console: "Open with local agent"
        │
        ▼
 Backend mints a single-use launch token, returns pam-agent://… 
        │
        ▼
 OS URL handler  ──▶  pam-agent launch <url>
        │
        ├─ 1. keystore.Load(server)          identity for THIS server
        ├─ 2. POST /agent/launch/resolve     Ed25519-signed; returns host, port,
        │                                    credential, resource type, policy,
        │                                    RecordingRequired
        │                                    (server also opens a tracked session)
        ├─ 3. LoadTemplates()                which tools can open this type
        ├─ 4. discovery.Locate()             which of them exist on THIS machine
        ├─ 5. credential injection           env var / temp file / clipboard
        ├─ 6. launcher.Spawn()               per-OS, see §6
        │
        ├─ 7. session end reported           exactly, by whoever owned the terminal
        └─ 8. recording uploaded             asciicast + reconstructed command log
```

If candidate selection fails after step 2, the agent still calls `EndLaunch`
with `FAILED`. *(That was a real bug: a MinIO resource with no `console_url`
left one stuck ACTIVE session per attempt, invisible to the operator.)*

---

## 6. Per-platform execution — the heart of the agent

To record a session and enforce policy, the agent must be **in the terminal's
data path**. All three platforms now are, by two different routes.

### Windows — in-process ConPTY

```
launch ──▶ AllocConsole ──▶ ConPTY ──▶ psql
             │                 │
        operator's console  record + guard
```

`spawn_windows.go` + `conpty_windows.go`. One process does everything: it
allocates its own console, creates a pseudo-console, and relays both
directions. Follows Microsoft's documented sequence exactly
(`CreatePseudoConsole` → `STARTUPINFOEX` + `PROC_THREAD_ATTRIBUTE_LIST` →
`CreateProcessW` → wait → `ClosePseudoConsole`), against raw syscalls.

Also manages raw console mode: `enableQuickEditMode`, `enableExtendedFlags`,
`enableMouseInput`, and an echo filter.

### macOS / Linux — out-of-process pty relay

```
launch ──▶ terminal emulator ──▶ wrapper ──▶ relay ──▶ pty ──▶ psql
                                                │
                                           record + guard
```

**Why it can't be one process.** `launch` has no terminal: the desktop starts
it from a `pam-agent://` URL. Windows solves this with `AllocConsole`; Unix has
no equivalent, so a terminal emulator must be asked for a window. And those
emulators don't block — `open -a Terminal` returns as soon as the AppleScript
is delivered, and gnome-terminal/konsole/xfce4-terminal are client/server. Only
`xterm` genuinely blocks. So `launch` was always dead long before the operator
closed the window.

**The fix inverts who reports.** The wrapper (`wrapper.go`) runs *inside* the
terminal, so it lives exactly as long as the session. It `exec`s
`pam-agent relay -- <tool>`, and the relay (`relay_unix.go`) allocates a pty,
runs the tool inside it, and sits between the two — logically identical to the
Windows arrangement, reached by a different route.

Because the relay owns the child it can `Wait()` on it, so **session end is
exact, not best-effort**, on every emulator. Because every byte passes through
it, the recording is the same asciicast Windows produces. And because
`guard.go` is pure logic with no platform code, the controls work unchanged.

**Implementation notes:**
- `pty_linux.go` — `/dev/ptmx`, `TIOCSPTLCK`, `TIOCGPTN`, `TCGETS`/`TCSETS`
- `pty_darwin.go` — `TIOCPTYGRANT`, `TIOCPTYUNLK`, `TIOCPTYGNAME`,
  `TIOCGETA`/`TIOCSETA` (macOS returns the slave's *name*, not an index)
- `Setsid` + `Setctty` gives the child a real controlling terminal, so job
  control, Ctrl+C and size queries behave normally
- raw mode on the operator's tty is what moves control from the emulator to the
  relay — without it the line discipline buffers whole lines and echoes them
  itself, so nothing could be refused *before* submission
- `SIGWINCH` is forwarded, so the tool reflows when the window is dragged
- the output drain after the child exits is **bounded (2s)**: the pty master
  only EOFs when *every* slave descriptor closes, and a disowned background job
  keeps it open forever — an unbounded wait would be a session that never ends,
  the original bug one level down

**Missing-agent fallback.** `exec` on a moved binary exits 127 and the window
vanishes with no tool and no message. So the wrapper tests the path first: a
session that is recorded or policy-bound is **refused** with a readable reason
and a pause (a session that looks supervised and is not is worse than one that
did not open); an unrestricted session falls back to running the tool plus
`report-end`.

### Capability matrix

| | Windows | macOS | Linux |
|---|---|---|---|
| CLI session recording | ✅ ConPTY | ✅ relay | ✅ relay |
| Exact session end | ✅ | ✅ | ✅ |
| Clipboard / command guard | ✅ | ✅ | ✅ |
| Command log | ✅ | ✅ | ✅ |
| **GUI** launches (`gui`) | ❌ | ❌ | ❌ |
| **Browser** launches (`browser`) | ❌ | ❌ | ❌ |

`gui` and `browser` have no terminal to relay and aren't processes the agent
can watch to completion. For `browser`-kind resources, use the **brokered web
proxy** instead — PAM is in the data path there, so it genuinely can record and
enforce.

---

## 7. Credential injection

`internal/launcher/credential.go`

**The rule: a password must never appear in `argv`**, because argv is visible
to every other process via `ps` / Task Manager. Where a tool supports it, use
an environment variable; where it doesn't, write a short-lived `0600` temp
file.

| Mode | Mechanism |
|---|---|
| `env` / `credential_env_var` | e.g. `REDISCLI_AUTH`, `MONGODB_URI` |
| `pgpass` | libpq-format `0600` file via `PGPASSFILE` — no prompt, nothing in argv |
| `mongo_init_file` | mongosh init JS |
| `clickhouse_config_file` | ClickHouse client XML config |
| `minio_mc_shell` | `mc` alias set up in a scratch config dir |
| `pgadmin_preseed` | best-effort `servers.json` preseed (`pgadmin_preseed.go`) |
| `connection_string_arg` / `oracle_connect_string` | **puts the credential in argv** — last resort, documented, not hidden |
| `clipboard` | copies the password for a GUI login prompt |
| `none` | |

An env var is still readable via `/proc/<pid>/environ` by the same user — a
real improvement, not a perfect one, and the code says so.

Temp files land in a per-session dir, are listed in `CleanupFiles`, and are
removed a few seconds after spawn (the child needs time to read them; there's
no way to make this exact on every platform).

---

## 8. Tool discovery & templates

`internal/discovery/discovery.go` · `internal/launcher/templates.go`

`launch-templates.json` maps each resource type to an **ordered list of
candidates**, so a machine with only the GUI client still works:

| Resource type | Candidates (in order) |
|---|---|
| `postgresql` | `psql` (cli) → `pgadmin4` (gui) |
| `mongodb` | `mongosh` (cli) → `mongodb-compass` (gui) |
| `redis` | `redis-cli` (cli) → `redisinsight` (gui) |
| `oracle` | `sqlplus` → `sqlcl` (cli) → `sqldeveloper` (gui) |
| `clickhouse` | `clickhouse-client` (cli) |
| `minio` | `mc-shell` (cli) → `minio-console` (browser) |
| `qdrant` / `langfuse` / `metabase` | dashboard (browser) |

Defaults are embedded via `//go:embed` and written to the config dir on first
run, so it works out of the box **and** an admin can edit it afterwards — add
types, repoint binaries, change args — with no recompile.

Discovery looks in `PATH`, Windows `App Paths` registry (via `reg.exe`),
absolute-path globs, and per-OS locations. A `Spec` is safe to share verbatim
across platforms; OS-scoped fields are only consulted on their matching
`runtime.GOOS`.

Args are Go templates over `{{.Host}} {{.Port}} {{.DatabaseName}}
{{.AccountName}} {{.ConsoleURL}}`.

---

## 9. Recording & the command log

`internal/recorder/cast.go`

**asciicast v2** — a JSON header line then one array per event
(`[t, "i"|"o", data]`). A deliberate small reimplementation rather than a
shared dependency: the backend's `internal/recorder` is internal to that module
and physically cannot be imported, and the zero-dependency invariant rules out
a library. **Reusing the format** is what lets PAM's existing admin player
replay an agent session with no changes on that side.

Alongside it, a **searchable command log** reconstructed from keystrokes
(`keylog.go` — `lineAccumulator`), not from screen output. Both relays feed it.

On the way out: `EndLaunch` first (stamps `ended_at`), then `UploadRecording`
(stamps `COMPLETED`). Reversing them leaves `ended_at` NULL forever. On
macOS/Linux, `launch` deliberately **skips its own upload** — the relay owns
the capture, and an empty upload from `launch` would win the race and close the
session out before the real artifact arrived.

---

## 10. Data-protection guard

`internal/launcher/guard.go` — pure logic, no platform code, used by both relays.

| Control | Mechanism |
|---|---|
| `BlockClipboard` | paste-burst detection: an input chunk ≥ 24 bytes arriving at once is a paste, not typing. Dropped, with a `Ctrl+U` kill-line so nothing partial is left on the prompt. |
| `DeniedCommands` | the command line is reconstructed keystroke by keystroke and matched **at token boundaries on both sides** before Enter is forwarded — so `select copy_count from stats` is not refused for containing `copy`. |
| `MaxEgressBytes` | cumulative output budget. On exhaustion the child is **killed**, not just silenced — a live child could still write what it already pulled to a file. |

The recording captures input **before** the guard runs, and output past the
budget: the evidence is what the operator *did*, including the paste they
attempted and the command that was refused. Truncating the evidence would
punish the investigation for the operator's behaviour.

Ordering is deliberate: clipboard blocking is what clients ask for and the
weakest thing here; the output budget is the one that actually bounds a worst
case, because it holds regardless of which command or trick is used.

Everything is reported back in an enforcement summary attached to the session
end, so PAM records what was *actually* enforced rather than what was
*configured*.

---

## 11. Installation & distribution

```
install/
  build-release.sh              cross-compiles all 5 targets + a VERSION file
  generate-onboarding-script.sh
  templates/onboard-unix.sh.tmpl
  templates/onboard-windows.ps1.tmpl
  windows/build-msi.ps1 + pam-agent.wxs
  macos/build-pkg.sh
  linux/build-deb.sh
```

The filename `pam-agent_<os>_<arch>[.exe]` is a **contract** with the backend's
`internal/agentdist/store.go`, not a convention — it's parsed to build the
platform picker.

**One-click enrolment:** the console offers a platform → the backend renders an
install script with the pairing code embedded → download, install, pair, done.
The console can only offer platforms whose binary is present in
`PAM_AGENT_BINARY_DIR`; a missing one silently disappears rather than becoming
a 404 button.

`internal/register/` registers the `pam-agent://` URL handler per OS: registry
(Windows), `LSSetDefaultHandler`/Info.plist (macOS), `.desktop` +
`xdg-mime` (Linux).

> **No auto-update.** Rolling a new build to installed machines is manual
> redistribution. After an agent change, operators must re-install — the
> one-click enrolment is what makes that cheap.

---

## 12. Known limitations

- `gui` and `browser` launches: no recording, best-effort session end.
- `connection_string_arg` / `oracle_connect_string` put the credential in argv.
- Private key is permission-protected, not encrypted at rest.
- No auto-update.
- pgAdmin4 preseed is version-dependent and best-effort; it never blocks the
  GUI from opening if it fails.
- The Windows `.msi` (WiX) and macOS `.pkg` sources are complete but **not
  build-verified** — no WiX/Xcode in the build environment. Run a real
  build + install/uninstall cycle on each OS before shipping those.
- The relay's pty tests (`relay_unix_test.go`) compile and vet for both Unix
  targets but need one run on a real Linux/macOS box; they cannot execute on a
  Windows dev machine.
