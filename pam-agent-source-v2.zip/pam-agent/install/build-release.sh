#!/bin/sh
# Cross-compile every pam-agent target the PAM console offers, into the
# directory the server serves them from.
#
# The console's one-click enrolment can only offer a platform whose binary is
# present here, so this script is what decides which buttons an operator sees.
# A missing target is not an error — it just means that platform silently
# disappears from the picker, which is the correct failure mode for a download
# that would otherwise 404.
#
# pam-agent is pure Go with no cgo, so every target below cross-compiles from
# any host with no toolchain beyond Go itself.
#
# Usage:
#   ./install/build-release.sh /opt/pam/agents            # explicit output dir
#   PAM_AGENT_BINARY_DIR=/opt/pam/agents ./install/build-release.sh
#
# Then point the API at it:
#   PAM_AGENT_BINARY_DIR=/opt/pam/agents
set -eu

OUT="${1:-${PAM_AGENT_BINARY_DIR:-}}"
if [ -z "$OUT" ]; then
  echo "usage: $0 <output-dir>   (or set PAM_AGENT_BINARY_DIR)" >&2
  exit 2
fi

cd "$(dirname "$0")/.."
mkdir -p "$OUT"

# Version stamped into a VERSION file the server reads and shows in the
# console, so an operator can see which agent build they are about to install.
VERSION="${PAM_AGENT_VERSION:-$(git describe --tags --always --dirty 2>/dev/null || date -u +%Y.%m.%d)}"

# The filename carries the platform: the server parses pam-agent_<os>_<arch>
# to build its target list, so these names are a contract with
# internal/agentdist/store.go, not a convention.
TARGETS="windows/amd64 darwin/arm64 darwin/amd64 linux/amd64 linux/arm64"

echo "Building pam-agent $VERSION"
echo "  output: $OUT"
echo ""

for t in $TARGETS; do
  GOOS="${t%%/*}"
  GOARCH="${t##*/}"
  NAME="pam-agent_${GOOS}_${GOARCH}"
  [ "$GOOS" = "windows" ] && NAME="$NAME.exe"

  printf '  %-28s' "$GOOS/$GOARCH"
  # -trimpath and -ldflags="-s -w" keep the binary reproducible and small;
  # an operator downloads this over their own connection.
  CGO_ENABLED=0 GOOS="$GOOS" GOARCH="$GOARCH" \
    go build -trimpath -ldflags "-s -w -X main.version=$VERSION" \
    -o "$OUT/$NAME" ./cmd/pam-agent
  SIZE=$(wc -c < "$OUT/$NAME" | tr -d ' ')
  echo "ok  ($SIZE bytes)"
done

printf '%s\n' "$VERSION" > "$OUT/VERSION"

echo ""
echo "Wrote $(ls -1 "$OUT" | grep -c '^pam-agent_') binaries + VERSION to $OUT"
echo "Restart pam-api (or have it re-scan) to pick them up."
