#!/bin/sh
# pam-agent/install/generate-onboarding-script.sh
#
# Produces a single, self-contained "one-click setup" script for one
# operator on one OS: it embeds the pam-agent binary itself (as base64) AND
# a one-time pairing code, so running the generated script does
# `pam-agent install` + `pam-agent pair` in one step, no package manager
# and no admin rights required. This is the concrete implementation of
# "installer embeds a one-time setup token so install+pair happen
# automatically in one step" for Linux and macOS (see the "windows" branch
# below for the PowerShell equivalent).
#
# Intended integration: the PAM backend's "Download agent installer" button
# calls POST /api/v1/pam/agent/pair/init with a longer ttl_minutes (see
# CHANGES.md), then invokes this script server-side with that code, and
# serves the result to the operator as a download. Wired here as a
# standalone script so it can be exercised and verified without needing
# that backend integration to exist yet.
#
# Usage:
#   generate-onboarding-script.sh <linux|darwin|windows> <path-to-pam-agent-binary-for-that-os> \
#       <server-url> <pairing-code> [device-name] [ttl-minutes] > setup.sh
#
# Pure POSIX sh (no bash-only features like process substitution) so this
# runs unmodified on whatever shell the PAM backend host has as /bin/sh.
set -eu

OS="${1:?usage: generate-onboarding-script.sh <linux|darwin|windows> <binary-path> <server-url> <pairing-code> [device-name] [ttl-minutes]}"
BINARY_PATH="${2:?missing: path to the pam-agent binary for that OS}"
SERVER_URL="${3:?missing: PAM server URL}"
PAIRING_CODE="${4:?missing: pairing code}"
DEVICE_NAME="${5:-}"
TTL_MINUTES="${6:-60}"

if [ ! -f "$BINARY_PATH" ]; then
  echo "error: binary not found at $BINARY_PATH" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

case "$OS" in
  linux|darwin) TEMPLATE="$SCRIPT_DIR/templates/onboard-unix.sh.tmpl" ;;
  windows)      TEMPLATE="$SCRIPT_DIR/templates/onboard-windows.ps1.tmpl" ;;
  *) echo "error: unsupported OS $OS (supported: linux, darwin, windows)" >&2; exit 1 ;;
esac

WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

B64_FILE="$WORK_DIR/binary.b64"
base64 "$BINARY_PATH" | tr -d '\n' > "$B64_FILE.oneline" 2>/dev/null || true
if [ -s "$B64_FILE.oneline" ]; then
  # Re-wrap at 76 cols for a readable/diffable generated file — GNU base64
  # -w0 gives one giant line; do the wrapping ourselves so this works
  # identically whether or not -w0 is supported.
  fold -w 76 "$B64_FILE.oneline" > "$B64_FILE"
else
  base64 "$BINARY_PATH" > "$B64_FILE"
fi

# Substitute the small placeholders first (sed handles these fine — they're
# short strings, not megabytes of base64).
SUBSTITUTED="$WORK_DIR/substituted.tmpl"
sed \
  -e "s|__PAM_SERVER_URL__|$SERVER_URL|g" \
  -e "s|__PAM_PAIRING_CODE__|$PAIRING_CODE|g" \
  -e "s|__PAM_DEVICE_NAME__|$DEVICE_NAME|g" \
  -e "s|__TTL_MINUTES__|$TTL_MINUTES|g" \
  "$TEMPLATE" > "$SUBSTITUTED"

# Splice the (potentially multi-megabyte) base64 blob in at its marker
# line via awk + a real temp file, rather than sed, which chokes on huge
# replacement text.
awk -v b64file="$B64_FILE" '
  $0 == "__BASE64_BINARY__" {
    while ((getline line < b64file) > 0) print line
    next
  }
  { print }
' "$SUBSTITUTED"
