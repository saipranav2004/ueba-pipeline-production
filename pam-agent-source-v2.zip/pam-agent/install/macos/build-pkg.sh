#!/bin/sh
# pam-agent/install/macos/build-pkg.sh
#
# Builds a real macOS installer package (pam-agent.pkg) using pkgbuild +
# productbuild (both ship with Xcode Command Line Tools -- no third-party
# packaging tooling). NOT build-verified in this sandbox -- there is no
# macOS machine here (Linux-only sandbox), so pkgbuild/productbuild
# themselves aren't even available to invoke. This is complete, reviewed
# source written directly against Apple's documented pkgbuild/productbuild
# usage, but treat it as "should work" rather than "verified working" until
# it's actually been built and installed on a real Mac. See CHANGES.md for
# what to check after a real build.
#
# NOTE: for most operators, the self-contained onboarding script from
# ../generate-onboarding-script.sh (OS=darwin) is the simpler, ALREADY
# end-to-end-verified option -- it reuses the exact same shell logic already
# proven working for Linux (this project's own dpkg-based test), just with
# a macOS binary embedded instead; POSIX `base64`/`chmod`/`mkdir` behave
# identically on both. Reach for THIS .pkg only when you specifically need
# a "real" macOS installer experience (Installer.app UI, a Receipts entry,
# clean uninstall bookkeeping) for a fleet-management tool.
#
# Usage: ./build-pkg.sh <version> [output-dir]
set -eu

VERSION="${1:?usage: build-pkg.sh <version> [output-dir]}"
OUT_DIR="${2:-.}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODULE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT

PKGROOT="$WORK_DIR/pkgroot"
SCRIPTS_DIR="$WORK_DIR/scripts"
mkdir -p "$PKGROOT/usr/local/bin" "$SCRIPTS_DIR"

echo "Building pam-agent for darwin/amd64 and darwin/arm64..."
(cd "$MODULE_ROOT" && GOOS=darwin GOARCH=amd64 go build -trimpath -ldflags "-s -w" \
    -o "$WORK_DIR/pam-agent-amd64" ./cmd/pam-agent)
(cd "$MODULE_ROOT" && GOOS=darwin GOARCH=arm64 go build -trimpath -ldflags "-s -w" \
    -o "$WORK_DIR/pam-agent-arm64" ./cmd/pam-agent)

if command -v lipo >/dev/null 2>&1; then
  echo "Combining into a universal binary with lipo..."
  lipo -create -output "$PKGROOT/usr/local/bin/pam-agent" \
    "$WORK_DIR/pam-agent-amd64" "$WORK_DIR/pam-agent-arm64"
else
  echo "lipo not found (expected -- this is a Linux sandbox, not macOS)."
  echo "Falling back to the amd64 binary alone; on a real Mac, run this"
  echo "script there so lipo can produce a proper universal binary."
  cp "$WORK_DIR/pam-agent-amd64" "$PKGROOT/usr/local/bin/pam-agent"
fi
chmod 0755 "$PKGROOT/usr/local/bin/pam-agent"

# postinstall runs as root (pkgbuild scripts always do), but URL-handler
# registration and pairing are per-user (see register_darwin.go) -- so it
# resolves the actual logged-in console user and runs those steps AS that
# user via `sudo -u`, rather than doing them as root (which would silently
# register the URL scheme for the wrong account, or write ~root/Applications
# instead of the operator's own ~/Applications).
cat > "$SCRIPTS_DIR/postinstall" <<'EOF'
#!/bin/sh
set -e

CONSOLE_USER=$(stat -f%Su /dev/console 2>/dev/null || echo "")

echo ""
echo "pam-agent installed to /usr/local/bin/pam-agent."

if [ -z "$CONSOLE_USER" ] || [ "$CONSOLE_USER" = "root" ]; then
  echo "Could not determine the logged-in user automatically."
  echo "Finish setup as your own user account by running:"
  echo "  pam-agent install"
  echo "  pam-agent pair --code <code from the PAM web app> --server <your PAM server URL>"
  exit 0
fi

echo "Registering the pam-agent:// URL handler for $CONSOLE_USER..."
if ! sudo -u "$CONSOLE_USER" /usr/local/bin/pam-agent install; then
  echo "warning: could not auto-register the URL handler as $CONSOLE_USER."
  echo "Run 'pam-agent install' yourself to finish this step."
fi

echo ""
echo "Next: pair this Mac with your PAM account by running (as $CONSOLE_USER, not root):"
echo "  pam-agent pair --code <code from the PAM web app> --server <your PAM server URL>"
echo ""
echo "(Prefer the one-click onboarding script from generate-onboarding-script.sh"
echo " if your PAM administrator gave you one -- it does pairing automatically too.)"
exit 0
EOF
chmod 0755 "$SCRIPTS_DIR/postinstall"

COMPONENT_PKG="$WORK_DIR/pam-agent-component.pkg"
echo "Building component package..."
pkgbuild \
  --root "$PKGROOT" \
  --scripts "$SCRIPTS_DIR" \
  --identifier "com.yourorg.pam-agent" \
  --version "$VERSION" \
  --install-location "/" \
  "$COMPONENT_PKG"

DISTRIBUTION_XML="$WORK_DIR/distribution.xml"
cat > "$DISTRIBUTION_XML" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="1">
    <title>PAM Agent</title>
    <organization>com.yourorg</organization>
    <domains enable_localSystem="true"/>
    <options customize="never" require-scripts="true" rootVolumeOnly="true"/>
    <choices-outline>
        <line choice="default">
            <line choice="com.yourorg.pam-agent"/>
        </line>
    </choices-outline>
    <choice id="default"/>
    <choice id="com.yourorg.pam-agent" visible="false">
        <pkg-ref id="com.yourorg.pam-agent"/>
    </choice>
    <pkg-ref id="com.yourorg.pam-agent" version="$VERSION" onConclusion="none">pam-agent-component.pkg</pkg-ref>
</installer-gui-script>
EOF

mkdir -p "$OUT_DIR"
FINAL_PKG="$OUT_DIR/pam-agent-$VERSION.pkg"
echo "Building final distribution package..."
productbuild \
  --distribution "$DISTRIBUTION_XML" \
  --package-path "$WORK_DIR" \
  "$FINAL_PKG"

echo ""
echo "Built: $FINAL_PKG"
echo "NOT installed/tested as part of this build (no macOS available here)."
echo "Before shipping to a client, on a real Mac verify:"
echo "  installer -pkg $FINAL_PKG -target /            (install, check the postinstall output)"
echo "  sudo -u <you> pam-agent devices                (confirm registration/pairing worked)"
echo "  pkgutil --forget com.yourorg.pam-agent          (clean up the receipt when testing repeatedly)"
