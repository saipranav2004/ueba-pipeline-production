//go:build darwin || linux

// pam-agent/internal/launcher/relay_unix.go
//
// The macOS/Linux counterpart to the Windows ConPTY relay, giving those
// platforms the three things they were missing: exact session end, session
// recording, and the copy/paste and command-blocking guard.
//
// WHY IT IS A SEPARATE INVOCATION OF THE AGENT. To relay a terminal you have
// to own one, and `pam-agent launch` does not: it is started by the desktop
// through the pam-agent:// URL handler, with no controlling terminal to draw
// on. Windows solves this by allocating its own console (AllocConsole); there
// is no equivalent on Unix, which is why the launcher has always had to ask a
// terminal emulator for a window.
//
// So the work is split. `launch` spawns the emulator, and the emulator runs
// `pam-agent relay -- <tool> <args…>`. THAT process inherits the emulator's
// terminal as its stdin/stdout, allocates a pseudo-terminal for the tool, and
// sits between the two. Logically identical to the Windows arrangement — the
// agent is the terminal the tool talks to — just reached by a different route:
//
//	launch ─▶ terminal emulator ─▶ relay ─▶ pty ─▶ psql
//	                                 │
//	                            record + guard
//
// Because the relay owns the child it can wait on it, so session end is exact
// rather than best-effort. Because every byte passes through it, the recording
// is the same asciicast the browser gateway and Windows produce. And because
// guard.go is pure logic with no platform code, the clipboard and command
// controls work here unchanged.
package launcher

import (
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
	"time"
	"unsafe"

	"github.com/yourorg/pam-agent/internal/recorder"
)

// outputDrainTimeout is how long the relay waits for the tool's final output
// after the tool itself has exited. Generous for a drain — the bytes are
// already in the kernel buffer — and short enough that a pty held open by
// something the operator left behind costs a couple of seconds rather than the
// whole session.
const outputDrainTimeout = 2 * time.Second

func ioctl(fd uintptr, request, arg uintptr) error {
	if _, _, e := syscall.Syscall(syscall.SYS_IOCTL, fd, request, arg); e != 0 {
		return e
	}
	return nil
}

// winsize matches struct winsize. Field order is fixed by the kernel ABI.
type winsize struct {
	Rows, Cols, X, Y uint16
}

func getWinsize(fd uintptr) (winsize, error) {
	var ws winsize
	err := ioctl(fd, syscall.TIOCGWINSZ, uintptr(unsafe.Pointer(&ws)))
	return ws, err
}

func setWinsize(fd uintptr, ws winsize) error {
	return ioctl(fd, syscall.TIOCSWINSZ, uintptr(unsafe.Pointer(&ws)))
}

// makeRaw puts the operator's real terminal into raw mode and returns the
// previous settings so they can be restored.
//
// Raw mode is what moves control from the emulator to us: without it the tty
// line discipline buffers whole lines, echoes them itself, and turns Ctrl+C
// into a signal — so the relay would see nothing until Enter, echo everything
// twice, and never be able to refuse a command before it was submitted.
func makeRaw(fd uintptr) (syscall.Termios, error) {
	prev, err := getTermios(fd)
	if err != nil {
		return prev, fmt.Errorf("read terminal mode: %w", err)
	}

	raw := prev
	// The canonical cfmakeraw set.
	raw.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP |
		syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	raw.Cflag &^= syscall.CSIZE | syscall.PARENB
	raw.Cflag |= syscall.CS8
	// Return from read as soon as one byte is available. Without this a raw
	// terminal blocks until VMIN bytes arrive, which for an interactive relay
	// means keystrokes appear in clumps.
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0

	if err := setTermios(fd, raw); err != nil {
		return prev, fmt.Errorf("set raw terminal mode: %w", err)
	}
	return prev, nil
}

// RelayOptions is everything `pam-agent relay` needs.
type RelayOptions struct {
	Exec string
	Args []string
	Env  []string

	Policy Policy
	Rec    *recorder.Cast

	// In and Out are the operator's own terminal. Both default to the process
	// standard streams, which is what the real relay always uses; they are
	// settable so the relay can be driven by a test, since a pty relay whose
	// only entry point demands an interactive terminal is a pty relay nobody
	// can check.
	In  *os.File
	Out io.Writer
}

// RelayResult is what the caller reports to PAM.
type RelayResult struct {
	ExitCode    int
	Enforcement Summary
}

// RunRelay allocates a pseudo-terminal, runs the tool inside it, and relays
// between the operator's terminal and that pty until the tool exits.
func RunRelay(opt RelayOptions) (RelayResult, error) {
	var res RelayResult

	in, out := opt.In, opt.Out
	if in == nil {
		in = os.Stdin
	}
	if out == nil {
		out = os.Stdout
	}

	master, slave, err := openPTY()
	if err != nil {
		return res, err
	}
	defer master.Close()

	// Match the pty to the operator's real terminal before the tool starts, so
	// it draws correctly from its first frame rather than assuming 80x24.
	if ws, wsErr := getWinsize(in.Fd()); wsErr == nil {
		_ = setWinsize(slave.Fd(), ws)
	}

	cmd := exec.Command(opt.Exec, opt.Args...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = slave, slave, slave
	cmd.Env = append(os.Environ(), opt.Env...)
	// Setsid + Setctty is what makes this a real terminal session for the
	// child: a new session with the pty slave as its controlling terminal, so
	// job control, Ctrl+C and terminal-size queries all behave as they would
	// under a normal shell.
	// Ctty is 0, NOT slave.Fd(), and the difference is the whole launch.
	//
	// Go's own doc on SysProcAttr.Setctty: "Ctty must be a descriptor number in
	// the CHILD process: an index into ProcAttr.Files." The child receives the
	// slave as its stdin/stdout/stderr above, so in the child it is fd 0, 1 and
	// 2 — never the number it happens to hold in this process.
	//
	// Passing the parent's fd made the child's ioctl(TIOCSCTTY) fail, so
	// cmd.Start() returned an error, the relay exited immediately, and the
	// terminal window closed with nothing in it. From the operator's side the
	// agent simply "did not open the application".
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true, Setctty: true, Ctty: 0}

	if err := cmd.Start(); err != nil {
		slave.Close()
		return res, fmt.Errorf("start %s: %w", opt.Exec, err)
	}
	// The child holds its own descriptor for the slave now. Ours has to be
	// closed or the master never sees EOF when the child exits, and the output
	// relay below would block forever.
	slave.Close()

	prev, rawErr := makeRaw(in.Fd())
	restore := func() {
		if rawErr == nil {
			_ = setTermios(in.Fd(), prev)
		}
	}
	defer restore()

	guard := NewGuard(opt.Policy)

	// The searchable command log, reconstructed from keystrokes exactly as the
	// Windows relay does it (see spawn_windows.go). Without this a Unix
	// session's recording would replay correctly but its command pane would be
	// empty, which is the half auditors actually search.
	var keylog *lineAccumulator
	if opt.Rec != nil {
		keylog = newLineAccumulator(func(line string) { opt.Rec.Command(line) })
	}

	// Forward terminal resizes for as long as the session lasts, so the tool
	// reflows when the operator drags the window.
	winch := make(chan os.Signal, 1)
	signal.Notify(winch, syscall.SIGWINCH)
	defer signal.Stop(winch)
	go func() {
		for range winch {
			if ws, e := getWinsize(in.Fd()); e == nil {
				_ = setWinsize(master.Fd(), ws)
			}
		}
	}()

	// Input: operator's terminal -> guard -> tool.
	go func() {
		buf := make([]byte, 4096)
		for {
			n, rerr := in.Read(buf)
			if n > 0 {
				// Recorded before the guard runs, deliberately: the recording
				// is evidence of what the operator did, which includes the
				// paste they attempted and the command that was refused.
				if opt.Rec != nil {
					opt.Rec.Input(buf[:n])
				}
				if keylog != nil {
					keylog.Feed(buf[:n])
				}

				act := guard.OnInput(buf[:n])
				if act.Notice != "" {
					// To the operator's own terminal, not into the pty: this is
					// PAM speaking, and writing it to the child would feed it to
					// psql as input.
					_, _ = io.WriteString(out, act.Notice)
					if opt.Rec != nil {
						opt.Rec.Output([]byte(act.Notice))
					}
				}
				if len(act.Forward) > 0 {
					if _, werr := master.Write(act.Forward); werr != nil {
						return
					}
				}
			}
			if rerr != nil {
				// Input is finished. Forward it as the EOF CHARACTER rather
				// than tearing the pty down.
				//
				// Closing the master here was the obvious move and it is wrong:
				// a child that never reads stdin at all (a one-shot command)
				// would be killed the instant its input stream ended, which is
				// immediately when the relay is driven by anything other than a
				// live terminal. Every exit code came back as -1.
				//
				// 0x04 is what a terminal sends for Ctrl-D. The slave's line
				// discipline is in canonical mode, so a child blocked on a read
				// — psql at its prompt, mongosh, cat — sees a clean end of
				// input and exits on its own terms, flushing as it goes. A
				// child that is not reading simply never notices.
				_, _ = master.Write([]byte{0x04})
				return
			}
		}
	}()

	// Output: tool -> guard -> operator's terminal. On its own goroutine, with
	// outDone closed when it stops, so the teardown below can wait for the
	// child's last bytes to be written before returning.
	outDone := make(chan struct{})
	go func() {
		defer close(outDone)
		buf := make([]byte, 4096)
		for {
			n, rerr := master.Read(buf)
			if n > 0 {
				// The recording gets the full stream even past the budget: the
				// cap exists to stop data reaching the OPERATOR, and truncating
				// the evidence too would punish the investigation for the
				// operator's behaviour.
				if opt.Rec != nil {
					opt.Rec.Output(buf[:n])
				}

				visible, capped, notice := guard.OnOutput(buf[:n])
				if len(visible) > 0 {
					_, _ = out.Write(visible)
				}
				if capped {
					if notice != "" {
						_, _ = io.WriteString(out, notice)
						if opt.Rec != nil {
							opt.Rec.Output([]byte(notice))
						}
					}
					// Ending the session is the point of the cap. Leaving the
					// child running with its output suppressed would let it keep
					// pulling data it could still write to a file.
					_ = cmd.Process.Kill()
					return
				}
			}
			if rerr != nil {
				return
			}
		}
	}()

	waitErr := cmd.Wait()

	// The child is gone, but the master side only reports EOF once EVERY
	// descriptor on the slave is closed — and a tool that left something
	// holding it open (a shell with a disowned background job, a daemon that
	// forked) never lets that happen. Waiting unconditionally would park this
	// goroutine forever, and a relay that never returns is a session that
	// never ends and a recording that is never uploaded: precisely the bug
	// this whole path was built to fix, reintroduced one level down.
	//
	// So the drain is bounded. Closing the master unblocks the pending read
	// (the fd is pollable, so the runtime interrupts it rather than leaking a
	// blocked thread), and the goroutine exits on the resulting error.
	select {
	case <-outDone:
	case <-time.After(outputDrainTimeout):
		_ = master.Close()
		<-outDone
	}

	res.Enforcement = guard.Summary()
	if code, ok := exitCodeOf(waitErr); ok {
		res.ExitCode = code
	} else if waitErr != nil {
		res.ExitCode = 1
	}

	// Restore before the caller prints anything, or its output lands on a
	// terminal still in raw mode with no newline translation.
	restore()
	fmt.Fprintf(out, "\r\n*** %s exited (code %d) ***\r\n", opt.Exec, res.ExitCode)
	return res, nil
}

func exitCodeOf(err error) (int, bool) {
	if err == nil {
		return 0, true
	}
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return ee.ExitCode(), true
	}
	return 0, false
}
