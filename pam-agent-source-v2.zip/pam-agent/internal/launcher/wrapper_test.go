//go:build darwin || linux

package launcher

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func report() EndReport {
	return EndReport{
		AgentPath: "/usr/local/bin/pam-agent",
		ServerURL: "https://pam.example.com",
		SessionID: "sess-123",
	}
}

func recordedReport() EndReport {
	r := report()
	r.PolicyJSON = `{"block_clipboard":true,"max_egress_bytes":5242880}`
	r.Record = true
	return r
}

func psqlCommand() *PreparedCommand {
	return &PreparedCommand{
		Exec: "/usr/bin/psql",
		Args: []string{"-h", "db.internal", "-U", "svc_reporting"},
		Env:  []string{"PGPASSWORD=s3cret pass", "PGSSLMODE=require"},
	}
}

func readWrapper(t *testing.T, pc *PreparedCommand, r EndReport) (string, string) {
	t.Helper()
	path, err := writeSessionWrapper(pc, r)
	if err != nil {
		t.Fatalf("writeSessionWrapper: %v", err)
	}
	t.Cleanup(func() { os.Remove(path) })
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read wrapper: %v", err)
	}
	return path, string(body)
}

// The wrapper does not run the tool — it runs the relay, with the tool behind
// `--`. That is what puts the agent in the data path on macOS and Linux, and
// so what makes recording, the clipboard guard, and an exact session end
// possible at all. A wrapper that launched psql directly could only ever
// report the lifecycle.
func TestWrapperRunsTheToolThroughTheRelay(t *testing.T) {
	_, body := readWrapper(t, psqlCommand(), report())

	if !strings.Contains(body, "relay") {
		t.Fatalf("wrapper does not hand the session to the relay:\n%s", body)
	}
	if !strings.Contains(body, "--session 'sess-123'") {
		t.Fatalf("relay invocation is missing the session id:\n%s", body)
	}
	if !strings.Contains(body, "--server 'https://pam.example.com'") {
		t.Fatalf("relay invocation is missing the server:\n%s", body)
	}
	// `--` is load-bearing: without it the tool's own flags (psql -h, -U) are
	// parsed as the relay's and the launch fails.
	if !strings.Contains(body, "-- '/usr/bin/psql' '-h' 'db.internal' '-U' 'svc_reporting'") {
		t.Fatalf("the tool and its arguments are not passed through after --:\n%s", body)
	}
}

// `exec` is correct here, and was wrong for the previous design. The relay is
// the session for its whole duration and reports the end itself, so the shell
// has nothing left to do once it has started — where the old report-after-tool
// wrapper had to survive the tool to be able to speak.
func TestWrapperExecsTheRelayRatherThanWaitingOnIt(t *testing.T) {
	_, body := readWrapper(t, psqlCommand(), report())

	lines := strings.Split(strings.TrimRight(body, "\n"), "\n")
	last := lines[len(lines)-1]
	if !strings.HasPrefix(last, "exec ") || !strings.Contains(last, " relay ") {
		t.Fatalf("the script's last act should be to exec the relay, got %q:\n%s", last, body)
	}

	// The relay reports the end over the API, so nothing may follow it here —
	// and any report-end line must belong to the missing-agent fallback, which
	// only runs when the relay could not be started at all. One reachable on
	// the normal path would close the session while the operator was still
	// sitting in it.
	if i := strings.Index(body, "report-end"); i >= 0 && i > strings.Index(body, last) {
		t.Fatalf("a report-end line follows the relay on the normal path:\n%s", body)
	}
}

// The policy has to reach the relay, or a resource an admin restricted opens
// unrestricted. It is JSON going through a bash script, so the quoting matters
// as much as the presence.
func TestWrapperForwardsThePolicyAndTheRecordingObligation(t *testing.T) {
	_, body := readWrapper(t, psqlCommand(), recordedReport())

	if !strings.Contains(body, "--policy ") {
		t.Fatalf("the data-protection policy never reaches the relay:\n%s", body)
	}
	if !strings.Contains(body, `'{"block_clipboard":true,"max_egress_bytes":5242880}'`) {
		t.Fatalf("the policy JSON is not passed intact:\n%s", body)
	}
	if !strings.Contains(body, "--record") {
		t.Fatalf("the session is meant to be recorded but the relay is not told to:\n%s", body)
	}

	// And a session with neither must not acquire them by accident.
	_, plain := readWrapper(t, psqlCommand(), report())
	if strings.Contains(plain, "--policy") {
		t.Fatalf("a session with no policy was given one:\n%s", plain)
	}
	if strings.Contains(plain, "--record") {
		t.Fatalf("a session with no recording obligation was recorded:\n%s", plain)
	}
}

// A GUI launch has no terminal to relay through and no session to close, so
// it runs the tool directly.
func TestWrapperRunsTheToolDirectlyWhenThereIsNoSessionToRelay(t *testing.T) {
	_, body := readWrapper(t, psqlCommand(), EndReport{})

	if !strings.Contains(body, "exec '/usr/bin/psql'") {
		t.Fatalf("with nothing to relay the wrapper should run the tool itself:\n%s", body)
	}
	if strings.Contains(body, "relay") {
		t.Fatalf("no session id was given, so there is nothing to relay:\n%s", body)
	}

	// Partial configuration must be treated as "cannot relay" and fall back to
	// running the tool, not as a half-built relay command line — which would
	// fail to launch and leave the operator with a window that closes instantly.
	for _, partial := range []EndReport{
		{AgentPath: "/x/pam-agent", ServerURL: "https://p", SessionID: ""},
		{AgentPath: "", ServerURL: "https://p", SessionID: "s"},
		{AgentPath: "/x/pam-agent", ServerURL: "", SessionID: "s"},
	} {
		_, b := readWrapper(t, psqlCommand(), partial)
		if strings.Contains(b, "relay") {
			t.Fatalf("incomplete config produced a relay invocation: %+v", partial)
		}
	}
}

// The credential goes in the file, never on a command line every process on
// the machine can read out of `ps`.
func TestWrapperCarriesEnvironmentInTheFileNotArgv(t *testing.T) {
	path, body := readWrapper(t, psqlCommand(), report())

	if !strings.Contains(body, `export PGPASSWORD='s3cret pass'`) {
		t.Fatalf("environment is not exported inside the wrapper:\n%s", body)
	}

	info, err := os.Stat(path)
	if err != nil {
		t.Fatalf("stat: %v", err)
	}
	// 0700: the file holds a live credential for as long as the session runs.
	if perm := info.Mode().Perm(); perm != 0o700 {
		t.Fatalf("wrapper permissions = %o, want 700 — it contains a credential", perm)
	}
}

// Every value interpolated here is executed with the operator's own
// privileges, so a hostile one must not be able to add a command.
func TestWrapperQuotesValuesThatWouldOtherwiseInjectCommands(t *testing.T) {
	pc := &PreparedCommand{
		Exec: "/usr/bin/psql",
		Args: []string{"-c", "select 1; rm -rf $HOME"},
		Env:  []string{`PGPASSWORD=it's a 'quoted' pass; whoami`},
	}
	_, body := readWrapper(t, pc, report())

	// The dangerous fragments must appear only inside quotes, never as their
	// own commands. Verified by asking bash itself to parse it.
	if strings.Contains(body, "\nrm -rf") || strings.Contains(body, "\nwhoami") {
		t.Fatalf("a value escaped its quoting and became a command:\n%s", body)
	}

	if _, err := exec.LookPath("bash"); err != nil {
		t.Skip("bash not available to parse-check the generated script")
	}
	path, _ := readWrapper(t, pc, report())
	// -n parses without executing: a quoting bug shows up as a syntax error,
	// with no side effects.
	if out, err := exec.Command("bash", "-n", path).CombinedOutput(); err != nil {
		t.Fatalf("generated wrapper is not valid bash: %v\n%s", err, out)
	}
}

func TestShellQuoteHandlesEmbeddedSingleQuotes(t *testing.T) {
	cases := map[string]string{
		"plain":     `'plain'`,
		"it's":      `'it'\''s'`,
		"":          `''`,
		"a b;c":     `'a b;c'`,
		`$(whoami)`: `'$(whoami)'`,
	}
	for in, want := range cases {
		if got := shellQuote(in); got != want {
			t.Fatalf("shellQuote(%q) = %s, want %s", in, got, want)
		}
	}
}

// The generated script must be valid bash in the ordinary case too, not just
// the hostile one.
func TestGeneratedWrapperParsesInBash(t *testing.T) {
	if _, err := exec.LookPath("bash"); err != nil {
		t.Skip("bash not available")
	}
	for _, r := range []EndReport{report(), recordedReport(), {}} {
		path, _ := readWrapper(t, psqlCommand(), r)
		if out, err := exec.Command("bash", "-n", path).CombinedOutput(); err != nil {
			t.Fatalf("wrapper does not parse: %v\n%s", err, out)
		}
	}
}

// A missing agent binary must not turn into a terminal that flashes and
// vanishes. `exec` on a path that is not there exits 127 immediately, and the
// operator would have no tool, no session, and nothing to read.
func TestWrapperRefusesARecordedSessionWhenTheAgentIsMissing(t *testing.T) {
	if _, err := exec.LookPath("bash"); err != nil {
		t.Skip("bash not available")
	}
	r := recordedReport()
	r.AgentPath = filepath.Join(t.TempDir(), "pam-agent-that-is-not-there")
	r.RelayRequired = true

	marker := filepath.Join(t.TempDir(), "tool-ran")
	pc := &PreparedCommand{Exec: "/usr/bin/touch", Args: []string{marker}}

	path, _ := readWrapper(t, pc, r)
	out, err := exec.Command("bash", path).CombinedOutput()

	if err == nil {
		t.Fatalf("a recorded session opened with no agent to record it:\n%s", out)
	}
	// The tool must not have run: a session that looks supervised and is not is
	// worse than a session that did not open.
	if _, statErr := os.Stat(marker); statErr == nil {
		t.Fatalf("the tool ran anyway, unrecorded and unrestricted:\n%s", out)
	}
	if !strings.Contains(string(out), "must be recorded or restricted") {
		t.Fatalf("the operator was given no reason for the refusal:\n%s", out)
	}
}

// With nothing to record and nothing to restrict, only the lifecycle is at
// stake, so the operator keeps their session and the older report path covers
// the rest.
func TestWrapperStillOpensAnUnrestrictedSessionWhenTheAgentIsMissing(t *testing.T) {
	if _, err := exec.LookPath("bash"); err != nil {
		t.Skip("bash not available")
	}
	r := report()
	r.AgentPath = filepath.Join(t.TempDir(), "pam-agent-that-is-not-there")
	r.RelayRequired = false

	marker := filepath.Join(t.TempDir(), "tool-ran")
	pc := &PreparedCommand{Exec: "/usr/bin/touch", Args: []string{marker}}

	path, body := readWrapper(t, pc, r)
	out, err := exec.Command("bash", path).CombinedOutput()
	if err != nil {
		t.Fatalf("wrapper failed instead of falling back: %v\n%s\nscript:\n%s", err, out, body)
	}
	if _, statErr := os.Stat(marker); statErr != nil {
		t.Fatalf("the tool never ran, so the operator lost a session for no reason:\n%s", out)
	}
	// The lifecycle still has to be reported, or the session sits ACTIVE.
	if !strings.Contains(body, "report-end") {
		t.Fatalf("the fallback path does not report the session end:\n%s", body)
	}
}
