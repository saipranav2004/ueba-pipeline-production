//go:build linux

// pam-agent/internal/launcher/pty_linux.go
//
// Pseudo-terminal allocation on Linux, with no dependencies beyond the
// standard library.
//
// The agent has zero third-party dependencies, which is a property worth
// keeping for a binary that runs on operator machines and handles privileged
// credentials: every dependency is code somebody else can change underneath a
// security tool. github.com/creack/pty would do this in one call, and the
// ioctl numbers below are the price of not taking it.
//
// The Linux sequence is: open the multiplexer, unlock the pair, ask which slave
// index was allocated, open that slave by name.
package launcher

import (
	"fmt"
	"os"
	"syscall"
	"unsafe"
)

// openPTY returns the master and the slave of a fresh pseudo-terminal pair.
func openPTY() (master, slave *os.File, err error) {
	m, err := os.OpenFile("/dev/ptmx", os.O_RDWR, 0)
	if err != nil {
		return nil, nil, fmt.Errorf("open /dev/ptmx: %w", err)
	}

	// Any failure past this point must not leak the master.
	defer func() {
		if err != nil {
			m.Close()
		}
	}()

	// Unlock before opening the slave: until TIOCSPTLCK is cleared the kernel
	// refuses to open it. The argument is a pointer to a zero int, not the
	// value zero.
	var unlock int32
	if e := ioctl(m.Fd(), syscall.TIOCSPTLCK, uintptr(unsafe.Pointer(&unlock))); e != nil {
		return nil, nil, fmt.Errorf("unlock pty: %w", e)
	}

	var index int32
	if e := ioctl(m.Fd(), syscall.TIOCGPTN, uintptr(unsafe.Pointer(&index))); e != nil {
		return nil, nil, fmt.Errorf("get pty index: %w", e)
	}

	// O_NOCTTY: opening the slave here must not make it this process's
	// controlling terminal — that belongs to the child, which claims it with
	// TIOCSCTTY after setsid (see relay_unix.go).
	s, err := os.OpenFile(fmt.Sprintf("/dev/pts/%d", index), os.O_RDWR|syscall.O_NOCTTY, 0)
	if err != nil {
		return nil, nil, fmt.Errorf("open pty slave: %w", err)
	}
	return m, s, nil
}

// termios get/set. Linux spells these TCGETS/TCSETS; darwin uses
// TIOCGETA/TIOCSETA, which is the only reason these two files exist
// separately at all.
func getTermios(fd uintptr) (syscall.Termios, error) {
	var t syscall.Termios
	if err := ioctl(fd, syscall.TCGETS, uintptr(unsafe.Pointer(&t))); err != nil {
		return t, err
	}
	return t, nil
}

func setTermios(fd uintptr, t syscall.Termios) error {
	return ioctl(fd, syscall.TCSETS, uintptr(unsafe.Pointer(&t)))
}
