// pam-agent/internal/launcher/guard_test.go
//
// The guard is the only part of CLI data protection that is pure logic, so it
// is the only part that can be tested without a console. Everything asserted
// here is a decision the relay then acts on.
package launcher

import (
	"strings"
	"testing"
)

func pgPolicy() Policy {
	return Policy{
		BlockClipboard: true,
		MaxEgressBytes: 0,
		DeniedCommands: DefaultDeniedCommands["postgresql"],
	}
}

// Typing must pass through untouched. A guard that interferes with ordinary
// keystrokes would be switched off within a day.
func TestTypingPassesThrough(t *testing.T) {
	g := NewGuard(pgPolicy())
	for _, keystroke := range []string{"s", "e", "l", "e", "c", "t", " ", "1"} {
		act := g.OnInput([]byte(keystroke))
		if string(act.Forward) != keystroke {
			t.Fatalf("keystroke %q was altered to %q", keystroke, act.Forward)
		}
		if act.Notice != "" {
			t.Fatalf("keystroke %q produced a notice: %q", keystroke, act.Notice)
		}
	}
	// And submitting a permitted command forwards the Enter.
	act := g.OnInput([]byte("\r"))
	if len(act.Forward) == 0 || act.BlockedCommand != "" {
		t.Fatalf("a permitted command must submit normally, got %+v", act)
	}
}

func TestPasteIsDroppedWholeAndReported(t *testing.T) {
	g := NewGuard(pgPolicy())
	paste := []byte(strings.Repeat("x", pasteBurstBytes+10))

	act := g.OnInput(paste)
	if len(act.Forward) != 0 {
		t.Fatalf("a paste must not reach the child, %d bytes forwarded", len(act.Forward))
	}
	if !act.BlockedPaste || act.Notice == "" {
		t.Fatalf("a blocked paste must be visible to the operator and recorded: %+v", act)
	}
	if got := g.Summary().PasteBlocked; got != 1 {
		t.Fatalf("PasteBlocked = %d, want 1", got)
	}

	// Including one that carries its own Enter: forwarding the text and
	// refusing only the newline would leave a half-typed command on the prompt,
	// which reads as a glitch rather than a decision.
	withEnter := append([]byte(strings.Repeat("y", pasteBurstBytes)), '\r')
	if act := g.OnInput(withEnter); len(act.Forward) != 0 {
		t.Fatalf("a paste containing Enter must be dropped whole, forwarded %q", act.Forward)
	}
}

// A held-down key or a fast typist must not be mistaken for a paste.
func TestSmallBurstsAreNotTreatedAsPaste(t *testing.T) {
	g := NewGuard(pgPolicy())
	for _, chunk := range []string{"sel", "ect ", "1", "\x1b[A"} { // incl. an arrow key
		act := g.OnInput([]byte(chunk))
		if act.BlockedPaste {
			t.Fatalf("chunk %q of %d bytes was misread as a paste", chunk, len(chunk))
		}
		if string(act.Forward) != chunk {
			t.Fatalf("chunk %q was altered", chunk)
		}
	}
}

func TestPasteIsAllowedWhenPolicyDoesNotBlockClipboard(t *testing.T) {
	g := NewGuard(Policy{DeniedCommands: DefaultDeniedCommands["postgresql"]})
	paste := []byte(strings.Repeat("x", pasteBurstBytes+10))
	if act := g.OnInput(paste); len(act.Forward) != len(paste) {
		t.Fatal("a session without clipboard blocking must paste normally")
	}
}

// ── Command blocking ─────────────────────────────────────────────────────

func typeLine(g *Guard, line string) InputAction {
	for _, r := range line {
		g.OnInput([]byte(string(r)))
	}
	return g.OnInput([]byte("\r"))
}

func TestBulkExtractionCommandsAreRefusedBeforeSubmission(t *testing.T) {
	for _, cmd := range []string{
		`\copy customers to '/tmp/out.csv'`,
		`COPY customers TO '/tmp/out.csv'`,
		"pg_dump -t customers",
		`\o /tmp/dump.txt`,
	} {
		g := NewGuard(pgPolicy())
		act := typeLine(g, cmd)

		if act.BlockedCommand == "" {
			t.Fatalf("%q was allowed through", cmd)
		}
		// The line must be erased, not submitted: the characters were already
		// relayed as they were typed, so refusing only the Enter would leave
		// the command on the prompt ready for a second Enter.
		if len(act.Forward) != 1 || act.Forward[0] != killLine {
			t.Fatalf("%q: forwarded %v, want a single kill-line byte to erase the pending command",
				cmd, act.Forward)
		}
		if !strings.Contains(act.Notice, "Blocked") {
			t.Fatalf("%q: the refusal must be visible to the operator, got %q", cmd, act.Notice)
		}

		blocked := g.Summary().CommandsBlocked
		if len(blocked) != 1 || blocked[0].Command == "" || blocked[0].Pattern == "" {
			t.Fatalf("%q: the attempt must be recorded with its command and pattern, got %+v", cmd, blocked)
		}
	}
}

// The reason matching is anchored to a token boundary: a bare substring test
// refuses ordinary work, and a control that blocks legitimate queries gets
// turned off.
func TestOrdinaryQueriesMentioningADeniedWordAreAllowed(t *testing.T) {
	allowed := []string{
		"select copy_count from stats", // column prefixed with a pattern
		"select * from backup_copy",    // pattern inside an identifier
		"select id from pg_dumpster",   // pattern is a prefix of a real name
		"update jobs set saved = true", // 'save' inside a word
	}
	for _, cmd := range allowed {
		g := NewGuard(Policy{DeniedCommands: []string{`\copy`, "copy", "pg_dump", "save"}})
		if act := typeLine(g, cmd); act.BlockedCommand != "" {
			t.Fatalf("%q was refused but is legitimate work", cmd)
		}
	}
}

func TestDeniedCommandMatchingIsCaseInsensitiveAndIgnoresLeadingSpace(t *testing.T) {
	for _, cmd := range []string{"   PG_DUMP -t x", "\tCopy t To '/tmp/x'"} {
		g := NewGuard(pgPolicy())
		if act := typeLine(g, cmd); act.BlockedCommand == "" {
			t.Fatalf("%q should have been refused", cmd)
		}
	}
}

// Editing keys have to be honoured or the reconstruction judges a command the
// operator never actually typed.
func TestBackspaceIsAppliedBeforeJudging(t *testing.T) {
	g := NewGuard(pgPolicy())
	// Type "pg_dumpX", erase the X, submit: still pg_dump, still refused.
	for _, r := range "pg_dumpX" {
		g.OnInput([]byte(string(r)))
	}
	g.OnInput([]byte{0x7F})
	if act := g.OnInput([]byte("\r")); act.BlockedCommand == "" {
		t.Fatal("backspace must be applied before the command is judged")
	}

	// And the reverse: typing a denied word then erasing it must not refuse.
	g2 := NewGuard(pgPolicy())
	for _, r := range "pg_dump" {
		g2.OnInput([]byte(string(r)))
	}
	for i := 0; i < 7; i++ {
		g2.OnInput([]byte{0x7F})
	}
	for _, r := range "select 1" {
		g2.OnInput([]byte(string(r)))
	}
	if act := g2.OnInput([]byte("\r")); act.BlockedCommand != "" {
		t.Fatalf("an erased command must not be refused, got %q", act.BlockedCommand)
	}
}

func TestLineResetsBetweenCommands(t *testing.T) {
	g := NewGuard(pgPolicy())
	if act := typeLine(g, "pg_dump x"); act.BlockedCommand == "" {
		t.Fatal("first command should be refused")
	}
	if act := typeLine(g, "select 1"); act.BlockedCommand != "" {
		t.Fatalf("a refusal must not leak into the next command, got %q", act.BlockedCommand)
	}
}

// ── Output budget ────────────────────────────────────────────────────────

func TestOutputBudgetTruncatesAtTheBoundary(t *testing.T) {
	g := NewGuard(Policy{MaxEgressBytes: 100})

	out, capped, _ := g.OnOutput(make([]byte, 60))
	if len(out) != 60 || capped {
		t.Fatalf("under the budget: forwarded %d, capped %v", len(out), capped)
	}

	// A budget that can be overshot by one read of arbitrary size is not a
	// budget, so the crossing chunk is cut exactly at the limit.
	out, capped, notice := g.OnOutput(make([]byte, 500))
	if len(out) != 40 {
		t.Fatalf("crossing chunk forwarded %d bytes, want exactly the remaining 40", len(out))
	}
	if !capped || notice == "" {
		t.Fatalf("crossing the budget must cap the session and say so: capped=%v notice=%q", capped, notice)
	}

	// And nothing more escapes afterwards.
	out, capped, _ = g.OnOutput(make([]byte, 10))
	if len(out) != 0 || !capped {
		t.Fatalf("after the cap: forwarded %d bytes, capped %v", len(out), capped)
	}

	s := g.Summary()
	if s.OutputBytes != 100 || !s.OutputCapped {
		t.Fatalf("summary = %+v, want exactly the budget and capped", s)
	}
}

func TestNoBudgetMeansUnmeteredOutput(t *testing.T) {
	g := NewGuard(Policy{BlockClipboard: true})
	out, capped, _ := g.OnOutput(make([]byte, 1<<20))
	if len(out) != 1<<20 || capped {
		t.Fatal("a session with no budget must not be metered")
	}
	if g.Summary().OutputBytes != 1<<20 {
		t.Fatal("output bytes must still be counted for the summary")
	}
}

// An unrestricted session must take the cheapest path and change nothing.
func TestInactivePolicyIsAPassThrough(t *testing.T) {
	g := NewGuard(Policy{})
	if g.policy.Active() {
		t.Fatal("an empty policy must report inactive")
	}
	paste := []byte(strings.Repeat("x", pasteBurstBytes+10))
	if act := g.OnInput(paste); len(act.Forward) != len(paste) || act.BlockedPaste {
		t.Fatal("an inactive policy must forward everything untouched")
	}
	if s := g.Summary(); s.Enforced {
		t.Fatal("an inactive policy must report itself as not enforced")
	}
}

// A nil guard is what a non-Windows launch has, and the relay must be able to
// ask it for a summary without special-casing.
func TestNilGuardSummaryIsSafe(t *testing.T) {
	var g *Guard
	if s := g.Summary(); s.Enforced || s.PasteBlocked != 0 {
		t.Fatalf("a nil guard must summarise as unenforced, got %+v", s)
	}
}
