//go:build windows

package launcher

import (
	"bytes"
	"testing"
)

func TestWin32InputModeSuppressor(t *testing.T) {
	t.Run("responds once when the marker arrives in one chunk", func(t *testing.T) {
		var s win32InputModeSuppressor
		var out bytes.Buffer
		s.scan([]byte("\x1b[?9001h\x1b[?1004h"), &out)
		if out.String() != win32InputModeDisable {
			t.Fatalf("got %q, want %q", out.String(), win32InputModeDisable)
		}
		out.Reset()
		s.scan([]byte("more output"), &out)
		if out.Len() != 0 {
			t.Fatalf("expected no further response, got %q", out.String())
		}
	})

	t.Run("responds when the marker straddles two chunks", func(t *testing.T) {
		var s win32InputModeSuppressor
		var out bytes.Buffer
		s.scan([]byte("\x1b[?90"), &out)
		if out.Len() != 0 {
			t.Fatalf("expected no response yet, got %q", out.String())
		}
		s.scan([]byte("01h"), &out)
		if out.String() != win32InputModeDisable {
			t.Fatalf("got %q, want %q", out.String(), win32InputModeDisable)
		}
	})

	t.Run("does not respond when the marker never appears", func(t *testing.T) {
		var s win32InputModeSuppressor
		var out bytes.Buffer
		s.scan([]byte("cirmdb=> select 1;\r\n"), &out)
		if out.Len() != 0 {
			t.Fatalf("expected no response, got %q", out.String())
		}
	})
}
