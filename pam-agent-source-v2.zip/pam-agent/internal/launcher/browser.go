// pam-agent/internal/launcher/browser.go
//
// OpenBrowser opens the OS default browser to a URL — the whole
// implementation of the "browser" launch kind (Langfuse, Metabase, MinIO
// Console, Qdrant's dashboard: web apps the operator just needs pointed at,
// with no local credential injection at all). No build tags needed: this
// file branches on runtime.GOOS at call time, same style as
// internal/discovery, so it compiles and cross-compiles cleanly for every
// target without OS-specific files.
package launcher

import (
	"fmt"
	"os/exec"
	"runtime"
)

// OpenBrowser hands rawURL to the OS's own "open this in the default
// application" mechanism. Never returns credentials in rawURL — callers
// (buildBrowserCommand) only ever pass a resource's console_url, which PAM
// never populates with a password.
func OpenBrowser(rawURL string) error {
	var c *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		// `cmd /c start "" <url>` is the standard way to hand a URL to the
		// default browser from Windows without invoking a shell built-in
		// directly; the empty "" is a required placeholder for start's
		// optional window-title argument.
		c = exec.Command("cmd", "/c", "start", "", rawURL)
	case "darwin":
		c = exec.Command("open", rawURL)
	default: // linux and other unix-likes
		c = exec.Command("xdg-open", rawURL)
	}
	if err := c.Run(); err != nil {
		return fmt.Errorf("could not open the default browser (tried the standard %s opener): %w", runtime.GOOS, err)
	}
	return nil
}
