//go:build darwin || linux

package launcher

import (
	"bytes"
	"compress/gzip"
	"io"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/yourorg/pam-agent/internal/recorder"
)

// syncBuf is the operator's terminal for these tests. The relay writes to it
// from its output goroutine, so reads have to be guarded even though the relay
// is finished by the time the assertions run.
type syncBuf struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (b *syncBuf) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.Write(p)
}

func (b *syncBuf) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.String()
}

// runRelay drives RunRelay with a pipe standing in for the operator's keyboard
// and a buffer standing in for their screen.
//
// input is written and the write end closed, so the relay's input goroutine
// sees EOF and stops; the session still ends on the child's exit, not on that.
func runRelay(t *testing.T, opt RelayOptions, input string) (RelayResult, string) {
	t.Helper()

	pr, pw, err := os.Pipe()
	if err != nil {
		t.Fatalf("pipe: %v", err)
	}
	defer pr.Close()

	var screen syncBuf
	opt.In, opt.Out = pr, &screen

	go func() {
		defer pw.Close()
		if input != "" {
			_, _ = io.WriteString(pw, input)
		}
	}()

	done := make(chan RelayResult, 1)
	go func() {
		res, runErr := RunRelay(opt)
		if runErr != nil {
			t.Errorf("RunRelay: %v", runErr)
		}
		done <- res
	}()

	select {
	case res := <-done:
		return res, screen.String()
	case <-time.After(30 * time.Second):
		// A hang here is the failure mode that matters most: it means the relay
		// did not notice its child exiting, which in production is a session
		// that never ends.
		t.Fatalf("relay did not finish; screen so far:\n%s", screen.String())
		return RelayResult{}, ""
	}
}

// The core of the fix: the relay owns the child, so it sees the exit and knows
// the code. This is what makes session-end exact on macOS and Linux instead of
// best-effort.
func TestRelayRunsTheToolAndReportsItsExitCode(t *testing.T) {
	res, screen := runRelay(t, RelayOptions{
		Exec: "/bin/sh",
		Args: []string{"-c", "printf 'hello from the pty'; exit 3"},
	}, "")

	if res.ExitCode != 3 {
		t.Fatalf("ExitCode = %d, want 3 — a failed tool must not read as a clean finish", res.ExitCode)
	}
	if !strings.Contains(screen, "hello from the pty") {
		t.Fatalf("the tool's output never reached the operator's terminal:\n%s", screen)
	}
}

func TestRelayReportsZeroForACleanExit(t *testing.T) {
	res, _ := runRelay(t, RelayOptions{Exec: "/bin/sh", Args: []string{"-c", "exit 0"}}, "")
	if res.ExitCode != 0 {
		t.Fatalf("ExitCode = %d, want 0", res.ExitCode)
	}
}

// The child has to get a real terminal, not a pipe. Tools branch on this:
// psql without a tty gives up its pager and its prompt, and `tty` itself is
// the cheapest way to prove the pty is actually the child's controlling
// terminal rather than something merely wired to its stdout.
func TestRelayGivesTheChildARealControllingTerminal(t *testing.T) {
	_, screen := runRelay(t, RelayOptions{
		Exec: "/bin/sh",
		Args: []string{"-c", "tty; test -t 0 && echo STDIN_IS_TTY"},
	}, "")

	if !strings.Contains(screen, "STDIN_IS_TTY") {
		t.Fatalf("the child's stdin is not a terminal — interactive tools will misbehave:\n%s", screen)
	}
	if strings.Contains(screen, "not a tty") {
		t.Fatalf("no controlling terminal was attached to the child:\n%s", screen)
	}
}

// Recording is the half macOS and Linux were missing entirely. The asciicast
// has to contain what the operator actually saw.
func TestRelayCapturesTheSessionIntoAnAsciicast(t *testing.T) {
	cast := recorder.NewCast(120, 30, "relay test")

	res, _ := runRelay(t, RelayOptions{
		Exec: "/bin/sh",
		Args: []string{"-c", "printf 'SENTINEL_OUTPUT_9f2a'"},
		Rec:  cast,
	}, "")
	if res.ExitCode != 0 {
		t.Fatalf("ExitCode = %d", res.ExitCode)
	}

	gz, err := cast.Finalize()
	if err != nil {
		t.Fatalf("Finalize: %v", err)
	}
	zr, err := gzip.NewReader(bytes.NewReader(gz))
	if err != nil {
		t.Fatalf("recording is not valid gzip: %v", err)
	}
	body, err := io.ReadAll(zr)
	if err != nil {
		t.Fatalf("read recording: %v", err)
	}
	if !strings.Contains(string(body), "SENTINEL_OUTPUT_9f2a") {
		t.Fatalf("the session output is not in the recording:\n%s", body)
	}
}

// The command log is what auditors search, and it is built from keystrokes on
// the way in rather than from the screen on the way out.
func TestRelayReconstructsTheCommandLogFromKeystrokes(t *testing.T) {
	cast := recorder.NewCast(120, 30, "relay test")

	// `cat` echoes and exits on EOF, so the typed line is consumed by a real
	// child without needing a shell prompt to synchronise against.
	runRelay(t, RelayOptions{
		Exec: "/bin/cat",
		Rec:  cast,
	}, "select count(*) from audit_log;\r")

	var found bool
	for _, c := range cast.Commands() {
		if strings.Contains(c.Input, "select count(*) from audit_log;") {
			found = true
		}
	}
	if !found {
		t.Fatalf("the typed command was not recorded; commands = %+v", cast.Commands())
	}
}

// Egress capping has to actually stop the flow. The child is killed rather
// than left running with its output dropped, because a live child can still
// write what it pulled to a file the operator keeps.
func TestRelayStopsTheSessionWhenTheEgressBudgetIsExhausted(t *testing.T) {
	res, screen := runRelay(t, RelayOptions{
		Exec:   "/bin/sh",
		Args:   []string{"-c", "i=0; while :; do printf 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'; i=$((i+1)); done"},
		Policy: Policy{MaxEgressBytes: 4096},
	}, "")

	if len(screen) > 64*1024 {
		t.Fatalf("egress cap did not stop the stream: %d bytes reached the terminal", len(screen))
	}
	if !res.Enforcement.OutputCapped {
		t.Fatalf("the stream stopped but the enforcement summary does not say the cap fired: %+v", res.Enforcement)
	}
}

// A tool that leaves something behind holding the pty must not hang the relay.
// The master side only reports EOF when every slave descriptor is closed, so a
// disowned background job keeps it open indefinitely — and a relay that never
// returns is a session that never ends and a recording that is never uploaded,
// which is the original bug one level down.
func TestRelayDoesNotHangWhenSomethingElseHoldsThePtyOpen(t *testing.T) {
	start := time.Now()

	// The backgrounded sleep inherits the pty as its stdout and outlives the
	// shell, so the master never sees EOF on its own.
	res, _ := runRelay(t, RelayOptions{
		Exec: "/bin/sh",
		Args: []string{"-c", "(sleep 60 &) ; printf 'done'; exit 0"},
	}, "")

	if elapsed := time.Since(start); elapsed > 20*time.Second {
		t.Fatalf("relay took %s to notice its child had exited", elapsed)
	}
	if res.ExitCode != 0 {
		t.Fatalf("ExitCode = %d, want 0", res.ExitCode)
	}
}
