//go:build windows

// pam-agent/internal/launcher/conpty_windows.go
//
// Raw ConPTY bindings via syscall.NewLazyDLL against kernel32.dll —
// deliberately not golang.org/x/sys/windows or a ConPTY wrapper library.
// pam-agent's README documents "zero third-party Go dependencies" as a
// hard invariant (single static binary, easy to audit/ship); ConPTY isn't
// exposed through plain package syscall, so the alternative to hand-rolling
// this is adding a dependency, which isn't on the table here.
//
// This follows the exact call sequence Microsoft's own ConPTY sample
// documents (CreatePseudoConsole -> STARTUPINFOEX + PROC_THREAD_ATTRIBUTE_LIST
// -> CreateProcessW -> wait -> ClosePseudoConsole), just against raw
// syscalls instead of the C++ headers that sample assumes.
package launcher

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"time"
	"unicode/utf16"
	"unsafe"

	"syscall"
)

var (
	kernel32                              = syscall.NewLazyDLL("kernel32.dll")
	procCreatePseudoConsole               = kernel32.NewProc("CreatePseudoConsole")
	procResizePseudoConsole               = kernel32.NewProc("ResizePseudoConsole")
	procClosePseudoConsole                = kernel32.NewProc("ClosePseudoConsole")
	procInitializeProcThreadAttributeList = kernel32.NewProc("InitializeProcThreadAttributeList")
	procUpdateProcThreadAttribute         = kernel32.NewProc("UpdateProcThreadAttribute")
	procDeleteProcThreadAttributeList     = kernel32.NewProc("DeleteProcThreadAttributeList")
	procCreateProcessW                    = kernel32.NewProc("CreateProcessW")
	procAllocConsole                      = kernel32.NewProc("AllocConsole")
	procGetConsoleMode                    = kernel32.NewProc("GetConsoleMode")
	procSetConsoleMode                    = kernel32.NewProc("SetConsoleMode")
	procSetConsoleCtrlHandler             = kernel32.NewProc("SetConsoleCtrlHandler")
)

// ctrlCloseEvent is the value HandlerRoutine receives when the operator
// closes the console window directly (X button / Alt-F4 / taskbar "Close
// window") — see installCloseHandler.
const ctrlCloseEvent = 2

// PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = ProcThreadAttributeValue(22, FALSE, TRUE, FALSE)
// = 22 | PROC_THREAD_ATTRIBUTE_INPUT(0x00020000) — the well-known constant
// every ConPTY sample/binding uses for this attribute.
const procThreadAttributePseudoConsole = 0x20016

const (
	extendedStartupinfoPresent = 0x00080000
	createUnicodeEnvironment   = 0x00000400
)

// Console mode bits (winbase.h / wincon.h) — only the handful this file
// actually flips.
const (
	enableProcessedInput       = 0x0001
	enableLineInput            = 0x0002
	enableEchoInput            = 0x0004
	enableVirtualTerminalInput = 0x0200

	// The three flags that decide whether the console lets the operator
	// select and copy text.
	//
	// enableExtendedFlags is NOT optional and is the reason this is widely
	// believed to be impossible: SetConsoleMode ignores a change to
	// enableQuickEditMode unless enableExtendedFlags is set in the same call.
	// Clear QuickEdit on its own and the call succeeds while changing nothing.
	//
	// enableMouseInput is what makes it stick in a modern host. With QuickEdit
	// off and mouse input on, clicks and drags are delivered to the application
	// instead of being interpreted as selection — so Windows Terminal never
	// builds a selection either, and its own Ctrl+Shift+C has nothing to copy.
	enableMouseInput                = 0x0010
	enableQuickEditMode             = 0x0040
	enableExtendedFlags             = 0x0080
	enableVirtualTerminalProcessing = 0x0004
	disableNewlineAutoReturn        = 0x0008
)

type coord struct {
	X, Y int16
}

// coordArg packs a COORD into the single register CreatePseudoConsole/
// ResizePseudoConsole expect it in on the x64 calling convention (a COORD
// is 4 bytes — two int16s — passed by value in one argument slot, not by
// pointer). Widening through int32 first (rather than reading 8 raw bytes
// via *uintptr) avoids reading past the 4-byte struct.
func (c coord) arg() uintptr {
	return uintptr(*(*int32)(unsafe.Pointer(&c)))
}

type startupInfoEx struct {
	StartupInfo   syscall.StartupInfo
	AttributeList uintptr
}

// pseudoConsole owns one ConPTY session for the lifetime of one launched
// process. InPipe/OutPipe are the ends the caller actually uses — write
// operator keystrokes to InPipe, read the child's output from OutPipe.
type pseudoConsole struct {
	handle  uintptr
	InPipe  *os.File
	OutPipe *os.File
}

func newPseudoConsole(cols, rows int16) (*pseudoConsole, error) {
	// ptyIn: ConPTY reads from the R side; we hold and write to the W side
	// (operator input flows in). ptyOut: ConPTY writes to the W side; we
	// hold and read from the R side (child output flows out).
	ptyInR, ptyInW, err := os.Pipe()
	if err != nil {
		return nil, fmt.Errorf("create input pipe: %w", err)
	}
	ptyOutR, ptyOutW, err := os.Pipe()
	if err != nil {
		ptyInR.Close()
		ptyInW.Close()
		return nil, fmt.Errorf("create output pipe: %w", err)
	}

	var hpc uintptr
	size := coord{X: cols, Y: rows}
	ret, _, _ := procCreatePseudoConsole.Call(
		size.arg(),
		ptyInR.Fd(),
		ptyOutW.Fd(),
		0,
		uintptr(unsafe.Pointer(&hpc)),
	)
	// CreatePseudoConsole duplicates the handles it needs internally — our
	// copies of the ends we handed over are no longer ours to hold open.
	ptyInR.Close()
	ptyOutW.Close()

	if hr := int32(ret); hr < 0 {
		ptyInW.Close()
		ptyOutR.Close()
		return nil, fmt.Errorf("CreatePseudoConsole failed: hresult=0x%x", uint32(hr))
	}

	// conhost's renderer doesn't reliably start actively flushing VT output
	// to the pipe right after creation — a resize event (even a same-size,
	// effectively-no-op one) is the documented kick that gets it going.
	// Confirmed necessary while testing this file: without this call, only
	// conhost's own initial mode-set sequences ever made it through the
	// pipe — a spawned process's actual output (e.g. a plain `echo`) never
	// arrived, no matter how long the caller waited before closing.
	procResizePseudoConsole.Call(hpc, size.arg())

	return &pseudoConsole{handle: hpc, InPipe: ptyInW, OutPipe: ptyOutR}, nil
}

func (p *pseudoConsole) Close() {
	if p.handle != 0 {
		procClosePseudoConsole.Call(p.handle)
		p.handle = 0
	}
	p.InPipe.Close()
	p.OutPipe.Close()
}

// buildProcThreadAttributeList allocates and initializes a
// PROC_THREAD_ATTRIBUTE_LIST carrying exactly one attribute: the pseudo
// console handle. The returned byte slice must be kept alive (and eventually
// passed to deleteProcThreadAttributeList) for as long as the STARTUPINFOEX
// referencing it is in use.
func buildProcThreadAttributeList(hpc uintptr) ([]byte, error) {
	var size uintptr
	procInitializeProcThreadAttributeList.Call(0, 1, 0, uintptr(unsafe.Pointer(&size)))
	if size == 0 {
		return nil, fmt.Errorf("InitializeProcThreadAttributeList: failed to determine required size")
	}

	buf := make([]byte, size)
	ret, _, err := procInitializeProcThreadAttributeList.Call(
		uintptr(unsafe.Pointer(&buf[0])), 1, 0, uintptr(unsafe.Pointer(&size)),
	)
	if ret == 0 {
		return nil, fmt.Errorf("InitializeProcThreadAttributeList: %w", err)
	}

	ret, _, err = procUpdateProcThreadAttribute.Call(
		uintptr(unsafe.Pointer(&buf[0])),
		0,
		procThreadAttributePseudoConsole,
		hpc,
		unsafe.Sizeof(hpc),
		0,
		0,
	)
	if ret == 0 {
		procDeleteProcThreadAttributeList.Call(uintptr(unsafe.Pointer(&buf[0])))
		return nil, fmt.Errorf("UpdateProcThreadAttribute: %w", err)
	}
	return buf, nil
}

func deleteProcThreadAttributeList(buf []byte) {
	if len(buf) > 0 {
		procDeleteProcThreadAttributeList.Call(uintptr(unsafe.Pointer(&buf[0])))
	}
}

// quoteArg applies the same argv-quoting rules CreateProcess's own
// command-line parser expects (MSDN "Parsing C++ Command-Line Arguments"),
// mirrored here because package syscall doesn't export its internal
// equivalent (used by os/exec) for reuse.
func quoteArg(s string) string {
	if s == "" {
		return `""`
	}
	if !strings.ContainsAny(s, " \t\n\v\"") {
		return s
	}
	var b strings.Builder
	b.WriteByte('"')
	slashes := 0
	for _, r := range s {
		switch r {
		case '\\':
			slashes++
			b.WriteRune(r)
		case '"':
			for i := 0; i < slashes+1; i++ {
				b.WriteByte('\\')
			}
			b.WriteRune(r)
			slashes = 0
		default:
			slashes = 0
			b.WriteRune(r)
		}
	}
	for i := 0; i < slashes; i++ {
		b.WriteByte('\\')
	}
	b.WriteByte('"')
	return b.String()
}

func buildCommandLine(exe string, args []string) string {
	parts := make([]string, 0, len(args)+1)
	parts = append(parts, quoteArg(exe))
	for _, a := range args {
		parts = append(parts, quoteArg(a))
	}
	return strings.Join(parts, " ")
}

// buildEnvBlock renders env ("KEY=VALUE" entries) as the double-null
// terminated UTF-16 block CreateProcessW's lpEnvironment expects. A nil
// return means "inherit the caller's environment," matching CreateProcessW's
// own default when lpEnvironment is NULL.
func buildEnvBlock(env []string) *uint16 {
	if len(env) == 0 {
		return nil
	}
	var buf []uint16
	for _, s := range env {
		buf = append(buf, utf16.Encode([]rune(s))...)
		buf = append(buf, 0)
	}
	buf = append(buf, 0)
	return &buf[0]
}

// spawnAttachedTo launches exe/args/env with its console I/O attached to
// pc, returning a handle to the new process and its main thread. Caller
// owns closing both handles (via syscall.CloseHandle) once done with them.
func spawnAttachedTo(pc *pseudoConsole, exe string, args, env []string) (processHandle, threadHandle syscall.Handle, pid uint32, err error) {
	attrList, err := buildProcThreadAttributeList(pc.handle)
	if err != nil {
		return 0, 0, 0, err
	}
	defer deleteProcThreadAttributeList(attrList)

	var si startupInfoEx
	si.StartupInfo.Cb = uint32(unsafe.Sizeof(si))
	si.AttributeList = uintptr(unsafe.Pointer(&attrList[0]))

	cmdLine, err := syscall.UTF16PtrFromString(buildCommandLine(exe, args))
	if err != nil {
		return 0, 0, 0, fmt.Errorf("encode command line: %w", err)
	}

	var pi syscall.ProcessInformation
	flags := uint32(extendedStartupinfoPresent)
	if len(env) > 0 {
		flags |= createUnicodeEnvironment
	}

	ret, _, callErr := procCreateProcessW.Call(
		0, // lpApplicationName — resolved via argv[0] in lpCommandLine instead
		uintptr(unsafe.Pointer(cmdLine)),
		0, 0, // process/thread security attributes
		0, // bInheritHandles — the child's console comes from the pseudo console attribute, not inherited std handles
		uintptr(flags),
		uintptr(unsafe.Pointer(buildEnvBlock(env))),
		0, // lpCurrentDirectory — inherit ours
		uintptr(unsafe.Pointer(&si.StartupInfo)),
		uintptr(unsafe.Pointer(&pi)),
	)
	if ret == 0 {
		return 0, 0, 0, fmt.Errorf("CreateProcessW: %w", callErr)
	}
	return pi.Process, pi.Thread, pi.ProcessId, nil
}

func allocConsole() error {
	ret, _, err := procAllocConsole.Call()
	if ret == 0 {
		return err
	}
	return nil
}

// openConsoleHandles opens fresh CONIN$/CONOUT$ handles bound to whatever
// console this process is currently attached to. Needed because
// AllocConsole doesn't retroactively fix up os.Stdin/os.Stdout — those
// *os.File values cache the (likely NUL, since pam-agent is normally
// launched with no console at all) handle Go's runtime captured at process
// start, before AllocConsole ran.
func openConsoleHandles() (in, out *os.File, err error) {
	inHandle, err := syscall.CreateFile(
		syscall.StringToUTF16Ptr("CONIN$"),
		syscall.GENERIC_READ|syscall.GENERIC_WRITE,
		syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE,
		nil, syscall.OPEN_EXISTING, 0, 0,
	)
	if err != nil {
		return nil, nil, fmt.Errorf("open CONIN$: %w", err)
	}
	outHandle, err := syscall.CreateFile(
		syscall.StringToUTF16Ptr("CONOUT$"),
		syscall.GENERIC_READ|syscall.GENERIC_WRITE,
		syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE,
		nil, syscall.OPEN_EXISTING, 0, 0,
	)
	if err != nil {
		syscall.CloseHandle(inHandle)
		return nil, nil, fmt.Errorf("open CONOUT$: %w", err)
	}
	return os.NewFile(uintptr(inHandle), "CONIN$"), os.NewFile(uintptr(outHandle), "CONOUT$"), nil
}

// setRawConsoleMode puts the console into the mode a terminal-in-the-middle
// needs: no line buffering/echo on input (we relay every keystroke through
// immediately, exactly like a real pty), VT sequence passthrough both ways
// so arrow keys/ANSI colors survive the relay intact. This is the same mode
// flip Microsoft's own ConPTY sample applies before attaching a console to
// a pseudo console.
// setRawConsoleMode puts the inherited console into the raw, VT-driven mode
// the ConPTY relay needs.
//
// blockSelection additionally takes text selection away from the console host,
// which is the only copy affordance a console actually has. It is a real
// control rather than a cosmetic one, and it is also the limit of what the
// agent can do about copying: an operator who wants the text badly enough can
// screenshot it, or not use the agent at all. See guard.go on why this whole
// layer is friction and attribution rather than prevention.
func setRawConsoleMode(in, out *os.File, blockSelection bool) error {
	inHandle := syscall.Handle(in.Fd())
	outHandle := syscall.Handle(out.Fd())

	var inMode uint32
	if ret, _, err := procGetConsoleMode.Call(uintptr(inHandle), uintptr(unsafe.Pointer(&inMode))); ret == 0 {
		return fmt.Errorf("GetConsoleMode(in): %w", err)
	}
	inMode &^= enableEchoInput | enableLineInput | enableProcessedInput
	inMode |= enableVirtualTerminalInput
	if blockSelection {
		// Order matters only in that all three must be in the one call:
		// clearing QuickEdit without enableExtendedFlags is silently ignored.
		inMode &^= enableQuickEditMode
		inMode |= enableExtendedFlags | enableMouseInput
	}
	if ret, _, err := procSetConsoleMode.Call(uintptr(inHandle), uintptr(inMode)); ret == 0 {
		return fmt.Errorf("SetConsoleMode(in): %w", err)
	}

	var outMode uint32
	if ret, _, err := procGetConsoleMode.Call(uintptr(outHandle), uintptr(unsafe.Pointer(&outMode))); ret == 0 {
		return fmt.Errorf("GetConsoleMode(out): %w", err)
	}
	outMode |= enableVirtualTerminalProcessing | disableNewlineAutoReturn
	if ret, _, err := procSetConsoleMode.Call(uintptr(outHandle), uintptr(outMode)); ret == 0 {
		return fmt.Errorf("SetConsoleMode(out): %w", err)
	}
	return nil
}

// shutdownComplete/shutdownOnce let main.go tell installCloseHandler's
// callback "the PAM server has already been told this session ended — it's
// safe to let the process actually die now." Package-level and used at most
// once per process because pam-agent handles exactly one launch per process
// invocation (see cmd/pam-agent/main.go's cmdLaunch).
var (
	shutdownComplete = make(chan struct{})
	shutdownOnce     sync.Once

	// closeHandlerCallback must be kept reachable for the life of the
	// process — SetConsoleCtrlHandler stores a raw function pointer, so if
	// this were a local variable the Go GC would be free to collect it
	// (and the OS would end up calling into freed/reused memory) the
	// moment installCloseHandler returns.
	closeHandlerCallback uintptr
)

// SignalShutdownComplete tells any pending console-close handler (see
// installCloseHandler) that this launch has already finished reporting its
// outcome to PAM (EndLaunch/UploadRecording) — so if the operator closed
// the window, the handler currently waiting to let this process die can
// stop waiting immediately instead of sitting out its full grace period.
// Safe to call unconditionally (including on the normal exit path, where
// nothing is waiting on it) and safe to call more than once.
func SignalShutdownComplete() {
	shutdownOnce.Do(func() { close(shutdownComplete) })
}

// installCloseHandler arranges for the operator closing the console window
// directly (X button, Alt-F4, "Close window") to terminate childProcess —
// otherwise it would survive as an orphan: it's attached to the pseudo
// console this process owns, not to the real window being closed, so
// Windows has no reason to tear it down on its own, and it would be left
// running (still connected to whatever database it opened) with PAM never
// told the session ended. Once terminated, the rest of spawnCLIWithConPTY's
// normal exit path runs exactly as it would for `exit`/`\q` — this only
// ever forces that same path to start.
//
// The handler blocks returning (which is what lets the OS actually kill
// this process) until SignalShutdownComplete is called or a bounded grace
// period elapses — giving the normal post-Spawn cleanup (recording upload,
// EndLaunch) a real chance to reach PAM before the process disappears.
func installCloseHandler(childProcess syscall.Handle) {
	handler := func(ctrlType uint32) uintptr {
		if ctrlType != ctrlCloseEvent {
			return 0 // FALSE — not ours to handle; let default processing continue.
		}
		syscall.TerminateProcess(childProcess, 1)
		select {
		case <-shutdownComplete:
		case <-time.After(4 * time.Second):
		}
		return 1 // TRUE — handled.
	}
	closeHandlerCallback = syscall.NewCallback(handler)
	procSetConsoleCtrlHandler.Call(closeHandlerCallback, 1)
}
