//go:build windows

// pam-agent/internal/register/register_windows.go
package register

import (
	"fmt"
	"os/exec"
)

// Register associates the pam-agent:// URL scheme with execPath under
// HKEY_CURRENT_USER — no admin rights required, since it's a per-user
// registration rather than a machine-wide one. Uses reg.exe (present on
// every Windows install) rather than a registry-editing Go package, keeping
// the agent's dependency footprint at zero.
func Register(execPath string) error {
	steps := [][]string{
		{"add", `HKCU\Software\Classes\pam-agent`, "/ve", "/d", "URL:PAM Agent Protocol", "/f"},
		{"add", `HKCU\Software\Classes\pam-agent`, "/v", "URL Protocol", "/d", "", "/f"},
		{"add", `HKCU\Software\Classes\pam-agent\shell\open\command`, "/ve",
			"/d", fmt.Sprintf(`"%s" launch "%%1"`, execPath), "/f"},
	}
	for _, args := range steps {
		out, err := exec.Command("reg", args...).CombinedOutput()
		if err != nil {
			return fmt.Errorf("reg %v failed: %w (%s)", args, err, string(out))
		}
	}
	return nil
}

// Unregister removes the pam-agent:// URL scheme association.
func Unregister() error {
	out, err := exec.Command("reg", "delete", `HKCU\Software\Classes\pam-agent`, "/f").CombinedOutput()
	if err != nil {
		return fmt.Errorf("reg delete failed: %w (%s)", err, string(out))
	}
	return nil
}
