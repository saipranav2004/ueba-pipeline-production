// pam-agent/internal/keystore/keystore.go
//
// Package keystore manages the agent's local Ed25519 identity. One keypair
// is generated per (server, since a user could reasonably pair with more
// than one PAM deployment) the FIRST time `pam-agent pair` succeeds against
// that server, and reused for every subsequent launch. PAM only ever sees
// the public half — the private key never leaves this machine and never
// crosses the network.
//
// SECURITY NOTE (stated plainly rather than glossed over): the private key
// file is protected with 0600 permissions, which is a real but partial
// control — it stops other OS user accounts on a shared machine from
// reading it, but it does NOT encrypt it at rest against, say, another
// process running as the same user, or someone with full-disk access to an
// unencrypted drive. Wrapping this with the OS's native secret store
// (Windows DPAPI / macOS Keychain / a Linux Secret Service provider) would
// close that gap and is the natural next hardening step — flagged here
// rather than silently claimed as done. Disk encryption (BitLocker/FileVault/
// LUKS), which most managed enterprise endpoints already require, covers a
// large part of the same risk in the meantime.
package keystore

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// Identity is one paired device's local state for one PAM server.
type Identity struct {
	ServerURL     string `json:"server_url"`
	AgentDeviceID string `json:"agent_device_id"`
	PublicKeyB64  string `json:"public_key_b64"`
	privateKey    ed25519.PrivateKey
}

// PrivateKey returns the loaded Ed25519 private key. Only populated after
// Load or Save within the same process — never (de)serialized alongside the
// rest of Identity's JSON, since privateKeyPath below stores it separately.
func (id *Identity) PrivateKey() ed25519.PrivateKey { return id.privateKey }

var ErrNotPaired = errors.New("no paired identity found for this server — run: pam-agent pair --code <code> --server <url>")

// baseDir returns (and creates) the agent's per-user config directory:
// %AppData%\pam-agent on Windows, ~/Library/Application Support/pam-agent on
// macOS, ~/.config/pam-agent on Linux (via os.UserConfigDir, which already
// knows the right answer per OS).
func baseDir() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", fmt.Errorf("could not determine config directory: %w", err)
	}
	dir = filepath.Join(dir, "pam-agent")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", fmt.Errorf("could not create config directory %s: %w", dir, err)
	}
	return dir, nil
}

var unsafeChars = regexp.MustCompile(`[^a-zA-Z0-9._-]+`)

// serverDir returns a filesystem-safe per-server subdirectory, since a user
// may pair the same machine against more than one PAM deployment.
func serverDir(serverURL string) (string, error) {
	base, err := baseDir()
	if err != nil {
		return "", err
	}
	safe := unsafeChars.ReplaceAllString(strings.ToLower(serverURL), "_")
	dir := filepath.Join(base, "servers", safe)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", fmt.Errorf("could not create server directory %s: %w", dir, err)
	}
	return dir, nil
}

// Generate creates a brand new Ed25519 identity for serverURL. It does not
// persist anything — call Save once pairing succeeds against the server, so
// a failed pairing attempt never leaves an orphaned, unregistered key behind.
func Generate(serverURL string) (*Identity, error) {
	pub, priv, err := ed25519.GenerateKey(nil) // nil -> crypto/rand.Reader
	if err != nil {
		return nil, fmt.Errorf("failed to generate device keypair: %w", err)
	}
	return &Identity{
		ServerURL:    serverURL,
		PublicKeyB64: base64.StdEncoding.EncodeToString(pub),
		privateKey:   priv,
	}, nil
}

// Save persists the identity: the private key to its own 0600 file, and the
// rest (server URL, device ID, public key) to a companion metadata file.
func Save(id *Identity) error {
	dir, err := serverDir(id.ServerURL)
	if err != nil {
		return err
	}

	keyPath := filepath.Join(dir, "device.key")
	if err := os.WriteFile(keyPath, id.privateKey, 0o600); err != nil {
		return fmt.Errorf("failed to write device key: %w", err)
	}

	metaPath := filepath.Join(dir, "identity.json")
	metaBytes, err := json.MarshalIndent(id, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to encode identity metadata: %w", err)
	}
	if err := os.WriteFile(metaPath, metaBytes, 0o600); err != nil {
		return fmt.Errorf("failed to write identity metadata: %w", err)
	}
	return nil
}

// Load reads back a previously-paired identity for serverURL. Returns
// ErrNotPaired if this machine has never paired against that server.
func Load(serverURL string) (*Identity, error) {
	dir, err := serverDir(serverURL)
	if err != nil {
		return nil, err
	}

	metaPath := filepath.Join(dir, "identity.json")
	metaBytes, err := os.ReadFile(metaPath)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, ErrNotPaired
		}
		return nil, fmt.Errorf("failed to read identity metadata: %w", err)
	}

	var id Identity
	if err := json.Unmarshal(metaBytes, &id); err != nil {
		return nil, fmt.Errorf("failed to parse identity metadata: %w", err)
	}

	keyPath := filepath.Join(dir, "device.key")
	keyBytes, err := os.ReadFile(keyPath)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, ErrNotPaired
		}
		return nil, fmt.Errorf("failed to read device key: %w", err)
	}
	if len(keyBytes) != ed25519.PrivateKeySize {
		return nil, fmt.Errorf("device key file is corrupt (unexpected size)")
	}
	id.privateKey = ed25519.PrivateKey(keyBytes)

	return &id, nil
}

// List returns every server this machine has ever paired against, for the
// `pam-agent devices` command.
func List() ([]string, error) {
	base, err := baseDir()
	if err != nil {
		return nil, err
	}
	serversDir := filepath.Join(base, "servers")
	entries, err := os.ReadDir(serversDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}

	var servers []string
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		metaPath := filepath.Join(serversDir, e.Name(), "identity.json")
		metaBytes, err := os.ReadFile(metaPath)
		if err != nil {
			continue
		}
		var id Identity
		if json.Unmarshal(metaBytes, &id) == nil {
			servers = append(servers, id.ServerURL)
		}
	}
	return servers, nil
}
