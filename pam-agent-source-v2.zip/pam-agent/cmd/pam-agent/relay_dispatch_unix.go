//go:build darwin || linux

package main

func cmdRelayDispatch(args []string) error { return cmdRelay(args) }
