// pam/internal/services/mfa_enabled_flag_test.go
//
// users.mfa_enabled is a denormalised copy of "this account holds an active
// second factor". It is what an ADMINISTRATOR sees: the Sign-in posture card
// on the identity detail page reads it, and so does the identity graph.
//
// The person enrolling never sees it, because their own screens read the
// device table directly. That is what let it stay broken: enrolment wrote
// pam_mfa and never touched the column, the admin reset was its only writer,
// and the only value it ever wrote was false. Every account in the install
// therefore read as "Not set up" to an admin, including accounts that had just
// enrolled.
//
// These pin both edges of the flag so it cannot drift from the device again.
package services

import (
	"testing"

	"github.com/yourorg/pam/internal/models"
)

func TestEnrolmentSetsTheAdminVisibleMFAFlag(t *testing.T) {
	db := newAuthTestDB(t)
	_, user, _ := newActivatedMFAUser(t, db)

	var fresh models.User
	if err := db.Where("user_id = ?", user.UserID).First(&fresh).Error; err != nil {
		t.Fatalf("reload user: %v", err)
	}
	if !fresh.MFAEnabled {
		t.Fatal("an account that has just completed enrolment must read as enrolled to an administrator")
	}

	// And the device really is active, so the flag is not just optimistic.
	var mfa models.PAMMFA
	if err := db.Where("user_id = ?", user.UserID).First(&mfa).Error; err != nil {
		t.Fatalf("reload mfa: %v", err)
	}
	if mfa.Status != "ACTIVE" {
		t.Fatalf("expected an ACTIVE device alongside the flag, got %q", mfa.Status)
	}
}

// The flag must not be written for an enrolment that never completed.
func TestPendingEnrolmentDoesNotSetTheFlag(t *testing.T) {
	db := newAuthTestDB(t)
	auth, user, _ := newActivatedMFAUser(t, db)

	// A second initiate leaves a PENDING device and must not, on its own,
	// change what an administrator is told.
	if _, err := auth.SetupMFAInitiate(user.UserID, user.Email); err != nil {
		t.Fatalf("SetupMFAInitiate: %v", err)
	}
	if err := db.Model(&models.User{}).Where("user_id = ?", user.UserID).
		Update("mfa_enabled", false).Error; err != nil {
		t.Fatalf("reset flag for the test: %v", err)
	}

	var fresh models.User
	if err := db.Where("user_id = ?", user.UserID).First(&fresh).Error; err != nil {
		t.Fatalf("reload user: %v", err)
	}
	if fresh.MFAEnabled {
		t.Fatal("a PENDING device must not report as enrolled")
	}
}
