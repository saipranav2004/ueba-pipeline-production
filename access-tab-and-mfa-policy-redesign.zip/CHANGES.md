# Identity Access tab + MFA Policy redesign

Apply on top of the previous zips — `mfa_policy.go`, `mfa_policy_handler.go`,
`mfa_policy_test.go`, `MfaPolicyPage.jsx`, `mfaPolicy.js` and the two identity
pages are all edited again here.

```
frontend/src/pages/admin/IdentityListPage.jsx    roles column removed, filter kept
frontend/src/pages/admin/IdentityDetailPage.jsx  Access tab redesigned
frontend/src/pages/admin/MfaPolicyPage.jsx       rebuilt from scratch
frontend/src/lib/mfaPolicy.js                    phase-in model + helpers
backend/internal/services/identity_delegation.go usernames on the delegation record
backend/internal/services/mfa_policy.go          enforce_from (cutover date)
backend/internal/services/mfa_policy_test.go     +7 cases for the cutover
backend/internal/api/handlers/mfa_policy_handler.go  accepts enforce_from
```

---

## Task 1

### Roles column gone, Role filter intact

The column is removed from `COLUMNS` (so it also leaves the column chooser),
along with its header, colgroup entry and cell. The **filter still works**, and
so does the CSV export — both read roles from the same hydration query, which
is why that query survives even though nothing renders a role chip any more.

Two roles never fitted in that column anyway; the truncated "+2" told the
reader nothing they could act on. "Show me the admins" was always the useful
half.

### "Granted by" now shows a username

This was a backend gap, not a display bug: `AdminDelegation` only ever carried
the actor's **UUID**. It now carries `delegated_by_username` and
`revoked_by_username` alongside the IDs, resolved in one query, and a deleted
operator degrades to the ID rather than blanking the record. The console needed
no change — its delegation normaliser already prefers the `*_username` fields.

`revoked_by` and `revoke_reason` were not returned at all before, so a revoked
delegation displayed empty fields. Both are returned now.

### Access tab redesigned

The old tab answered every question in a full sentence — a six-row definition
list for the delegation, a paragraph under each grant control, an explanatory
line under every card. All true, none of it read.

* **Delegation** is now a four-column fact grid (granted by / granted /
  expires / scope) with the reason on its own row — one glance instead of six
  stacked rows. The primary action moved into the card header.
* **Roles and policies** share a tighter card: 7×7 icon tile, name, one meta
  chip, a one-line description that truncates, and an action that fades in on
  hover. Rows are ~30% shorter.
* **Helper text** is one short line per card, inline beside the control and
  hidden below `xl`, instead of one paragraph per control. Everything that was
  not load-bearing became a `title` tooltip.
* Long empty-state paragraphs became single sentences.

Nothing was removed from the model — only from the screen.

## Task 2

### Why grace hours only? — it isn't any more

Fair question, and the honest answer was "because I only built the relative
one". Operators think in **both** units, so both now exist:

| | Meaning | Right for |
|---|---|---|
| `grace_hours` | relative, per account, from when it first falls under the rule | a standing rule that keeps catching new joiners |
| `enforce_from` | absolute — one instant for the whole role | a planned cutover you can put in an announcement email |

Either, both, or neither. **With both set the later deadline wins**, so neither
half can quietly cancel a window the other promised. Covered by 7 new tests
(future cutover doesn't block, past cutover does, ignored when enrolled, inert
on a monitor rule, latest-of-two-roles wins, and the no-phase-in path is
unchanged).

### MFA Policy page rebuilt

Structured around the order the work actually happens in.

**1. Coverage** — four KPI cards, led by a **Protected %** with a progress bar,
ending with **Blocked at next sign-in**, the number that decides whether it is
safe to press Save. Tone follows the value: green at 100%, red when anyone
would be locked out. When nothing is gated yet, a single "start with admin in
Monitor" card replaces the wall of zeros.

**2. Rules** — one row per role: mode pill, roll-out in three words ("2d
grace", "from 12 Sep"), and a **members bar** showing `4/6 protected` with `2
at risk`. Gated roles sort to the top. Editing opens a **focused dialog**
instead of expanding the row — choosing an enforcement mode deserves the whole
screen, and an inline form pushed every other role out of view while the reader
was thinking.

**3. Who is affected** — the compliance table, now with **search**, a
**segmented filter** carrying live counts (All / Not compliant / Gated / Not
gated) and **pagination** at 10 per page, via the same `useTableState` +
`Pagination` the rest of the console uses.

**The rule editor** replaces three form fields with two decisions, each a row
of selectable cards that state their own consequence: *Monitor / Enforce / Off*,
then *Immediately / After a grace period / From a set date* (only when
enforcing, since the others cannot block). A live impact line reads "3 of 5
members have no second factor — they will be restricted at their next sign-in",
computed for the mode being **chosen**, not the one stored.

---

## Verification

- `go build ./...`, `go vet ./...`, `go test ./...` clean — 20 policy cases now
- `npm run lint` clean (same 4 pre-existing), `npm run build` passes
- 20 runtime assertions over the new phase-in helpers, including the
  datetime-local ↔ RFC3339 round trip and the "from Invalid Date" guard
