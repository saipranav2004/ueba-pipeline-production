# Roles filter, Access tab redesign, and the new role model

Extract at the project root — all paths are `src/...`.

```
src/config/constants.js                      (edited)  the role model
src/lib/roles.js                             (NEW)     reading roles off any payload
src/api/identity.js                          (edited)  delegation grants `admin`
src/pages/admin/IdentityListPage.jsx         (edited)  bug #34
src/pages/admin/IdentityDetailPage.jsx       (edited)  Access tab redesign
src/components/admin/CreateUserModal.jsx     (edited)  create-time role rules
src/components/admin/DelegateAdminModal.jsx  (edited)  copy: subadmin → admin
```

Verified: `npm run lint` clean (only the 4 pre-existing issues in `nav.js`,
`useMfaStatus.js` and `validators.js`), `npm run build` passes, and ~90 runtime
assertions over the role rules and payload parsing pass.

---

## 1. Bug #34 — the Roles filter on the Identity page

The filter logic was never wrong. The **data** was: the list endpoint does not
return roles, so every row read as "no role assigned", the facet counts were all
zero, and filtering by any role matched nobody — while the same account opened
from that list showed its role correctly, because the detail endpoint reports
access separately. Two causes hide behind that one symptom, and both are fixed:

**a. The roles arrive under another name.** `src/lib/roles.js` now reads
`roles`, `role_names`, `roleNames`, `assigned_roles`, `user_roles`,
`effective_roles` and a singular `role`, accepting arrays of strings, arrays of
Role objects, a single object, or a comma-separated string.

**b. The list genuinely carries no roles.** No parsing invents them, so the page
**hydrates** them from the account endpoint: when no row in the payload has any
role data, it fetches each account's access in batches of 8, merges the result
into the rows, and caches it for a minute. The column, the facet counts, the
filter, the sort and the CSV export all read the same `roles` field, so filling
it in fixes all five at once.

Bounded on purpose: above 120 accounts it does not fire at all — the Role filter
is disabled with the reason in its tooltip instead of firing hundreds of
requests behind one page load.

The three states are now distinguishable, which they were not before:

| State | Column | Filter |
|---|---|---|
| Roles known | the role chips | works |
| Being fetched | subtle skeleton | disabled, "Loading roles…" |
| Not knowable here | `—` (not "None") | disabled, with the reason |

`—` is a claim about the screen. `None` is a claim about the account. The old UI
said "None" for both, which is what made this look like a data bug.

## 2. The role model — subadmin gone, one root, delegation only

`subadmin` is removed everywhere. Delegation grants plain **`admin`** through
the same endpoints, so `SYSTEM_ROLES` is back to `root, admin, user`.
`normalizeDelegation` still prefers whatever role the API reports and only falls
back to `admin`, so a future rename needs no frontend change.

The rules are now two exported functions, and every surface reads them:

* **Access tab → `isAssignableRoleName`** — custom roles only. No system role is
  offered, to anyone. This is *not* a per-viewer gate any more: custom roles
  carry no administrative privilege, so a non-root admin and root see the same
  list. Administrative access has exactly one door — the delegation panel.
* **Create user → `canCreateWithRoleName`** — `user` (the default) plus custom
  roles. Never `admin`, never `root`. Checked before the account is created, so
  a blocked role can't leave a half-created account behind.

A role the catalogue itself marks `is_system: true` is excluded from the
dropdown as well, whatever it is called.

**System roles are read-only on the Access tab.** They render as locked rows
carrying the reason, instead of a Remove button that would fail:

| Role | Row action |
|---|---|
| `root` | locked — "Root owns the install and cannot be changed from the console." |
| `admin` | **Revoke** (root only, while a delegation is active) — otherwise locked, pointing at the panel above |
| `user` | locked — "Set when the account was created." |
| custom | **Remove** |

This closes a trap in the previous build: `user` was removable but not
re-assignable, so removing it stranded the account with no way back from the UI.

Both role mutations re-check the rule before calling the API, so a stale control
cannot fire a request the model forbids.

## 3. Access tab — redesigned

Rebuilt as one system rather than two ad-hoc cards. Roles and policies do the
same job, so they share a shell (`GrantCard`), a row (`GrantRow`) and a footer
control (`GrantFooter`) — one set of states, one visual language.

* **Summary strip** opens the tab: Privilege / Roles / Direct policies as three
  tiles. Privilege comes first and is accented when the account is
  administrative, because that is the question an auditor opens this tab to ask.
  It reads *Root*, *Administrator* or *Standard*, with the delegation's own
  expiry underneath when there is one.
* **Administrative access** panel keeps its place, restyled to match, and reads
  `admin` now rather than `subadmin`.
* **Cards** get an icon tile, a live count chip, and their RBAC/PBAC marker
  right-aligned with the section link.
* **Rows** get a leading icon tile (crown for root, shield for system, tag for
  custom), the role chip, a System/Custom marker, the role's own description,
  and a row action that sits at 60% opacity until hover or keyboard focus — so
  twelve grants don't read as a wall of buttons.
* **The grant footer always renders** and always says which of its five states
  it is in: loading, failed (with Retry), no custom roles defined yet (with a
  link to create one), everything already assigned, or ready. A control that
  silently disappears is indistinguishable from a broken one — which is how the
  old one was read.
* Every card carries a one-line hint explaining what is *not* on offer, so an
  absent option is never mistaken for a missing feature.
