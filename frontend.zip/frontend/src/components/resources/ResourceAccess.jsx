import { useCallback, useEffect, useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import clsx from 'clsx'
import {
  Laptop,
  Globe,
  AlertCircle,
  KeyRound,
  Square,
  CheckCircle2,
  Copy,
  Check,
  ShieldAlert,
  Download,
  Loader2,
} from 'lucide-react'
import { toast } from 'sonner'
import { getConnectInfo, startSession } from '../../api/resources'
import { ChannelControls } from './ChannelControls'
import { endSession } from '../../api/sessions'
import { createLaunch, getLaunchStatus, isNotPairedError, listAgentDevices } from '../../api/agent'
import {
  NOT_PAIRED_MESSAGE,
  matchThisDevice,
  capabilityFor,
  missingToolMessage,
  recordingRefusal,
} from '../../lib/agentDevice'
import { startWebSession, listMyWebSessions, endWebSession } from '../../api/webSessions'
import { normalizeApiError, apiErrorMessage } from '../../lib/apiError'
import { Button } from '../common/Button'
import { Card, CardHeader, CardTitle } from '../common/Layout'
import { Spinner } from '../common/Spinner'
import { PairAgentPanel } from '../agent/PairAgentPanel'

// ---------------------------------------------------------------------------
// Resource access launcher
// ---------------------------------------------------------------------------
// WHAT THIS REPLACES. The detail page used to hide connecting behind a
// "Connect" tab that opened a panel of loose <button>s, a dl of host/port, a
// "Start tracked session" and an "Open in Desktop App", none of which came
// from the console's button system. So the single most important thing a
// non-admin comes to this page to DO was two clicks deep, and looked like a
// debug panel when they got there.
//
// HOW ENTERPRISE PAM CONSOLES ACTUALLY SHAPE THIS, and what we took:
//   · CyberArk PVWA puts "Connect" as the primary object action with the
// client choice (RDP file / PSM web / native) as siblings under it. We
// take the three-way client choice.
//   · Delinea Secret Server surfaces the launcher as the object's own header
// action, not a tab. We take that placement.
//   · AWS Systems Manager and GCP both show a role-appropriate surface: an
// operator gets "Connect" and nothing else; an owner gets the whole
// configuration object. We take the ROLE SPLIT, a non-admin sees the
// four facts that decide whether they can connect, and the three ways to
// connect. Nothing else, because nothing else is theirs to act on.
//
// Three launch paths, and the honest difference between them:
//
//   OPEN IN DESKTOP , hands off to the already-installed pam-agent via a
// signed single-use pam-agent:// URL. This is the real
// brokered path and is therefore the primary action.
//   OPEN IN CLI     , opens a TRACKED session row (audit + JIT expiry) and
// reveals the exact command for the user's own client.
//                      There is no server-side proxy on this backend, so
// pretending to be a terminal would be a lie; giving the
// correct command and recording the session is not.
//   OPEN IN WEB     , the BROKERED browser path. PAM performs the target
// application's own login SERVER-SIDE and reverse-proxies
// it, so the operator lands in the app already
// authenticated and the credential never reaches their
// browser at all. The session is bound, recorded, and
// killable like any other.
//   OPEN CONSOLE    , the resource's registered console URL, unbrokered. This
// opens the app's OWN login page and leaves the operator to
// authenticate themselves: no PAM session binding, no
// activity trail, no kill switch, and a credential they now
// know. Shown only when the brokered path is unavailable,
// because offering both side by side invites the wrong one.
//
// A NOTE ON A COMMENT THAT USED TO BE HERE. This file previously said "there
// is no server-side proxy on this backend, so pretending to be a terminal
// would be a lie". That was true when it was written and is not any more:
// internal/webproxy is exactly that proxy. OPEN IN WEB above is it, and it is
// the reason the raw console link has been demoted rather than removed.

const CLI_HINTS = {
  postgresql: (i) =>
    `psql -h ${i.host} -p ${i.port}${i.database_name ? ` -d ${i.database_name}` : ''} -U <username>`,
  mongodb: (i) => `mongosh "mongodb://${i.host}:${i.port}${i.database_name ? `/${i.database_name}` : ''}"`,
  redis: (i) => `redis-cli -h ${i.host} -p ${i.port}`,
  clickhouse: (i) => `clickhouse-client --host ${i.host} --port ${i.port}`,
  mysql: (i) =>
    `mysql -h ${i.host} -P ${i.port}${i.database_name ? ` -D ${i.database_name}` : ''} -u <username> -p`,
  ssh: (i) => `ssh <username>@${i.host} -p ${i.port}`,
}

// EXPORTED so the resources table's own connect menu builds its command from
// the same map. A second copy in another file is a second map, and the two
// drift the first time a resource type is added to one of them.
//
// NOTE THE KEY. connect-info returns the resource type as `type`, not
// `resource_type`. The catalogue row and the connect payload spell it
// differently, and reading the wrong one silently falls through to the
// host:port default for every resource.
export function cliCommand(info) {
  if (!info) return null
  return CLI_HINTS[info.type]?.(info) || `${info.host}:${info.port}`
}

// True when the command above is a real client invocation rather than the
// bare endpoint fallback. The menu uses it to label the action honestly.
export function hasCliClient(info) {
  return !!info && !!CLI_HINTS[info.type]
}

// ---------------------------------------------------------------------------
// Shared launch logic
// ---------------------------------------------------------------------------
// Exported so the page header's primary "Open in Desktop" button and the
// panel's own copy of it drive the identical mutation, one code path, so the
// pairing flow and the 409 handling can't diverge between the two entry
// points.
// How long to keep asking what became of a launch.
//
// The window has to outlast a cold agent start (the OS resolves the
// pam-agent:// handler, the binary starts, it signs and redeems the token)
// without leaving a spinner on screen when nothing is listening at all. The
// launch token's own lifetime is the real ceiling: once it expires unredeemed
// the backend reports "expired", which IS the answer, so polling past that
// point learns nothing new.
const LAUNCH_POLL_MS = 1200
const LAUNCH_POLL_TIMEOUT_MS = 45000
// How long to keep watching after the agent has opened the launch. Covers
// the agent's own hand-off check (the app exiting within 8 s of spawn, which
// comes after pgAdmin's few-second server import).
const OPENED_GRACE_MS = 25000

// Two refusals this hook raises itself, before any request is made. Classes
// rather than sentinel strings so onError can branch without parsing English.
class NotThisDeviceError extends Error {
  constructor() {
    super(NOT_PAIRED_MESSAGE)
    this.name = 'NotThisDeviceError'
  }
}

class ToolMissingError extends Error {
  constructor(message) {
    super(message)
    this.name = 'ToolMissingError'
  }
}

export function useDesktopLaunch(
  resourceId,
  { onNeedsPairing, onLaunchState, resourceType, recordingRequired } = {}
) {
  // A ref, not state: the poll loop must not restart on re-render, and
  // nothing renders from it directly.
  const pollRef = useRef(null)

  // THE PRE-FLIGHT THIS HOOK EXISTS AROUND.
  //
  // Without it the only question anybody asked was "does this account have a
  // paired device", which the server answers with a 409 — so an operator who
  // had ever paired ANY machine got "Handing off to the desktop agent" on
  // every other machine they ever signed in from, and then silence.
  //
  // Devices are cheap and change rarely, so this is fetched once and shared
  // with every other consumer of the same key rather than being asked for at
  // click time, when a round trip would sit between the gesture and the
  // handoff (and would also cost the popup-blocker grace the browser gives a
  // user-initiated navigation).
  const devicesQuery = useQuery({
    queryKey: ['agent', 'devices'],
    queryFn: ({ signal }) => listAgentDevices(signal),
    staleTime: 30_000,
    retry: false,
  })
  const devices = devicesQuery.data?.devices

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearTimeout(pollRef.current.timer)
      pollRef.current.cancelled = true
      pollRef.current = null
    }
  }, [])

  // Stop when the component goes away, or an unmounted panel keeps asking the
  // backend about a launch nobody is looking at.
  useEffect(() => stopPolling, [stopPolling])

  const pollLaunch = useCallback(
    (launchId) => {
      stopPolling()
      const ctl = { cancelled: false, timer: null, startedAt: Date.now() }
      pollRef.current = ctl

      const tick = async () => {
        if (ctl.cancelled) return
        try {
          const status = await getLaunchStatus(launchId)
          if (ctl.cancelled) return
          onLaunchState?.(status)
          if (status.state === 'failed') {
            toast.error(status.failure_reason || 'The desktop agent could not open this resource.')
            stopPolling()
            return
          }
          // EXPIRED IS AN ANSWER, NOT A TIMEOUT. The handoff window closed
          // without any agent redeeming it, which in practice means no agent
          // is installed or running on this machine — exactly the case the
          // pre-flight above could not rule out. Saying so here is what
          // closes the gap for the ambiguous state without refusing the
          // operators the pre-flight would have wrongly blocked.
          if (status.state === 'expired') {
            toast.error(NOT_PAIRED_MESSAGE)
            onNeedsPairing?.()
            stopPolling()
            return
          }
          // completed is final. opened is final too, but only after a short
          // grace period: a desktop application that was already open hands
          // over to that window and exits within seconds, and the agent then
          // reports the launch as failed with what to do about it. Stopping
          // at the first 'opened' left the operator reading "Opened on your
          // machine" for a session that never happened.
          if (status.state === 'opened') {
            ctl.openedAt = ctl.openedAt || Date.now()
            if (Date.now() - ctl.openedAt > OPENED_GRACE_MS) {
              stopPolling()
              return
            }
          } else if (status.state !== 'waiting') {
            stopPolling()
            return
          }
        } catch {
          // A failed poll is not a failed launch. The operator's session may
          // be opening perfectly well and only the reporting channel is
          // unavailable, so keep trying until the window closes.
        }
        if (ctl.cancelled) return
        // The overall window bounds the wait for an agent; once one has
        // opened the launch, the grace period above is what ends the poll.
        if (!ctl.openedAt && Date.now() - ctl.startedAt > LAUNCH_POLL_TIMEOUT_MS) {
          stopPolling()
          return
        }
        ctl.timer = setTimeout(tick, LAUNCH_POLL_MS)
      }
      ctl.timer = setTimeout(tick, LAUNCH_POLL_MS)
    },
    [onLaunchState, stopPolling]
  )

  const mutation = useMutation({
    // `channel` is what the operator actually clicked — 'cli' or 'desktop'.
    // It is passed to the server, stamped on the launch token, and BINDING on
    // the agent: a missing terminal client now fails with a remedy instead of
    // quietly opening a desktop app. ('web' never reaches here; a brokered
    // web session needs no agent and goes through useWebSessionLaunch.)
    mutationFn: async (channel) => {
      // Refused here rather than by the server, because the server cannot see
      // which machine the browser is on — it only knows whether the ACCOUNT
      // has a device. See lib/agentDevice.js for what is certain and what is
      // a guess; only the certain cases refuse.
      const match = matchThisDevice(devices)
      if (match.state === 'none' || match.state === 'other') {
        throw new NotThisDeviceError()
      }

      // Second pre-flight: the machine is plausible, but does it have a tool
      // that can open this KIND of resource? The agent reports what it found
      // when it paired, and refreshes it on every launch. Unknown is not a
      // refusal — an agent too old to report, or a resource type it has no
      // template for, falls through and lets the launch produce the agent's
      // own, more precise failure.
      // Only meaningful for the desktop channel. The server now answers
      // availability per channel (GET /resources/:id/channels) and the
      // controls are disabled from that, so this is a backstop for the case
      // where the control was rendered before the answer arrived — not the
      // primary gate it used to be.
      const capability = capabilityFor(match.device, resourceType)
      if (channel === 'desktop' && capability.known && capability.desktopToolMissing) {
        throw new ToolMissingError(missingToolMessage(resourceType, capability))
      }

      // Third pre-flight, about RECORDING rather than the machine: the agent
      // refuses a launch it cannot capture when the resource demands one, so
      // the console names the reason instead of letting the launch fail.
      const refusal = recordingRefusal({ device: match.device, resourceType, recordingRequired })
      if (refusal) throw new ToolMissingError(refusal)

      return createLaunch(resourceId, channel)
    },
    onSuccess: (data) => {
      // NOT a success toast, and that is the whole point of this change.
      // Nothing has succeeded yet: the browser has handed a URL to the OS and
      // has no idea whether anything picked it up. Claiming success here is
      // what made a machine with no agent look like a machine that had one.
      // If nothing redeems the handoff, the poll below says so for real.
      toast.message('Opening on this device…', {
        description: 'If nothing opens, the agent is not running on this machine.',
      })
      onLaunchState?.({ state: 'waiting', launch_id: data.launch_id })
      // launch_id is absent on a backend older than this feature. Navigate
      // anyway: the handoff is what matters, and losing the progress report
      // is the old behaviour rather than a new failure.
      if (data.launch_id) pollLaunch(data.launch_id)
      window.location.href = data.launch_url
    },
    onError: (err) => {
      // Refused before any request left the browser.
      if (err instanceof NotThisDeviceError) {
        toast.error(NOT_PAIRED_MESSAGE)
        onNeedsPairing?.()
        return
      }
      if (err instanceof ToolMissingError) {
        toast.error(err.message)
        return
      }
      const normalized = normalizeApiError(err)
      // Policy said no. Distinct from every device-side refusal above,
      // because nothing the operator installs will change it.
      if (normalized.status === 403 && normalized.code === 'channel_not_allowed') {
        toast.error('This resource may not be opened that way.', {
          description: 'An administrator has restricted which ways it can be reached.',
        })
        return
      }
      if (isNotPairedError(normalized)) {
        // The server's own version of the same refusal: this ACCOUNT has no
        // paired device. Reached when the pre-flight could not tell (an
        // empty or failed device fetch), so it stays as the backstop.
        toast.error(NOT_PAIRED_MESSAGE)
        onNeedsPairing?.()
        return
      }
      toast.error(normalized.message)
    },
  })

  return { ...mutation, stopPolling, devices, deviceMatch: matchThisDevice(devices) }
}

// Brokered web sessions, the counterpart to useDesktopLaunch above.
//
// Exported for the same reason: the page header's button and the panel's own
// copy must drive one mutation, so the popup handling and the error mapping
// cannot drift apart between two entry points.
export function useWebSessionLaunch(resourceId) {
  const queryClient = useQueryClient()

  return useMutation({
    // The tab is opened SYNCHRONOUSLY, before the request, and only pointed at
    // launch_url once it returns. Calling window.open() from onSuccess would be
    // a popup outside a user gesture that has already ended, which browsers
    // block, and the handoff token expires in about 30 seconds, so there is no
    // second attempt.
    //
    // A separate tab is also what makes the session's lifecycle correct: PAM
    // detects a closed tab and ends the session, finalising its recording, so
    // "close the tab when you are done" is a real end-of-session action.
    mutationFn: async () => {
      // No 'noopener' here, deliberately: with that flag window.open returns
      // null by specification, leaving nothing to point at the launch URL.
      // Opener isolation is enforced instead by the Cross-Origin-Opener-Policy
      // header the proxy sets on its own responses.
      const opened = window.open('about:blank', '_blank')
      try {
        const result = await startWebSession(resourceId)
        return { result, opened }
      } catch (err) {
        try {
          opened?.close()
        } catch {
          /* a tab that never opened needs no closing */
        }
        throw err
      }
    },
    onSuccess: ({ result, opened }) => {
      queryClient.invalidateQueries({ queryKey: ['web-sessions', 'mine'] })
      if (opened && !opened.closed) {
        opened.location.href = result.launch_url
        toast.success('Opened in a new tab. Close it when you are done and the session ends.')
        return
      }
      // Popup blocked. Navigating THIS tab would take the operator out of the
      // console and make tab-close detection apply to the tab they are working
      // in, so the session would end the moment they came back.
      toast.error('Your browser blocked the new tab. Allow pop-ups for this site, then try again.', {
        duration: 10000,
      })
    },
    onError: (err) => {
      const normalized = normalizeApiError(err)
      // Each of these is a configuration answer, not a fault, and saying which
      // one stops the operator retrying a button that cannot work.
      if (normalized.code === 'connect_method_not_allowed') {
        toast.error('This resource does not permit brokered browser access.')
        return
      }
      if (normalized.code === 'web_proxy_disabled') {
        toast.error('The brokered web gateway is not enabled on this server.')
        return
      }
      if (normalized.code === 'web_proxy_upstream_login_failed') {
        toast.error(
          normalized.message || 'PAM could not sign in to the application with the stored credential.'
        )
        return
      }
      toast.error(normalized.message)
    },
  })
}

function CopyRow({ value }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="flex items-center gap-2">
      <code
        className="min-w-0 flex-1 truncate rounded-lg border border-surface-700 bg-surface-850 px-2.5 py-2 font-mono text-xs text-ink-200"
        title={value}
      >
        {value}
      </code>
      <Button
        size="sm"
        variant="secondary"
        icon={copied ? Check : Copy}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(value)
            setCopied(true)
            setTimeout(() => setCopied(false), 1600)
          } catch {
            toast.error('Clipboard unavailable in this browser')
          }
        }}
      >
        {copied ? 'Copied' : 'Copy'}
      </Button>
    </div>
  )
}

// ---------------------------------------------------------------------------
// The panel
// ---------------------------------------------------------------------------

// `compact` is read only by the parked CLI paragraph below, so it is unused
// while that block is commented out. Kept in the signature because callers
// still pass it and it comes back with the block.
// eslint-disable-next-line no-unused-vars
export function ResourceAccessPanel({ resource, resourceId, compact = false }) {
  const queryClient = useQueryClient()
  const [activeSession, setActiveSession] = useState(null)
  const [needsPairing, setNeedsPairing] = useState(false)
  const [cliOpen, setCliOpen] = useState(false)
  // What became of the last desktop launch. See LaunchOutcome: a handoff to
  // pam-agent:// is one-way, so without this the panel could not tell a
  // working session from a missing tool from a missing agent.
  const [launch, setLaunch] = useState(null)

  const connectInfoQuery = useQuery({
    queryKey: ['resources', resourceId, 'connect-info'],
    queryFn: ({ signal }) => getConnectInfo(resourceId, signal),
    retry: false,
  })

  const launchMutation = useDesktopLaunch(resourceId, {
    onNeedsPairing: () => setNeedsPairing(true),
    onLaunchState: setLaunch,
    // The resource's kind is what decides which tools could open it, so the
    // pre-flight cannot check "is a client installed" without it.
    resourceType: connectInfoQuery.data?.type,
    // always_record on the resource, or a grant that carries the obligation.
    recordingRequired:
      connectInfoQuery.data?.always_record === true ||
      connectInfoQuery.data?.recording_required === true,
  })
  const webLaunch = useWebSessionLaunch(resourceId)

  const startMutation = useMutation({
    mutationFn: () => startSession(resourceId),
    onSuccess: (data) => {
      setActiveSession(data.session)
      setCliOpen(true)
      if (data.notice) toast.info(data.notice)
      else toast.success('Session started and recorded')
      queryClient.invalidateQueries({ queryKey: ['sessions'] })
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const endMutation = useMutation({
    mutationFn: (sessionId) => endSession(sessionId),
    onSuccess: () => {
      setActiveSession(null)
      setCliOpen(false)
      toast.success('Session ended')
      queryClient.invalidateQueries({ queryKey: ['sessions'] })
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (connectInfoQuery.isLoading) {
    return (
      <Card>
        <div className="flex items-center gap-2.5 px-4 py-8 text-ink-400">
          <Spinner /> <span className="text-sm">Checking your access…</span>
        </div>
      </Card>
    )
  }

  // JIT gating is not an error state, it is the product working. It gets its
  // own plate with the one action that resolves it.
  if (connectInfoQuery.isError) {
    const err = normalizeApiError(connectInfoQuery.error)
    if (err.code === 'jit_grant_required') {
      return (
        <Card className="overflow-hidden">
          <div className="flex flex-col gap-4 border-l-[3px] border-amber-500 bg-amber-50/60 px-4 py-4 dark:bg-amber-950/15 sm:flex-row sm:items-center">
            <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-amber-100 text-amber-600 ring-1 ring-inset ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
              <KeyRound className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-amber-900 dark:text-amber-200">
                Time-boxed access required
              </p>
              <p className="mt-1 text-sm leading-relaxed text-amber-800/90 dark:text-amber-300/85">
                This resource has no standing access. Raise a just-in-time request and connect once an
                approver has granted it.
              </p>
            </div>
            <Link to={`/jit?resourceId=${resourceId}`} className="flex-none">
              <Button variant="primary" icon={KeyRound}>
                Request access
              </Button>
            </Link>
          </div>
        </Card>
      )
    }
    return (
      <Card className="overflow-hidden">
        <div className="flex items-start gap-3 border-l-[3px] border-red-500 bg-red-50/60 px-4 py-4 dark:bg-red-950/15">
          <ShieldAlert
            className="mt-0.5 h-4 w-4 flex-none text-red-600 dark:text-red-400"
            strokeWidth={1.9}
          />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-red-800 dark:text-red-200">Access check failed</p>
            <p className="mt-1 text-sm leading-relaxed text-red-700/90 dark:text-red-300/85">{err.message}</p>
          </div>
        </div>
      </Card>
    )
  }

  const info = connectInfoQuery.data
  const command = cliCommand(info)
  const hasCredential = !!info?.has_credential
  const consoleUrl = info?.console_url || resource?.console_url
  const busy = launchMutation.isPending || startMutation.isPending

  const blockedReason = !hasCredential ? 'No credential is attached to this resource yet' : undefined

  // What the SERVER says is possible right now. available_methods already
  // accounts for every precondition (a console URL, a stored credential, the
  // gateway being enabled, and the resource's connect-method policy) so a
  // button is absent rather than present-and-failing.
  const methods = Array.isArray(info?.available_methods) ? info.available_methods : []
  const canBrokerWeb = methods.includes('web_proxy')

  // The raw console link is the UNBROKERED fallback and is deliberately hidden
  // whenever the brokered path exists. Offering both side by side asks the
  // operator to know the difference between "PAM logs you in and records it"
  // and "here is the app's login page, good luck", and the wrong choice is
  // the one that leaks a credential.
  const showRawConsole = !!consoleUrl && !canBrokerWeb

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle icon={Laptop}>Connect</CardTitle>
        <span className="ml-auto flex items-center gap-1.5 text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" strokeWidth={1.9} />
          Brokered &amp; recorded
        </span>
      </CardHeader>

      <div className="px-4 py-4">
        {/* ONE CONTROL PER CHANNEL, each carrying its own true state.
            This replaced a single "Open in Desktop" that silently stood in for
            whatever happened to be installed: an operator who asked for a
            terminal and did not have one got a GUI, with nothing on screen
            saying a substitution had happened.

            The server answers both axes for every channel this resource type
            supports — allowed (policy, org-wide) and available (this
            operator's own devices) — and ChannelControls never merges them,
            because "not permitted" and "not installed" have completely
            different remedies. */}
        <ChannelControls
          resourceId={resourceId}
          busy={busy}
          blockedReason={blockedReason}
          hasCredential={hasCredential}
          pendingChannel={
            launchMutation.isPending ? launchMutation.variables : webLaunch.isPending ? 'web' : null
          }
          onOpen={(channel) => {
            // Web is brokered by the server and needs no agent at all, so it
            // takes a different path entirely. Routing it through the agent
            // launch would demand a paired device for something that does not
            // need one.
            if (channel === 'web') {
              webLaunch.mutate()
              return
            }
            launchMutation.mutate(channel)
          }}
        />

        {showRawConsole && (
          <div className="mt-3">
            <Button
              variant="ghost"
              size="sm"
              icon={Globe}
              onClick={() => window.open(consoleUrl, '_blank', 'noopener')}
              title="Opens the application's own login page. You authenticate yourself, and PAM does not broker or record it"
            >
              Open the application&apos;s own console
            </Button>
            <p className="mt-1 text-2xs leading-relaxed text-ink-500">
              Unbrokered: you sign in yourself and PAM neither injects the credential nor records the
              session.
            </p>
          </div>
        )}

        {!hasCredential && (
          <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-ink-500">
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-none" strokeWidth={1.9} />
            No credential is attached to this resource, so PAM has nothing to broker on your behalf.
            Ask an administrator to store one.
          </p>
        )}

        {showRawConsole && (
          <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-ink-500">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 flex-none" strokeWidth={1.9} />
            <span>
              <span className="font-medium text-ink-400">Open console</span> is not brokered. It opens
              the application&apos;s own sign-in page, so there is no PAM session, no activity trail and
              no kill switch. Ask an administrator to enable brokered access for this resource.
            </span>
          </p>
        )}

        {/* A tracked session is open. This is the state that matters most, so
            it gets a plate rather than a line of text. */}
        {activeSession && (
          <div className="mt-4 rounded-xl border border-emerald-600/25 bg-emerald-50/70 p-3.5 dark:bg-emerald-950/15">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="flex items-center gap-2 text-sm font-medium text-emerald-800 dark:text-emerald-300">
                <span className="relative flex h-2 w-2 flex-none rounded-full bg-emerald-500 text-emerald-500">
                  <span className="dot-live absolute inset-0 rounded-full bg-emerald-500" />
                </span>
                Session open and recording · #{String(activeSession.id).slice(0, 8)}
              </span>
              <Button
                size="sm"
                variant="secondary"
                icon={Square}
                loading={endMutation.isPending}
                onClick={() => endMutation.mutate(activeSession.id)}
              >
                End session
              </Button>
            </div>
            {cliOpen && command && (
              <div className="mt-3">
                <p className="mb-1.5 text-xs font-semibold text-emerald-800/80 dark:text-emerald-300/75">
                  Run this in your own client
                </p>
                <CopyRow value={command} />
              </div>
            )}
          </div>
        )}

        <LaunchOutcome state={launch} />

        {needsPairing && (
          <div className="mt-4">
            <PairAgentPanel
              onPaired={() => {
                setNeedsPairing(false)
                toast.success('Agent paired, opening…')
                launchMutation.mutate()
              }}
            />
          </div>
        )}

        {/* {!compact && !activeSession && command && (
          <p className="mt-4 text-xs leading-relaxed text-ink-500">
            <span className="font-medium text-ink-400">Open in CLI</span> records a session against
            this resource before showing you the connection command, so the access appears in the
            audit trail and counts against any grant expiry.
          </p>
        )} */}
      </div>
    </Card>
  )
}

// The one-line variant used in the page header. Same mutation, same pairing
// path, it just needs somewhere to put the pairing panel when a 409 comes
// back, which is why it accepts the setter rather than owning the state.
// What became of the launch, in the browser that started it.
//
// A handoff to pam-agent:// is one-way: the OS takes over and nothing comes
// back. Until the backend started recording launch outcomes there was nothing
// to render here and nothing rendered, so a missing psql, a missing agent and
// a perfectly good session all looked identical.
//
// Deliberately quiet on success. An operator whose tool just opened is looking
// at the tool, not at this page.
function LaunchOutcome({ state }) {
  if (!state) return null

  if (state.state === 'waiting') {
    return (
      <p className="mt-4 flex items-center gap-2 text-sm text-ink-400">
        <Loader2 className="h-3.5 w-3.5 flex-none animate-spin" aria-hidden="true" />
        Waiting for the desktop agent to pick this up…
      </p>
    )
  }

  // Deliberately does NOT promise that closing the tool ends the session. It
  // does for a terminal or a desktop application, where the agent is still
  // watching. It does not for a resource whose candidate opens the operator's
  // own browser: nothing can observe that tab, which is what PAM's brokered
  // web proxy exists for. The console cannot tell the two apart from here, so
  // it states only what it knows.
  if (state.state === 'opened') {
    return (
      <p className="mt-4 flex items-center gap-2 text-sm text-emerald-700 dark:text-emerald-400">
        <CheckCircle2 className="h-3.5 w-3.5 flex-none" strokeWidth={1.9} aria-hidden="true" />
        Opened on your machine.
      </p>
    )
  }

  if (state.state === 'completed') {
    return (
      <p className="mt-4 flex items-center gap-2 text-sm text-ink-500">
        <CheckCircle2 className="h-3.5 w-3.5 flex-none" strokeWidth={1.9} aria-hidden="true" />
        The session has ended.
      </p>
    )
  }

  // An expired handoff is how "no agent is installed or running here" actually
  // looks from the server: the token simply ages out untouched. Saying that
  // plainly is the difference between a diagnosable problem and a button that
  // does nothing.
  if (state.state === 'expired') {
    return (
      <LaunchProblem
        title="The desktop agent did not respond"
        detail="Nothing on this machine picked up the handoff, so the PAM agent is probably not installed or not running here."
        hint="Install the agent from Settings > Devices, then try again."
      />
    )
  }

  if (state.state === 'failed') {
    return (
      <LaunchProblem
        title="The desktop agent could not open this resource"
        detail={state.failure_reason}
        hint={state.failure_hint}
      />
    )
  }

  return null
}

function LaunchProblem({ title, detail, hint }) {
  return (
    <div className="mt-4 flex items-start gap-3 rounded-lg border-l-[3px] border-red-500 bg-red-50/60 px-3 py-3 dark:bg-red-950/15">
      <Download
        className="mt-0.5 h-4 w-4 flex-none text-red-600 dark:text-red-400"
        strokeWidth={1.9}
        aria-hidden="true"
      />
      <div className="min-w-0">
        <p className="text-sm font-semibold text-red-800 dark:text-red-200">{title}</p>
        {detail ? (
          <p className="mt-1 text-sm leading-relaxed text-red-700/90 dark:text-red-300/85">{detail}</p>
        ) : null}
        {hint ? <p className="mt-1.5 text-sm leading-relaxed text-ink-500 dark:text-ink-400">{hint}</p> : null}
      </div>
    </div>
  )
}

export function OpenInDesktopButton({
  resourceId,
  resourceType,
  recordingRequired,
  onNeedsPairing,
  className,
  size = 'md',
}) {
  const launch = useDesktopLaunch(resourceId, { onNeedsPairing, resourceType, recordingRequired })
  return (
    <Button
      variant="primary"
      size={size}
      icon={Laptop}
      className={clsx(className)}
      loading={launch.isPending}
      onClick={() => launch.mutate()}
    >
      Connect
    </Button>
  )
}

// The one-line brokered-web variant for the page header, mirroring
// OpenInDesktopButton above.
//
// Rendered only when the backend says this resource can actually be brokered
// right now: available_methods accounts for all four preconditions (a console
// URL, a stored credential, the gateway enabled server-side, and the policy
// permitting it), so the button is absent rather than present-and-failing.
export function OpenInWebButton({ resourceId, className, size = 'md' }) {
  const launch = useWebSessionLaunch(resourceId)

  const connectInfoQuery = useQuery({
    queryKey: ['resources', resourceId, 'connect-info'],
    queryFn: ({ signal }) => getConnectInfo(resourceId, signal),
    retry: false,
    // A 403 here is the JIT gate, not a transient failure; the button just
    // stays hidden and the page's own gate messaging handles it.
    throwOnError: false,
  })

  const methods = connectInfoQuery.data?.available_methods
  if (!Array.isArray(methods) || !methods.includes('web_proxy')) return null

  return (
    <Button
      variant="secondary"
      size={size}
      icon={Globe}
      className={clsx(className)}
      loading={launch.isPending}
      onClick={() => launch.mutate()}
      title="PAM signs in to the application server-side and proxies it, so the credential never reaches your browser"
    >
      Open in Web
    </Button>
  )
}

// A live brokered session for one resource, with the two actions that matter:
// go back into it, or end it.
//
// It is a separate bar rather than part of the Connect card because a brokered
// session outlives the page: the operator is working in another tab, and what
// they need on returning here is re-entry and a kill switch, not the launcher
// they already used.
export function LiveWebSessionBar({ resourceId }) {
  const queryClient = useQueryClient()
  const { data } = useQuery({
    queryKey: ['web-sessions', 'mine'],
    queryFn: ({ signal }) => listMyWebSessions(signal),
    staleTime: 10_000,
  })
  const endMutation = useMutation({
    mutationFn: (id) => endWebSession(id),
    onSuccess: () => {
      toast.success('Brokered web session ended')
      queryClient.invalidateQueries({ queryKey: ['web-sessions', 'mine'] })
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const live = (data || []).find((ws) => ws.resource_id === resourceId)
  if (!live) return null

  return (
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-600/25 bg-blue-50/70 px-3.5 py-3 dark:bg-blue-950/15">
      <span className="flex items-center gap-2 text-sm font-medium text-blue-800 dark:text-blue-300">
        <span className="relative flex h-2 w-2 flex-none rounded-full bg-blue-500">
          <span className="dot-live absolute inset-0 rounded-full bg-blue-500" />
        </span>
        Brokered web session open
        <code className="font-mono text-xs text-blue-700/80 dark:text-blue-400/80">
          #{String(live.id).slice(0, 8)}
        </code>
      </span>
      <span className="flex items-center gap-2">
        <a href={live.app_url} target="_blank" rel="noreferrer noopener">
          <Button variant="secondary" size="sm" icon={Globe}>
            Re-open
          </Button>
        </a>
        <Button
          variant="secondary"
          size="sm"
          icon={Square}
          loading={endMutation.isPending}
          onClick={() => endMutation.mutate(live.id)}
        >
          End session
        </Button>
      </span>
    </div>
  )
}
