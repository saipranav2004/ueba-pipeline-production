import { useState } from 'react'
import clsx from 'clsx'
import { ChevronDown, ChevronRight, Terminal, Laptop, Globe, Video, VideoOff } from 'lucide-react'
import { StatusIndicator } from '../common/Badge'
import { formatRelativeToNow } from '../../lib/format'
import { RESOURCE_TYPES, RESOURCE_TYPE_LABELS, RESOURCE_TYPE_CHANNELS } from '../../config/constants'

// ---------------------------------------------------------------------------
// WHAT THIS MACHINE CAN OPEN
// ---------------------------------------------------------------------------
// The agent has reported this since pairing — one entry per resource type,
// naming the tools it found and every tool it looked for and did not find,
// with the install hint from the launch template. The console has been using
// it to decide whether to grey out a button (see lib/agentDevice.js), and
// throwing the rest away: the device list showed a name, a last-seen time and
// a Revoke button, which is everything except the answer to the only question
// anyone asks about a paired machine — "why can't I open this from here?"
//
// So it is shown. An operator reads their own row to find out what to
// install; an administrator reads someone else's to answer the support
// question without asking them to run anything.
//
// STALE IN THE SAFE DIRECTION, and said out loud. The report is a snapshot
// taken when the agent last ran, not a live query — the agent is not
// resident, so there is nothing to ask at the moment this renders. A tool
// installed five minutes ago is not in here until the next launch. The
// timestamp is therefore part of the data, not decoration.

// The agent reports discovery KINDS (cli/gui/browser); the console speaks in
// CHANNELS (cli/desktop/web). Same three things, two vocabularies, and the
// mapping lives in exactly one place so a rename cannot make the two screens
// disagree.
const KIND_CHANNEL = {
  cli: { short: 'CLI', icon: Terminal },
  gui: { short: 'Desktop', icon: Laptop },
  browser: { short: 'Web', icon: Globe },
}

const KIND_ORDER = ['cli', 'gui', 'browser']

// The agent reports its launch-template IDs ("pgadmin4", "mc-shell"). Those
// are internal names; an operator knows the tools by their product names.
// Each is also tagged with the channel it serves, because the report lists
// found tools without saying which channel each one belongs to.
const TOOL_INFO = {
  psql: { label: 'psql', kind: 'cli' },
  pgadmin4: { label: 'pgAdmin 4', kind: 'gui' },
  mongosh: { label: 'mongosh', kind: 'cli' },
  'mongodb-compass': { label: 'MongoDB Compass', kind: 'gui' },
  'redis-cli': { label: 'redis-cli', kind: 'cli' },
  redisinsight: { label: 'Redis Insight', kind: 'gui' },
  sqlplus: { label: 'SQL*Plus', kind: 'cli' },
  sqlcl: { label: 'SQLcl', kind: 'cli' },
  sqldeveloper: { label: 'SQL Developer', kind: 'gui' },
  'clickhouse-client': { label: 'clickhouse-client', kind: 'cli' },
  'mc-shell': { label: 'MinIO Client (mc)', kind: 'cli' },
  'langfuse-cli': { label: 'Langfuse CLI', kind: 'cli' },
}

// Template IDs the report does not name above: the browser ones are all
// "open this URL" entries, recognisable by suffix. Anything else is shown
// under its own name rather than hidden.
function toolInfo(id) {
  if (TOOL_INFO[id]) return TOOL_INFO[id]
  if (/-(web|console|dashboard|play|app)$/.test(String(id))) return { label: null, kind: 'browser' }
  return { label: String(id), kind: 'cli' }
}

// Only the resource types PAM actually has. The agent's launch templates
// also carry keys that are not resource types — "mongodb-compass" is an
// alias entry for the Compass template, and "web" is the retired Web
// Application type — and listing those made a machine look as though it
// supported two MongoDBs and a resource type that no longer exists.
const PANEL_TYPES = new Set(RESOURCE_TYPES.map((t) => t.value))

// The one thing a "No ffmpeg" badge does not say on its own: what to
// actually run. Keyed on the device's own reported OS, because "install
// ffmpeg" means a different command on each — pointing a Windows operator
// at brew or a Linux operator at winget wastes the one click they get.
function ffmpegRemedyFor(os) {
  switch (String(os || '').toLowerCase()) {
    case 'windows':
      return 'Install ffmpeg on this machine, then open a session from it — the next session ' +
        'updates this report. winget: winget install ffmpeg (from an elevated PowerShell), or ' +
        'download a build from ffmpeg.org and add its bin folder to PATH.'
    case 'darwin':
    case 'macos':
      return 'Install ffmpeg on this machine, then open a session from it — the next session ' +
        'updates this report. With Homebrew: brew install ffmpeg.'
    case 'linux':
      return 'Install ffmpeg on this machine, then open a session from it — the next session ' +
        'updates this report. Debian/Ubuntu: apt install ffmpeg. Fedora/RHEL: dnf install ffmpeg.'
    default:
      return 'Install ffmpeg on this machine, then open a session from it — the next session ' +
        'updates this report.'
  }
}

function ChannelChip({ kind, present, tools }) {
  const meta = KIND_CHANNEL[kind]
  if (!meta) return null
  const Icon = meta.icon
  const title =
    kind === 'browser'
      ? 'Opens in the browser through PAM — nothing needs to be installed on this machine'
      : present
        ? `${meta.short}: ${tools.join(', ')}`
        : `${meta.short}: not available on this machine`
  return (
    <span
      title={title}
      className={clsx(
        'inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-2xs font-medium',
        present
          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
          : // Not a warning colour. A channel this machine does not have is
            // ordinary — most machines have one or two — and colouring every
            // absence amber makes a healthy laptop look broken.
            'border-surface-700 bg-surface-850 text-ink-500'
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {meta.short}
      {present && tools.length > 0 && (
        <span className="font-normal opacity-80">· {tools.join(', ')}</span>
      )}
    </span>
  )
}

// One resource type: which channels this machine has, with the tool behind
// each, and — only for a channel it does NOT have — what to install.
// Discovery kind -> console channel, for RESOURCE_TYPE_CHANNELS.
const KIND_TO_CHANNEL = { cli: 'cli', gui: 'desktop', browser: 'web' }

function TypeRow({ type }) {
  // Only channels PAM offers for this type (see RESOURCE_TYPE_CHANNELS).
  const offered = RESOURCE_TYPE_CHANNELS[type.resource_type]
  const isOffered = (k) => !offered || offered.includes(KIND_TO_CHANNEL[k])
  const kinds = (Array.isArray(type.kinds) ? type.kinds : []).filter(isOffered)
  const found = (Array.isArray(type.tools) ? type.tools : []).map((id) => ({ id, ...toolInfo(id) }))
  // A browser candidate is never "missing" — opening a URL needs nothing
  // installed. And a tool is only worth mentioning as missing when its
  // channel has nothing else: SQL*Plus being there makes SQLcl's absence
  // irrelevant, and saying "sql is not installed" beside a working CLI
  // chip reads like a fault.
  const missing = (Array.isArray(type.missing) ? type.missing : []).filter(
    (m) => m?.kind !== 'browser' && !kinds.includes(m?.kind) && isOffered(m?.kind)
  )
  const shownKinds = KIND_ORDER.filter((k) => kinds.includes(k) || missing.some((m) => m.kind === k))
  // One line per unavailable channel, naming the first tool that would
  // provide it and the template's own install instructions.
  const missingByKind = shownKinds
    .filter((k) => !kinds.includes(k))
    .map((k) => ({ kind: k, tool: missing.find((m) => m.kind === k) }))
    .filter((x) => x.tool)

  return (
    <div className="grid grid-cols-1 gap-x-4 gap-y-1 py-2.5 sm:grid-cols-[9rem_1fr]">
      <span className="text-xs font-medium text-ink-200">
        {RESOURCE_TYPE_LABELS[type.resource_type] || type.resource_type}
      </span>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-1.5">
          {shownKinds.map((k) => (
            <ChannelChip
              key={k}
              kind={k}
              present={kinds.includes(k)}
              tools={found.filter((t) => t.kind === k && t.label).map((t) => t.label)}
            />
          ))}
        </div>
        {missingByKind.map(({ kind, tool }) => (
          <p key={kind} className="mt-1 text-2xs leading-relaxed text-ink-500">
            <span className="font-medium text-ink-400">No {KIND_CHANNEL[kind].short} tool on this machine.</span>{' '}
            To add one, install {toolInfo(tool.id).label || tool.command || tool.id}
            {tool.install_hint ? <> — {tool.install_hint}</> : '.'}
          </p>
        ))}
      </div>
    </div>
  )
}

export function DeviceCapabilities({ device }) {
  const [open, setOpen] = useState(false)
  const caps = device?.capabilities
  const types = Array.isArray(caps?.types) ? caps.types.filter((t) => PANEL_TYPES.has(t?.resource_type)) : null

  // An agent too old to report capabilities, or one that has not run since
  // the field was added. Saying nothing here would read as "this machine can
  // open nothing", which is the opposite of what is known.
  if (!types) {
    return (
      <p className="mt-2 text-2xs leading-relaxed text-ink-500">
        This device has not reported which applications it has yet. The agent reports that each
        time a session is opened from it.
      </p>
    )
  }

  const openable = types.filter((t) =>
    (Array.isArray(t.kinds) ? t.kinds : []).some(
      (k) => !RESOURCE_TYPE_CHANNELS[t.resource_type] || RESOURCE_TYPE_CHANNELS[t.resource_type].includes(KIND_TO_CHANNEL[k])
    )
  ).length
  const canRecordDesktop = caps.screen_recorder === true
  const Chevron = open ? ChevronDown : ChevronRight

  return (
    <div className="mt-2">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="flex items-center gap-1 text-2xs font-medium text-ink-300 transition-colors hover:text-ink-100"
        >
          <Chevron className="h-3.5 w-3.5" aria-hidden="true" />
          Ready for {openable} of {RESOURCE_TYPES.length} resource types
        </button>

        {/* ffmpeg is not a detail. It is the single thing that decides
            whether a desktop session on a record-required resource can be
            opened at all — the agent refuses such a launch without it, so a
            machine missing it looks like a machine with a broken button. */}
        <StatusIndicator tone={canRecordDesktop ? 'emerald' : 'amber'}>
          {canRecordDesktop ? (
            <>
              <Video className="h-3 w-3" aria-hidden="true" /> Can record desktop sessions
            </>
          ) : (
            <span title={ffmpegRemedyFor(device.os)} className="inline-flex items-center gap-1">
              <VideoOff className="h-3 w-3" aria-hidden="true" /> Cannot record desktop sessions (ffmpeg
              not installed) — recorded desktop sessions will not open
            </span>
          )}
        </StatusIndicator>

        {device.capabilities_at && (
          <span className="text-2xs text-ink-500" title={device.capabilities_at}>
            checked {formatRelativeToNow(device.capabilities_at)}
          </span>
        )}
      </div>

      {open && (
        <div className="mt-2 divide-y divide-surface-800 rounded-lg border border-surface-700/70 bg-surface-950/40 px-3 py-1">
          {[...types]
            .sort((a, b) =>
              String(RESOURCE_TYPE_LABELS[a.resource_type] || a.resource_type).localeCompare(
                String(RESOURCE_TYPE_LABELS[b.resource_type] || b.resource_type)
              )
            )
            .map((t) => (
              <TypeRow key={t.resource_type} type={t} />
            ))}
          <p className="py-2 text-2xs leading-relaxed text-ink-500">
            Checked when a session was last opened from this machine. Anything installed since then
            shows up after the next session.
          </p>
        </div>
      )}
    </div>
  )
}
