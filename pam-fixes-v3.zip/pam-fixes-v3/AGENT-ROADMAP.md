# Making the agent better — an audit, and what the market does

Ordered by what I'd actually do first. Each says what is true today, what
changes, and how hard it really is — including the ones I think you should
*not* do.

---

## Tier 1 — close the honesty gaps (do these next)

### 1. A server-side reaper for native sessions  ·  small  ·  highest value/effort

Today `ReconcileStaleSessionsOnStartup` runs **once, at boot**. An agent that
is SIGKILLed, loses power or loses the network leaves an ACTIVE row holding a
JIT grant until someone restarts the API.

The brokered web proxy already solves this exact problem the right way — a
heartbeat plus `ReconcileExpired` registered on the sweeper. Give the native
path the same: the relay pings `/agent/session/:id/heartbeat` every ~30s, and
a sweeper closes anything silent for N minutes as `ENDED_STALE`. This is the
one case my SIGHUP fix provably cannot cover, because nothing running in the
agent process survives SIGKILL.

Roughly a day. It reuses a pattern already in your codebase.

### 2. Make "terminate" actually terminate  ·  medium  ·  security-visible

Right now the console says "Session terminated" while `psql` keeps running. Two
honest options:

**(a) Cheap and truthful — a control channel.** The heartbeat from #1 is a
round trip; let the response carry `{"revoked": true}`. The relay sees it, kills
the tool, finalises the recording. Kill takes effect within one heartbeat
(~30s). Add roughly a hundred lines on top of #1.

**(b) Correct — put PAM back in the data path.** This is what
[Teleport](https://goteleport.com/docs/reference/architecture/agents/) does:
`tsh` spins up a **local proxy** that client tools connect to, so a lock
terminates live connections almost immediately. Your agent already has the
hard parts (pty relay, guard, recorder) — a local TCP proxy for Postgres/Redis/
Mongo would mean the agent, not the target, owns the socket, and a revocation
closes it. It also turns the egress cap and DLP from *friction* into
*enforcement*, which `guard.go` is currently careful to say they are not.

Until one of these ships, **change the console's wording** — "Session marked
terminated; the operator's client may still be connected" — because the current
string claims something that is not true.

### 3. Short-lived credentials instead of long-lived injected ones  ·  medium-large

The agent receives the **plaintext standing credential**. Once handed over, it
is valid until rotated, and the operator can copy it out of their own
environment.

The industry answer is to stop handing over reusable secrets: Teleport
[issues certificates good for minutes-to-hours and relies on time rather than
revocation lists](https://goteleport.com/how-it-works/certificate-based-authentication-ssh-kubernetes/).
For your ten resource types the practical equivalents are:

- **PostgreSQL** — a per-session role with a short `VALID UNTIL`, dropped on
  session end. Or IAM auth tokens on RDS (15-minute lifetime).
- **MongoDB / Redis / ClickHouse** — an ephemeral user created at launch and
  dropped at end.
- **MinIO** — STS `AssumeRole`, which already returns short-lived keys.

You already have `rotation_connector.go` talking to these systems, so the
"create and drop a user" plumbing is half-built. Do PostgreSQL and MinIO first;
they have first-class support and cover the most sensitive targets.

### 4. Hardware-backed device keys  ·  small-medium

`keystore.go` is honest that the private key is `0600` and not encrypted. The
[recommended practice is hardware-backed storage](https://trustedcomputinggroup.org/resource/how-to-use-the-tpm-a-guide-to-hardware-based-endpoint-security/) —
TPM on Windows, Secure Enclave on macOS — rather than file permissions or
software-only wrapping like [DPAPI](https://en.wikipedia.org/wiki/Data_Protection_API)
alone. On Linux, `libsecret`/Secret Service is the realistic step.

Worth it because it changes what a stolen laptop image is worth: with a
non-exportable key, copying the file buys nothing.

---

## Tier 2 — worth doing

### 5. Agent auto-update
`CONTEXT.md` says plainly: no auto-update, re-installation is manual. With the
one-click enrolment you have, a signed manifest + "this build is old, update"
in the console is a modest addition. Do it before the fleet gets large, because
the cost of not having it grows with every install.

### 6. Prove the untested platforms
Windows ConPTY, the macOS relay, GUI capture and the WiX/pkg installers are
built and unit-tested but — per the agent's own "Known limitations" — have
never been run on their own platforms in CI. GitHub Actions gives you
`windows-latest` and `macos-latest` free. Until that exists, every Windows and
macOS release is a hope.

### 7. Recording integrity
Recordings are AES-GCM encrypted at rest, but nothing binds a recording to its
session cryptographically. You already have `pkg/auditchain` — hash-chain the
recordings the same way, so a deleted or swapped artifact is detectable.

### 8. Clipboard and egress controls are friction, not prevention
`guard.go` says this honestly, which is good. Just make sure the console says
it too: an admin who ticks "Block clipboard" should see that it applies to the
brokered paths and is best-effort on the native one. Anything else oversells a
control. (#2b is what makes them real.)

---

## Tier 3 — I would not build these

- **Blocking DevTools.** `devtoolsGuard.js` already states it is a deterrent
  and cannot be prevention. Leave it there; do not invest further.
- **A resident agent daemon just for presence.** You would take on a
  service on three OSes and a localhost port every website can probe, to
  answer a question the OS check and the expiry already answer. Only worth it
  if you are doing #2a anyway, in which case you get presence for free.
- **Your own recording format.** asciicast v2 was the right call; keep it.

---

## What is genuinely missing versus commercial PAM

Measured against what [BeyondTrust](https://www.beyondtrust.com/resources/glossary/privileged-session-management)
and [ManageEngine](https://www.manageengine.com/privileged-session-management/)
describe as table stakes for privileged session management:

| Capability | You | Gap |
|---|---|---|
| Session recording + replay | ✅ terminal, video, web | none |
| Searchable command log | ✅ | none |
| Live session monitoring (watch in progress) | ❌ | you can only replay afterwards |
| Real-time termination | ⚠️ row only | see #2 |
| Four-eyes / session approval | ✅ JIT + four-eyes | none |
| Credential injection without disclosure | ✅ brokered · ⚠️ native | see #3 |
| Automated response to risk signals | ❌ | no rules engine on live sessions |

**Live monitoring** is the one capability a buyer will ask for that you do not
have at all. With #1's heartbeat carrying the asciicast in near-real-time, an
admin could watch a session in progress — and the same channel then feeds an
automated "terminate on this pattern" rule, which is where the market is going.
That sequence — heartbeat → live view → auto-terminate — is one coherent line
of work, and #1 is its first step.

## Sources

- [Teleport agent architecture](https://goteleport.com/docs/reference/architecture/agents/)
- [Teleport certificate-based authentication](https://goteleport.com/how-it-works/certificate-based-authentication-ssh-kubernetes/)
- [TCG: how to use the TPM](https://trustedcomputinggroup.org/resource/how-to-use-the-tpm-a-guide-to-hardware-based-endpoint-security/)
- [Data Protection API (DPAPI)](https://en.wikipedia.org/wiki/Data_Protection_API)
- [BeyondTrust: privileged session management](https://www.beyondtrust.com/resources/glossary/privileged-session-management)
- [ManageEngine: privileged session management](https://www.manageengine.com/privileged-session-management/)
- [Netwrix: what is privileged session management](https://netwrix.com/en/resources/blog/what-is-privileged-session-management/)
