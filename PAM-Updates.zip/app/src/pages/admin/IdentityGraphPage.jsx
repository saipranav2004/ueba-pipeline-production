import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useSearchParams } from 'react-router-dom'
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  Controls,
  useReactFlow,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import {
  ChevronRight,
  Database,
  FileKey2,
  KeyRound,
  Maximize2,
  Minimize2,
  RotateCcw,
  Search,
  ShieldCheck,
  Share2,
  UserRound,
  X,
  Layers,
} from 'lucide-react'
import clsx from 'clsx'
import { listUsers } from '../../api/identity'
import { getMemberGraph } from '../../api/identityGraph'
import {
  LEVELS,
  buildTree,
  layout,
  pathToRoot,
  summarise,
  visibleNodes,
} from '../../lib/identityGraph'
import GraphNodeCard from '../../components/graph/GraphNode'
import { PageTitle, Stack } from '../../components/ui/layout'
import { Button } from '../../components/common/Button'
import { DeniedState, EmptyState, ErrorState, OfflineState } from '../../components/ui/states'
import { apiErrorMessage, normalizeApiError } from '../../lib/apiError'
import { formatDateTime } from '../../lib/format'
import { SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Identity graph
// ---------------------------------------------------------------------------
// "How is this account actually assembled, and what can it reach?"
//
// THE ONE DESIGN DECISION THIS PAGE IS BUILT ON: it never draws the whole
// graph. A single ordinary account returns around a hundred nodes, and a
// hundred nodes drawn at once is a hairball that answers nothing. Every
// product that does attack-path and access visualisation well collapses the
// graph and lets the reader open one branch at a time, keeping a count on the
// closed ones so nothing is silently hidden. That is the model here:
//
//   01 ACCOUNT -> 02 GRANTS -> 03 POLICIES -> 04 REACH
//
// Opening a card reveals only its own children. The branch you are reading
// stays fully lit; everything else dims rather than disappearing, so you keep
// your bearings while following a path.
//
// The colours are this console's own semantic tokens, not a second palette. A
// canvas is still part of the product, and a graph that invents its own reds
// and ambers teaches the reader that colour means something different here
// than it does on every other screen.

const nodeTypes = { identity: GraphNodeCard }

// ── Small pieces ───────────────────────────────────────────────────────────

// Screen furniture, so it behaves like screen furniture. The first version
// positioned each label at its column's x, which cannot work: the canvas pans
// and zooms underneath, so the labels drifted off their columns the moment
// anyone moved the view and the last one slid under the detail panel. This
// reports how many nodes are open at each level and never pretends to be
// anchored to the scene.
function LevelRail({ counts }) {
  return (
    <div className="pointer-events-none absolute left-3 top-3 z-10 flex items-center gap-1 rounded-lg border border-line-soft bg-surface/90 px-2 py-1.5 backdrop-blur">
      {LEVELS.map((l, i) => {
        const open = counts[l.index] > 0
        return (
          <span key={l.key} className="flex items-center gap-1">
            {i > 0 && (
              <ChevronRight
                className="h-3 w-3 flex-none text-tertiary/50"
                strokeWidth={2}
                aria-hidden="true"
              />
            )}
            <span
              className={clsx(
                'flex items-center gap-1.5 rounded px-1.5 py-0.5 transition-colors',
                open && 'bg-accent-soft'
              )}
            >
              <span
                className={clsx(
                  'text-2xs font-semibold uppercase tracking-[0.08em]',
                  open ? 'text-accent' : 'text-tertiary'
                )}
              >
                {l.label}
              </span>
              {open && <span className="tabular text-2xs font-bold text-accent">{counts[l.index]}</span>}
            </span>
          </span>
        )
      })}
    </div>
  )
}

const LEGEND = [
  { tone: 'bg-danger', label: 'Secret or full access' },
  { tone: 'bg-warn', label: 'Standing access' },
  { tone: 'bg-ok', label: 'Time boxed or deny' },
  { tone: 'bg-accent', label: 'Structure' },
  { tone: 'bg-line-strong', label: 'Informational' },
]

function Legend() {
  return (
    <div className="pointer-events-none absolute bottom-3 left-3 z-10 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-lg border border-line-soft bg-surface/90 px-3 py-2 backdrop-blur">
      {LEGEND.map((l) => (
        <span key={l.label} className="flex items-center gap-1.5 text-2xs text-secondary">
          <span className={clsx('h-2 w-2 rounded-sm', l.tone)} aria-hidden="true" />
          {l.label}
        </span>
      ))}
    </div>
  )
}

function StatTile({ icon: Icon, label, value, hint, tone }) {
  return (
    <div className="rounded-lg border border-line-soft px-3 py-2.5">
      <div className="flex items-center gap-1.5">
        <Icon className="h-3 w-3 flex-none text-tertiary" strokeWidth={1.9} />
        <span className="text-2xs font-medium text-tertiary">{label}</span>
      </div>
      <p
        className={clsx(
          'mt-1 tabular text-xl font-bold leading-none',
          tone === 'warn' ? 'text-warn' : tone === 'danger' ? 'text-danger' : 'text-primary'
        )}
      >
        {value}
      </p>
      {hint && <p className="mt-1 text-2xs leading-relaxed text-tertiary">{hint}</p>}
    </div>
  )
}

/** The right rail: the account, then whatever card is selected. */
function DetailPanel({ graph, tree, selected, onClose }) {
  const stats = useMemo(() => summarise(tree), [tree])
  const user = graph?.user || {}

  return (
    <aside className="flex h-full w-full flex-col overflow-y-auto border-l border-line bg-surface">
      <div className="flex items-start gap-3 border-b border-line-soft px-4 py-3.5">
        <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-accent-soft text-sm font-bold text-accent">
          {(user.username || '?').slice(0, 2).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-base font-bold text-primary">{user.username}</p>
          <p className="truncate text-xs text-tertiary">{user.email}</p>
        </div>
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close panel"
            className="flex h-7 w-7 flex-none items-center justify-center rounded-lg text-tertiary transition-colors hover:bg-hover hover:text-primary"
          >
            <X className="h-4 w-4" strokeWidth={1.8} />
          </button>
        )}
      </div>

      <div className="flex flex-wrap gap-x-4 gap-y-1.5 border-b border-line-soft px-4 py-2.5">
        <span className="text-xs text-secondary">
          Status <span className="font-medium text-primary">{user.status || 'Unknown'}</span>
        </span>
        <span className="text-xs text-secondary">
          MFA{' '}
          <span className={user.mfa_enabled ? 'font-medium text-ok' : 'font-medium text-warn'}>
            {user.mfa_enabled ? 'Enrolled' : 'Not set up'}
          </span>
        </span>
        {user.is_protected && <span className="text-xs text-tertiary">Protected</span>}
      </div>

      <div className="px-4 py-4">
        <h3 className="text-sm font-semibold text-primary">What this account reaches</h3>
        <p className="mt-1 text-xs leading-relaxed text-secondary">
          Counted from the branches on the canvas, so the panel and the picture can never
          disagree.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <StatTile
            icon={Database}
            label="Resources"
            value={stats.resources}
            hint={`${stats.jitGated} behind a JIT gate`}
          />
          <StatTile
            icon={KeyRound}
            label="Credentials"
            value={stats.credentials}
            hint="Can be revealed"
            tone={stats.credentials > 0 ? 'danger' : undefined}
          />
          <StatTile
            icon={ShieldCheck}
            label="Standing"
            value={stats.standing}
            hint="Reachable with no request"
            tone={stats.standing > 0 ? 'warn' : undefined}
          />
          <StatTile
            icon={FileKey2}
            label="Policies"
            value={stats.policies}
            hint={`${stats.denyPolicies} deny`}
          />
        </div>
      </div>

      {selected ? (
        <div className="border-t border-line-soft px-4 py-4">
          <p className="text-2xs font-semibold uppercase tracking-wide text-tertiary">Selected</p>
          <p className="mt-1 break-words text-sm font-semibold text-primary">{selected.label}</p>
          {selected.sublabel && (
            <p className="mt-0.5 text-xs text-tertiary">{selected.sublabel}</p>
          )}

          {selected.kind === 'policy' || selected.kind === 'direct_policy' ? (
            <div className="mt-3 space-y-3">
              {selected.meta?.description && (
                <p className="text-xs leading-relaxed text-secondary">{selected.meta.description}</p>
              )}
              <div>
                <p className="text-2xs font-semibold uppercase tracking-wide text-tertiary">
                  Actions
                </p>
                <ul className="mt-1 space-y-0.5">
                  {(selected.meta?.actions || []).map((a) => (
                    <li key={a} className="break-all font-mono text-xs text-secondary">
                      {a}
                    </li>
                  ))}
                  {(selected.meta?.actions || []).length === 0 && (
                    <li className="text-xs text-tertiary">None recorded</li>
                  )}
                </ul>
              </div>
              <div>
                <p className="text-2xs font-semibold uppercase tracking-wide text-tertiary">
                  Resource patterns
                </p>
                <ul className="mt-1 space-y-0.5">
                  {(selected.meta?.patterns || []).map((p) => (
                    <li key={p} className="break-all font-mono text-xs text-secondary">
                      {p}
                    </li>
                  ))}
                  {(selected.meta?.patterns || []).length === 0 && (
                    <li className="text-xs text-tertiary">
                      None. This policy matches nothing on its own.
                    </li>
                  )}
                </ul>
              </div>
            </div>
          ) : selected.kind === 'resource' ? (
            <dl className="mt-3 space-y-1.5">
              {[
                ['Type', selected.sublabel],
                ['Access', selected.badge],
                ['JIT gated', selected.meta?.requiresJit ? 'Yes' : 'No'],
                ['Always recorded', selected.meta?.alwaysRecord ? 'Yes' : 'No'],
                ['Active', selected.meta?.active ? 'Yes' : 'No'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3">
                  <dt className="text-xs text-tertiary">{k}</dt>
                  <dd className="text-xs font-medium text-primary">{v}</dd>
                </div>
              ))}
              {selected.meta?.standing && (
                <p className="mt-2 rounded-lg border border-warn/40 bg-warn-soft px-2.5 py-2 text-xs leading-relaxed text-primary">
                  Standing access. This account can connect right now, with nothing to request and
                  nobody to approve.
                </p>
              )}
            </dl>
          ) : selected.kind === 'credential' ? (
            <p className="mt-3 rounded-lg border border-danger/40 bg-danger-soft px-2.5 py-2 text-xs leading-relaxed text-primary">
              A policy on this account can reveal this credential in plaintext. Revealing a secret
              is the most damaging single call the product exposes.
            </p>
          ) : selected.meta?.description ? (
            <p className="mt-3 text-xs leading-relaxed text-secondary">
              {selected.meta.description}
            </p>
          ) : null}
        </div>
      ) : (
        <div className="border-t border-line-soft px-4 py-4">
          <p className="flex items-start gap-2 text-xs leading-relaxed text-secondary">
            <Share2 className="mt-0.5 h-3.5 w-3.5 flex-none text-tertiary" strokeWidth={1.9} />
            <span>
              Open one branch at a time. Each card reports how much sits underneath it, so a closed
              branch is never hidden, only folded.
            </span>
          </p>
        </div>
      )}

      {graph?.built_at && (
        <p className="mt-auto border-t border-line-soft px-4 py-3 text-2xs leading-relaxed text-tertiary">
          Built {formatDateTime(graph.built_at)} from live identity records.
        </p>
      )}
    </aside>
  )
}

// ── Canvas ─────────────────────────────────────────────────────────────────

function Canvas({ tree, expanded, onToggle, selectedId, onSelect }) {
  const { fitView } = useReactFlow()

  const nodes = useMemo(() => visibleNodes(tree, expanded), [tree, expanded])
  const positions = useMemo(() => layout(nodes), [nodes])

  // The lit branch: root down to whatever is selected. Used to keep one path
  // at full strength while the rest recedes.
  const lit = useMemo(() => new Set(selectedId ? pathToRoot(tree, selectedId) : []), [tree, selectedId])

  const rfNodes = useMemo(
    () =>
      nodes.map((n) => ({
        id: n.id,
        type: 'identity',
        position: positions.get(n.id) || { x: 0, y: 0 },
        draggable: false,
        selectable: true,
        data: {
          ...n,
          selected: n.id === selectedId,
          onLit: lit.has(n.id),
          dimmed: lit.size > 0 && !lit.has(n.id),
        },
      })),
    [nodes, positions, selectedId, lit]
  )

  const rfEdges = useMemo(
    () =>
      nodes
        .filter((n) => n.parentId)
        .map((n) => {
          const onPath = lit.has(n.id) && lit.has(n.parentId)
          return {
            id: `${n.parentId}->${n.id}`,
            source: n.parentId,
            target: n.id,
            type: 'smoothstep',
            // Only the lit branch animates. Animating every edge is how a
            // canvas turns into a screensaver: motion stops meaning anything
            // once it is everywhere.
            animated: onPath,
            style: {
              stroke: onPath ? 'rgb(var(--accent))' : 'rgb(var(--border))',
              strokeWidth: onPath ? 2 : 1.25,
              strokeDasharray: onPath ? '6 5' : undefined,
              opacity: lit.size > 0 && !onPath ? 0.35 : 1,
              transition: 'stroke 200ms ease, opacity 200ms ease',
            },
          }
        }),
    [nodes, lit]
  )

  // Refit when the visible set changes, so opening a branch never leaves the
  // new cards off screen. Deferred a frame so React Flow measures first.
  //
  // minZoom MATTERS HERE. A policy can match forty resources, and fitting a
  // column that tall to the viewport shrinks every card until the labels are
  // grey smears, which defeats the point of opening the branch at all. The
  // floor keeps the cards readable and lets a long column overflow instead;
  // readable-and-pannable beats complete-and-illegible.
  const count = rfNodes.length
  useEffect(() => {
    const t = setTimeout(
      () => fitView({ duration: 450, padding: 0.18, minZoom: 0.62, maxZoom: 1 }),
      60
    )
    return () => clearTimeout(t)
  }, [count, fitView])

  const levelCounts = useMemo(() => {
    const c = [0, 0, 0, 0]
    for (const n of nodes) c[n.level] = (c[n.level] || 0) + 1
    return c
  }, [nodes])

  const handleNodeClick = useCallback(
    (_e, node) => {
      onSelect(node.id)
      const model = nodes.find((n) => n.id === node.id)
      if (model && !model.isLeaf) onToggle(node.id)
    },
    [nodes, onSelect, onToggle]
  )

  return (
    <>
      <LevelRail counts={levelCounts} />
      <ReactFlow
        nodes={rfNodes}
        edges={rfEdges}
        nodeTypes={nodeTypes}
        onNodeClick={handleNodeClick}
        onPaneClick={() => onSelect(null)}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable
        proOptions={{ hideAttribution: true }}
        minZoom={0.25}
        maxZoom={1.6}
        defaultEdgeOptions={{ type: 'smoothstep' }}
        fitView
        fitViewOptions={{ padding: 0.18, minZoom: 0.62, maxZoom: 1 }}
      >
        <Background variant={BackgroundVariant.Dots} gap={22} size={1} className="opacity-60" />
        {/* NO MINIMAP, deliberately. A minimap earns its place when the scene
            is bigger than the viewport, and progressive disclosure means this
            one never is: the canvas holds an account, its grants, and one
            opened branch, which is a dozen or two cards. An overview of a
            scene that already fits is decoration, and it was rendering as an
            empty grey rectangle in the corner. */}
        <Controls
          showInteractive={false}
          position="bottom-right"
          className="!rounded-lg !border !border-line-soft !bg-surface !shadow-card"
        />
      </ReactFlow>
      <Legend />
    </>
  )
}

// ── Page ───────────────────────────────────────────────────────────────────

export default function IdentityGraphPage() {
  const [params, setParams] = useSearchParams()
  const userId = params.get('user') || ''

  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState(new Set())
  const [selectedId, setSelectedId] = useState(null)
  const [panelOpen, setPanelOpen] = useState(true)
  const [full, setFull] = useState(false)
  const shellRef = useRef(null)

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })
  const users = usersQuery.data?.users || []

  const graphQuery = useQuery({
    queryKey: ['admin', 'identity', userId, 'graph'],
    queryFn: ({ signal }) => getMemberGraph(userId, signal),
    enabled: !!userId,
  })

  const tree = useMemo(() => buildTree(graphQuery.data), [graphQuery.data])

  // Open the account's own row on arrival, so the canvas never lands on a
  // single card with nothing to look at.
  useEffect(() => {
    if (tree) {
      setExpanded(new Set([tree.id]))
      setSelectedId(null)
    }
  }, [tree])

  const toggle = useCallback((id) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        // Collapsing a branch closes everything under it too, otherwise
        // reopening later restores a shape the reader never chose.
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }, [])

  const selectUser = (id) => {
    const next = new URLSearchParams(params)
    if (id) next.set('user', id)
    else next.delete('user')
    setParams(next, { replace: true })
  }

  const selected = useMemo(() => {
    if (!selectedId || !tree) return null
    const found = visibleNodes(tree, expanded).find((n) => n.id === selectedId)
    return found || null
  }, [selectedId, tree, expanded])

  const resetView = () => {
    if (tree) setExpanded(new Set([tree.id]))
    setSelectedId(null)
  }

  const expandAll = () => {
    if (!tree) return
    // Deliberately bounded: opening every level of a hundred-node account is
    // the hairball this page exists to avoid. Two levels is the most that
    // stays readable, and the reader can go deeper by hand from there.
    const next = new Set([tree.id])
    for (const g of tree.children || []) next.add(g.id)
    setExpanded(next)
  }

  const err = graphQuery.isError ? normalizeApiError(graphQuery.error) : null

  return (
    <Stack gap="lg">
      <PageTitle
        title="Identity graph"
        description="How one account is assembled, and everything it can reach. Open one branch at a time: each card reports what sits underneath it."
      />

      {/* Toolbar. Account picker plus the canvas controls, in one row, because
          they act on the same thing. */}
      <div className="flex flex-wrap items-center gap-2">
        <label className="relative flex min-w-[15rem] flex-1 items-center sm:max-w-sm">
          <Search
            className="pointer-events-none absolute left-3 h-4 w-4 text-tertiary"
            strokeWidth={1.8}
          />
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search an account"
            aria-label="Search accounts"
            className="h-9 w-full rounded-lg border border-line-strong bg-surface pl-9 pr-3 text-sm text-primary transition-colors placeholder:text-tertiary hover:border-primary/40 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
          />
        </label>

        <select
          value={userId}
          onChange={(e) => selectUser(e.target.value)}
          aria-label="Account to graph"
          className="h-9 min-w-[13rem] cursor-pointer rounded-lg border border-line-strong bg-surface pl-2.5 pr-8 text-sm text-primary transition-colors hover:border-primary/40 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
        >
          <option value="">Choose an account…</option>
          {users.map((u) => (
            <option key={u.user_id} value={u.user_id}>
              {u.username}
            </option>
          ))}
        </select>

        <span className="ml-auto flex flex-wrap items-center gap-2">
          <Button size="sm" variant="secondary" onClick={expandAll} disabled={!tree}>
            Expand grants
          </Button>
          <Button size="sm" variant="ghost" icon={RotateCcw} onClick={resetView} disabled={!tree}>
            Reset
          </Button>
          <Button
            size="sm"
            variant="ghost"
            icon={full ? Minimize2 : Maximize2}
            onClick={() => setFull((v) => !v)}
            disabled={!tree}
          >
            {full ? 'Exit full view' : 'Full view'}
          </Button>
        </span>
      </div>

      <div
        ref={shellRef}
        className={clsx(
          'relative overflow-hidden rounded-2xl border border-line bg-app',
          // Full view takes the viewport below the navbar rather than opening a
          // modal: the graph is the page, so it grows in place.
          full ? 'fixed inset-x-3 bottom-3 top-[4.75rem] z-40 shadow-overlay' : 'h-[calc(100vh-17rem)] min-h-[30rem]'
        )}
      >
        {!userId ? (
          <div className="flex h-full items-center justify-center p-6">
            <EmptyState
              icon={UserRound}
              title="Choose an account"
              description="Pick an account above to see how it is assembled: its user type, the roles and policies attached to it, and the resources and credentials those actually reach."
            />
          </div>
        ) : graphQuery.isLoading ? (
          <div className="flex h-full items-center justify-center gap-3 text-sm text-secondary">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-line-strong border-t-accent" />
            Building the identity graph
          </div>
        ) : err ? (
          <div className="flex h-full items-center justify-center p-6">
            {err.status === 403 ? (
              <DeniedState description={err.message} />
            ) : err.code === 'network_error' ? (
              <OfflineState onRetry={() => graphQuery.refetch()} retrying={graphQuery.isFetching} />
            ) : (
              <ErrorState
                description={apiErrorMessage(graphQuery.error)}
                onRetry={() => graphQuery.refetch()}
                retrying={graphQuery.isFetching}
              />
            )}
          </div>
        ) : !tree ? (
          <div className="flex h-full items-center justify-center p-6">
            <EmptyState
              icon={Layers}
              title="Nothing to graph"
              description="This account holds no roles or policies, so there is no structure to draw."
            />
          </div>
        ) : (
          <div className="flex h-full">
            <div className="relative min-w-0 flex-1">
              <ReactFlowProvider>
                <Canvas
                  tree={tree}
                  expanded={expanded}
                  onToggle={toggle}
                  selectedId={selectedId}
                  onSelect={setSelectedId}
                />
              </ReactFlowProvider>
            </div>
            {panelOpen && (
              <div className="hidden w-[21rem] flex-none lg:block">
                <DetailPanel
                  graph={graphQuery.data}
                  tree={tree}
                  selected={selected}
                  onClose={() => setPanelOpen(false)}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </Stack>
  )
}
