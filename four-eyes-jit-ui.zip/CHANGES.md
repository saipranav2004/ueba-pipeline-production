# Four-Eyes JIT Approval — UI changes

Frontend only. No backend file is touched: the four-eyes backend described in
`PAM_Four_Eyes_API_Doc.md` is a different service, so this is the console
catching up to it.

Copy `src/` over your project's `src/` — every path below is already in the
right place.

## What the API changed

A STANDARD JIT request is no longer settled by one approval:

| Who | Result |
|---|---|
| Admin A | `PARTIALLY_APPROVED` — **no grant** |
| Admin A again | `409 duplicate approver` |
| Admin B (different) | `APPROVED` + grant |
| Root, at any point | `APPROVED` + grant |
| Anyone denies | `DENIED` — one denial is enough |

Break-glass (`WAITING`) has no approvers and is kept separate throughout.

## Files

### New

| File | What it is |
|---|---|
| `src/lib/fourEyes.js` | Every four-eyes judgement in one place: read the trail, compute progress, decide whether Approve may be pressed and why not, tell the two approve-response shapes apart, and name the 403/409 refusals. Pure functions — no React, no network. |
| `src/components/jit/ApprovalTrail.jsx` | `ApprovalProgress` (the 2-slot "1 of 2" pill), `ApprovalTrail` (named decision trail with rank, reason, time, and the empty slot still waiting), `ApproverStack` (compact avatars for a queue row). |

### Changed

| File | Change |
|---|---|
| `src/config/constants.js` | `PARTIALLY_APPROVED` added to `JIT_STATUS`, `JIT_STATUS_LABELS` ("Awaiting second approver") and `JIT_STATUS_BADGE` (blue — deliberately not green). New `JIT_OPEN_STATUSES` / `JIT_TERMINAL_STATUSES` with `isOpenJitStatus` / `isTerminalJitStatus`, and `APPROVER_RANK` (100 root / 80 admin) with `approverRankLabel`. |
| `src/api/admin.js` | Documents the two approve-response shapes, the 403/409 rules, that `GET /admin/jit-requests/:id` is the only source of `approvals`, and that `pending_approvals` is not the sum of the two new stat fields. |
| `src/api/jit.js` | Notes that self-service payloads now carry `PARTIALLY_APPROVED` as an OPEN state, and that cancel is allowed while half-approved. |
| `src/pages/admin/AdminJitPage.jsx` | The real work. `PARTIALLY_APPROVED` counts as open (stays in the queue, keeps polling); decision cards show progress + who already approved; Approve is disabled with the reason in words for self-approval and duplicate approver; the button reads "Approve", "Give second approval" or "Approve (final)" for root; the confirm dialog says which of the two things the click will do; the approve toast distinguishes "approval recorded" from "grant issued"; 409 refreshes instead of retrying; a "Needs 2nd approval" facet; org-wide `awaiting_first → awaiting_second` counts from `GET /admin/stats`; the drawer renders the full approvals trail. |
| `src/pages/admin/AdminOverviewPage.jsx` | Fourth KPI tile "Needs 2nd approval"; the queue card lists half-approved requests first (closest to done); same button/label/dialog/error handling as above. |
| `src/pages/DashboardPage.jsx` | Admin masthead caption splits the queue (`N new · N need a 2nd`); the approval queue merges `PENDING` + `PARTIALLY_APPROVED`; approve honours both response shapes and both refusals. User dashboard counts and lists half-approved requests as still in flight. |
| `src/pages/jit/JitPage.jsx` | `PARTIALLY_APPROVED` is cancellable and in-flight; its own rail colour and icon. |
| `src/pages/jit/JitRequestDetailPage.jsx` | New banner ("One approval in — waiting for a second"), a four-eyes stage in the lifecycle that counts instead of ticking over on the first decision, polling on the new state, "Finalised by" instead of "Decided by", and an "Approvals required" fact. |
| `src/components/jit/CreateJitRequestModal.jsx` | Says two administrators must approve *before* the form is submitted, and surfaces the server's own `next` sentence in the success toast. |
| `src/components/common/NotificationsMenu.jsx` | Separate bell item for requests needing a second approval. |

## Deliberate limits

- **Nothing here decides quorum.** The server owns it. Every client-side guard
  is a prediction of a refusal; a wrong prediction costs a greyed-out button,
  never a wrongly issued grant.
- **The trail is admin-only.** The requester's own detail endpoint returns no
  `approvals`, so their page counts from `status` and never names approvers.
- **Trail hydration is bounded** to the partially-approved rows on the visible
  page (max 12), because the trail costs one request each.

## Verification

- `npm run lint` — clean apart from the 4 pre-existing issues in `nav.js`,
  `useMfaStatus.js` and `validators.js`.
- `npm run build` — succeeds.
- 35 assertions over `src/lib/fourEyes.js` (progress inference with and without
  a trail, root-as-quorum, self/duplicate/unknown blocking, both approve
  response shapes, and the 403/409/string-body error paths) — all passing.
