# PAM bug fixes

Five reported issues. Each entry says what was wrong, where, and how it was
verified. Paths are relative to the repo roots (`backend_upd/`, `frontend_upd/`).

Apply by copying these files over the originals — no other files change.

---

## 1. Enrolled account still told to "Set up MFA"  (Mallesh)

`frontend_upd/src/lib/mfaStatus.js`, `frontend_upd/src/lib/mfaPolicy.js`

**Status: hardened, not a reproduced defect.** Against the payload
`AuthHandler.Me` actually builds (`mfa_enabled: true`), the banner already
clears correctly — I could not reproduce the report on this code. What I did
find is that enrolment was read under exactly one name (`mfa_enabled`/
`mfaEnabled`) while every neighbouring field in the same reader deliberately
accepts several spellings. Any build reporting it as `mfa_enrolled`, or as a
nested `mfa: { enrolled: true }` block, makes the banner permanent.

`readEnrolmentFlag()` now reads every spelling, plus a nested posture block,
and is shared by both readers. Flat fields still win over nested ones, so it
can never contradict a server that answers plainly, and absence still means
*unknown* rather than *not enrolled*.

If the banner is still showing on your deployment after this, capture
`GET /api/v1/auth/me` for that account — the answer will be in `mfa_enabled`.

## 2. Re-used recovery code shows the error, then redirects to /login  (Mallesh)

`frontend_upd/src/lib/http.js`

Re-submitting a spent backup code makes the server answer **401**
(`AuthHandler.MFARecover` → "Invalid or already-used backup code"). That is a
rejected *code* during sign-in, not a dead session — but
`/api/v1/auth/mfa/recover` was missing from the interceptor's
`AUTH_ENTRY_POINTS`, so the 401 was read as an expired session: `logout()`
then a redirect to `/login`, mid-challenge. The user saw the correct error
flash and got thrown back to sign-in instead of being allowed to type another
code.

Added the route to the allow-list, beside `/mfa/setup/verify`, which was on it
for precisely this reason.

## 3. Admin revokes a session, user's dashboard still shows it Active  (Mallesh)

`frontend_upd/src/pages/DashboardPage.jsx`

The Sessions *page* polls every 15s. The **dashboard** card did not: no
`refetchInterval`, and the client-wide defaults are `refetchOnWindowFocus:
false` with a 10s `staleTime`. Nothing refetched it, so a killed session stayed
on screen as Active until a manual reload. Being told you still hold privileged
access you no longer hold is the one direction this console must not be wrong
in.

Both the self-service sessions card and the admin counters (`active_sessions`,
`pending_requests`) now poll on the shared `SESSIONS_POLL_MS` cadence and
refetch on window focus.

## 4. Resources search misses matches on a 2-letter query  (Rohit)

`frontend_upd/src/hooks/useTableState.js`

`setFilter` reset the page; `setQuery` did not. So the page index survived the
query change and you were shown *that slice* of the new matches. Long queries
hid it — they narrow the set to one page, and the existing clamp
(`page > totalPages`) pulled you back to page 1, so search "worked". A short,
broad query still spans several pages, the clamp has nothing to correct, and
you land mid-list: on page 3 of `bi` you get `billing-shard-48` onward and
never see `billing-primary`. Same control, different behaviour depending on how
much you typed — exactly as reported.

`setQuery` now resets to page 1, fixing every table built on this hook.

## 5. Audit & Compliance search by Username or ID is unreliable  (Rohit)

`backend_upd/internal/api/handlers/admin_handler.go`,
`backend_upd/internal/services/audit_service.go`

Two faults, both server-side:

1. **The filter never reached the database.** The console sends the box as
   `actor`; `ListAudit` read `c.Query("actor_user_id")`. The parameter was
   dropped, the server returned an unfiltered page, and the browser filtered
   whatever happened to be on it — so the search worked when the person's
   events were on the page in hand and returned nothing when they were not.
2. **`ActorUserID` could not have served that box anyway.** It is an exact
   `user_id =` match, so a username matched nothing and a partial id matched
   nothing.

Added `AuditFilter.Actor`: a case-insensitive substring match against
**username OR user_id**, so both halves of the field's own label work.
`ActorUserID` keeps its exact-match meaning for links built by other screens.
`username` and `user_id` were also added to the free-text `q` search, which
previously matched every column except the two naming the person.

Written as `LOWER(col) LIKE ?` rather than `ILIKE` so the package's sqlite
tests can exercise it — a filter the suite cannot reach is how this one came to
be wrong. Semantics on Postgres are identical.

**New test:** `backend_upd/internal/services/audit_actor_filter_test.go` —
username, prefix, case-insensitivity, full and partial id, dotted usernames,
combination with other filters, and that `ActorUserID` stays exact.

---

## Verification

- `go build ./...`, `go vet ./...` — clean
- `go test ./...` — 12/12 packages pass, including the 3 new tests (11 cases)
- `npx eslint src --max-warnings 0` — clean
- `npm run build` — clean
- Browser tests driving the built console in Chromium against a mocked API:
  **15/15 pass after the fix; 8 of the same checks fail against the original
  build**, including "landed on /login" for #2 and `billing-shard-48` for #4.
  Bug #1's canonical-payload case passes on both, which is why it is described
  above as hardening rather than a reproduced fix.

Line endings were preserved per file (this tree is mixed CRLF/LF) and both Go
files are gofmt-clean.
