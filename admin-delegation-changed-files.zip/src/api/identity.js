import { http } from '../lib/http'

// Identity Management — the Admin Center's user lifecycle screens
// (/api/v1/pam/admin/identity/*). Admin/root only. Brand new surface: PAM
// now owns user accounts end to end (no external IAM service), so this is
// full user CRUD + lifecycle + RBAC role assignment + PBAC direct policy
// attachment — see identity_handler.go.

export async function listUsers(q, signal) {
  const { data } = await http.get('/api/v1/pam/admin/identity/users', {
    params: q ? { q } : undefined,
    signal,
  })
  return data.data // { users, count }
}

export async function getUser(id, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/identity/users/${id}`, { signal })
  return data.data // { user, access: { roles, policies } }
}

export async function createUser(payload) {
  const { data } = await http.post('/api/v1/pam/admin/identity/users', payload)
  return data.data.user
}

export async function updateUser(id, payload) {
  const { data } = await http.patch(`/api/v1/pam/admin/identity/users/${id}`, payload)
  return data.data.user
}

export async function setUserStatus(id, status) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${id}/status`, { status })
  return data.data
}

export async function deleteUser(id) {
  const { data } = await http.delete(`/api/v1/pam/admin/identity/users/${id}`)
  return data.data
}

export async function resetUserPassword(id, newPassword) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${id}/reset-password`, {
    new_password: newPassword,
  })
  return data.data
}

export async function assignRole(userId, roleName) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${userId}/roles`, {
    role_name: roleName,
  })
  return data.data
}

export async function removeRole(userId, roleName) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${userId}/roles/${encodeURIComponent(roleName)}`
  )
  return data.data
}

// ---------------------------------------------------------------------------
// Admin delegation (subadmin) — /users/:id/delegate-admin, /users/:id/delegation
// ---------------------------------------------------------------------------
// Administrative access is NOT handed out with assignRole() any more. It is
// delegated: root grants the `subadmin` role with a recorded reason, an
// optional expiry and an optional resource scope, and can take it back. Only
// a root caller succeeds on grant/revoke — everyone else gets 403 — which is
// why every caller of these three is gated on authStore.isRoot() as well.
//
// The read (delegation status) is open to admin and root alike, so an ordinary
// admin can still SEE that an account holds delegated admin without being able
// to change it.

// Grant. `payload` is { reason (required), expires_at?, scope_resource_ids?,
// replace_admin? }. Returns { delegated_role, replaced_admin, ... }.
export async function delegateAdmin(userId, payload) {
  const { data } = await http.post(
    `/api/v1/pam/admin/identity/users/${userId}/delegate-admin`,
    payload
  )
  return data.data ?? null
}

// Revoke. The reason travels in the BODY of a DELETE, which axios only sends
// when it is passed as `config.data` — `http.delete(url, payload)` would send
// the payload as the request config and drop the reason silently.
export async function revokeAdminDelegation(userId, payload) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${userId}/delegate-admin`,
    { data: payload }
  )
  return data.data ?? null
}

export async function getDelegationStatus(userId, signal) {
  const { data } = await http.get(
    `/api/v1/pam/admin/identity/users/${userId}/delegation`,
    { signal }
  )
  return normalizeDelegation(data?.data)
}

// The delegation payload is read by three different bits of UI, so it is
// flattened to one shape HERE rather than each of them guessing.
//
// Two things this defends against, both cheap to absorb and expensive to hit
// in production: the object may arrive either bare (`data: { status, ... }`)
// or wrapped (`data: { delegation: { ... } }`), and an account that has never
// been delegated may come back as `data: null` rather than
// `{ status: "none" }`. React Query also treats an `undefined` return from a
// queryFn as an error, so this never returns undefined.
export function normalizeDelegation(payload) {
  const raw = payload && typeof payload === 'object' ? payload : {}
  const inner = raw.delegation && typeof raw.delegation === 'object' ? raw.delegation : {}
  const first = (...values) => values.find((v) => v !== undefined && v !== null) ?? null

  const status = String(first(raw.status, inner.status, 'none')).toLowerCase()
  const scope = first(raw.scope_resource_ids, inner.scope_resource_ids)

  return {
    status,
    isActive: status === 'active',
    reason: first(raw.reason, inner.reason),
    delegated_role: first(raw.delegated_role, inner.delegated_role, 'subadmin'),
    granted_at: first(raw.granted_at, inner.granted_at, raw.created_at, inner.created_at),
    granted_by: first(
      raw.granted_by_username, inner.granted_by_username,
      raw.granted_by, inner.granted_by
    ),
    expires_at: first(raw.expires_at, inner.expires_at),
    revoked_at: first(raw.revoked_at, inner.revoked_at),
    revoked_by: first(
      raw.revoked_by_username, inner.revoked_by_username,
      raw.revoked_by, inner.revoked_by
    ),
    revoke_reason: first(raw.revoke_reason, inner.revoke_reason),
    scope_resource_ids: Array.isArray(scope) ? scope : [],
    // Kept so a field this normaliser does not know about is still reachable
    // rather than silently dropped.
    raw,
  }
}

export async function attachPolicy(userId, policyId) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${userId}/policies`, {
    policy_id: policyId,
  })
  return data.data
}

export async function detachPolicy(userId, policyId) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${userId}/policies/${policyId}`
  )
  return data.data
}
