// Central place for every enum/status the backend uses, kept in sync with
// internal/models/*.go. Importing these instead of hardcoding string
// literals in components is what prevents "PENDING" vs "Pending" vs
// "pending" typo bugs from silently breaking a status filter or badge color.
//
// Every *_BADGE map below carries BOTH a light-mode and a dark-mode class
// fragment (`dark:` variants) — see src/index.css / themeStore.js for how
// the `dark` class gets toggled on <html>. A badge built from only the old
// dark-console shades (e.g. `text-emerald-300` with no light equivalent)
// reads as barely-visible pale text on a white card in light mode, so this
// is deliberate, not decorative.

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://das-iam.bharatgen.dev'

// ---------------------------------------------------------------------------
// Roles (RBAC) — the system roles that ship with every install
// ---------------------------------------------------------------------------
// `subadmin` is the DELEGATED ADMIN role introduced by the Admin Delegation
// API. It is not handed out with the generic role-assignment endpoint: it is
// minted and revoked exclusively through
// POST/DELETE /admin/identity/users/:id/delegate-admin, and only a caller
// holding `root` gets anything but a 403 from those two routes. It is listed
// here because it IS a built-in — the Roles screen must mark it as a system
// role (undeletable) and CreateRoleModal must refuse the name.
export const SYSTEM_ROLES = ['root', 'admin', 'subadmin', 'user']

// The one place the delegated-admin role name is written down.
export const DELEGATED_ADMIN_ROLE = 'subadmin'

export function isAdminRole(roles) {
  return Array.isArray(roles) && (roles.includes('admin') || roles.includes('root'))
}
export function isRootRole(roles) {
  return Array.isArray(roles) && roles.includes('root')
}
export function hasDelegatedAdminRole(roles) {
  return Array.isArray(roles) && roles.some(isDelegatedAdminRoleName)
}

export const ROLE_BADGE = {
  root: 'bg-purple-100 text-purple-700 ring-purple-600/20 dark:bg-purple-500/15 dark:text-purple-300 dark:ring-purple-500/30',
  admin: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  // Delegated admin reads as adjacent to admin but deliberately not the same
  // colour — the whole point of the badge is that you can tell at a glance
  // whether someone holds admin outright or holds it on loan from root.
  subadmin: 'bg-teal-100 text-teal-700 ring-teal-600/20 dark:bg-teal-500/15 dark:text-teal-300 dark:ring-teal-500/30',
  user: 'bg-slate-100 text-slate-700 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
}

// What a role is CALLED on screen. Only `subadmin` differs from its wire
// name — "subadmin" is the value the API sends and expects, "Delegated admin"
// is what it means to the person reading the badge. Anything not listed here
// renders exactly as the API named it.
export const ROLE_LABELS = {
  subadmin: 'Delegated admin',
}

export function roleLabel(name) {
  const key = String(name || '').toLowerCase()
  return ROLE_LABELS[key] || name
}

// A custom role has no reserved colour — it gets the neutral chip, the same
// one the Roles table uses for its "Custom" marker. Centralised here because
// four screens render role chips and three of them used to inline this
// fallback string (and one of them forgot to, so a custom role rendered as
// an unstyled chip).
export const ROLE_BADGE_FALLBACK = 'bg-surface-800 text-ink-300 ring-surface-700'

export function roleBadgeClass(name) {
  return ROLE_BADGE[String(name || '').toLowerCase()] || ROLE_BADGE_FALLBACK
}

// ---------------------------------------------------------------------------
// Role identity helpers
// ---------------------------------------------------------------------------
// THE BUG THESE EXIST TO PREVENT. Several screens treated SYSTEM_ROLES as if
// it were "the roles that exist", when it is only "the roles that ship with
// every install". Anything that offers a role for ASSIGNMENT must read the
// live catalogue (GET /admin/rbac/roles via api/rbac.js listRoles) — otherwise
// a custom role can be created, listed and edited but never actually given to
// anybody. SYSTEM_ROLES stays for what it genuinely answers: is this one of
// the built-ins that must not be deleted or re-created.

// Roles that carry administrative privilege — what the "Privileged" marker on
// the identity screens means. `subadmin` is included because a delegated admin
// operates the Admin Center for as long as the delegation is live; leaving it
// out would have shown a delegated administrator as an ordinary account.
export const PRIVILEGED_ROLES = ['root', 'admin', 'subadmin']

// Roles that ONLY a root user may hand out. This is the client-side half of
// the server's privilege rule: `admin` and `root` are root-only assignments,
// and `subadmin` is not assignable through the generic roles endpoint at all
// (see canAssignRoleName below).
export const ROOT_ONLY_ROLES = ['root', 'admin', 'subadmin']

export function isSystemRoleName(name) {
  return SYSTEM_ROLES.includes(String(name || '').toLowerCase())
}

export function isPrivilegedRoleName(name) {
  return PRIVILEGED_ROLES.includes(String(name || '').toLowerCase())
}

export function isRootOnlyRoleName(name) {
  return ROOT_ONLY_ROLES.includes(String(name || '').toLowerCase())
}

export function isDelegatedAdminRoleName(name) {
  return String(name || '').toLowerCase() === DELEGATED_ADMIN_ROLE
}

// ---------------------------------------------------------------------------
// Who may assign what (client-side gate)
// ---------------------------------------------------------------------------
// THE RULE, in one function, so every surface that offers a role — the Access
// tab's dropdown, Create user's initial role — agrees with the others and with
// the server:
//
//   * `subadmin` is NEVER assignable here. Delegated admin is granted and
//     revoked through /delegate-admin, which records a reason, an optional
//     expiry and an optional resource scope. Minting it as a bare role would
//     produce a delegation with no audit story behind it.
//   * `admin` and `root` are assignable by a root user only. A non-root admin
//     asking for them gets 403 from the server; hiding them client-side means
//     the console never offers an action it knows will be refused.
//   * everything else — `user` and every custom role — is unchanged.
//
// `viewerIsRoot` is the answer to authStore.isRoot(), passed in rather than
// read here so this file stays free of store imports.
export function canAssignRoleName(name, viewerIsRoot) {
  if (isDelegatedAdminRoleName(name)) return false
  if (isRootOnlyRoleName(name)) return !!viewerIsRoot
  return true
}

// Why a role is not on offer — shown as helper text next to the control so an
// absent option is never mistaken for a broken one.
export function roleAssignmentBlockedReason(name, viewerIsRoot) {
  if (isDelegatedAdminRoleName(name)) {
    return 'Delegated admin is granted through the Delegate admin action, not as a plain role.'
  }
  if (isRootOnlyRoleName(name) && !viewerIsRoot) {
    return 'Only root users can grant administrative access.'
  }
  return null
}

// Accepts either a Role object from the RBAC API (which carries `is_system`)
// or a bare name string (which does not, so the built-in list decides).
export function isSystemRole(role) {
  if (role && typeof role === 'object') return role.is_system === true || isSystemRoleName(role.name)
  return isSystemRoleName(role)
}

// What each built-in role means, in one line. Custom roles carry their own
// description from the API; these three do not always, because they are
// seeded by the backend.
export const SYSTEM_ROLE_NOTES = {
  root: 'Full control, including other administrators',
  admin: 'Runs the Admin Center',
  subadmin: 'Delegated admin — operational Admin Center access, granted by root and revocable at any time',
  user: 'Self-service access only',
}

// One line describing a role, wherever it is shown. `role` may be the full
// object or undefined (when all we hold is the name off an access record).
export function roleBlurb(role, name) {
  const description = role && typeof role === 'object' ? role.description : null
  if (description && description.trim()) return description.trim()
  return (
    SYSTEM_ROLE_NOTES[String(name ?? (role && role.name) ?? role ?? '').toLowerCase()] ||
    'Custom role — grants exactly the policies attached to it'
  )
}

// Normalises whatever the API hands back (Role objects, or bare name strings
// on some access payloads) into a de-duplicated list of Role-shaped objects,
// ordered the way an administrator reads them: the built-ins first, in their
// privilege order, then custom roles alphabetically.
export function normalizeRoleList(roles) {
  const byName = new Map()
  for (const entry of Array.isArray(roles) ? roles : []) {
    const name = typeof entry === 'string' ? entry : entry?.name
    if (!name) continue
    const key = String(name).toLowerCase()
    if (byName.has(key)) continue
    byName.set(key, typeof entry === 'string' ? { name } : entry)
  }
  return [...byName.values()].sort((a, b) => {
    const ai = SYSTEM_ROLES.indexOf(String(a.name).toLowerCase())
    const bi = SYSTEM_ROLES.indexOf(String(b.name).toLowerCase())
    if (ai !== -1 || bi !== -1) {
      if (ai === -1) return 1
      if (bi === -1) return -1
      return ai - bi
    }
    return String(a.name).localeCompare(String(b.name))
  })
}

// ---------------------------------------------------------------------------
// Admin delegation (subadmin)
// ---------------------------------------------------------------------------
// GET /admin/identity/users/:id/delegation reports one of four states. They
// are lowercase on the wire; everything here keys off the lowercased value so
// a backend that ever shouts "ACTIVE" still lands on the right chip.
export const DELEGATION_STATUS = {
  NONE: 'none',
  ACTIVE: 'active',
  EXPIRED: 'expired',
  REVOKED: 'revoked',
}

export const DELEGATION_STATUS_LABELS = {
  none: 'Not delegated',
  active: 'Delegated admin',
  expired: 'Delegation expired',
  revoked: 'Delegation revoked',
}

export const DELEGATION_STATUS_BADGE = {
  none: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  active: 'bg-teal-100 text-teal-700 ring-teal-600/20 dark:bg-teal-500/15 dark:text-teal-300 dark:ring-teal-500/30',
  expired: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  revoked: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
}

export function delegationStatusLabel(status) {
  const key = String(status || DELEGATION_STATUS.NONE).toLowerCase()
  return DELEGATION_STATUS_LABELS[key] || key
}

export function delegationStatusBadgeClass(status) {
  const key = String(status || DELEGATION_STATUS.NONE).toLowerCase()
  return DELEGATION_STATUS_BADGE[key] || DELEGATION_STATUS_BADGE.none
}

// ---------------------------------------------------------------------------
// Identity Management (users)
// ---------------------------------------------------------------------------
export const USER_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DISABLED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  LOCKED: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  DELETED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// PBAC (policies)
// ---------------------------------------------------------------------------
export const POLICY_EFFECTS = [
  { value: 'allow', label: 'Allow' },
  { value: 'deny', label: 'Deny' },
]

export const POLICY_EFFECT_BADGE = {
  allow: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  deny: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// Common action vocabulary (pam:<module>:<Verb>) shown as suggestions when
// building a policy — not exhaustive/enforced client-side, the server is
// the source of truth for what's a valid action string.
export const COMMON_ACTIONS = [
  'pam:resource:List', 'pam:resource:Read', 'pam:resource:Connect',
  'pam:session:Start', 'pam:session:End',
  'pam:vault:List', 'pam:vault:Read', 'pam:vault:Create', 'pam:vault:Store',
  'pam:vault:Reveal', 'pam:vault:Rotate',
  'pam:jit:Request', 'pam:jit:Cancel', 'pam:breakglass:Use',
  'pam:audit:Read', 'pam:report:Generate',
  '*',
]

// ---------------------------------------------------------------------------
// Resources
// ---------------------------------------------------------------------------

export const RESOURCE_TYPES = [
  { value: 'postgresql', label: 'PostgreSQL' },
  { value: 'mongodb', label: 'MongoDB' },
  { value: 'redis', label: 'Redis' },
  { value: 'clickhouse', label: 'ClickHouse' },
  { value: 'minio', label: 'MinIO' },
  { value: 'qdrant', label: 'Qdrant' },
  { value: 'metabase', label: 'Metabase' },
  { value: 'langfuse', label: 'Langfuse' },
  { value: 'web', label: 'Web Application' },
  { value: 'oracle', label: 'Oracle' },
]

export const CONNECT_MODES = [
  { value: 'web_terminal', label: 'Web terminal (host/port shown, connect with your own client)' },
  { value: 'embed_redirect', label: 'Embed / redirect to console URL' },
]

// ---------------------------------------------------------------------------
// Vault
// ---------------------------------------------------------------------------

export const CREDENTIAL_TYPES = [
  { value: 'password', label: 'Password' },
  { value: 'ssh_key', label: 'SSH Private Key' },
  { value: 'x509_cert', label: 'X.509 Certificate' },
  { value: 'api_key', label: 'API Key / Bearer Token' },
  { value: 'token', label: 'OAuth / OIDC Token' },
  { value: 'connection_string', label: 'Connection String' },
  { value: 'kerberos_keytab', label: 'Kerberos Keytab' },
]

// ---------------------------------------------------------------------------
// JIT
// ---------------------------------------------------------------------------

export const JIT_STATUS = {
  PENDING: 'PENDING',
  WAITING: 'WAITING',
  APPROVED: 'APPROVED',
  DENIED: 'DENIED',
  CANCELLED: 'CANCELLED',
  EXPIRED: 'EXPIRED',
}

export const JIT_STATUS_LABELS = {
  PENDING: 'Pending approval',
  WAITING: 'Cooling-off period',
  APPROVED: 'Approved',
  DENIED: 'Denied',
  CANCELLED: 'Cancelled',
  EXPIRED: 'Expired',
}

export const JIT_STATUS_BADGE = {
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  WAITING: 'bg-orange-100 text-orange-700 ring-orange-600/20 dark:bg-orange-500/15 dark:text-orange-300 dark:ring-orange-500/30',
  APPROVED: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DENIED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  CANCELLED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  EXPIRED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
}

export const JIT_TYPE = {
  STANDARD: 'STANDARD',
  BREAKGLASS: 'BREAKGLASS',
}

export const GRANT_STATUS = {
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  REVOKED: 'REVOKED',
}

export const GRANT_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  EXPIRED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  REVOKED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// Server-configured defaults (internal/config/config.go's viper defaults).
// These are HINTS ONLY for the UI (placeholders, helper text) — the server
// is always the source of truth and its own validation error is what's
// shown when a submission actually violates the real configured policy,
// which may differ per deployment.
export const JIT_DEFAULTS = {
  DEFAULT_DURATION_MIN: 60,
  MAX_DURATION_MIN: 480,
  MIN_REASON_LENGTH: 10,
  BREAKGLASS_WAIT_MIN: 15,
  BREAKGLASS_MAX_DURATION_MIN: 60,
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

export const SESSION_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  COMPLETED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  KILLED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  FAILED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Audit
// ---------------------------------------------------------------------------

export const AUDIT_CATEGORIES = [
  'AUTH', 'AUTHZ', 'VAULT', 'SESSION', 'RESOURCE',
  'BREAK_GLASS', 'JIT', 'ADMIN', 'REPORT', 'OTHER',
]

export const AUDIT_OUTCOMES = ['SUCCESS', 'DENIED', 'ERROR', 'PENDING', 'FAILURE']

export const AUDIT_OUTCOME_BADGE = {
  SUCCESS: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DENIED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  ERROR: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  FAILURE: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

export const AUDIT_SEVERITY_BADGE = {
  INFO: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  WARN: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  CRITICAL: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

export const AUDIT_SORT_OPTIONS = [
  { value: 'occurred_at_desc', label: 'Newest first' },
  { value: 'occurred_at_asc', label: 'Oldest first' },
  { value: 'sequence_desc', label: 'Sequence (desc)' },
]

// ---------------------------------------------------------------------------
// Recording
// ---------------------------------------------------------------------------

export const RECORDING_STATUS_BADGE = {
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  RECORDING: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  COMPLETED: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  FAILED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------

export const DEFAULT_PAGE_SIZE = 20
export const SESSIONS_POLL_MS = 15000 // no push channel on the backend yet
export const SEARCH_DEBOUNCE_MS = 350
