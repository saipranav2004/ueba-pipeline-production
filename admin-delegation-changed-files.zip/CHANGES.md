# Admin Delegation — changed files

Drop these into the project root (they keep their `src/...` paths).

```
src/config/constants.js                      (edited)
src/api/identity.js                          (edited)
src/pages/admin/IdentityDetailPage.jsx       (edited)
src/components/admin/CreateUserModal.jsx     (edited)
src/components/admin/DelegateAdminModal.jsx  (NEW)
```

Verified with `npm run lint` (clean on these five files) and `npm run build` (passes).

---

## 1. `src/config/constants.js`

* `SYSTEM_ROLES` is now `['root', 'admin', 'subadmin', 'user']` — `subadmin` is a
  built-in, so the Roles screen marks it "System" and refuses to delete it, and
  CreateRoleModal refuses the name. Both come for free from this constant.
* `DELEGATED_ADMIN_ROLE = 'subadmin'`, `ROLE_LABELS`, `roleLabel()` — `subadmin`
  renders as **Delegated admin** wherever a label is shown; the wire value is
  untouched.
* `ROLE_BADGE.subadmin` — teal chip, deliberately not admin-blue. Picked up
  automatically by `UserMenu`, `SettingsPage`, `RolesPage` and `IdentityListPage`,
  which all read `ROLE_BADGE` / `roleBadgeClass`. No edits needed there.
* `PRIVILEGED_ROLES` now includes `subadmin`, so a delegated admin is counted and
  marked as privileged on the identity list and detail pages.
* `ROOT_ONLY_ROLES`, `isRootOnlyRoleName()`, `isDelegatedAdminRoleName()`.
* **`canAssignRoleName(name, viewerIsRoot)`** — the single client-side gate:
  * `subadmin` → never assignable as a plain role (delegation flow only);
  * `admin` / `root` → root only;
  * everything else (`user` + all custom roles) → unchanged.
* `DELEGATION_STATUS`, `delegationStatusLabel()`, `delegationStatusBadgeClass()`
  for `none | active | expired | revoked`.

## 2. `src/api/identity.js`

* `delegateAdmin(userId, payload)` → `POST …/users/:id/delegate-admin`
* `revokeAdminDelegation(userId, payload)` → `DELETE …/users/:id/delegate-admin`
  (the reason goes in `config.data`, which is the only way axios sends a DELETE
  body — `http.delete(url, payload)` would silently drop it)
* `getDelegationStatus(userId, signal)` → `GET …/users/:id/delegation`
* `normalizeDelegation()` — flattens the response whether it arrives bare
  (`data: { status, … }`) or wrapped (`data: { delegation: { … } }`), copes with
  `data: null`, lowercases `status`, and always returns an object (React Query
  treats an `undefined` queryFn return as an error).

## 3. `src/pages/admin/IdentityDetailPage.jsx`

* Reads `useAuthStore(s => s.isRoot())`.
* New `delegationQuery` on key `['admin','users',id,'delegation']` — the page's
  existing `invalidate()` already covers the `['admin','users']` prefix, so one
  call refreshes both the user record and the delegation after every action.
* **Access tab → new "Administrative access" panel**: status badge, delegated
  role, granted by/at, expiry (absolute + relative), reason, scope, and
  revoked-by/at/reason for a revoked delegation. Read-only for a non-root admin
  (the GET is admin-or-root), with **Delegate admin** / **Revoke delegation**
  buttons for root only.
* **Role dropdown is gated** by `canAssignRoleName`: a non-root admin no longer
  sees `admin`, `root` or `subadmin`; root sees `admin`/`root` but not
  `subadmin`. Filtered-out roles are explained in place instead of silently
  vanishing, and the "all roles assigned" message no longer lies when the
  remainder is merely restricted.
* **Both role mutations re-check the rule** before calling the API, so a stale
  or tampered control cannot fire a request the server would 403.
* The `subadmin` row's action is **Revoke** (opens the reason-required confirm),
  not the generic role Remove; `admin`/`root` rows are non-removable by non-root.
* Revoke goes through `revokeAdminDelegation(id, { reason })` with an explicit
  "Only root users can revoke admin delegation." message on 403.
* Badges use `roleLabel()`; a live delegation whose role list hasn't caught up
  still shows a "Delegated admin" chip plus an expiry tag. Overview gains an
  **Admin delegation** row.

## 4. `src/components/admin/DelegateAdminModal.jsx` (new)

Root-only dialog: required **Reason**, optional **Expires at**
(`datetime-local`, must be future, converted to RFC3339), optional
**scope resource IDs**, and **Replace the existing admin role** — pre-ticked when
the target already holds `admin`. Optional fields are omitted from the payload
when blank. Errors surface inline as well as in a toast:
403 → "Only root users can delegate admin access.", 409 → the server message
plus the hint to tick *Replace the existing admin role*. On success the toast
distinguishes a plain grant from a `replaced_admin: true` one, and the parent
refreshes the user + delegation queries.

## 5. `src/components/admin/CreateUserModal.jsx`

Initial-role options run through the same `canAssignRoleName` gate, so a non-root
admin cannot create an account that starts out administrative. The check also
runs **before** `createUser()`, so a blocked role can never leave a half-created
account behind.

---

### Note on `authStore.isAdmin()` — deliberately unchanged

The spec states the Admin Center gate is "a JWT with **admin** or **root**
(middleware)", so `isAdmin()` still tests exactly those two. If the backend also
admits `subadmin` through that middleware, add `subadmin` to that one check in
`src/store/authStore.js` — nothing else needs to change.
